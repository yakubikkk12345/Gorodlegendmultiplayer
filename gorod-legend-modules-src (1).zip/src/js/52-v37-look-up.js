/* ===================== v37: ВЗГЛЯД ВВЕРХ БЕЗ ПРИЦЕЛА, ПРОХОЖИЕ ОБХОДЯТ ПОРТ ===================== */
{
  // прохожие не ходят по кварталу порта (там вода и склад контрабанды)
  const up0 = updatePeds;
  updatePeds = function (dt) {
    const pb = BIZ_BY.port && BIZ_BY.port.blk;
    if (pb) for (const p of peds) {
      if (p.bi === pb[0] && p.bj === pb[1] && !p.drv && !p.fixed) {
        p.bi = clamp(pb[0] + (Math.random() < 0.5 ? -1 : 1), 0, GRID - 1); p.s = Math.random() * 240;
        if (p.x !== undefined) { p.x = bc(p.bi); }
      }
    }
    return up0(dt);
  };
}

function gunBoxes(gm, gun) {
  const a = gun === PGUN && S && S.guns && S.guns.att ? S.guns.att[gun.id] : null;
  if (!a || !(a.scope || a.supp || a.mag || a.laser)) return gm.b;
  const key = (a.scope ? 's' : '') + (a.supp ? 'p' : '') + (a.mag ? 'm' : '') + (a.laser ? 'l' : '');
  const C = gm._ac || (gm._ac = {});
  if (C[key]) return C[key];
  const b0 = gm.b[0], b1 = gm.b[1] || b0, out = gm.b.slice(), top = b0[1] + b0[4] / 2, m = gm.m;
  if (a.mag) out.push([b1[0], b1[1] - b1[4] / 2 - 0.05, b1[2], b1[3] * 1.15, 0.13, b1[5] * 1.15, 0.12, 0.12, 0.13]);
  if (a.scope) {
    out.push([0, top + 0.03, b0[2], 0.03, 0.035, 0.1, 0.1, 0.1, 0.12]);
    out.push([0, top + 0.075, b0[2] + 0.02, 0.05, 0.05, 0.26, 0.09, 0.09, 0.1]);
    out.push([0, top + 0.075, b0[2] + 0.155, 0.04, 0.04, 0.02, 0.2, 0.6, 0.95]);
  }
  if (a.supp) out.push([0, b0[1], m + 0.1, 0.075, 0.075, 0.24, 0.13, 0.13, 0.15]);
  if (a.laser) { out.push([0, b0[1] - 0.06, m - 0.1, 0.03, 0.03, 0.09, 0.1, 0.1, 0.1]); out.push([0, b0[1] - 0.06, m - 0.05, 0.02, 0.02, 0.02, 1, 0.1, 0.1]); }
  return (C[key] = out);
}
function meleeArm(gun, k) {
  if (gun.blk) return -2.3;
  if (gun.fin > 0) { const u = 1 - gun.fin / 0.45; return -2.95 + 2.75 * u * u; }
  const t = gun.swT;
  if (t > 0) {
    if (t < 0.3) { const u = t / 0.3; return -0.9 - 1.85 * (1 - (1 - u) * (1 - u)); }
    const u = Math.min(1, (t - 0.3) / 0.7); return -2.75 + 1.85 * (u * u * (3 - 2 * u));
  }
  return -0.9 - 1.9 * k * k;
}
