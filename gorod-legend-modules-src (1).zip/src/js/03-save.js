/* ===================== 3. СОХРАНЕНИЕ ===================== */
(function shiftMissions() {
  const sh = a => [a[0] + OFS, a[1] + OFS];
  for (const m of MISSIONS) {
    m.start = sh(m.start);
    if (m.pts) m.pts = m.pts.map(sh);
    if (m.route) m.route = m.route.map(sh);
    if (m.stages) m.stages.forEach(st => { st.p = sh(st.p); });
  }
})();
const slotKey = n => n === 1 ? 'gorod_legend_save_v1' : 'gorod_legend_save_v1_s' + n;
let SLOT = 1; try { SLOT = Math.min(3, Math.max(1, +localStorage.getItem('gorod_legend_slot') || 1)); } catch (e) { }
function defaultSettings() {
  const t = isTouch();
  return { sfx: 0.8, music: 0.35, quality: t ? 'med' : 'high', sens: 1, touch: 'auto', traffic: 1, fps: false, radio: 0, shake: true, mph: false, hints: true, lefty: false };
}
function defaultSave() {
  return { v: 1, started: false, money: 1000, sel: 'hatch', cars: { hatch: { u: { eng: 0, acc: 0, tir: 0, nit: 0 }, color: '#e63946' } }, missions: {}, stats: { dist: 0, time: 0, missions: 0, drift: 0, robs: 0 }, pos: null, guns: defaultGuns(), look: 0, biz: {}, props: {}, rob: {}, story: { ch: 0 }, bizT: Date.now(), armor: 0, ach: {}, flags: {}, set: defaultSettings() };
}
function defaultGuns() { return { own: { fist: true }, ammo: {}, sel: 'fist' }; }
/* Вставьте сюда код сохранения (кнопка «Скопировать код» в меню слотов), чтобы сохранение жило прямо в файле игры.
   Используется, если слот пуст (слот 1). */
const EMBEDDED_SAVE = '';
function decodeSaveCode(c) {
  c = String(c || '').trim(); if (!c) return null;
  try {
    if (c[0] !== '{') c = decodeURIComponent(escape(atob(c.replace(/\s+/g, ''))));
    const s = JSON.parse(c);
    return (s && s.v === 1 && typeof s.money === 'number' && s.cars) ? s : null;
  } catch (e) { return null; }
}
function encodeSaveCode(o) { return btoa(unescape(encodeURIComponent(JSON.stringify(o)))); }
function loadSave() {
  const d = defaultSave();
  try {
    let raw = localStorage.getItem(slotKey(SLOT));
    if (!raw && SLOT === 1 && EMBEDDED_SAVE) { const es = decodeSaveCode(EMBEDDED_SAVE); if (es) raw = JSON.stringify(es); }
    if (raw) {
      const s = JSON.parse(raw);
      if (s && s.v === 1) {
        const r = Object.assign(d, s);
        if (!r.guns || !r.guns.own || !r.guns.ammo) r.guns = defaultGuns();
        r.guns.own.fist = true; if (!r.guns.sel || !r.guns.own[r.guns.sel]) r.guns.sel = 'fist';
        r.set = Object.assign(defaultSettings(), s.set || {});
        r.biz = r.biz || {}; r.props = r.props || {}; r.rob = r.rob || {}; r.story = Object.assign({ ch: 0 }, r.story || {}); r.armor = r.armor || 0; r.ach = r.ach || {}; r.flags = r.flags || {};
        const offs = Math.min(1200, Math.max(0, (Date.now() - (r.bizT || Date.now())) / 1000));
        for (const k in r.biz) { const b = BIZ_BY[k]; if (b && r.biz[k] && r.biz[k].own) bizAdd(r.biz[k], b, offs); }
        r.stats = Object.assign({ dist: 0, time: 0, missions: 0, drift: 0, robs: 0 }, s.stats || {});
        if (!r.cars || !r.cars[r.sel]) { r.cars = r.cars || {}; r.cars.hatch = r.cars.hatch || { u: { eng: 0, acc: 0, tir: 0, nit: 0 }, color: '#e63946' }; r.sel = Object.keys(r.cars)[0]; }
        return r;
      }
    }
  } catch (e) { console.warn('save load', e); }
  return d;
}
let S = loadSave();
function persist() { S.bizT = Date.now(); try { localStorage.setItem(slotKey(SLOT), JSON.stringify(S)); } catch (e) { } cloudSave(); }

