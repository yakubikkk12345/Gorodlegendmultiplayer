/* ===================== ОРУЖИЕ И ПЕРЕСТРЕЛКИ ===================== */
const WEAPONS = [
  { id: 'fist', name: 'Кулаки', icon: '👊', price: 0, dmg: 14, pellets: 1, rate: 0.42, mag: 1, reload: 0, spread: 0, range: 2.6, ammoPack: 0, packPrice: 0, minAmmo: 0, melee: true },
  { id: 'bat', name: 'Бейсбольная бита', icon: '🏏', price: 300, dmg: 34, pellets: 1, rate: 0.55, mag: 1, reload: 0, spread: 0, range: 3.0, ammoPack: 0, packPrice: 0, minAmmo: 0, melee: true },
  { id: 'knife', name: 'Нож', icon: '🔪', price: 600, dmg: 24, pellets: 1, rate: 0.28, mag: 1, reload: 0, spread: 0, range: 2.4, ammoPack: 0, packPrice: 0, minAmmo: 0, melee: true },
  { id: 'pistol', name: 'Пистолет', icon: '🔫', price: 400, dmg: 20, pellets: 1, rate: 0.3, mag: 12, reload: 1.0, spread: 0.025, range: 70, ammoPack: 24, packPrice: 120, minAmmo: 60 },
  { id: 'smg', name: 'Пистолет-пулемёт', icon: '🔫', price: 3500, dmg: 11, pellets: 1, rate: 0.085, mag: 30, reload: 1.4, spread: 0.07, range: 55, ammoPack: 60, packPrice: 240, minAmmo: 120 },
  { id: 'shotgun', name: 'Дробовик', icon: '💥', price: 6000, dmg: 9, pellets: 7, rate: 0.8, mag: 6, reload: 1.8, spread: 0.15, range: 30, ammoPack: 12, packPrice: 200, minAmmo: 24 },
  { id: 'rifle', name: 'Винтовка', icon: '🎯', price: 9500, dmg: 40, pellets: 1, rate: 0.45, mag: 10, reload: 1.7, spread: 0.008, range: 160, ammoPack: 20, packPrice: 300, minAmmo: 40 }
];
const WBY = {}; WEAPONS.forEach(w => WBY[w.id] = w);
const WS = { mag: {}, cd: 0, reload: 0, reloadId: null, dryT: 0, zoom: 0, zoomLvl: 0, zf: 1.05, resume: 0, resumeT: 0, zoomHold: false, zoomTog: false, mf: false };
const TRACERS = [];
const HITFX = { flash: 0, lastHit: -99 };
const HIT_LOOK = { pants: [1, 1, 1], shirt: [1, 1, 1], skin: [1, 1, 1], hair: [1, 1, 1], dark: [1, 1, 1] };
const GANG_LOOKS = [
  { pants: hexRGB('#1b1b22'), shirt: hexRGB('#7a1f1f'), skin: hexRGB('#d9a07d'), hair: hexRGB('#111111'), dark: [0.05, 0.05, 0.05] },
  { pants: hexRGB('#2a2a2a'), shirt: hexRGB('#222222'), skin: hexRGB('#8d5a3b'), hair: hexRGB('#0b0b0b'), dark: [0.05, 0.05, 0.05] },
  { pants: hexRGB('#222831'), shirt: hexRGB('#5b2a86'), skin: hexRGB('#f1c7a5'), hair: hexRGB('#5a3825'), dark: [0.05, 0.05, 0.05] },
  { pants: hexRGB('#3a2f1f'), shirt: hexRGB('#b45f06'), skin: hexRGB('#c68e6b'), hair: hexRGB('#222222'), dark: [0.05, 0.05, 0.05] }
];
const BOSS_LOOK = { pants: hexRGB('#111111'), shirt: hexRGB('#d4af37'), skin: hexRGB('#e0ac86'), hair: hexRGB('#ffffff'), dark: [0.02, 0.02, 0.02] };
function wDef() { return WBY[S.guns.sel] || WBY.pistol; }
function wMag(id) {
  if (WS.mag[id] === undefined) { const d = WBY[id], n = Math.min(d.mag, S.guns.ammo[id] || 0); WS.mag[id] = n; S.guns.ammo[id] = (S.guns.ammo[id] || 0) - n; }
  return WS.mag[id];
}
function topUpAmmo() {
  for (const w of WEAPONS) if (S.guns.own[w.id] && !w.melee) {
    const tot = wMag(w.id) + (S.guns.ammo[w.id] || 0);
    if (tot < w.minAmmo) S.guns.ammo[w.id] = (S.guns.ammo[w.id] || 0) + (w.minAmmo - tot);
  }
}
function selectWeapon(id) {
  if (!S.guns.own[id] || S.guns.sel === id) return;
  S.guns.sel = id; WS.reload = 0; WS.cd = 0.25; SFX.click(); toast(WBY[id].icon + ' ' + WBY[id].name); persist();
}
function selectWeaponIdx(i) { const o = WEAPONS.filter(w => S.guns.own[w.id]); if (o[i]) selectWeapon(o[i].id); }
function cycleWeapon() {
  const o = WEAPONS.filter(w => S.guns.own[w.id]); if (o.length < 2) return;
  const i = o.findIndex(w => w.id === S.guns.sel); selectWeapon(o[(i + 1) % o.length].id);
}
function reloadWeapon() {
  if (G.mode !== 'play' || G.paused || G.inHome || WS.reload > 0) return;
  const d = wDef(); if (d.melee || wMag(d.id) >= d.mag) return;
  if (!(S.guns.ammo[d.id] > 0)) { toast('Нет патронов. Загляните в оружейный магазин'); SFX.err(); return; }
  WS.reload = d.reload; WS.reloadId = d.id; SFX.reload();
}
function finishReload() {
  const d = WBY[WS.reloadId]; if (!d) return;
  const take = Math.min(d.mag - wMag(d.id), S.guns.ammo[d.id] || 0);
  WS.mag[d.id] += take; S.guns.ammo[d.id] -= take;
}
function rayBox(x, z, dx, dz, b, max) {
  let t0 = 0, t1 = max;
  if (Math.abs(dx) < 1e-9) { if (x < b.x0 || x > b.x1) return -1; }
  else { let a = (b.x0 - x) / dx, c = (b.x1 - x) / dx; if (a > c) { const q = a; a = c; c = q; } t0 = Math.max(t0, a); t1 = Math.min(t1, c); if (t0 > t1) return -1; }
  if (Math.abs(dz) < 1e-9) { if (z < b.z0 || z > b.z1) return -1; }
  else { let a = (b.z0 - z) / dz, c = (b.z1 - z) / dz; if (a > c) { const q = a; a = c; c = q; } t0 = Math.max(t0, a); t1 = Math.min(t1, c); if (t0 > t1) return -1; }
  return t0;
}
function rayCircle(x, z, dx, dz, cx, cz, r) {
  const ox = cx - x, oz = cz - z, pr = ox * dx + oz * dz;
  if (pr < 0) return -1;
  const perp = ox * ox + oz * oz - pr * pr;
  if (perp > r * r) return -1;
  return pr - Math.sqrt(r * r - perp);
}
function traceRay(x, z, a, range, withEnemies, vr) {
  const dx = Math.sin(a), dz = Math.cos(a);
  let best = range, kind = null, obj = null;
  const yAt = t => vr ? vr.ey - Math.tan(vr.pd) * ((x + dx * t - vr.ex) * vr.dx + (z + dz * t - vr.ez) * vr.dz) : 0;
  const okY = (t, lo, hi) => { if (!vr) return true; const y = yAt(t); return y >= lo && y <= hi; };
  if (vr && Math.tan(vr.pd) > 0.002) {
    const tg = vr.ey / Math.tan(vr.pd) - ((x - vr.ex) * vr.dx + (z - vr.ez) * vr.dz);
    if (tg > 0.3 && tg < best) { best = tg; kind = 'ground'; }
  }
  for (let k = 0; k < boxes.length; k++) {
    const b = boxes[k]; if (b.h < 1.4) continue;
    const t = rayBox(x, z, dx, dz, b, best); if (t >= 0 && t < best && (!vr || yAt(t) <= b.h)) { best = t; kind = 'wall'; }
  }
  for (let k = 0; k < circles.length; k++) {
    const c = circles[k]; if (Math.abs(c.x - x) > range + 2 || Math.abs(c.z - z) > range + 2) continue;
    const t = rayCircle(x, z, dx, dz, c.x, c.z, c.r * 0.6); if (t >= 0 && t < best && okY(t, -1, 3.2)) { best = t; kind = 'wall'; }
  }
  for (const c of cars) {
    if (c === P.car || Math.abs(c.x - x) > best + 6 || Math.abs(c.z - z) > best + 6) continue;
    for (let j = -1; j <= 1; j++) {
      const t = rayCircle(x, z, dx, dz, c.x + Math.sin(c.h) * j * c.L * 0.3, c.z + Math.cos(c.h) * j * c.L * 0.3, 0.95);
      if (t >= 0 && t < best && okY(t, -0.3, 1.8)) { best = t; kind = 'car'; }
    }
  }
  if (withEnemies && M && M.enemies) for (const e of M.enemies) {
    const t = rayCircle(x, z, dx, dz, e.x, e.z, 0.6 * e.sc); if (t >= 0 && t < best && okY(t, -0.2, 2.1 * e.sc)) { best = t; kind = 'enemy'; obj = e; }
  }
  if (withEnemies) {
    for (const e of WANT.units) { const t = rayCircle(x, z, dx, dz, e.x, e.z, 0.6); if (t >= 0 && t < best && okY(t, -0.2, 2.1)) { best = t; kind = 'cop'; obj = e; } }
    for (const e of GANG.units) { const t = rayCircle(x, z, dx, dz, e.x, e.z, 0.6); if (t >= 0 && t < best && okY(t, -0.2, 2.1)) { best = t; kind = 'gang'; obj = e; } }
    if (MP.state === 'on' && MP.pvp) for (const p of MP.peers.values()) {
      if (!mpVisible(p) || !p.pv || !mpFoe(p)) continue;
      const t = rayCircle(x, z, dx, dz, p.x, p.z, p.car ? 1.1 : 0.55); if (t >= 0 && t < best && okY(t, p.y - 0.2, p.y + (p.car ? 2.2 : 2.0))) { best = t; kind = 'rp'; obj = p; }
    }
    for (const p of peds) {
      if (p.dead || Math.abs(p.x - x) > best + 1 || Math.abs(p.z - z) > best + 1) continue;
      const t = rayCircle(x, z, dx, dz, p.x, p.z, 0.5); if (t >= 0 && t < best && okY(t, -0.2, 2.0)) { best = t; kind = 'ped'; obj = p; }
    }
  }
  return { t: best, kind, obj, x: x + dx * best, z: z + dz * best };
}
function sparks(x, y, z, c) {
  for (let i = 0; i < 4; i++) emit(x, y, z, rand(-3, 3), rand(0.5, 3), rand(-3, 3), 0.3, 0.12, 0.02, c[0], c[1], c[2], 1, true);
}
function pickTarget(range) {
  let best = null, bd = range;
  const test = e => {
    const d = Math.hypot(e.x - P.x, e.z - P.z);
    if (d < bd) { const r = traceRay(P.x, P.z, Math.atan2(e.x - P.x, e.z - P.z), d, false); if (r.kind === null) { bd = d; best = e; } }
  };
  if (M && M.enemies) M.enemies.forEach(test);
  WANT.units.forEach(test);
  GANG.units.forEach(test);
  if (MP.state === 'on' && MP.pvp) for (const p of MP.peers.values()) if (mpVisible(p) && p.pv && mpFoe(p)) test(p);
  if (!best && !(M && M.enemies)) {
    bd = 22;
    for (const p of peds) {
      if (p.dead) continue;
      const dx = p.x - P.x, dz = p.z - P.z;
      if (Math.abs(wrapA(Math.atan2(dx, dz) - P.h)) < 0.5) test(p);
    }
  }
  return best;
}
function punch(d) {
  if (WS.cd > 0) return;
  WS.cd = d.rate;
  let best = null, kind = '', bd = d.range;
  const test = (e, k) => { const dd = Math.hypot(e.x - P.x, e.z - P.z); if (dd < bd) { bd = dd; best = e; kind = k; } };
  if (M && M.enemies) M.enemies.forEach(e => test(e, 'enemy'));
  WANT.units.forEach(e => test(e, 'cop'));
  GANG.units.forEach(e => test(e, 'gang'));
  for (const p of peds) if (!p.dead) test(p, 'ped');
  if (MP.state === 'on' && MP.pvp) for (const p of MP.peers.values()) if (mpVisible(p) && p.pv && !p.car && mpFoe(p)) test(p, 'rp');
  PGUN.kick = 1; P.aimT = 0.3; SFX.punch();
  if (!best) return;
  P.h = Math.atan2(best.x - P.x, best.z - P.z);
  for (const p of peds) if (!p.dead && Math.abs(p.x - P.x) < 25 && Math.abs(p.z - P.z) < 25) p.panic = 5;
  if (kind === 'rp') { mpHit(best, d.dmg); return; }
  const dm = cbMelee(best, kind, d.dmg);
  if (kind === 'enemy') { damageEnemy(best, dm); best.x += Math.sin(P.h) * 0.5; best.z += Math.cos(P.h) * 0.5; }
  else if (kind === 'cop') { damageCop(best, dm); best.x += Math.sin(P.h) * 0.5; best.z += Math.cos(P.h) * 0.5; }
  else if (kind === 'gang') { damageGang(best, dm); best.x += Math.sin(P.h) * 0.5; best.z += Math.cos(P.h) * 0.5; }
  else damagePed(best, dm);
}
function playerShoot() {
  if (P.car && P.car.def.tank) { tankFire(P.car); return; }
  if (wDef().melee) {
    if (P.car) { if (G.time - WS.dryT > 1.5) { WS.dryT = G.time; toast('🔫 Для стрельбы из машины возьмите огнестрельное оружие (🔁)'); SFX.err(); } return; }
    punch(wDef()); return;
  }
  const d = wDef();
  if (WS.reload > 0 || WS.cd > 0) return;
  if (wMag(d.id) <= 0) {
    if (S.guns.ammo[d.id] > 0) reloadWeapon();
    else if (G.time - WS.dryT > 0.9) { WS.dryT = G.time; SFX.err(); toast('Нет патронов!'); }
    return;
  }
  WS.mag[d.id]--; WS.cd = d.rate;
  let ang = P.h;
  const man = aimManual(); let vr = null;
  if (man) { ang = CAM.yaw; vr = aimRay(); }
  else { const tg = pickTarget(d.range); if (tg && !(CB.inp && Math.hypot(CB.inp.x, CB.inp.y) > 0.3)) ang = Math.atan2(tg.x - P.x, tg.z - P.z); }
  P.h = ang; P.aimT = 0.35; PGUN.kick = 1;
  for (const p of peds) if (!p.dead && Math.abs(p.x - P.x) < (WS.supp ? 9 : 35) && Math.abs(p.z - P.z) < (WS.supp ? 9 : 35)) p.panic = 6;
  const lat = man ? 0.5 * (1 - WS.zoom * WS.zoom * (3 - 2 * WS.zoom)) : 0;
  const mx = P.x + Math.sin(ang) * 0.8 + Math.cos(ang) * lat, mz = P.z + Math.cos(ang) * 0.8 - Math.sin(ang) * lat;
  const sf = (d.id === 'rifle' || d.id === 'sniper') ? (WS.zoom > 0.6 ? 0.05 : 3) : (1 - 0.7 * WS.zoom);
  for (let k = 0; k < d.pellets; k++) {
    const a = ang + (Math.random() - 0.5) * 2 * d.spread * sf;
    let vk = null; if (vr) vk = Object.assign({}, vr, { pd: vr.pd + (Math.random() - 0.5) * 2 * d.spread * sf });
    const r = traceRay(mx, mz, a, d.range, true, vk);
    if (vk) { const y2 = Math.max(0.05, vk.ey - Math.tan(vk.pd) * ((r.x - vk.ex) * vk.dx + (r.z - vk.ez) * vk.dz)); TRACERS.push({ x1: mx, y1: P.y + 1.35, z1: mz, x2: r.x, y2, z2: r.z, t: 0.07, max: 0.07, c: [1, 0.9, 0.5] }); }
    else TRACERS.push({ x1: mx, z1: mz, x2: r.x, z2: r.z, t: 0.07, max: 0.07, c: [1, 0.9, 0.5] });
    if (r.kind === 'enemy') damageEnemy(r.obj, d.dmg);
    else if (r.kind === 'cop') damageCop(r.obj, d.dmg);
    else if (r.kind === 'gang') damageGang(r.obj, d.dmg);
    else if (r.kind === 'ped') damagePed(r.obj, d.dmg);
    else if (r.kind === 'rp') mpHit(r.obj, d.dmg);
    else if (r.kind === 'ground') sparks(r.x, 0.15, r.z, [0.8, 0.7, 0.5]);
    else if (r.kind) sparks(r.x, vk ? Math.max(0.2, vk.ey - Math.tan(vk.pd) * ((r.x - vk.ex) * vk.dx + (r.z - vk.ez) * vk.dz)) : 1.3, r.z, r.kind === 'car' ? [1, 0.7, 0.3] : [1, 0.85, 0.5]);
  }
  emit(mx, 1.35, mz, 0, 0, 0, 0.07, 0.55, 0.15, 1, 0.8, 0.35, 1, true);
  SFX.gun(d.id, WS.supp ? 0.3 : 1);
  if ((d.id === 'rifle' || d.id === 'sniper' || (S.guns.att && S.guns.att[d.id] && S.guns.att[d.id].scope)) && WS.zoomLvl > 0) { WS.resume = WS.zoomLvl; WS.zoomLvl = 0; WS.resumeT = 0.55; }
  CAM.shake = Math.max(CAM.shake, d.id === 'shotgun' ? 0.25 : 0.08);
  if (wMag(d.id) <= 0 && S.guns.ammo[d.id] > 0) reloadWeapon();
}
function damageEnemy(e, dmg) {
  e.hp -= dmg; e.hit = 0.1; SFX.hit();
  sparks(e.x, 1.2, e.z, [1, 0.4, 0.3]);
  if (e.hp <= 0) killEnemy(e);
}
function killEnemy(e) {
  const i = M.enemies.indexOf(e); if (i >= 0) M.enemies.splice(i, 1);
  M.kills++;
  addMoney(e.boss ? 500 : 60);
  P.hp = Math.min(100, P.hp + 8);
  for (let k = 0; k < 7; k++) emit(e.x, 1 + Math.random(), e.z, rand(-2, 2), rand(0.5, 2.5), rand(-2, 2), 0.7, 0.3, 1.2, 0.85, 0.85, 0.9, 0.6, false);
  toast(e.boss ? '👑 Главарь повержен!' : '💨 Бандит обезврежен');
}
function hurtPlayer(n, src) {
  if (P.hp <= 0) return;
  if (CB.inv > 0) return;
  n *= cbDefense();
  if (P.car && P.car.def.armorK) n *= P.car.def.armorK;
  P.lastSrc = src || 'gang';
  if (S.armor > 0) { const ab = Math.min(S.armor, n * 0.75); S.armor -= ab; n -= ab; }
  P.hp -= n; HITFX.flash = 1; HITFX.lastHit = G.time; SFX.hurt(); CAM.shake = Math.max(CAM.shake, 0.25);
  if (P.hp <= 0 && src === 'pvp') mpDied();
}
function spawnEnemy(ax, az, hp, boss) {
  const ang = Math.random() * TAU, r = rand(16, 28);
  const e = { x: ax + Math.cos(ang) * r, z: az + Math.sin(ang) * r, h: 0, hp, maxhp: hp, cd: rand(1.2, 2.6), ph: Math.random() * 6, amp: 0,
    sp: rand(3.4, 4.6) * (boss ? 0.9 : 1), pref: rand(10, 20), sdir: Math.random() < 0.5 ? 1 : -1, sflip: rand(1, 3), hit: 0, boss: !!boss, sc: boss ? 1.3 : 1,
    look: boss ? BOSS_LOOK : pick(GANG_LOOKS), gun: { id: boss ? 'shotgun' : pick(['pistol', 'smg', 'smg', 'rifle']), aim: 0, kick: 0, reload: 0 }, dmg: boss ? 11 : rand(5, 8), rate: boss ? 0.8 : rand(1.1, 1.7) };
  const p = { x: e.x, z: e.z }; pushCircle(p, 0.6); e.x = p.x; e.z = p.z;
  M.enemies.push(e);
  return e;
}
function arenaCenter(def) { return { x: bc(def.arena[0]), z: bc(def.arena[1]) }; }
function spawnWave() {
  const def = M.def, n = M.waves[M.wave], ac = arenaCenter(def), last = M.wave === M.waves.length - 1;
  for (let k = 0; k < n; k++) {
    if (def.boss && last && k === 0) spawnEnemy(ac.x, ac.z, 220, true); else spawnEnemy(ac.x, ac.z, def.hp || 40, false);
  }
}
function initShootout(def) {
  M.enemies = []; M.kills = 0; M.waves = def.waves || [def.count]; M.wave = 0; M.waveWait = 0;
  spawnWave();
}
function updateEnemies(dt) { updateEnemyList(M.enemies, dt); }
function updateEnemyList(list, dt) {
  const px = P.x, pz = P.z;
  for (const e of list) {
    if (e.hit > 0) e.hit -= dt;
    e.gun.kick = Math.max(0, e.gun.kick - dt * 7); e.gun.aim += ((e.gun.t > 0 ? 1 : 0) - e.gun.aim) * Math.min(1, dt * 10); if (e.gun.t > 0) e.gun.t -= dt;
    const dx = px - e.x, dz = pz - e.z, d = Math.hypot(dx, dz) || 1, tgt = Math.atan2(dx, dz);
    e.h += wrapA(tgt - e.h) * Math.min(1, dt * 8);
    let vx, vz;
    if (d > e.pref + 3) { vx = dx / d * e.sp; vz = dz / d * e.sp; }
    else if (d < e.pref - 4) { vx = -dx / d * e.sp * 0.6; vz = -dz / d * e.sp * 0.6; }
    else { e.sflip -= dt; if (e.sflip <= 0) { e.sdir = -e.sdir; e.sflip = rand(1, 3); } vx = -dz / d * e.sp * 0.55 * e.sdir; vz = dx / d * e.sp * 0.55 * e.sdir; }
    e.x += vx * dt; e.z += vz * dt;
    pushCircle(e, 0.55);
    const sp = Math.hypot(vx, vz); e.ph += sp * dt * 1.2; e.amp = clamp(sp / 4, 0, 1);
    e.cd -= dt;
    if (e.cd <= 0 && d < 48) {
      const r = traceRay(e.x, e.z, tgt, d, false);
      if (r.kind === null) {
        e.cd = e.rate; e.gun.kick = 1; e.gun.t = 0.7;
        const hitP = Math.random() < clamp(0.62 - d * 0.012, 0.15, 0.6);
        const a = hitP ? tgt : tgt + (Math.random() < 0.5 ? -1 : 1) * rand(0.06, 0.2);
        const mx = e.x + Math.sin(tgt) * 0.8, mz = e.z + Math.cos(tgt) * 0.8, len = hitP ? d - 0.8 : d + 5;
        TRACERS.push({ x1: mx, z1: mz, x2: e.x + Math.sin(a) * len, z2: e.z + Math.cos(a) * len, t: 0.09, max: 0.09, c: [1, 0.45, 0.2] });
        emit(mx, 1.35, mz, 0, 0, 0, 0.07, 0.5, 0.12, 1, 0.5, 0.2, 1, true);
        SFX.gun('enemy', clamp(1 - d / 60, 0.12, 0.6));
        if (hitP) hurtPlayer(e.dmg, e.cop ? 'cop' : 'gang');
      } else e.cd = 0.35;
    }
  }
  for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) {
    const a = list[i], b = list[j], dx = b.x - a.x, dz = b.z - a.z, d = Math.hypot(dx, dz);
    if (d < 1.1 && d > 0.001) { const k = (1.1 - d) / 2 / d; a.x -= dx * k; a.z -= dz * k; b.x += dx * k; b.z += dz * k; }
  }
}
function shootStep(dt) {
  updateEnemies(dt);
  if (P.hp <= 0) { endMission(false, 'Вас подстрелили!'); return; }
  if (M.enemies.length === 0) {
    if (M.wave < M.waves.length - 1) {
      M.waveWait += dt;
      if (M.waveWait > 2.2) { M.waveWait = 0; M.wave++; spawnWave(); toast('⚠ Волна ' + (M.wave + 1) + ' из ' + M.waves.length); SFX.tick(); }
    } else endMission(true);
  }
}
function updateCombat(dt, inp) {
  v25Combat(dt, inp);
  if (HITFX.flash > 0) HITFX.flash = Math.max(0, HITFX.flash - dt * 2.2);
  for (let i = TRACERS.length - 1; i >= 0; i--) { TRACERS[i].t -= dt; if (TRACERS[i].t <= 0) TRACERS.splice(i, 1); }
  if (P.aimT > 0) P.aimT -= dt;
  PGUN.kick = Math.max(0, PGUN.kick - dt * (S.guns.sel === 'shotgun' || (WBY[S.guns.sel] && WBY[S.guns.sel].melee) ? 4 : 8)); PGUN.aim += (((P.aimT > 0 || (aimManual() && !P.car)) ? 1 : 0) - PGUN.aim) * Math.min(1, dt * 12); PGUN.reload += ((WS.reload > 0 ? 1 : 0) - PGUN.reload) * Math.min(1, dt * 8);
  if (WS.cd > 0) WS.cd -= dt;
  if (TK.cd > 0) TK.cd -= dt;
  zoomTick(dt);
  if (WS.reload > 0) { WS.reload -= dt; if (WS.reload <= 0) { WS.reload = 0; finishReload(); } }
  if (P.hp < 100 && P.hp > 0 && G.time - HITFX.lastHit > (S.vit ? 3 : 5)) P.hp = Math.min(100, P.hp + (S.vit ? 10 : 5) * dt);
  if (!G.inHome && inp.fire && !(M && M.state === 'countdown')) playerShoot();
  carHitPlayer(dt);
  if (P.hp <= 0 && !M && G.mode === 'play') playerDown();
}
function drawTracers() {
  for (const t of TRACERS) {
    if (t.y1 !== undefined) {
      const ex = t.x2 - t.x1, ey = t.y2 - t.y1, ez = t.z2 - t.z1, el = Math.hypot(ex, ey, ez) || 1;
      mTRS(DM, t.x1, t.y1, t.z1, Math.atan2(ex, ez), Math.acos(clamp(ey / el, -1, 1)), 0, t.w || 0.14, el, t.w || 0.14);
      drawMesh(M_UCOL, DM, t.c[0], t.c[1], t.c[2], clamp(t.t / t.max, 0, 1) * 0.9, 2, false);
      continue;
    }
    const dx = t.x2 - t.x1, dz = t.z2 - t.z1, len = Math.hypot(dx, dz); if (len < 0.5) continue;
    mTRS(DM, (t.x1 + t.x2) / 2, 1.3, (t.z1 + t.z2) / 2, Math.atan2(dx, dz), 0, 0, 0.07, 0.07, len);
    drawMesh(M_UCOL, DM, t.c[0], t.c[1], t.c[2], clamp(t.t / t.max, 0, 1) * 0.9, 2, false);
  }
}
function drawEnemies(list) {
  const rx = Math.cos(CAM.yaw), rz = -Math.sin(CAM.yaw), fx = Math.sin(CAM.yaw), fz = Math.cos(CAM.yaw);
  for (const e of list) {
    drawHuman(e.x, terrainY(e.x, e.z), e.z, e.h, e.ph, e.amp, e.hit > 0 ? HIT_LOOK : e.look, false, e.sc, e.gun);
    const y = 2.1 * e.sc + 0.35, w = 1.2, f = clamp(e.hp / e.maxhp, 0.02, 1), off = -w * (1 - f) / 2;
    mTRS(DM, e.x, y, e.z, CAM.yaw, 0, 0, w, 0.13, 0.04); drawMesh(M_UCOL, DM, 0.08, 0.08, 0.08, 1, 1, false);
    mTRS(DM, e.x + rx * off - fx * 0.04, y + 0.015, e.z + rz * off - fz * 0.04, CAM.yaw, 0, 0, w * f, 0.09, 0.05); drawMesh(M_UCOL, DM, 1, 0.2, 0.15, 1, 1, false);
  }
}
function renderGunshop() {
  $('gunList').innerHTML = WEAPONS.filter(w => w.id !== 'fist').map(w => {
    const own = !!S.guns.own[w.id], sel = S.guns.sel === w.id, res = (S.guns.ammo[w.id] || 0) + (WS.mag[w.id] || 0);
    return '<div class="card"><div class="c-body"><b>' + w.icon + ' ' + w.name + '</b><small>Урон ' + w.dmg + (w.pellets > 1 ? '×' + w.pellets : '') + (w.melee ? ' · ближний бой' : ' · магазин ' + w.mag + ' · дальность ' + w.range + ' м') + (own ? ' · патронов: ' + res : '') + '</small></div>' +
      '<div class="gbtns">' + (own ?
        ((w.melee ? '' : '<button class="btn small" data-gammo="' + w.id + '"' + (S.money < w.packPrice ? ' disabled' : '') + '>+' + w.ammoPack + ' · ' + fmtMoney(w.packPrice) + '</button>') + (sel ? '<span class="tag">В руках</span>' : '<button class="btn small" data-gequip="' + w.id + '">Взять</button>')) :
        '<button class="btn small" data-gbuy="' + w.id + '"' + (S.money < w.price ? ' disabled' : '') + '>' + fmtMoney(w.price) + '</button>') + '</div></div>';
  }).join('') + expCards();
}
/* ---- Продавцы и диалоги ---- */
const TALK = { kind: null, say: '', opts: [] };
const NPC = {
  gun: { ico: '🧔', name: 'Борис', role: 'Продавец оружия',
    greet: ['Добро пожаловать! У меня лучшие стволы в городе.', 'Заходи, не стесняйся. Пистолеты, дробовики, винтовки — всё есть.', 'Нужны патроны? Или присмотрел что-то посерьёзнее?'],
    tips: ['Дробовик страшен вблизи, винтовка — на дальних дистанциях. Пистолет-пулемёт — золотая середина.', 'Не стреляй по полиции без нужды: розыск быстро растёт. Кулаки — для уличных стычек, ствол — для серьёзных дел.', 'Патроны лучше иметь в запасе. Перед заданием с перестрелкой зайди ко мне.', 'Двигайся, не стой на месте — по неподвижной цели попасть проще простого.'] },
  car: { ico: '🧑‍💼', name: 'Виктор', role: 'Менеджер автосалона',
    greet: ['Приветствую в нашем салоне! Лучшие машины города — только у нас.', 'Добрый день! Ищете что-то быстрое? Или надёжное?', 'Здравствуйте! Сегодня для вас особое предложение.'],
    tips: ['Для гонок берите спорткар или ралли — у них лучшее сцепление. Для дрифта хорош мускул.', 'Улучшения двигателя и нитро дают заметный прирост. Не экономьте на шинах!', 'Фургон и пикап медленные, зато надёжные. А вот гиперкар — вершина всего.', 'Скорость — это хорошо, но управляемость выигрывает гонки.'] },
  hosp: { ico: '👩‍⚕️', name: 'Доктор Анна', role: 'Врач',
    greet: ['Здравствуйте! Чем могу помочь?', 'Добро пожаловать в больницу. Как самочувствие?', 'Проходите. Лечение — $50, есть ещё витамины для быстрого восстановления.'],
    tips: ['Здоровье со временем восстанавливается само, если не получать урон около пяти секунд.', 'Витамины ускоряют восстановление навсегда — хорошая инвестиция для любителей перестрелок.', 'Не лезьте под колёса: машины сбивают и пешеходов, и вас!', 'Если вас подстрелят — очнётесь у нас, за небольшую плату.'] },
  pol: { ico: '👮', name: 'Офицер Петров', role: 'Дежурный по участку',
    greet: ['Добрый день. По какому вопросу?', 'Участок слушает. Что у вас?', 'Проходите. Если есть штрафы — оплачиваем здесь.'],
    tips: ['Одна звезда — убили человека, две — полицейского. Дальше — больше. Помните об этом.', 'От погони можно оторваться: держитесь подальше от патрулей около 30 секунд.', 'Спрятаться дома тоже работает — розыск спадёт.', 'Порядок в городе держим мы. Не создавайте нам лишней работы.'] }
};
Object.assign(NPC, {
  b_gas: { ico: '🧑‍🔧', name: 'Семён', role: 'Управляющий АЗС', greet: [''], tips: [] },
  b_wash: { ico: '👩‍🔧', name: 'Ирина', role: 'Администратор автомойки', greet: [''], tips: [] },
  b_port: { ico: '👷', name: 'Михалыч', role: 'Бригадир порта', greet: [''], tips: [] },
  b_club: { ico: '🕺', name: 'Макс', role: 'Управляющий клуба', greet: [''], tips: [] },
  boss: { ico: '🕶️', name: 'Крот', role: 'Босс города', greet: [''], tips: [] }
});
Object.assign(NPC, {
  taxi: { ico: '🧑‍✈️', name: 'Диспетчер Рита', role: 'Таксопарк', greet: [''], tips: [] },
  food: { ico: '🧑‍🍳', name: 'Повар Гена', role: 'Кафе «Вкусно»', greet: [''], tips: [] }
});
const byeOpt = () => ({ t: '👋 До свидания', fn: () => { SFX.back(); closeScreens(); } });
function bizGreet(id) {
  if (id === 'port') return portGreet();
  const b = BIZ_BY[id], r = S.biz[id];
  if (!r || !r.own) return 'Этот бизнес продаётся: «' + b.name + '». Принесёт ≈ ' + fmtMoney(b.rate) + ' в минуту. Берёте?';
  const a = Math.floor(r.acc || 0);
  return a >= 1 ? 'Хозяин, добро пожаловать! В кассе уже ' + fmtMoney(a) + '.' : 'Дела идут, выручка копится. Загляните позже.';
}
function bizOptions(id) { const o = bizOptions0(id); if (id === 'gas') { const f = fuelOpts(); for (let i = f.length - 1; i >= 0; i--) o.unshift(f[i]); } if (id === 'port') { const f = portOptions(); for (let i = f.length - 1; i >= 0; i--) o.unshift(f[i]); } return o; }
function bizOptions0(id) {
  const b = BIZ_BY[id], r = S.biz[id], o = [];
  if (!r || !r.own) {
    o.push({ t: '💰 Купить «' + b.name + '» — ' + fmtMoney(b.price), dis: S.money < b.price, fn: () => { S.money -= b.price; S.biz[id] = { own: true, lvl: 1, acc: 0 }; persist(); SFX.buy(); refreshMoney(true); say('Поздравляю, теперь это ваш бизнес! Выручка копится сама, даже пока вы заняты.'); } });
    o.push({ t: '📊 Расскажите о доходе', fn: () => say('Приносит около ' + fmtMoney(b.rate) + ' в минуту, касса вмещает ' + fmtMoney(bizCap({ lvl: 1 }, b)) + '. Бизнес можно расширить до 3 уровня.') });
  } else {
    const a = Math.floor(r.acc || 0);
    o.push({ t: a >= 1 ? '💵 Забрать выручку — ' + fmtMoney(a) : (hasOffice() ? '💼 Выручка идёт в сейф кабинета пентхауса' : '💵 Выручки пока нет'), dis: a < 1, fn: () => { const n = Math.floor(r.acc || 0); r.acc = 0; addMoney(n); persist(); SFX.cash(); say('Вот ваша выручка: ' + fmtMoney(n) + '.'); } });
    if ((r.lvl || 1) < 3) { const cost = Math.round(b.price * 0.6 * (r.lvl || 1)); o.push({ t: '⬆️ Расширить до уровня ' + ((r.lvl || 1) + 1) + ' — ' + fmtMoney(cost) + ' (+50% дохода)', dis: S.money < cost, fn: () => { S.money -= cost; r.lvl = (r.lvl || 1) + 1; persist(); SFX.buy(); refreshMoney(true); say('Расширились! Теперь доход ' + fmtMoney(Math.round(b.rate * bizMult(r))) + ' в минуту.'); } }); }
    else o.push({ t: '⭐ Максимальный уровень', dis: true, fn: () => { } });
    o.push({ t: '📊 Отчёт', fn: () => say('Уровень ' + (r.lvl || 1) + '. Доход ' + fmtMoney(Math.round(b.rate * bizMult(r))) + ' в минуту. Касса вмещает ' + fmtMoney(Math.round(bizCap(r, b))) + '.') });
  }
  o.push(byeOpt());
  return o;
}
function storyDone(c) { const r = S.missions[c.req]; return !!(r && r.done); }
function storyGreet() {
  const ch = S.story.ch;
  if (ch >= STORY.length) return epiGreet();
  const c = STORY[ch];
  return storyDone(c) ? 'Слышал, ты справился. Заходи, рассчитаемся.' : 'Глава ' + (ch + 1) + ' из ' + STORY.length + ': «' + c.t + '». ' + c.intro;
}
function storyOptions() {
  const ch = S.story.ch, o = [];
  if (ch >= STORY.length) {
    epiOptions(o);
  } else {
    const c = STORY[ch], m = MISSIONS.find(x => x.id === c.req), done = storyDone(c);
    o.push({ t: '📋 Что за задание?', fn: () => say(c.intro + ' Задание «' + m.name + '» — в меню заданий (📋).') });
    o.push({ t: done ? '✅ Сдать задание — награда ' + fmtMoney(c.reward) : '⏳ Задание «' + m.name + '» не выполнено', dis: !done, fn: () => {
      S.story.ch++; addMoney(c.reward); SFX.cash();
      let extra = '';
      if (c.final) { if (!S.cars.hyper) { S.cars.hyper = { u: { eng: 0, acc: 0, tir: 0, nit: 0 }, color: CAR_BY_ID.hyper.color }; extra = ' И ключи от гиперкара «Легенда» — он ваш.'; } else { addMoney(50000); extra = ' Гиперкар у вас уже есть, так что держите ещё $50 000.'; } }
      persist(); say(c.outro + extra);
    } });
  }
  o.push({ t: '📖 Мой прогресс: глава ' + Math.min(ch + 1, STORY.length) + ' из ' + STORY.length, fn: () => say(ch >= STORY.length ? 'Сюжет пройден полностью.' : 'Сейчас: «' + STORY[ch].t + '». Выполнено глав: ' + ch + '.') });
  o.push(byeOpt());
  return o;
}
function hasAnyGun() { return WEAPONS.some(w => !w.melee && S.guns.own[w.id]); }
function say(t) { TALK.say = t; renderTalk(); }
function openTalk(kind) {
  const n = NPC[kind]; if (!n) return;
  TALK.sub = null;
  TALK.kind = kind;
  let g = pick(n.greet);
  if (kind === 'gun' && !hasAnyGun()) g = 'Эй, да у тебя одни кулаки! Возьми пистолет за ' + fmtMoney(WBY.pistol.price) + ' — патроны в комплекте.';
  if (kind === 'hosp' && P.hp < 70) g = 'Вы ранены! Давайте скорее вылечу — всего $50.';
  if (kind === 'pol' && WANT.stars > 0) g = 'Так-так... за вами числится розыск. Можно уладить: оплатите штраф.';
  if (kind === 'car') { const no = CARS.filter(c => !S.cars[c.id]); if (no.length && S.money >= no[0].price) g = 'Здравствуйте! У вас хватает на ' + no.filter(c => c.price <= S.money).pop().name + ' — загляните, не пожалеете.'; }
  if (kind === 'taxi') g = taxiGreet(); else if (kind === 'food') g = 'Горячее, свежее! Что будете?'; else if (kind === 'boss') g = storyGreet(); else if (kind.indexOf('b_') === 0) g = bizGreet(kind.slice(2)); else if (kind.indexOf('p_') === 0) g = propGreet(kind.slice(2));
  TALK.say = g; openScreen('talk');
}
function talkOptions(k) {
  if (k === 'taxi') return taxiOptions();
  if (k === 'food') return foodOptions();
  if (k === 'boss') return storyOptions();
  if (k.indexOf('b_') === 0) return bizOptions(k.slice(2));
  if (k === 'estate') return estateOptions();
  if (k.indexOf('p_') === 0) return propOptions(k.slice(2));
  if (k === 'tune') return tuneOptions();
  if (k === 'club') return clubOptions();
  if (k === 'office') return officeOptions();
  if (k === 'metro') return metroOptions();
  if (k === 'cloth') return clothOptions();
  if (k === 'salon') return salonOptions();
  const o = [];
  if (k === 'gun') {
    o.push({ t: '🔫 Посмотреть оружие и патроны', fn: () => openScreen('gunshop') });
    if (!S.guns.own.pistol) o.push({ t: '🛒 Купить пистолет с патронами — ' + fmtMoney(WBY.pistol.price), dis: S.money < WBY.pistol.price, fn: () => { buyGun('pistol'); say('Отличный выбор! Береги патроны и не стреляй без нужды.'); } });
    else { const d = wDef(); if (!d.melee) o.push({ t: '🛒 Патроны для «' + d.name + '» (+' + d.ammoPack + ') — ' + fmtMoney(d.packPrice), dis: S.money < d.packPrice, fn: () => { buyAmmo(d.id); say('Держи патроны. Бей точно!'); } }); }
    o.push({ t: S.armor >= 99 ? '🛡 Бронежилет — уже на вас' : '🛡 Бронежилет (+100 брони) — ' + fmtMoney(600), dis: S.armor >= 99 || S.money < 600, fn: () => { S.money -= 600; S.armor = 100; S.flags.armor = true; persist(); SFX.buy(); refreshMoney(true); say('Надевай. Броня поглощает 75% урона, пока не износится.'); } });
    o.push({ t: '❓ Что посоветуешь?', fn: () => say(pick(NPC.gun.tips)) });
  } else if (k === 'car') {
    o.push({ t: '🚘 Посмотреть машины', fn: () => openScreen('shop') });
    const no = CARS.filter(c => !S.cars[c.id]);
    if (no.length) {
      const aff = no.filter(c => c.price <= S.money), off = aff.length ? aff[aff.length - 1] : no[0];
      o.push({ t: '🤝 Предложение: ' + off.name + ' — ' + fmtMoney(off.price), fn: () => { UI.shopSel = off.id; say(aff.length ? 'Вам как раз хватает на «' + off.name + '». Смотрите сами!' : 'Пока дороговато, зато цель на будущее: «' + off.name + '».'); openScreen('shop'); } });
    } else o.push({ t: '🏆 У вас вся коллекция!', dis: true, fn: () => { } });
    o.push({ t: '🎨 Покраска и тюнинг?', fn: () => say('Покраска бесплатная, а детали, неон и улучшения — в тюнинг-центре. Есть они и у вас дома на верстаке. А места для машин — у риелтора.') });
    o.push({ t: '❓ Какую машину выбрать?', fn: () => say(pick(NPC.car.tips)) });
  } else if (k === 'hosp') {
    o.push({ t: P.hp >= 99 ? '💉 Лечение — вы здоровы' : '💉 Лечение — $50', dis: P.hp >= 99 || S.money < 50, fn: () => { HOME_FN.healHere(); say('Вы как новенький. Берегите себя!'); } });
    if (!S.vit) o.push({ t: '💊 Витамины и полный осмотр — $400', dis: S.money < 400, fn: () => { S.money -= 400; S.vit = true; persist(); SFX.buy(); refreshMoney(true); say('Теперь здоровье будет восстанавливаться заметно быстрее. Это навсегда!'); } });
    else o.push({ t: '💊 Витамины уже куплены ✔', dis: true, fn: () => { } });
    o.push({ t: '❓ Совет врача', fn: () => say(pick(NPC.hosp.tips)) });
  } else if (k === 'pol') {
    const st = WANT.stars, fine = 400 * st, br = 1000 * st;
    o.push({ t: st ? '💵 Оплатить штраф — ' + fmtMoney(fine) : '💵 Оплатить штраф (розыска нет)', dis: !st || S.money < fine, fn: () => { HOME_FN.payFine(); say('Штраф оплачен, розыск снят. Живите честно.'); } });
    o.push({ t: st ? '🤫 Договориться по-тихому — ' + fmtMoney(br) + ' (риск)' : '🤫 Договориться (нечего улаживать)', dis: !st || S.money < br, fn: () => {
      S.money -= br; refreshMoney(true); persist();
      if (Math.random() < 0.7) { clearWanted(true); say('Я ничего не видел. Идите.'); } else { say('Деньги взял, но дело зашло слишком далеко. Розыск остаётся.'); SFX.err(); }
    } });
    o.push({ t: '📋 Проверить розыск', fn: () => say(st ? 'За вами числится ' + '★'.repeat(st) + '. Убито: людей — ' + WANT.civ + ', полицейских — ' + WANT.cop + '.' : 'За вами ничего нет. Чисто.') });
    o.push({ t: '❓ Правила города', fn: () => say(pick(NPC.pol.tips)) });
  }
  o.push({ t: '👋 До свидания', fn: () => { SFX.back(); closeScreens(); } });
  return o;
}
function renderTalk() {
  const n = NPC[TALK.kind]; if (!n) return;
  $('npcIco').textContent = n.ico; $('npcName').textContent = n.name; $('npcRole').textContent = n.role;
  $('npcSay').textContent = TALK.say;
  TALK.opts = talkOptions(TALK.kind);
  $('npcOpts').innerHTML = TALK.opts.map((x, i) => '<button class="btn" data-talk="' + i + '"' + (x.dis ? ' disabled' : '') + '>' + x.t + '</button>').join('');
}
function buyGun(id) {
  if (id === 'gren' || id === 'c4') { buyExp(id); return; }
  const w = WBY[id]; if (!w || S.guns.own[id]) return;
  if (S.money < w.price) { SFX.err(); toast('Не хватает денег'); return; }
  S.money -= w.price; S.guns.own[id] = true; S.guns.ammo[id] = (S.guns.ammo[id] || 0) + w.ammoPack * 2; S.guns.sel = id;
  SFX.buy(); persist(); refreshMoney(true); toast(w.icon + ' ' + w.name + ' куплен'); renderGunshop();
}
function buyAmmo(id) {
  const w = WBY[id]; if (!w || !S.guns.own[id]) return;
  if (S.money < w.packPrice) { SFX.err(); toast('Не хватает денег'); return; }
  S.money -= w.packPrice; S.guns.ammo[id] = Math.min(999, (S.guns.ammo[id] || 0) + w.ammoPack);
  SFX.cash(); persist(); refreshMoney(true); renderGunshop();
}


