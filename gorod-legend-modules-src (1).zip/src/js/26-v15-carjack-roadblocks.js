/* ===================== v15: УГОН, БЛОКПОСТЫ, ВЕРТОЛЁТ ===================== */
const STOLEN = [];
function crimeWanted(n, why) {
  WANT.crime = Math.max(WANT.crime || 0, n); WANT.heat = 0;
  if (M) return;
  if (n > WANT.stars) { WANT.stars = n; toast('🚨 Розыск: ' + '★'.repeat(n) + (why ? ' — ' + why : '')); SFX.err(); }
}
function carjack(c) {
  if (M) { toast('Сейчас не до угонов'); SFX.err(); return; }
  c.ai = null; c.vx = c.vz = c.vf = c.vl = 0; c.spd = 0; c.hitT = 0;
  const wit = peds.some(p => !p.dead && !p.fixed && Math.hypot(p.x - c.x, p.z - c.z) < 28);
  const copSaw = WANT.units.some(e => Math.hypot(e.x - c.x, e.z - c.z) < 60) || WANT.cars.some(o => Math.hypot(o.x - c.x, o.z - c.z) < 60);
  for (const p of peds) if (!p.dead && !p.fixed && Math.hypot(p.x - c.x, p.z - c.z) < 35) p.panic = 6;
  spawnDriver(c);
  enterCar(c);
  c.kind = 'parked'; c.stolen = true;
  STOLEN.push(c);
  if (STOLEN.length > 3) { const o = STOLEN.shift(); if (o === P.car) STOLEN.push(o); else removeCar(o); }
  CAM.shake = Math.max(CAM.shake, 0.25);
  if (copSaw) crimeWanted(2, 'угон на глазах у полиции');
  else if (wit) crimeWanted(1, 'угон');
  else toast('🚗 Угнано без свидетелей');
}
function placeBlock() {
  const car = P.car, hh = car ? car.h : P.h, hx = Math.sin(hh), hz = Math.cos(hh);
  const spd = car ? Math.abs(car.vf) : P.speed;
  const horiz = Math.abs(hx) > Math.abs(hz), sgn = (horiz ? hx : hz) >= 0 ? 1 : -1;
  const pa = horiz ? P.x : P.z, pc = horiz ? P.z : P.x;
  const line = clamp(Math.round((pc + HALF) / PITCH), 0, GRID), rc = nodeC(line);
  if (Math.abs(pc - rc) > 12) return false;            // игрок не на дороге
  const minD = Math.max(110, spd * 3.2);
  let best = null;
  for (let s = 0; s < GRID; s++) {
    const a = nodeC(s) + PITCH / 2, delta = (a - pa) * sgn;   // середина перегона между перекрёстками
    if (delta < minD || delta > 300) continue;
    const bx = horiz ? a : rc, bz = horiz ? rc : a;
    if (WANT.blocks.some(b => Math.hypot(b.x - bx, b.z - bz) < 120)) continue;
    if (!best || delta < best.delta) best = { delta, x: bx, z: bz };
  }
  if (!best) return false;
  const row = [], heading = horiz ? 0 : Math.PI / 2;
  for (const o of [-7.1, -2.7, 1.7, 6.1]) {
    const jit = rand(-0.35, 0.35), c = makeCar(POLICE_DEF, 'block', '#f5f5f5');
    c.x = best.x + (horiz ? 0 : o + jit); c.z = best.z + (horiz ? o + jit : 0);
    c.h = heading + (Math.random() < 0.5 ? 0 : Math.PI) + rand(-0.12, 0.12);
    c.mass *= 2.4; row.push(c);
  }
  WANT.blocks.push({ x: best.x, z: best.z, cars: row });
  toast('🚧 Впереди полицейский блокпост!'); SFX.tick();
  return true;
}
function updateBlocks(dt) {
  const car = P.car, hh = car ? car.h : P.h, hx = Math.sin(hh), hz = Math.cos(hh);
  for (let k = WANT.blocks.length - 1; k >= 0; k--) {
    const b = WANT.blocks[k], d = Math.hypot(b.x - P.x, b.z - P.z), ahead = (b.x - P.x) * hx + (b.z - P.z) * hz;
    if (d > 280 || (ahead < -30 && d > 120)) { for (const c of b.cars) removeCar(c); WANT.blocks.splice(k, 1); }
  }
  const want = [0, 0, 0, 1, 2, 3][WANT.stars] || 0;
  if (WANT.heat < 4 && WANT.blocks.length < want && WANT.blkT <= 0) WANT.blkT = placeBlock() ? 9 : 2.5;
}
function spawnHeli() {
  const a = Math.random() * TAU, lim = EDGE + 60;
  WANT.heli = { x: clamp(P.x + Math.cos(a) * 190, -lim, lim), z: clamp(P.z + Math.sin(a) * 190, -lim, lim), y: 46, vx: 0, vz: 0, h: 0, lx: P.x, lz: P.z, cd: 2, snd: 0 };
  toast('🚁 Над городом полицейский вертолёт!'); SFX.err();
}
/* возвращает горизонтальную дистанцию до игрока (или 1e9, если вертолёта нет) */
function updateHeli(dt) {
  if (WANT.stars < 4) return 1e9;
  let h = WANT.heli;
  if (!h) { if (WANT.heat >= 4) return 1e9; spawnHeli(); h = WANT.heli; }
  const car = P.car, pvx = car ? car.vx : 0, pvz = car ? car.vz : 0, a = G.time * 0.35;
  const tx = P.x + pvx * 1.1 + Math.cos(a) * 20, tz = P.z + pvz * 1.1 + Math.sin(a) * 20;
  const dx = tx - h.x, dz = tz - h.z, d = Math.hypot(dx, dz) || 1, want = Math.min(46, d * 1.3), k = Math.min(1, dt * 1.6);
  h.vx += (dx / d * want - h.vx) * k; h.vz += (dz / d * want - h.vz) * k;
  h.x += h.vx * dt; h.z += h.vz * dt;
  h.h += wrapA(Math.atan2(P.x - h.x, P.z - h.z) - h.h) * Math.min(1, dt * 2.5);
  h.lx += (P.x - h.lx) * Math.min(1, dt * 3.5); h.lz += (P.z - h.lz) * Math.min(1, dt * 3.5);
  const dh = Math.hypot(P.x - h.x, P.z - h.z);
  if ((h.snd -= dt) <= 0) {
    h.snd = 0.12; const v = clamp(1 - dh / 190, 0, 1);
    if (v > 0.03) { tone(48, 0.1, 'sawtooth', 0.14 * v, 30); noiseBurst(0.06, 0.05 * v, 500); }
  }
  if (WANT.stars >= 5 && dh < 90) {
    h.cd -= dt;
    if (h.cd <= 0) {
      h.cd = 1.0 + Math.random() * 0.5;
      const hit = Math.random() < 0.38, jx = hit ? 0 : rand(-3, 3), jz = hit ? 0 : rand(-3, 3);
      TRACERS.push({ x1: h.x, y1: h.y - 1, z1: h.z, x2: P.x + jx, y2: 1.2, z2: P.z + jz, t: 0.12, max: 0.12, c: [1, 0.5, 0.25] });
      SFX.gun('smg', 0.45);
      if (hit) hurtPlayer(5, 'cop'); else sparks(P.x + jx, 0.3, P.z + jz, [1, 0.8, 0.4]);
    }
  }
  return dh;
}
function updateWanted(dt) {
  if (WANT.stars <= 0 || G.mode !== 'play') return;
  if (M) { clearWanted(); return; }
  if (G.inHome) { if (G.int && G.int.kind === 'home') { WANT.heat += dt * 6; if (WANT.heat > 30) clearWanted(true); } return; }
  const st = WANT.stars, lost = WANT.heat >= 4, chase = WANT.heat < 0.5;   // chase: контакт есть — патрули подкрепляются; оторвались — новых нет
  WANT.spT -= dt; WANT.carT -= dt; WANT.blkT -= dt;
  if (chase && WANT.units.length < [0, 2, 3, 5, 6, 8][st] && WANT.spT <= 0) { spawnCop(); WANT.spT = 1.6; }
  if (chase && WANT.cars.length < (st >= 2 ? Math.min(4, st - 1) : 0) && WANT.carT <= 0) { spawnCopCar(); WANT.carT = 4; }
  updateBlocks(dt);
  let near = 1e9, nearCar = 1e9;
  for (let k = WANT.units.length - 1; k >= 0; k--) {
    const e = WANT.units[k], d = Math.hypot(e.x - P.x, e.z - P.z); near = Math.min(near, d);
    if (d > 110) {
      if (lost || WANT.heat > 0.8) { WANT.units.splice(k, 1); continue; }   // оторвались: патруль отстал — не телепортируем его обратно
      const a = Math.random() * TAU; e.x = clamp(P.x + Math.cos(a) * 55, -EDGE, EDGE); e.z = clamp(P.z + Math.sin(a) * 55, -EDGE, EDGE); pushCircle(e, 0.6);
    }
  }
  updateEnemyList(WANT.units, dt);
  for (let k = WANT.cars.length - 1; k >= 0; k--) {
    const c = WANT.cars[k], d = Math.hypot(c.x - P.x, c.z - P.z);
    if (d > 280) { removeCar(c); WANT.cars.splice(k, 1); continue; }
    nearCar = Math.min(nearCar, d); near = Math.min(near, d);
    c.ai.maxSp = c.ai.base * (d > 130 ? 1.25 : 1);
  }
  const hd = updateHeli(dt);
  if (hd < 1e8) near = Math.min(near, hd * 0.66);    // вертолёт видит дальше (порог ~90 м)
  WANT.seen = near < 60;
  const base = 70 + st * 22;
  if (WANT.seen || !WANT.zone) WANT.zone = { x: P.x, z: P.z, r: base };
  else WANT.zone.r = base * (1 - 0.7 * clamp(WANT.heat / 30, 0, 1));
  auSiren(WANT.cars.length ? clamp(1 - nearCar / 130, 0, 1) : 0);
  if (near > 60) WANT.heat += dt; else WANT.heat = Math.max(0, WANT.heat - dt * 0.5);
  if (WANT.heat > 30) clearWanted(true);
}

