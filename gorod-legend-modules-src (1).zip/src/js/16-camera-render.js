/* ===================== 12. КАМЕРА И ОТРИСОВКА ===================== */
let W = 1, H = 1, DPR = 1;
const PROJ = newM(), VIEW = newM(), VP = newM();
function resize() {
  const q = G.quality || QUAL.med;
  DPR = Math.min(window.devicePixelRatio || 1, q.dpr) * G.scale;
  W = Math.max(2, Math.floor(window.innerWidth * DPR)); H = Math.max(2, Math.floor(window.innerHeight * DPR));
  if (canvas.width !== W || canvas.height !== H) { canvas.width = W; canvas.height = H; }
}
function updateCamera(dt) {
  let ex, ey, ez, tx, ty, tz, fov = 1.05;
  if (G.mode === 'menu' || G.mode === 'loading') {
    CAM.orbit += dt * 0.06;
    ex = Math.cos(CAM.orbit) * 300; ez = Math.sin(CAM.orbit) * 300; ey = 100; tx = 0; ty = 30; tz = 0; fov = 0.95;
  } else {
    const car = P.car; let dist, tgtFov = 1.05;
    if (car) {
      const sp = clamp(Math.abs(car.vf) / car.st.maxSpeed, 0, 1.3);
      if (performance.now() - CAM.lastDrag > 1800) CAM.off *= Math.exp(-dt * 1.5);
      const tgt = car.h + CAM.off;
      CAM.yaw += wrapA(tgt - CAM.yaw) * (1 - Math.exp(-dt * 4.2));
      tx = car.x + Math.sin(car.h) * clamp(car.vf * 0.07, -1, 3); ty = car.y + 1.4; tz = car.z + Math.cos(car.h) * clamp(car.vf * 0.07, -1, 3);
      dist = 8.2 + sp * 3.2; tgtFov = 1.0 + sp * 0.3 + (car.nitroOn ? 0.16 : 0);
    } else {
      tx = P.x; ty = P.y + 1.55; tz = P.z; dist = 5.6;
      tgtFov = 1.05 + (WS.zf - 1.05) * WS.zoom;
    }
    CAM.fov += (tgtFov - CAM.fov) * (1 - Math.exp(-dt * (WS.zoom > 0.02 || CAM.fov < 0.95 ? 11 : 4))); fov = CAM.fov;
    if (G.inHome) { tx = P.x; ty = P.y + 1.3; tz = P.z; dist = 9.5; CAM.pitch = clamp(CAM.pitch, 0.7, 1.25); }
    if (G.inHome && UI.cur === 'style') {
      const por = window.innerHeight > window.innerWidth;
      const zm = ST.zoom ? 0.62 : 1;
      ty = P.y + (ST.zoom ? 1.45 : 1.0) - (por ? 0.35 : 0); dist = 4.6 * zm; CAM.pitch = 0.22; CAM.yaw = 0;
    }
    const cp = Math.cos(Math.max(CAM.pitch, 0.06)), sp2 = Math.sin(Math.max(CAM.pitch, 0.06));
    ex = tx - Math.sin(CAM.yaw) * dist * cp; ey = ty + dist * sp2; ez = tz - Math.cos(CAM.yaw) * dist * cp;
    // не даём камере уйти внутрь зданий
    if (!G.inHome) for (let t = 1; t >= 0.12; t -= 0.1) {
      const px = tx + (ex - tx) * t, py = ty + (ey - ty) * t, pz = tz + (ez - tz) * t;
      let inside = false;
      for (let k = 0; k < boxes.length; k++) { const b = boxes[k]; if (px > b.x0 - 0.6 && px < b.x1 + 0.6 && pz > b.z0 - 0.6 && pz < b.z1 + 0.6 && py < b.h + 0.5) { inside = true; break; } }
      if (!inside) { ex = px; ey = py; ez = pz; break; }
      if (t < 0.13) { ex = px; ey = py; ez = pz; }
    }
    ey = Math.max(ey, 0.9);
    if (!G.inHome && CAM.pitch < 0.06) ty += dist * Math.tan(0.06 - Math.max(CAM.pitch, -1.0));
    if (!car && !G.inHome) {
      const man = aimManual();
      if (man && !CAM.wasMan) CAM.pitch = Math.min(CAM.pitch, 0.1);
      CAM.wasMan = man;
      CAM.aimB += ((man ? 1 : 0) - CAM.aimB) * (1 - Math.exp(-dt * 9));
      if (!man && CAM.aimB < 0.05 && CAM.pitch < -0.9) CAM.pitch = -0.9;
      if (CAM.aimB > 0.003) {
        const zs = WS.zoom * WS.zoom * (3 - 2 * WS.zoom), back = 3.3 * (1 - zs) + 0.25 * zs, lat = 0.5 * (1 - zs);
        const sy = Math.sin(CAM.yaw), cy = Math.cos(CAM.yaw), cpp = Math.cos(CAM.pitch), spp = Math.sin(CAM.pitch);
        let fx = P.x - sy * back + cy * lat, fz = P.z - cy * back - sy * lat, fy = P.y + 1.72;
        const hx = P.x, hy = P.y + 1.6, hz = P.z;
        for (let t = 1; t >= 0.1; t -= 0.1) {
          const px = hx + (fx - hx) * t, py = hy + (fy - hy) * t, pz = hz + (fz - hz) * t;
          let inside = false;
          for (let k = 0; k < boxes.length; k++) { const b = boxes[k]; if (px > b.x0 - 0.5 && px < b.x1 + 0.5 && pz > b.z0 - 0.5 && pz < b.z1 + 0.5 && py < b.h + 0.5) { inside = true; break; } }
          if (!inside || t < 0.11) { fx = px; fy = py; fz = pz; break; }
        }
        const ftx = fx + sy * cpp * 12, fty = fy - spp * 12, ftz = fz + cy * cpp * 12, w = CAM.aimB * CAM.aimB * (3 - 2 * CAM.aimB);
        ex += (fx - ex) * w; ey += (fy - ey) * w; ez += (fz - ez) * w; tx += (ftx - tx) * w; ty += (fty - ty) * w; tz += (ftz - tz) * w;
      }
    }
    if (G.inHome) { const ix = G.int ? G.int.x : INX, iz = G.int ? G.int.z : INZ; if (UI.cur === 'style') { ex = clamp(ex, ix - 9.3, ix + 9.3); ez = clamp(ez, iz - 7.5, iz + 11); } else { const gw = G.int && G.int.kind === 'garage' ? 29.5 : (G.int && G.int.kind === 'casino' ? 22 : 13); ex = clamp(ex, ix - gw, ix + gw); ez = clamp(ez, iz - 11, iz + (G.int && G.int.kind === 'garage' ? 31 : 11)); } }
    else { const L = WLIM() + 15; ex = clamp(ex, -L, L); ez = clamp(ez, -L, L); }
    if (CAM.shake > 0.001 && S.set.shake !== false) { ex += (Math.random() - 0.5) * CAM.shake; ey += (Math.random() - 0.5) * CAM.shake; ez += (Math.random() - 0.5) * CAM.shake; CAM.shake *= Math.exp(-dt * 7); }
  }
  CAM.x = ex; CAM.y = ey; CAM.z = ez; CAM.tx = tx; CAM.ty = ty; CAM.tz = tz;
  mPersp(PROJ, fov, W / H, 0.6, 1400);
  mLookAt(VIEW, ex, ey, ez, tx, ty, tz);
  mMul(VP, PROJ, VIEW);
}
function visible(x, z, rad, maxD) {
  const dx = x - CAM.x, dz = z - CAM.z, d2 = dx * dx + dz * dz;
  if (d2 > maxD * maxD) return 0;
  const fx = CAM.tx - CAM.x, fz = CAM.tz - CAM.z, fl = Math.hypot(fx, fz) || 1;
  if ((dx * fx + dz * fz) / fl < -rad) return 0;
  return Math.sqrt(d2);
}
function project(x, y, z) {
  const w = VP[3] * x + VP[7] * y + VP[11] * z + VP[15];
  if (w <= 0.1) return null;
  const cx = (VP[0] * x + VP[4] * y + VP[8] * z + VP[12]) / w, cy = (VP[1] * x + VP[5] * y + VP[9] * z + VP[13]) / w;
  return { x: (cx * 0.5 + 0.5) * window.innerWidth, y: (0.5 - cy * 0.5) * window.innerHeight, w };
}
const CMX = newM(), WPM = newM(), WWM = newM();
function drawCar(c, dist) {
  const s = c.def.shape;
  mTRS(CMX, c.x, c.y, c.z, c.h, c.pitch, c.lean, 1, 1, 1);
  const m = c.meshes;
  const dk = 1 - 0.0045 * (c.dmg || 0);
  drawMesh(m.body, CMX, dk, dk, dk, 1, 0, false);
  if (m.rotor) { mTRS(WPM, 0, 2.15, 0, G.time * (c.driver ? 28 : 3), 0, 0, 1, 1, 1); mMul(WWM, CMX, WPM); drawMesh(m.rotor, WWM, 1, 1, 1, 1, 0, false); }
  if (dist < 120) {
    const wr = s.wr, wx = s.W / 2 - 0.06, wz = s.L * 0.32, bk = c.def.bike;
    const nw = c.def.heli ? 0 : bk ? 2 : 4;
    for (let k = 0; k < nw; k++) {
      const front = k < (bk ? 1 : 2), sx = bk ? 0 : ((k & 1) ? 1 : -1);
      mTRS(WPM, sx * wx, wr, front ? wz : -wz, front ? -c.steer * 0.45 : 0, c.roll, 0, 1, 1, 1);
      mMul(WWM, CMX, WPM);
      drawMesh(m.wheel, WWM, 1, 1, 1, 1, 0, false);
    }
  }
  const nl = 0.75 + ENV.night * 0.25;
  drawMesh(m.lights, CMX, nl, nl, nl * 0.95, 1, 1, false);
  const tb = c.brake ? 1 : 0.5;
  drawMesh(m.tail, CMX, tb, tb * 0.08, tb * 0.08, 1, 1, false);
  if (c.def.police || c.def.siren) {
    const ph = Math.floor(G.time * 6) % 2;
    drawMesh(m.barR, CMX, ph ? 1 : 0.2, 0.05, 0.05, 1, 1, false);
    drawMesh(m.barB, CMX, 0.05, 0.1 + (ph ? 0.2 : 0.85), ph ? 0.35 : 1, 1, 1, false);
  }
}
const DFAKE = [];
function drawDisplayCars() {
  const o = INT.car;
  DISPLAY.forEach((d, i) => {
    let f = DFAKE[i];
    if (!f) { const def = CAR_BY_ID[d[0]]; f = DFAKE[i] = { def, col: def.color, meshes: carMeshes(def, def.color), x: o.x + d[1], y: 0.24, z: o.z + d[2], h: 0, pitch: 0, lean: 0, roll: 0, steer: 0, brake: false, W: def.shape.W, L: def.shape.L, nitroOn: false }; }
    f.h = G.time * 0.4 + i * 1.3; drawCar(f, 0);
  });
}
function drawHomeScene() {
  const ik = G.int ? G.int.kind : 'home', II = ik === 'home' ? CITY.interior : CITY.ints[ik];
  for (const m of II.lit) drawMesh(m, IDENT, 1, 1, 1, 1, 0, false);
  for (const m of II.glow) drawMesh(m, IDENT, 1, 1, 1, 1, 1, false);
  if (ik === 'car') drawDisplayCars();
  if (ik === 'garage') drawGarageCars();
  if (ik === 'tune') drawTuneCar();
  const sl = SELLERS[ik]; if (sl) drawHuman(sl.x, 0, sl.z, Math.atan2(P.x - sl.x, P.z - sl.z), 0, 0, sl.look);
  if (P.vis) drawHuman(P.x, P.y, P.z, P.h, P.phase, P.amp, PLAYER_LOOK);
  setPass('alpha');
  if (P.vis) { mTRS(DM, P.x, P.y + 0.04, P.z, 0, 0, 0, 0.55, 1, 0.55); drawMesh(M_DISC, DM, 1, 1, 1, 1, 1, false); }
  setPass('opaque');
}
function drawScene(studio) {
  const inHome = G.inHome && !UI.studio;
  if (inHome) {
    ENV.top = [0.1, 0.1, 0.14]; ENV.bot = [0.1, 0.1, 0.14]; ENV.night = 0; ENV.sunVis = [0, -1, 0];
    ENV.sunCol = [0.34, 0.31, 0.27]; ENV.sky = [0.6, 0.57, 0.55]; ENV.ground = [0.4, 0.36, 0.33];
    ENV.sunDir = [0.3, 0.9, 0.3]; ENV.fogNear = 60; ENV.fogFar = 240;
  }
  // небо
  gl.viewport(0, 0, W, H);
  gl.disable(gl.DEPTH_TEST);
  gl.useProgram(SKYPROG);
  gl.uniform3f(SKYU.uTop, ENV.top[0], ENV.top[1], ENV.top[2]); gl.uniform3f(SKYU.uBot, ENV.bot[0], ENV.bot[1], ENV.bot[2]);
  gl.uniform3fv(SKYU.uSun, ENV.sunVis); gl.uniform1f(SKYU.uNight, ENV.night); gl.uniform1f(SKYU.uTime, G.time);
  gl.uniform1f(SKYU.uCl, (S.set.quality === 'low' || inHome) ? 0 : 1);
  gl.uniform3f(SKYU.uR, VIEW[0], VIEW[4], VIEW[8]); gl.uniform3f(SKYU.uU, VIEW[1], VIEW[5], VIEW[9]); gl.uniform3f(SKYU.uF, -VIEW[2], -VIEW[6], -VIEW[10]);
  gl.uniform2f(SKYU.uT, 1 / PROJ[0], 1 / PROJ[5]);
  gl.bindBuffer(gl.ARRAY_BUFFER, skyBuf);
  gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  gl.disableVertexAttribArray(1); gl.disableVertexAttribArray(2); gl.disableVertexAttribArray(3);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  gl.enableVertexAttribArray(1); gl.enableVertexAttribArray(2); gl.enableVertexAttribArray(3);
  gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.stencilMask(0xff); gl.clear(gl.DEPTH_BUFFER_BIT | gl.STENCIL_BUFFER_BIT);
  gl.useProgram(PROG);
  curBlend = ''; setPass('opaque');
  gl.uniformMatrix4fv(U.uVP, false, VP);
  gl.uniform3f(U.uCam, CAM.x, CAM.y, CAM.z);
  gl.uniform3fv(U.uSunDir, ENV.sunDir); gl.uniform3fv(U.uSunCol, ENV.sunCol);
  gl.uniform3fv(U.uSky, ENV.sky); gl.uniform3fv(U.uGround, ENV.ground);
  gl.uniform1f(U.uFogNear, ENV.fogNear); gl.uniform1f(U.uFogFar, ENV.fogFar); gl.uniform3fv(U.uFogCol, ENV.bot);
  gl.uniform1f(U.uNight, ENV.night);
  gl.uniform1i(U.uTex, 0); gl.uniform1i(U.uTexE, 1);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, TEX_DAY);
  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, TEX_NIGHT);
  gl.activeTexture(gl.TEXTURE0);
  if (inHome) { drawHomeScene(); return; }
  for (const m of CITY.ground) drawMesh(m, IDENT, 1, 1, 1, 1, 0, false);
  if (WINTER.on && CITY.snow) for (const m of CITY.snow) drawMesh(m, IDENT, 1, 1, 1, 1, 0, false);
  if (reflOn()) drawReflection();
  drawRoads();
  {
    const far = ENV.fogFar + 40;
    for (const r of CITY.world) {
      if (!r.always) {
        const dx = Math.max(r.x0 - CAM.x, 0, CAM.x - r.x1), dz = Math.max(r.z0 - CAM.z, 0, CAM.z - r.z1);
        if (dx * dx + dz * dz > far * far) continue;
      }
      for (const m of r.meshes) drawMesh(m, IDENT, 1, 1, 1, 1, 0, true);
    }
  }
  const lk = 0.55 + ENV.night * 0.75;
  for (const m of CITY.lamps) drawMesh(m, IDENT, lk, lk * 0.92, lk * 0.6, 1, 1, false);
  // маяк башни
  const bp = 0.5 + 0.5 * Math.sin(G.time * 3);
  mTRS(DM, CITY_TOWER.x, CITY_TOWER.y, CITY_TOWER.z, 0, 0, 0, 1.6, 1.6, 1.6);
  drawMesh(M_OCTA, DM, 0.4 + bp * 0.6, 0.04, 0.04, 1, 1, false);
  setPass('decal');
  for (const m of CITY.decal) drawMesh(m, IDENT, 1, 1, 1, 1, 0, false);
  setPass('opaque');
  v31Static();
  // машины
  for (const c of cars) {
    const d = visible(c.x, c.z, 6, 300); if (!d) continue;
    drawCar(c, d);
  }
  // игрок и пешеходы
  if (P.vis && WS.zoom < 0.55) drawHuman(P.x, P.y, P.z, (!P.car && aimManual() && P.downT <= 0) ? CAM.yaw : P.h, P.phase, P.amp, PLAYER_LOOK, false, 1, P.downT > 0 ? null : playerGun(), P.downT > 0 ? clamp(Math.min((0.9 - P.downT) / 0.15, P.downT / 0.3), 0, 1) : (CB.roll > 0 ? (1 - CB.roll / 0.5) * 4.19 : 0));
  drawIncHumans();
  v31Draw();
  for (const p of peds) { const d = visible(p.x, p.z, 2, 110); if (!d) continue; drawHuman(p.x, terrainY(p.x, p.z), p.z, p.h, p.ph, p.dead ? 0 : 0.9, p.look, d > 38, 1, null, p.fall); }
  if (M && M.enemies) drawEnemies(M.enemies);
  if (WANT.units.length) drawEnemies(WANT.units);
  if (GANG.units.length) drawEnemies(GANG.units);
  mpDraw();
  drawPoliceHeli();
  drawSignals();
  // сборные предметы
  drawPickups();
  // прозрачное
  setPass('alpha');
  drawBuildingShadows();
  for (const c of cars) {
    const d = visible(c.x, c.z, 6, 200); if (!d) continue;
    mTRS(DM, c.x, c.y + 0.04, c.z, c.h, 0, 0, c.W * 0.75, 1, c.L * 0.62);
    drawMesh(M_DISC, DM, 1, 1, 1, 1, 1, false);
  }
  if (P.vis) { mTRS(DM, P.x, P.y + 0.04, P.z, 0, 0, 0, 0.55, 1, 0.55); drawMesh(M_DISC, DM, 1, 1, 1, 1, 1, false); }
  mpShadow();
  drawParticles(false);
  setPass('add');
  if (ENV.night > 0.06) {
    const na = ENV.night;
    for (const m of CITY.lglow) drawMesh(m, IDENT, 1, 0.86, 0.55, na * 0.5, 2, false);
    for (const c of cars) {
      if (c.kind === 'parked' || c.kind === 'block') continue;
      const d = visible(c.x, c.z, 8, 110); if (!d) continue;
      const f = c.def.shape.L / 2 + 5.5;
      mTRS(DM, c.x + Math.sin(c.h) * f, c.y + 0.07, c.z + Math.cos(c.h) * f, c.h, 0, 0, c.W * 1.5, 1, 7.5);
      drawMesh(M_GLOW, DM, 1, 0.95, 0.72, na * 0.5 * (1 - d / 140), 2, false);
    }
  }
  for (const c of cars) {
    if (!(c.mods && c.mods.neon)) continue;
    const d = visible(c.x, c.z, 8, 140); if (!d) continue;
    const nc = hexRGB(c.mods.neon), na = (0.38 + 0.55 * ENV.night) * (1 - d / 170);
    mTRS(DM, c.x, c.y + 0.07, c.z, c.h, 0, 0, c.W * 1.5, 1, c.L * 0.82); drawMesh(M_GLOW, DM, nc[0], nc[1], nc[2], na, 2, false);
  }
  drawTracers(); drawExplosives();
  drawHeliLight();
  drawMarkers();
  for (const c of cars) {
    if (!c.nitroOn) continue;
    const d = visible(c.x, c.z, 6, 200); if (!d) continue;
    const fl = 0.8 + Math.random() * 0.6;
    for (const sx of [-1, 1]) {
      mTRS(DM, 0, 0, 0, 0, 0, 0, 1, 1, 1);
      mTRS(PMX, sx * c.W * 0.28, c.def.shape.wr * 0.9 + 0.12, -c.L / 2 - 0.05, 0, -Math.PI / 2, 0, 1.2, fl * 1.6, 1.2);
      mMul(WMX, CMX_OF(c), PMX);
      drawMesh(M_CONE, WMX, 1, 0.55, 0.12, 0.9, 2, false);
    }
  }
  drawParticles(true);
  setPass('opaque');
}
const CMX2 = newM();
function CMX_OF(c) { return mTRS(CMX2, c.x, c.y, c.z, c.h, c.pitch, c.lean, 1, 1, 1); }

