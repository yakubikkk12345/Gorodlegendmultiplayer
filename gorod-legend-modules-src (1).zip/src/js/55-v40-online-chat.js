/* ===================== v40: ИГРОКИ ОНЛАЙН, ОБЩИЙ ЧАТ, ПРИГЛАШЕНИЯ + чистка HUD ===================== */
{
  const css = document.createElement('style');
  css.textContent = `
#distPill, #wxChip { display: none !important; }
#evChip { top: calc(var(--safe-t, 0px) + 12px) !important; }
#onBtn { position: fixed; right: 170px; top: calc(var(--safe-t, 0px) + 64px); z-index: 21; width: 44px; height: 44px; border-radius: 50%; font-size: 20px; border: 1px solid var(--line, rgba(255,255,255,.2)); background: rgba(8,12,22,.7); color: #fff; display: none; }
#onBtn b { position: absolute; top: -4px; right: -4px; min-width: 18px; height: 18px; border-radius: 9px; background: #e5484d; font: 700 11px/18px system-ui; text-align: center; display: none; }
#onl { position: fixed; z-index: 70; right: 8px; top: calc(var(--safe-t, 0px) + 8px); bottom: calc(var(--safe-b, 0px) + 8px); width: min(94vw, 380px); display: none; flex-direction: column; background: rgba(10,14,26,.94); border: 1px solid rgba(255,255,255,.2); border-radius: 14px; color: #fff; font: 14px system-ui, sans-serif; backdrop-filter: blur(8px); }
#onl.show { display: flex; }
#onl .oh { display: flex; align-items: center; justify-content: space-between; padding: 10px 12px; font-weight: 700; border-bottom: 1px solid rgba(255,255,255,.12); }
#onl .oh button { background: none; border: 0; color: #fff; font-size: 20px; }
#onList { flex: 0 0 auto; max-height: 42%; overflow-y: auto; padding: 6px 8px; }
.onr { display: flex; align-items: center; gap: 8px; padding: 6px 4px; border-bottom: 1px solid rgba(255,255,255,.07); }
.onr .nm { flex: 1; min-width: 0; } .onr .nm b { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; } .onr .nm small { color: #9fb0c8; }
.onr button { background: #2a7de1; border: 0; color: #fff; border-radius: 8px; padding: 6px 10px; font-size: 12px; font-weight: 600; }
.onr button.alt { background: #3a4a62; }
#onTabs { display: flex; gap: 6px; padding: 6px 10px 0; } #onTabs button { flex: 1; padding: 6px; border-radius: 8px; border: 1px solid rgba(255,255,255,.18); background: transparent; color: #cfd8e8; font-size: 13px; } #onTabs button.on { background: #2a7de1; color: #fff; border-color: #2a7de1; }
#onLog { flex: 1; overflow-y: auto; padding: 6px 12px; font-size: 13px; }
#onLog div { margin: 3px 0; word-break: break-word; } #onLog .sys { color: #9fe7ff; } #onLog .rm b { color: #7be08c; }
#onSend { display: flex; gap: 6px; padding: 8px; border-top: 1px solid rgba(255,255,255,.12); }
#onIn { flex: 1; min-width: 0; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.2); border-radius: 10px; color: #fff; padding: 9px; font-size: 14px; }
#onSend button { background: #2a7de1; border: 0; color: #fff; border-radius: 10px; padding: 0 14px; font-weight: 700; }
#invBox { position: fixed; z-index: 80; left: 50%; top: calc(var(--safe-t, 0px) + 56px); transform: translateX(-50%); display: none; padding: 10px 14px; border-radius: 14px; background: rgba(16,24,44,.96); border: 1px solid #5aa9ff; color: #fff; font: 600 14px system-ui; max-width: 92vw; text-align: center; box-shadow: 0 6px 30px rgba(0,0,0,.5); }
#invBox .ib { display: flex; gap: 8px; justify-content: center; margin-top: 8px; } #invBox button { border: 0; border-radius: 9px; padding: 8px 16px; font-weight: 700; color: #fff; background: #2fa84f; } #invBox button.no { background: #4a5568; }
`;
  document.head.appendChild(css);
  const onBtn = document.createElement('button'); onBtn.id = 'onBtn'; onBtn.innerHTML = '👥<b></b>'; (document.getElementById('hud') || document.body).appendChild(onBtn);
  const onl = document.createElement('div'); onl.id = 'onl';
  onl.innerHTML = '<div class="oh"><span id="onTitle">👥 Игроки онлайн</span><button id="onX">✕</button></div><div id="onList"></div><div id="onTabs"><button data-m="g" class="on">🌐 Общий чат</button><button data-m="r">🏠 Комната</button></div><div id="onLog"></div><div id="onSend"><input id="onIn" maxlength="140" placeholder="Сообщение…" autocomplete="off"><button id="onGo">➤</button></div>';
  document.body.appendChild(onl);
  const inv = document.createElement('div'); inv.id = 'invBox'; document.body.appendChild(inv);

  let uid = ''; try { uid = localStorage.getItem('gl_uid') || ''; } catch (e) { }
  if (!uid) { uid = Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4); uid = uid.replace(/[^a-z0-9]/gi, '').slice(0, 12); try { localStorage.setItem('gl_uid', uid); } catch (e) { } }
  const LB = { ws: null, st: 'off', list: [], me: uid, uid, tries: 0, unread: 0, mode: 'g', after: '', log: [], t: 0, inv: null, invT: 0 };

  function lbUrl() {
    let url = ((MP.cfg && MP.cfg.url) || '').trim();
    if (/^wss?:\/\/localhost:8080\/?$/i.test(url) && location.hostname !== 'localhost') url = '';
    if (!url && location.protocol.startsWith('http') && location.hostname !== 'localhost') url = location.host;
    if (!url) return '';
    if (!/^wss?:\/\//i.test(url)) url = (location.protocol === 'http:' ? 'ws://' : 'wss://') + url.replace(/^https?:\/\//i, '');
    if (location.protocol === 'https:' && /^ws:\/\//i.test(url) && !/^ws:\/\/(localhost|127\.)/i.test(url)) return '';
    return url;
  }
  const lbName = () => (($('mpName') && $('mpName').value.trim()) || (MP.cfg && MP.cfg.name) || 'Игрок').slice(0, 16);
  function lbConnect(force) {
    if (LB.ws) return;
    const url = lbUrl(); if (!url) return;
    if (force) LB.tries = 0;
    let ws; try { ws = new WebSocket(url); } catch (e) { LB.tries++; return; }
    LB.ws = ws; LB.st = 'connecting'; let opened = false;
    ws.onopen = () => { opened = true; LB.st = 'on'; LB.tries = 0; ws.send(JSON.stringify({ t: 'hello', name: lbName(), uid })); lbRender(); };
    ws.onmessage = ev => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } lbMsg(m); };
    ws.onclose = () => { if (LB.ws === ws) { LB.ws = null; LB.st = 'off'; LB.list = []; if (!opened) LB.tries++; LB.t = 0; lbRender(); } };
    ws.onerror = () => { };
  }
  function lbSend(o) { if (LB.ws && LB.ws.readyState === 1) { LB.ws.send(JSON.stringify(o)); return true; } return false; }
  const lbLog = (cls, html) => {
    const box = $('onLog'); const d = document.createElement('div'); d.className = cls; d.innerHTML = html; box.appendChild(d);
    while (box.children.length > 80) box.removeChild(box.firstChild);
    box.scrollTop = box.scrollHeight;
  };
  const isOpen = () => onl.classList.contains('show');
  function badge() { const b = onBtn.querySelector('b'); b.style.display = LB.unread ? 'block' : 'none'; b.textContent = LB.unread > 9 ? '9+' : LB.unread; }
  function lbMsg(m) {
    if (m.t === 'online') { LB.list = m.list || []; if (m.me) LB.me = m.me; lbRender(); }
    else if (m.t === 'gchat') {
      lbLog('', '<b style="color:#7fc4ff">🌐 ' + mpEsc(m.name) + ':</b> ' + mpEsc(m.text));
      if (!isOpen()) { LB.unread++; badge(); cl0('🌐 ' + m.name, '#7fc4ff', m.text, false); }
    } else if (m.t === 'invite') showInvite(m);
  }
  function lbRender() {
    const l = $('onList'); if (!l) return;
    $('onTitle').textContent = '👥 Игроки онлайн' + (LB.st === 'on' ? ' · ' + LB.list.length : '');
    if (LB.st !== 'on') {
      l.innerHTML = '<div style="padding:10px;color:#9fb0c8">' + (lbUrl() ? (LB.st === 'connecting' ? 'Подключаемся к серверу…' : 'Нет связи с сервером. <button id="onRetry" class="alt" style="background:#2a7de1;border:0;color:#fff;border-radius:8px;padding:6px 10px">Повторить</button>') : 'Укажите адрес сервера в окне «Мультиплеер», чтобы видеть игроков.') + '</div>';
      return;
    }
    const inRoom = mpConnected(), mine = inRoom ? MP.room : '';
    l.innerHTML = LB.list.map(p => {
      const me = p.u === LB.me, same = mine && p.room === mine;
      const st = p.room ? '🏠 в комнате ' + p.room + ' (' + p.n + '/4)' : 'в лобби';
      let btn = '';
      if (!me && !same) {
        if (p.room && p.n < 4) btn += '<button data-go="' + mpEsc(p.room) + '">Войти</button>';
        btn += inRoom ? '<button class="alt" data-inv="' + mpEsc(p.u) + '">Позвать</button>' : '<button class="alt" data-mk="' + mpEsc(p.u) + '">Создать и позвать</button>';
      }
      return '<div class="onr"><div class="nm"><b>' + mpEsc(p.name) + (me ? ' (вы)' : '') + '</b><small>' + (same ? '✅ в вашей комнате' : st) + '</small></div>' + btn + '</div>';
    }).join('') || '<div style="padding:10px;color:#9fb0c8">Пока никого</div>';
  }
  function openPanel() {
    onl.classList.add('show'); LB.unread = 0; badge();
    if (!LB.ws) lbConnect(true); else lbSend({ t: 'who' });
    lbRender();
  }
  function closePanel() { onl.classList.remove('show'); $('onIn').blur(); }
  onBtn.addEventListener('pointerdown', e => { e.preventDefault(); isOpen() ? closePanel() : openPanel(); });
  $('onX').addEventListener('click', closePanel);
  onl.addEventListener('click', e => {
    const t = e.target.closest('button'); if (!t) return;
    if (t.id === 'onRetry') { lbConnect(true); lbRender(); return; }
    if (t.dataset.m) { LB.mode = t.dataset.m; onl.querySelectorAll('#onTabs button').forEach(b => b.classList.toggle('on', b === t)); return; }
    if (t.dataset.go) { lbJoin(t.dataset.go); return; }
    if (t.dataset.inv) { mpSend({ t: 'invite', to: t.dataset.inv }); return; }
    if (t.dataset.mk) { LB.after = t.dataset.mk; lbJoin('', true); return; }
    if (t.id === 'onGo') sendChat();
  });
  $('onIn').addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') sendChat(); else if (e.key === 'Escape') closePanel(); });
  $('onIn').addEventListener('keyup', e => e.stopPropagation());
  function sendChat() {
    const w = $('onIn'), t = w.value.trim(); if (!t) return;
    if (LB.mode === 'r') { if (!mpConnected()) { toast('Вы не в комнате'); return; } mpSend({ t: 'chat', text: t }); }
    else if (!lbSend({ t: 'gchat', text: t })) { toast('Нет связи с сервером'); return; }
    w.value = '';
  }
  function lbJoin(code, create) {
    const url = lbUrl();
    $('mpName').value = lbName(); if (!$('mpUrl').value && url) $('mpUrl').value = url;
    $('mpRoom').value = code || '';
    if (G.mode !== 'play') { toast('Сначала начните игру'); return; }
    mpConnect(!!create);
    closePanel();
  }
  // приглашения
  function showInvite(m) {
    LB.inv = m; clearTimeout(LB.invT);
    inv.innerHTML = '📨 <b>' + mpEsc(m.from) + '</b> зовёт вас в комнату <b>' + mpEsc(m.room) + '</b> (' + m.n + '/4)<div class="ib"><button id="invYes">Принять</button><button class="no" id="invNo">Позже</button></div>';
    inv.style.display = 'block'; SFX.click && SFX.click();
    lbLog('sys', '📨 ' + mpEsc(m.from) + ' приглашает в комнату ' + mpEsc(m.room));
    LB.invT = setTimeout(() => { inv.style.display = 'none'; LB.inv = null; }, 30000);
  }
  inv.addEventListener('click', e => {
    const t = e.target.closest('button'); if (!t) return;
    inv.style.display = 'none'; clearTimeout(LB.invT);
    if (t.id === 'invYes' && LB.inv) { const r = LB.inv.room; LB.inv = null; if (G.mode !== 'play') { toast('Сначала начните игру'); return; } lbJoin(r, false); }
  });
  // перехват сообщений комнаты
  const mm0 = mpMsg;
  mpMsg = function (m) {
    mm0(m);
    if (m.t === 'welcome') { lbRender(); if (LB.after) { mpSend({ t: 'invite', to: LB.after }); LB.after = ''; } }
    else if (m.t === 'invited') toast(m.ok ? '📨 Приглашение отправлено: ' + m.name : '⚠ ' + (m.msg || 'Не удалось пригласить'));
    else if (m.t === 'leave' || m.t === 'join') lbRender();
  };
  const cl0 = mpChatLine;
  mpChatLine = function (name, col, text, sys) {
    cl0(name, col, text, sys);
    lbLog(sys ? 'sys' : 'rm', sys ? mpEsc(text) : '<b>🏠 ' + mpEsc(name) + ':</b> ' + mpEsc(text));
  };
  const md0 = mpDisconnect;
  mpDisconnect = function (silent) { md0(silent); lbRender(); };
  // кнопка в окне «Мультиплеер»
  const st = $('mpStatus');
  if (st && !$('mpOnlBtn')) {
    const b = document.createElement('button'); b.className = 'btn'; b.id = 'mpOnlBtn'; b.textContent = '👥 Игроки онлайн и чат'; b.style.margin = '6px 0';
    st.insertAdjacentElement('afterend', b);
    b.addEventListener('click', () => { if (G.mode === 'play') { closeScreens(); } openPanel(); });
  }
  // периодика: автоподключение к лобби в игре, показ кнопки
  setInterval(() => {
    const play = G.mode === 'play' && !G.inHome && !UI.cur;
    onBtn.style.display = play && (LB.st === 'on' || lbUrl()) ? 'block' : 'none';
    if (G.mode === 'play' && !LB.ws && LB.tries < 3 && lbUrl() && ++LB.t >= 3 + LB.tries * 6) { LB.t = 0; lbConnect(); }
    if (G.mode === 'play' && LB.st === 'on' && isOpen() && !mpConnected() === false) lbRender();
  }, 2000);
  window.__v40 = { LB, lbMsg, showInvite };
}

function dmgHud(car) {
  const e = $('dmgFill'), h = car && !car.def.heli ? Math.max(0, 100 - (car.dmg || 0)) : 0;
  e.style.width = h + '%'; e.style.background = 'hsl(' + Math.round(h * 1.15) + ',80%,48%)';
  const s = e.nextElementSibling, tx = '🛡 ПРОЧНОСТЬ ' + Math.round(h) + '%';
  if (s && s._t !== tx) { s._t = tx; s.textContent = tx; }
}
