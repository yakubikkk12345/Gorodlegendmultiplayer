/* ===================== v21: прыжок, эпилог сюжета, гараж-клуб ===================== */

/* --- прыжок --- */
function walkJump(dt, inp, gy) {
  if (!inp.jump) P.jlock = false;
  if (inp.jump && !P.jlock && !(P.jh > 0) && !G.inHome && P.hp > 0) {
    P.jlock = true; P.jv = 7.6; P.jh = 0.01;
    S.stats.jumps = (S.stats.jumps || 0) + 1;
    tone(260, 0.14, 'sine', 0.12, 520, 0);
  }
  if (P.jh > 0) {
    P.jv -= 22 * dt; P.jh += P.jv * dt;
    if (P.jh <= 0) { P.jh = 0; P.jv = 0; tone(90, 0.08, 'sine', 0.1, 60, 0); }
    P.y = gy + P.jh;
  } else P.y += (gy - P.y) * Math.min(1, dt * 14);
}

/* --- Гараж-клуб --- */
const CLUB_FEE = 5000;
const CLUB_RANKS = ['Гость', 'Участник', 'Эксперт', 'Мастер'];
function clubState() {
  if (!S.flags.club || typeof S.flags.club !== 'object') S.flags.club = { m: 0, shows: 0, last: {} };
  return S.flags.club;
}
function clubRank() {
  const c = clubState(); if (!c.m) return 0;
  const n = Object.keys(S.cars).length;
  if (n >= 8 && c.shows >= 8) return 3;
  if (n >= 5 && c.shows >= 3) return 2;
  return 1;
}
function carShowPay(id) {
  const def = CAR_BY_ID[id], rec = S.cars[id]; if (!def || !rec) return 0;
  const u = rec.u || {}, lv = (u.eng || 0) + (u.acc || 0) + (u.tir || 0) + (u.nit || 0);
  const mods = rec.mods ? Object.keys(rec.mods).filter(k => rec.mods[k]).length : 0;
  return Math.round(Math.max(300, (def.price || 0) * 0.03) + lv * 220 + mods * 160);
}
const SHOW_CD = 4 * 60 * 1000;
function clubOptions() {
  const c = clubState(), o = [], rk = clubRank();
  if (TALK.sub === 'show') {
    const ids = Object.keys(S.cars);
    for (const id of ids.slice(0, 10)) {
      const left = ((c.last[id] || 0) + SHOW_CD - Date.now()) / 1000, pay = carShowPay(id);
      o.push({ t: '🚘 ' + CAR_BY_ID[id].name + ' — ' + (left > 0 ? 'отдыхает ' + Math.ceil(left) + ' с' : fmtMoney(pay)), dis: left > 0, fn: () => {
        c.shows++; c.last[id] = Date.now(); addMoney(pay); SFX.cash(); persist();
        const nr = clubRank();
        say('Зал аплодирует! «' + CAR_BY_ID[id].name + '» принёс ' + fmtMoney(pay) + '. Выставок: ' + c.shows + '.' + (nr > rk ? ' 🏅 Новый ранг: ' + CLUB_RANKS[nr] + '!' : ''));
      } });
    }
    o.push({ t: '⬅ Назад', fn: () => { TALK.sub = null; say('Что ещё?'); } });
    return o;
  }
  if (!c.m) {
    o.push({ t: '💳 Вступить в клуб — ' + fmtMoney(CLUB_FEE), dis: S.money < CLUB_FEE, fn: () => {
      S.money -= CLUB_FEE; c.m = 1; refreshMoney(false); SFX.buy(); persist();
      say('Добро пожаловать в «Гараж-клуб»! Ты теперь Участник: +2 места в гараже и взносы от клуба каждую минуту.');
    } });
  } else {
    o.push({ t: '🏆 Автошоу: выставить машину', fn: () => { TALK.sub = 'show'; say('Какую машину покажем публике? Чем больше тюнинга — тем выше награда.'); } });
  }
  o.push({ t: '📊 Мой ранг: ' + CLUB_RANKS[rk], fn: () => say(
    'Ранги: Участник — вступление. Эксперт — 5 машин в гараже и 3 автошоу. Мастер — 8 машин и 8 автошоу. У вас: машин ' + Object.keys(S.cars).length + ', автошоу ' + c.shows + '.') });
  o.push({ t: '🎁 Привилегии клуба', fn: () => say('За каждый ранг: +2 места в гараже и взносы клуба $250 в минуту. Сейчас: +' + rk * 2 + ' мест и $' + rk * 250 + '/мин.') });
  o.push({ t: '❓ Совет', fn: () => say(pick(NPC.club.tips)) });
  o.push(byeOpt());
  return o;
}
function buildClubHouse(WORLD, cx, cz) {
  const G = WORLD.g(), x0 = cx - 22, x1 = cx + 22, z0 = cz - 4, z1 = cz + 20, H = 11;
  const neon = [[1, 0.55, 0.1, 1], [0.1, 0.9, 0.85, 1], [1, 0.2, 0.4, 1]];
  G.box(cx - 31, 0.16, cz - 31, cx + 31, 0.2, cz - 4, [0.24, 0.24, 0.27, 1], false, true);
  G.box(x0, 0.16, z0, x1, H, z1, [0.17, 0.12, 0.12, 1], true, true);
  G.box(x0 - 0.5, H, z0 - 0.5, x1 + 0.5, H + 0.9, z1 + 0.5, [0.08, 0.08, 0.1, 1], false, true);
  for (const k of [-1, 1]) {
    const bx = cx + k * 11;
    G.box(bx - 4.5, 0.2, z0 - 0.3, bx + 4.5, 5.2, z0, [0.3, 0.32, 0.38, 1], false, true);
    G.box(bx - 4.9, 5.2, z0 - 0.6, bx + 4.9, 5.6, z0, neon[k > 0 ? 1 : 0], false, true);
    G.box(bx - 4.9, 0.2, z0 - 0.6, bx - 4.5, 5.2, z0, neon[k > 0 ? 1 : 0], false, true);
    G.box(bx + 4.5, 0.2, z0 - 0.6, bx + 4.9, 5.2, z0, neon[k > 0 ? 1 : 0], false, true);
  }
  G.box(cx - 3, 0.2, z0 - 0.4, cx + 3, 4.2, z0, [0.05, 0.05, 0.07, 1], false, true);
  G.box(cx - 14, 6.4, z0 - 0.8, cx + 14, 10, z0, [0.04, 0.04, 0.07, 1], false, true);
  for (let k = 0; k < 7; k++) G.box(cx - 12 + k * 3.7, 6.9, z0 - 1.0, cx - 10.2 + k * 3.7, 9.5, z0 - 0.8, neon[k % 3], false, true);
  G.box(cx - 14.4, 6.4, z0 - 1.0, cx + 14.4, 6.7, z0 - 0.8, neon[0], false, true);
  G.box(cx - 14.4, 9.8, z0 - 1.0, cx + 14.4, 10.1, z0 - 0.8, neon[0], false, true);
  for (const sx of [-17, 17]) {        // бочки с флажками у входа
    G.box(cx + sx - 0.8, 0.2, z0 - 4, cx + sx + 0.8, 1.6, z0 - 2.4, [0.85, 0.3, 0.1, 1], false, true);
    boxes.push({ x0: cx + sx - 0.8, x1: cx + sx + 0.8, z0: z0 - 4, z1: z0 - 2.4, h: 1.6 });
  }
  boxes.push({ x0, x1, z0, z1, h: H });
}
function buildClubInterior(B, GL, kind) {
  /* платформы с машинами */
  B(-9, 0, -3.6, -4.4, 0.35, 1.2, [0.14, 0.14, 0.17], true); B(-8.7, 0.35, -3.3, -4.7, 0.42, 0.9, [1, 0.55, 0.1]);
  B(-8.4, 0.42, -2.6, -4.9, 0.95, 0.2, [0.85, 0.12, 0.18]); B(-7.7, 0.95, -2.0, -5.6, 1.4, -0.2, [0.2, 0.26, 0.32]);
  B(4.4, 0, -3.6, 9, 0.35, 1.2, [0.14, 0.14, 0.17], true); B(4.7, 0.35, -3.3, 8.7, 0.42, 0.9, [0.1, 0.9, 0.85]);
  B(5, 0.42, -2.6, 8.5, 0.95, 0.2, [0.15, 0.55, 0.9]); B(5.7, 0.95, -2.0, 7.8, 1.4, -0.2, [0.2, 0.26, 0.32]);
  GL(-9, 0.0, -3.65, -4.4, 0.05, -3.6, [1, 0.55, 0.1]); GL(4.4, 0.0, -3.65, 9, 0.05, -3.6, [0.1, 0.9, 0.85]);
  /* бар и диваны */
  B(-9.6, 0, 4.4, -3.6, 1.1, 5.6, [0.3, 0.18, 0.1], true); B(-9.6, 1.1, 4.3, -3.6, 1.2, 5.7, [0.12, 0.1, 0.1]);
  for (let k = 0; k < 4; k++) B(-9 + k * 1.5, 0, 5.8, -8.4 + k * 1.5, 0.6, 6.4, [0.6, 0.2, 0.15], true);
  B(4.4, 0, 5.4, 9.6, 0.5, 7.2, [0.2, 0.2, 0.28], true); B(4.4, 0.5, 6.7, 9.6, 1.3, 7.2, [0.2, 0.2, 0.28]);
  B(0.5, 0, -6.5, 1.6, 1.0, -5.4, [0.9, 0.75, 0.2], true); B(0.8, 1.0, -6.2, 1.3, 1.4, -5.7, [0.9, 0.75, 0.2]);   // кубок
  /* полка с трофеями на задней стене */
  B(-3.6, 1.4, 7.7, 3.6, 1.55, 7.95, [0.35, 0.22, 0.12]); B(-3.6, 2.4, 7.7, 3.6, 2.55, 7.95, [0.35, 0.22, 0.12]);
  for (let k = 0; k < 7; k++) { B(-3.3 + k * 1.0, 1.55, 7.75, -3.0 + k * 1.0, 2.0 + (k % 3) * 0.12, 7.9, [0.9, 0.75, 0.2]); B(-3.3 + k * 1.0, 2.55, 7.75, -3.0 + k * 1.0, 2.9, 7.9, [0.85, 0.85, 0.9]); }
  /* неон */
  GL(-6, 2.8, 7.93, 6, 3.3, 7.98, [1, 0.55, 0.1]); GL(-9.97, 1.4, -1.0, -9.92, 2.8, 3.0, [0.1, 0.9, 0.85]); GL(9.92, 1.4, -1.0, 9.97, 2.8, 3.0, [1, 0.2, 0.4]);
  GL(-9.6, 3.0, -7.98, -1.9, 3.3, -7.93, [1, 0.2, 0.4]); GL(1.9, 3.0, -7.98, 9.6, 3.3, -7.93, [0.1, 0.9, 0.85]);
}

/* --- эпилог сюжета: «Синдикат» --- */
const STORY2 = [
  { t: 'Наследие Лиса', goal: 'Захватите 2 района банд', ok: () => ownedCount() >= 2, prog: () => ownedCount() + ' / 2', reward: 8000,
    intro: 'Лис сбежал, но его люди растащили город на куски — банды делят улицы, а за ними стоит некий «Синдикат». Отбери у банд два района: убивай их бойцов прямо на их территории.',
    outro: 'Два района наши. Синдикат уже в курсе — они злятся. Это хорошо: злой враг ошибается.' },
  { t: 'Свой угол', goal: 'Купите любую недвижимость', ok: () => PROPS.some(p => propOwn(p.id)), prog: () => PROPS.some(p => propOwn(p.id)) ? 'готово' : 'нет объекта', reward: 6000,
    intro: 'Королю нужен трон. Купи любую недвижимость — квартиру, дом, виллу. Там и гараж, и безопасное место, и стабильный доход.',
    outro: 'Своя крыша над головой — первый шаг к настоящей власти. Дальше будет проще.' },
  { t: 'Налёт на казну', goal: 'Ограбьте 5 магазинов или банков', ok: () => (S.stats.robs || 0) >= 5, prog: () => (S.stats.robs || 0) + ' / 5', reward: 10000,
    intro: 'Синдикат держит наличные в магазинах и банках. Ударь по их кассам — ограбь пять точек. Только не попадайся полиции.',
    outro: 'Пять касс — как не бывало. Синдикат считает убытки и скрипит зубами.' },
  { t: 'Клубный человек', goal: 'Достигните ранга «Эксперт» в Гараж-клубе', ok: () => clubRank() >= 2, prog: () => 'ранг: ' + CLUB_RANKS[clubRank()], reward: 15000,
    intro: 'В городе уважают тех, кто водит красиво. Вступи в «Гараж-клуб», собери коллекцию и покажи машины на автошоу — нужен ранг «Эксперт».',
    outro: 'Теперь тебя знают не только по перестрелкам, но и по гаражу. Клуб — это связи, а связи решают.' },
  { t: 'Небо принадлежит нам', goal: 'Посадите вертолёт на 3 разные крыши', ok: () => Object.keys(S.flags.roofs || {}).length >= 3, prog: () => Object.keys(S.flags.roofs || {}).length + ' / 3', reward: 20000,
    intro: 'Синдикат следит за улицами, но не за небом. Купи вертолёт и посади его на три разные крыши — пусть привыкают, что мы везде.',
    outro: 'Три крыши — три метки. Теперь они не знают, откуда ждать удара.' },
  { t: 'Хозяин города', goal: 'Захватите все 12 районов банд', ok: () => ownedCount() >= 12, prog: () => ownedCount() + ' / 12', reward: 100000, final: true,
    intro: 'Последний рывок. Забери у банд все двенадцать районов, и Синдикату будет негде держаться. Тогда город будет твоим по-настоящему.',
    outro: 'Двенадцать районов, ни одной банды. Синдикат ушёл, не прощаясь. Ты — хозяин города, и это не титул, а факт.' }
];
const epiIdx = () => S.story.ch2 | 0;
function epiGreet() {
  const i = epiIdx();
  if (i >= STORY2.length) return 'Хозяин города! Синдикат разбит, районы твои. Заходи в любое время, партнёр.';
  const c = STORY2[i];
  return c.ok() ? 'Слышал, ты справился с «' + c.t + '». Заходи, рассчитаемся.' : 'Эпилог, глава ' + (i + 1) + ' из ' + STORY2.length + ': «' + c.t + '». ' + c.intro;
}
function epiOptions(o) {
  const i = epiIdx();
  if (i >= STORY2.length) {
    o.push({ t: '🏆 Вспомнить путь', fn: () => say('Пицца, гонки, погони, перестрелки, банды и Синдикат. От курьера до хозяина города.') });
    o.push({ t: '💼 Что дальше?', fn: () => say('Доход с районов, бизнесов и недвижимости идёт сам. Собирай коллекцию, выставляй машины в клубе, лети над городом.') });
    return;
  }
  const c = STORY2[i];
  o.push({ t: '📋 Что нужно сделать?', fn: () => say(c.intro + ' Цель: ' + c.goal + ' (' + c.prog() + ').') });
  o.push({ t: c.ok() ? '✅ Сдать — награда ' + fmtMoney(c.reward) : '⏳ ' + c.goal + ' (' + c.prog() + ')', dis: !c.ok(), fn: () => {
    S.story.ch2 = i + 1; addMoney(c.reward); SFX.cash(); persist(); say(c.outro);
  } });
}
const V21 = { epiN: -1, clubT: 0 };
function v21Tick(dt) {
  if (G.mode !== 'play') return;
  const play = !G.paused && !G.inHome;
  if (P.car || G.inHome) { P.jh = 0; P.jv = 0; }
  // сообщить о выполнении цели эпилога
  if (play) {
    const i = epiIdx();
    if (i < STORY2.length && STORY2[i].ok()) { if (V21.epiN !== i) { V21.epiN = i; toast('📖 Цель сюжета «' + STORY2[i].t + '» выполнена — зайдите к Кроту в бар'); SFX.buy(); } }
    else if (V21.epiN === i) V21.epiN = -1;
    // взносы клуба
    V21.clubT += dt;
    if (V21.clubT >= 60) { V21.clubT = 0; const rk = clubRank(); if (rk) { addMoney(rk * 250); toast('🏁 Взносы Гараж-клуба: +' + fmtMoney(rk * 250)); } }
  }
}

