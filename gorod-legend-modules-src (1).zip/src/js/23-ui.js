/* ===================== 19. ИНТЕРФЕЙС ===================== */
const UI = { cur: null, stack: [], studio: false, shopSel: 'hatch', garSel: null, cfm: null, touchMode: false };
const SCREENS = ['slots', 'menu', 'pause', 'missions', 'garage', 'shop', 'settings', 'help', 'result', 'mapScreen', 'confirm', 'gunshop', 'talk', 'ach', 'style', 'mp', 'casino', 'guards'];
const ST = { open: false, mode: 'cloth', tab: 'top', pv: null, zoom: 0 };
function showScreen(name) {
  if (ST.open && name !== 'style') leaveStyle();
  SCREENS.forEach(s => $(s).classList.toggle('show', s === name));
  UI.cur = name; UI.studio = (name === 'garage' || name === 'shop'); document.body.classList.toggle('studio', UI.studio);
  if (name === 'missions') renderMissions();
  else if (name === 'garage') renderGarage();
  else if (name === 'shop') renderShop();
  else if (name === 'gunshop') renderGunshop();
  else if (name === 'talk') renderTalk();
  else if (name === 'style') renderStyle();
  else if (name === 'ach') renderAch();
  else if (name === 'settings') renderSettings();
  else if (name === 'mapScreen') drawFullMap();
  else if (name === 'slots') renderSlots();
  else if (name === 'mp') mpFillScreen();
  else if (name === 'casino') casRender();
  else if (name === 'guards') guardsRender();
  else if (name === 'menu') { $('btnContinue').style.display = S.started ? '' : 'none'; $('btnContinue').textContent = '▶ Продолжить · слот ' + SLOT; }
  refreshMoney(false);
}
function openScreen(name) {
  if (UI.cur) UI.stack.push(UI.cur);
  showScreen(name);
  if (G.mode === 'play') G.paused = true;
}
function backScreen() {
  const prev = UI.stack.pop();
  if (prev) showScreen(prev); else closeScreens();
}
function closeScreens() {
  if (ST.open) leaveStyle();
  UI.stack = []; UI.cur = null; UI.studio = false; document.body.classList.remove('studio');
  SCREENS.forEach(s => $(s).classList.remove('show'));
  if (G.mode === 'play') G.paused = false; else if (G.mode === 'menu') showScreen('menu');
}
function askConfirm(text, fn) { UI.cfm = fn; $('cfmText').textContent = text; openScreen('confirm'); }

function toast(text) {
  const box = $('toasts'); if (!box) return;
  const d = document.createElement('div'); d.className = 'toast'; d.textContent = text; box.appendChild(d);
  while (box.children.length > 4) box.removeChild(box.firstChild);
  setTimeout(() => { d.classList.add('out'); setTimeout(() => d.remove(), 400); }, 2600);
}
function floatMoney(text) {
  const d = document.createElement('div'); d.className = 'floatfx'; d.textContent = text; $('floatFx').appendChild(d);
  setTimeout(() => d.remove(), 1500);
}
function showCountdown(t) {
  const el = $('countdown'); el.textContent = t; el.classList.remove('pop'); void el.offsetWidth; if (t) el.classList.add('pop');
}
function fadeThen(fn) {
  const f = $('fade'); f.classList.add('on');
  setTimeout(() => { try { fn(); } catch (e) { console.error(e); } f.classList.remove('on'); }, 300);
}
let shownMoney = -1;
function refreshMoney(pulse) {
  const t = fmtMoney(S.money);
  document.querySelectorAll('[data-money]').forEach(e => { e.textContent = t; });
  const m = $('money'); if (m && pulse) { m.classList.remove('pulse'); void m.offsetWidth; m.classList.add('pulse'); }
}
const fmtTime = s => { s = Math.max(0, s); return Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0'); };

/* --- Задания --- */
function medalIcon(m) { return m === 3 ? '🥇' : m === 2 ? '🥈' : m === 1 ? '🥉' : ''; }
function renderMissions() {
  const done = MISSIONS.filter(m => S.missions[m.id] && S.missions[m.id].done).length;
  $('missProg').textContent = 'Выполнено: ' + done + ' / ' + MISSIONS.length;
  const typeName = { delivery: 'Доставка', checkpoints: 'На время', race: 'Гонка', collect: 'Сбор', drift: 'Дрифт', chase: 'Погоня', shootout: 'Перестрелка' };
  $('missionList').innerHTML = MISSIONS.map((m, i) => {
    const r = S.missions[m.id] || {};
    return '<div class="card mission' + (r.done ? ' done' : '') + '">' +
      '<div class="m-ico">' + m.icon + '</div>' +
      '<div class="m-body"><div class="m-title">' + (i + 1) + '. ' + m.name + ' ' + medalIcon(r.medal) + '</div>' +
      '<div class="m-desc">' + m.desc + '</div>' +
      '<div class="tags"><span class="tag">' + typeName[m.type] + '</span>' +
      (m.time ? '<span class="tag">⏱ ' + fmtTime(m.time) + '</span>' : '') +
      (m.needCar ? '<span class="tag">🚗 нужна машина</span>' : '<span class="tag">🚶 можно пешком</span>') +
      '<span class="tag gold">' + fmtMoney(m.reward) + '</span>' +
      (r.done && r.best ? '<span class="tag">лучшее: ' + fmtTime(r.best) + '</span>' : '') + '</div></div>' +
      '<button class="btn small" data-start="' + m.id + '">' + (r.done ? 'Повторить' : 'Старт') + '</button></div>';
  }).join('');
}
function showResult(r) {
  UI.stack = []; if (G.mode === 'play') G.paused = true;
  const medals = r.ok ? '<div class="medal">' + medalIcon(r.medal) + '</div>' : '<div class="medal fail">💥</div>';
  let body = '<div class="res-name">' + r.def.icon + ' ' + r.def.name + '</div>';
  body += '<div class="res-line">Время: <b>' + fmtTime(r.t) + '</b></div>';
  if (r.pos) body += '<div class="res-line">Место в гонке: <b>' + r.pos + '</b></div>';
  if (r.ok) {
    body += '<div class="res-line">Награда: <b class="gold">' + fmtMoney(r.reward) + '</b>' + (r.first ? '' : ' <small>(повтор: 50%)</small>') + '</div>';
    if (r.bonus) body += '<div class="res-line">Бонус за медаль: <b class="gold">+' + fmtMoney(r.bonus) + '</b></div>';
    const left = MISSIONS.filter(m => !(S.missions[m.id] && S.missions[m.id].done)).length;
    if (!left) body += '<div class="res-line big">👑 Вы прошли все задания! Вы — Легенда города!</div>';
  } else body += '<div class="res-line bad">' + (r.msg || 'Задание провалено') + '</div>';
  $('resTitle').textContent = r.ok ? 'ЗАДАНИЕ ВЫПОЛНЕНО!' : 'ЗАДАНИЕ ПРОВАЛЕНО';
  $('resTitle').className = r.ok ? 'ok' : 'bad';
  $('resBody').innerHTML = medals + body;
  showScreen('result');
}

/* --- Гараж --- */
function statBars(def, upg) {
  const st = statsFor(def, upg);
  const row = (n, v) => '<div class="bar"><span>' + n + '</span><i><b style="width:' + clamp(v, 4, 100) + '%"></b></i></div>';
  return row('Скорость', st.maxSpeed / 90 * 100) + row('Ускорение', st.accel / 32 * 100) + row('Управление', st.handling / 1.7 * 100) + row('Нитро', st.nitro / 1.8 * 100);
}
function renderGarage() {
  const ids = Object.keys(S.cars);
  if (!UI.garSel || !S.cars[UI.garSel]) UI.garSel = S.sel;
  const id = UI.garSel, def = CAR_BY_ID[id], rec = S.cars[id];
  STUDIO.def = def; STUDIO.color = rec.color; STUDIO.mods = rec.mods || null;
  $('garTitle').textContent = UI.tuneMode ? 'Тюнинг-центр' : 'Гараж';
  let h = '<div class="chips">' + ids.map(i => '<button class="chip' + (i === id ? ' on' : '') + '" data-gsel="' + i + '">' + CAR_BY_ID[i].name + (i === S.sel ? ' ✔' : '') + '</button>').join('') + '</div>';
  h += '<h3>' + def.name + '</h3><p class="muted">' + def.desc + '</p>' + statBars(def, rec.u);
  h += '<div class="row-btn">' + (id === S.sel ? '<span class="tag gold">Выбрана для езды</span>' : '<button class="btn small" data-use="' + id + '">Выбрать эту машину</button>') + '</div>';
  h += '<h4>Улучшения</h4>';
  for (const u of UPGRADES) {
    const lvl = rec.u[u.key], cost = upgCost(def, lvl), max = lvl >= MAX_UPG;
    h += '<div class="upg"><div class="u-ico">' + u.icon + '</div><div class="u-body"><b>' + u.name + '</b><small>' + u.desc + '</small>' +
      '<div class="pips">' + [0, 1, 2, 3, 4].map(k => '<i class="' + (k < lvl ? 'on' : '') + '"></i>').join('') + '</div></div>' +
      '<button class="btn small" data-upg="' + u.key + '"' + (max || S.money < cost ? ' disabled' : '') + '>' + (max ? 'МАКС' : fmtMoney(cost)) + '</button></div>';
  }
  h += '<h4>Покраска (бесплатно)</h4><div class="swatches">' + COLORS.map(c => '<button class="sw' + (c === rec.color ? ' on' : '') + '" style="background:' + c + '" data-paint="' + c + '" aria-label="цвет"></button>').join('') + '</div>';
  if (UI.tuneMode) h += modsHTML(def, rec);
  $('garPanel').innerHTML = h;
}
const LBL = {};
function mkLbl(m) { const d = document.createElement('div'); d.className = 'wlabel'; d.innerHTML = (m.short || m.label) + '<small>E</small>'; $('lblObj').parentNode.appendChild(d); return d; }
function selectCar(id) {
  if (!S.cars[id]) return;
  const old = OWN, wasIn = old && P.car === old;
  let x = old ? old.x : P.x, z = old ? old.z : P.z, hh = old ? old.h : P.h;
  if (!old && G.inHome) { const r = nearestRoad(34, -1.5, -1, 0); x = r.x; z = r.z; hh = r.h; }
  S.sel = id;
  if (G.mode === 'play') {
    const nc = spawnOwn(x, z, hh);
    if (wasIn) { P.car = null; seatPlayer(nc); }
  }
  persist(); SFX.click();
}
function upgradeCar(key) {
  const id = UI.garSel, def = CAR_BY_ID[id], rec = S.cars[id], lvl = rec.u[key], cost = upgCost(def, lvl);
  if (lvl >= MAX_UPG) return;
  if (S.money < cost) { SFX.err(); toast('Не хватает денег'); return; }
  S.money -= cost; rec.u[key]++; SFX.buy(); persist(); refreshMoney(true);
  if (OWN && S.sel === id) refreshOwnStats();
  renderGarage();
}
function paintCar(c) {
  const id = UI.garSel; S.cars[id].color = c; SFX.click(); persist();
  if (OWN && S.sel === id) setCarColor(OWN, c);
  renderGarage();
}

/* --- Магазин --- */
function renderShop() {
  const sel = UI.shopSel, def = CAR_BY_ID[sel];
  STUDIO.def = def; STUDIO.color = (S.cars[sel] && S.cars[sel].color) || def.color; STUDIO.mods = (S.cars[sel] && S.cars[sel].mods) || null;
  const full = carCount() >= garageCap();
  $('shopList').innerHTML = '<div class="muted" style="padding:4px 2px">🅿 Гараж: ' + carCount() + ' из ' + garageCap() + ' мест' + (full ? ' — нужна недвижимость с гаражом' : '') + '</div>' + CARS.map(c => {
    const own = !!S.cars[c.id];
    return '<div class="card car' + (c.id === sel ? ' sel' : '') + '" data-shopsel="' + c.id + '"><div class="c-body"><b>' + c.name + '</b><small>' + Math.round(c.speed * 3.6) + ' км/ч · ' + c.desc + '</small></div>' +
      (own ? '<span class="tag">В гараже</span>' : '<button class="btn small" data-buy="' + c.id + '"' + (S.money < c.price || full ? ' disabled' : '') + '>' + fmtMoney(c.price) + '</button>') + '</div>';
  }).join('');
  $('shopInfo').innerHTML = '<h3>' + def.name + '</h3><p class="muted">' + def.desc + '</p>' + statBars(def, S.cars[sel] ? S.cars[sel].u : null);
}
function buyCar(id) {
  const def = CAR_BY_ID[id];
  if (S.cars[id]) return;
  if (carCount() >= garageCap()) { SFX.err(); toast('🅿 Нет места в гараже! Купите недвижимость с гаражом'); return; }
  if (S.money < def.price) { SFX.err(); toast('Недостаточно денег'); return; }
  S.money -= def.price;
  S.cars[id] = { u: { eng: 0, acc: 0, tir: 0, nit: 0 }, color: def.color };
  SFX.buy(); persist(); refreshMoney(true);
  toast('🚘 Куплено: ' + def.name);
  askConfirm('Сесть за руль новой машины «' + def.name + '» прямо сейчас?', () => { selectCar(id); UI.garSel = id; });
}

/* --- Настройки --- */
function renderSettings() {
  const s = S.set;
  $('setSfx').value = s.sfx; $('setMus').value = s.music; $('setSens').value = s.sens;
  $('setQ').value = s.quality; $('setSeason').value = s.season || 'winter'; $('setTouch').value = s.touch; $('setTraffic').value = String(s.traffic); $('setFps').checked = !!s.fps; $('setShake').checked = s.shake !== false; $('setMph').checked = !!s.mph; $('setHints').checked = s.hints !== false; $('setLefty').checked = !!s.lefty;
}
function applyTouchMode() {
  const m = S.set.touch; UI.touchMode = m === 'on' || (m === 'auto' && isTouch());
  document.body.classList.toggle('touch', UI.touchMode);
  document.body.classList.toggle('lefty', !!S.set.lefty);
}
function bindSettings() {
  const upd = () => {
    const s = S.set;
    s.sfx = +$('setSfx').value; s.music = +$('setMus').value; s.sens = +$('setSens').value;
    s.quality = $('setQ').value; s.season = $('setSeason').value; s.touch = $('setTouch').value; s.traffic = +$('setTraffic').value; s.fps = $('setFps').checked;
    s.shake = $('setShake').checked; s.mph = $('setMph').checked; s.hints = $('setHints').checked; s.lefty = $('setLefty').checked;
    auVolumes(); applyTouchMode(); applyQuality(); $('fps').style.display = s.fps ? 'block' : 'none'; persist();
  };
  ['setSfx', 'setMus', 'setSens', 'setQ', 'setSeason', 'setTouch', 'setTraffic', 'setFps', 'setShake', 'setMph', 'setHints', 'setLefty'].forEach(id => $(id).addEventListener('input', upd));
  $('setSfx').addEventListener('change', () => SFX.coin());
}
function toggleFullscreen() {
  const el = document.documentElement;
  try {
    if (!document.fullscreenElement) {
      (el.requestFullscreen || el.webkitRequestFullscreen).call(el);
      if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => { });
    } else (document.exitFullscreen || document.webkitExitFullscreen).call(document);
  } catch (e) { toast('Полный экран недоступен в этом браузере'); }
}

/* --- Старт/выход из игры --- */
function resetProgress() {
  WS.mag = {}; WS.reload = 0;
  const set = S.set; S = defaultSave(); S.set = set; persist();
  OWN && removeCar(OWN); OWN = null; DR.total = 0;
}
function enterGame(isNew) {
  auInit();
  if (isNew) resetProgress();
  clearWanted();
  S.started = true;
  G.mode = 'play'; G.paused = false; setHomeState(false); applyLook();
  $('hud').classList.remove('hidden');
  closeScreens();
  if (P.car) { P.car.driver = null; P.car = null; }
  const p = S.pos && !isNew ? S.pos : homeDoorPos();
  P.x = clamp(p.x, -EDGE, EDGE); P.z = clamp(p.z, -EDGE, EDGE); P.y = terrainY(P.x, P.z); P.vis = true; P.speed = 0;
  pushCircle(P, 0.6);
  P.h = 0; CAM.yaw = 0; CAM.off = 0;
  const r = nearestRoad(P.x - 6, P.z - 18, -1, 0);
  spawnOwn(r.x, r.z, r.h);
  persist(); refreshMoney(false);
  if (isNew) setTimeout(() => toast('Добро пожаловать в Город Легенд! Это ваш дом: зайдите на жёлтую метку. Откройте 📋 Задания или исследуйте улицы.'), 600);
}
function toMenu() {
  cleanupMission(); clearWanted();
  if (P.car) exitCar(true);
  if (G.inHome) { const d = (G.int && G.int.ret) || homeDoorPos(); setHomeState(false); P.x = d.x; P.z = d.z; P.y = 0; }
  S.pos = { x: P.x, z: P.z }; persist();
  G.mode = 'menu'; G.paused = false; P.vis = false;
  $('hud').classList.add('hidden');
  auEngine(false, 0, 0, false); auSiren(0);
  UI.stack = []; showScreen('menu');
}
function togglePause() {
  if (G.mode !== 'play') return;
  if (UI.cur === 'result') return;
  if (UI.cur === 'pause') closeScreens();
  else if (UI.cur) backScreen();
  else openScreen('pause');
}

/* --- Действия кнопок --- */
function act(a, el) {
  auInit();
  switch (a) {
    case 'continue': SFX.click(); enterGame(false); break;
    case 'newgame': SFX.click(); if (S.started) askConfirm('Начать новую игру? Весь текущий прогресс будет удалён.', () => enterGame(true)); else enterGame(true); break;
    case 'style-close': SFX.back(); backScreen(); break;
    case 'style-rot': SFX.click(); P.h += Math.PI / 2; break;
    case 'style-zoom': SFX.click(); ST.zoom = ST.zoom ? 0 : 1; break;
    case 'open-missions': SFX.click(); openScreen('missions'); break;
    case 'open-garage': SFX.click(); UI.garSel = null; UI.tuneMode = false; openScreen('garage'); break;
    case 'open-shop': SFX.click(); openScreen('shop'); break;
    case 'open-settings': SFX.click(); openScreen('settings'); break;
    case 'open-help': SFX.click(); openScreen('help'); break;
    case 'open-ach': SFX.click(); openScreen('ach'); break;
    case 'open-map': SFX.click(); openScreen('mapScreen'); break;
    case 'open-mp': SFX.click(); openScreen('mp'); break;
    case 'mp-create': SFX.click(); mpConnect(true); break;
    case 'mp-join': SFX.click(); mpConnect(false); break;
    case 'mp-leave': SFX.click(); mpDisconnect(); break;
    case 'mp-invite': SFX.click(); mpInvite(); break;
    case 'mp-race': { SFX.click(); if (!mpConnected()) break; const why = v30Can(true); if (why) { toast('🏁 ' + why); SFX.err(); break; } mpSend({ t: 'race-open', route: +$('rcRoute').value, laps: +$('rcLaps').value }); closeScreens(); break; }
    case 'mp-arena': { SFX.click(); if (!mpConnected()) break; const why = v30Can(false); if (why) { toast('⚔ ' + why); SFX.err(); break; } mpSend({ t: 'arena-open', target: +$('arTarget').value }); closeScreens(); break; }
    case 'mp-trade': SFX.click(); tradeStart(); break;
    case 'open-slots': SFX.click(); openScreen('slots'); break;
    case 'slot-load': SFX.click(); { const n = +el.dataset.slot; switchSlot(n); enterGame(false); toast('💾 Загружен слот ' + n); } break;
    case 'slot-new': SFX.click(); { const n = +el.dataset.slot; switchSlot(n); enterGame(true); } break;
    case 'slot-del': { const n = +el.dataset.slot; askConfirm('Удалить слот ' + n + '? Прогресс будет потерян.', () => {
      if (n === SLOT) { if (G.mode === 'play') toMenu(); resetProgress(); }
      try { localStorage.removeItem(slotKey(n)); } catch (e) { }
      showScreen('slots'); toast('🗑 Слот ' + n + ' удалён');
    }); break; }
    case 'slot-export': SFX.click(); exportSave(); break;
    case 'slot-import': SFX.click(); $('slotFile').click(); break;
    case 'slot-copy': SFX.click(); copySaveCode(); break;
    case 'slot-paste': SFX.click(); showCodeBox(true); break;
    case 'code-apply': SFX.click(); applyCodeBox(); break;
    case 'code-close': SFX.click(); showCodeBox(false); break;
    case 'back': SFX.back(); backScreen(); break;
    case 'open-guards': SFX.click(); openScreen('guards'); break;
    case 'guard-hire': if ((S.guards | 0) < GUARD_MAX && S.money >= GUARD_PRICE) { S.money -= GUARD_PRICE; S.guards = (S.guards | 0) + 1; SFX.buy(); persist(); refreshMoney(false); guardsRender(); toast('🛡 Телохранитель нанят'); } else SFX.err(); break;
    case 'guard-fire': if ((S.guards | 0) > 0) { S.guards--; persist(); guardsRender(); SFX.click(); } break;
    case 'cas-tab': case 'cas-bet': case 'cas-roul': case 'cas-bj': case 'cas-slot': case 'cas-pk': case 'cas-vp': casAct(a, el); break;
    case 'resume': SFX.click(); closeScreens(); break;
    case 'pause': SFX.click(); togglePause(); break;
    case 'cancel-mission': SFX.click(); cancelMission(); closeScreens(); break;
    case 'to-menu': SFX.click(); toMenu(); break;
    case 'res-next': SFX.click(); closeScreens(); break;
    case 'res-retry': SFX.click(); if (lastMissionId) startMission(lastMissionId); break;
    case 'res-list': SFX.click(); UI.stack = []; showScreen('missions'); break;
    case 'fullscreen': toggleFullscreen(); break;
    case 'reset-progress': askConfirm('Удалить весь прогресс, деньги и машины?', () => { resetProgress(); toast('Прогресс удалён'); UI.stack = []; if (G.mode === 'play') toMenu(); else showScreen('menu'); }); break;
    case 'cfm-yes': { const f = UI.cfm; UI.cfm = null; SFX.click(); backScreen(); if (f) f(); break; }
    case 'cfm-no': SFX.back(); UI.cfm = null; backScreen(); break;
  }
}

/* --- Навигатор: кратчайший путь по сетке дорог --- */
const NAV = { on: false, x: 0, z: 0, path: [], dist: 0, t: 0 };
const NAVN = GRID + 1, NAVV = NAVN * NAVN;
const navId = (i, j) => i * NAVN + j;
function navSnap(x, z) {
  const li = clamp(Math.round((x + HALF) / PITCH), 0, GRID), lj = clamp(Math.round((z + HALF) / PITCH), 0, GRID);
  const dv = Math.abs(x - nodeC(li)), dh = Math.abs(z - nodeC(lj));
  if (dv <= dh) { const zz = clamp(z, -HALF, HALF); return { x: nodeC(li), z: zz, v: true, line: li, seg: clamp(Math.floor((zz + HALF) / PITCH), 0, GRID - 1) }; }
  const xx = clamp(x, -HALF, HALF);
  return { x: xx, z: nodeC(lj), v: false, line: lj, seg: clamp(Math.floor((xx + HALF) / PITCH), 0, GRID - 1) };
}
const navEnds = s => s.v ? [navId(s.line, s.seg), navId(s.line, s.seg + 1)] : [navId(s.seg, s.line), navId(s.seg + 1, s.line)];
const navPt = id => [nodeC(Math.floor(id / NAVN)), nodeC(id % NAVN)];
function navRoute() {
  const sx = P.car ? P.car.x : P.x, sz = P.car ? P.car.z : P.z;
  const a = navSnap(sx, sz), b = navSnap(NAV.x, NAV.z);
  const S_ = NAVV, T_ = NAVV + 1, n = NAVV + 2;
  const adj = []; for (let k = 0; k < n; k++) adj.push([]);
  const edge = (u, v, w) => { adj[u].push([v, w]); adj[v].push([u, w]); };
  for (let i = 0; i < NAVN; i++) for (let j = 0; j < NAVN; j++) {
    if (i + 1 < NAVN) edge(navId(i, j), navId(i + 1, j), PITCH);
    if (j + 1 < NAVN) edge(navId(i, j), navId(i, j + 1), PITCH);
  }
  for (const [s, id] of [[a, S_], [b, T_]]) for (const e of navEnds(s)) { const q = navPt(e); edge(id, e, Math.hypot(q[0] - s.x, q[1] - s.z)); }
  if (a.v === b.v && a.line === b.line && a.seg === b.seg) edge(S_, T_, Math.hypot(a.x - b.x, a.z - b.z));
  const dist = new Array(n).fill(Infinity), prev = new Array(n).fill(-1), done = new Array(n).fill(false);
  dist[S_] = 0;
  for (let it = 0; it < n; it++) {
    let u = -1; for (let k = 0; k < n; k++) if (!done[k] && (u < 0 || dist[k] < dist[u])) u = k;
    if (u < 0 || dist[u] === Infinity || u === T_) break;
    done[u] = true;
    for (const [v, w] of adj[u]) if (dist[u] + w < dist[v]) { dist[v] = dist[u] + w; prev[v] = u; }
  }
  const pts = []; for (let u = T_; u >= 0; u = prev[u]) pts.push(u === S_ ? [a.x, a.z] : u === T_ ? [b.x, b.z] : navPt(u));
  pts.reverse();
  const path = [[sx, sz]].concat(pts, [[NAV.x, NAV.z]]);
  let d = 0; for (let k = 1; k < path.length; k++) d += Math.hypot(path[k][0] - path[k - 1][0], path[k][1] - path[k - 1][1]);
  NAV.path = path; NAV.dist = d;
}
function navSet(x, z, force) {
  if (!force && JOB.state !== 'idle') { toast('🚕 Сначала завершите заказ такси'); return; }
  if (!force) S.flags.nav = true;
  NAV.job = !!force; NAV.on = true; NAV.x = x; NAV.z = z; NAV.t = 0; navRoute(); if (!force) { SFX.click(); toast('🧭 Маршрут проложен: ' + Math.round(NAV.dist) + ' м'); } }
function navClear(force) {
  if (!force && JOB.state !== 'idle') { toast('🚕 Сначала завершите заказ такси'); return false; }
  NAV.job = false; NAV.on = false; NAV.path = []; $('navBox').style.display = 'none'; return true;
}
const pjBoxEl = document.createElement('div'); pjBoxEl.id = 'pjBox'; document.body.appendChild(pjBoxEl);
const navBoxEl = document.createElement('div'); navBoxEl.id = 'navBox'; navBoxEl.title = 'Нажмите, чтобы убрать маршрут'; document.body.appendChild(navBoxEl);
navBoxEl.addEventListener('click', () => { if (navClear()) toast('🧭 Метка убрана'); });
function navTick(dt) {
  const box = $('navBox');
  if (!NAV.on) return;
  if (G.mode !== 'play' || G.inHome) { box.style.display = 'none'; return; }
  const px = P.car ? P.car.x : P.x, pz = P.car ? P.car.z : P.z;
  if (!NAV.job && Math.hypot(NAV.x - px, NAV.z - pz) < 12) { navClear(); toast('🧭 Вы прибыли!'); SFX.cash(); return; }
  if ((NAV.t += dt) > 0.7) { NAV.t = 0; navRoute(); }
  box.style.display = 'block'; setText(box, '🧭 ' + (NAV.dist >= 1000 ? (NAV.dist / 1000).toFixed(1) + ' км' : Math.round(NAV.dist) + ' м') + ' ✕');
}
/* --- HUD --- */
const mm = $('minimap'), mmc = mm.getContext('2d'), big = $('bigMap'), bigc = big.getContext('2d');
big.addEventListener('click', ev => {
  if (G.mode !== 'play') return;
  const r = big.getBoundingClientRect(), px = (ev.clientX - r.left) * big.width / r.width, py = (ev.clientY - r.top) * big.height / r.height;
  const s = big.width / (2 * HALF + 60), wx = (px - big.width / 2) / s, wz = (py - big.height / 2) / s;
  if (NAV.on && Math.hypot(wx - NAV.x, wz - NAV.z) < 26) { if (navClear()) { SFX.click(); toast('🧭 Метка убрана'); } }
  else if (Math.abs(wx) <= HALF + 8 && Math.abs(wz) <= HALF + 8) navSet(wx, wz);
  drawFullMap();
});

function mapXform(ctx, w, h, cx, cz, fx, fz, s) {
  const a = -s * fz, c = s * fx, b = -s * fx, d = -s * fz;
  ctx.setTransform(a, b, c, d, w / 2 - (a * cx + c * cz), h / 2 - (b * cx + d * cz));
  return { a, b, c, d, e: w / 2 - (a * cx + c * cz), f: h / 2 - (b * cx + d * cz) };
}
function drawMap(ctx, w, h, cx, cz, fx, fz, s, full) {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = '#10151f'; ctx.fillRect(0, 0, w, h);
  const T = mapXform(ctx, w, h, cx, cz, fx, fz, s);
  for (let bi = 0; bi < GRID; bi++) for (let bj = 0; bj < GRID; bj++) {
    ctx.fillStyle = blockType[bi] && blockType[bi][bj] === 'park' ? '#1d4a2c' : '#1b2335';
    ctx.fillRect(bc(bi) - 32, bc(bj) - 32, 64, 64);
  }
  drawDistricts(ctx, full);
  ctx.strokeStyle = '#46506a'; ctx.lineWidth = ROAD; ctx.lineCap = 'butt';
  ctx.beginPath();
  for (let k = 0; k <= GRID; k++) { const v = nodeC(k); ctx.moveTo(v, -HALF - 8); ctx.lineTo(v, HALF + 8); ctx.moveTo(-HALF - 8, v); ctx.lineTo(HALF + 8, v); }
  ctx.stroke();
  if (NAV.on && NAV.path.length > 1) {
    ctx.strokeStyle = '#ff3df2'; ctx.lineWidth = (full ? 7 : 5) / s; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.beginPath(); NAV.path.forEach((q, i) => { if (i) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }); ctx.stroke();
    ctx.lineCap = 'butt';
  }
  if (WANT.stars > 0 && WANT.zone) {
    const zn = WANT.zone, zph = Math.floor(G.time * 3) % 2;
    ctx.fillStyle = zph ? 'rgba(255,40,50,0.22)' : 'rgba(40,90,255,0.22)';
    ctx.strokeStyle = zph ? 'rgba(255,70,80,0.9)' : 'rgba(80,130,255,0.9)';
    ctx.lineWidth = (full ? 3 : 2.5) / s;
    ctx.beginPath(); ctx.arc(zn.x, zn.z, zn.r, 0, TAU); ctx.fill(); ctx.stroke();
  }
  drawAccidents(ctx, full, s);
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  const sc = (x, z) => [T.a * x + T.c * z + T.e, T.b * x + T.d * z + T.f];
  const dot = (x, z, col, r) => { const p = sc(x, z); if (p[0] < -10 || p[1] < -10 || p[0] > w + 10 || p[1] > h + 10) return; ctx.fillStyle = col; ctx.beginPath(); ctx.arc(p[0], p[1], r, 0, TAU); ctx.fill(); };
  const R = full ? 6 : 4;
  if (full) drawDistLabels(ctx, sc);
  for (const a of ACC.list) dot(a.x, a.z, '#ff7a00', R + 1);
  for (const e of GANG.units) dot(e.x, e.z, GANGS[e.gang].col, R - 1);
  if (!full) for (const c of cash) if (c.t <= 0) dot(c.x, c.z, '#3dff8a', 2);
  for (const e of WANT.units) dot(e.x, e.z, '#3a7bff', R - 1);
  for (const c of WANT.cars) dot(c.x, c.z, Math.floor(G.time * 4) % 2 ? '#ff2b2b' : '#2b6bff', R);
  for (const b of WANT.blocks) dot(b.x, b.z, Math.floor(G.time * 4) % 2 ? '#ff2b2b' : '#2b6bff', R + 2);
  if (WANT.heli) dot(WANT.heli.x, WANT.heli.z, Math.floor(G.time * 5) % 2 ? '#ffffff' : '#ff4d4d', R + 1);
  for (const m of WORLD_MARKS) { if (m.int) continue; dot(m.x, m.z, m.dot || '#3dff8a', R + 1); }
  if (OWN && !P.car) dot(OWN.x, OWN.z, '#9ad', R - 1);
  mpDots(dot, R);
  if (EV.thief) dot(EV.thief.x, EV.thief.z, Math.floor(G.time * 4) % 2 ? '#ff7a00' : '#ffd60a', R + 1);
  if (EV.wallet) dot(EV.wallet.x, EV.wallet.z, '#ffd60a', R);
  if (JOB.state === 'pickup' && JOB.ped) dot(JOB.ped.x, JOB.ped.z, '#ffd60a', R + 1);
  if (M && M.enemies) for (const e of M.enemies) dot(e.x, e.z, '#ff4d4d', R - 1);
  if (M) { for (const c of M.racers) dot(c.x, c.z, '#ff9f1c', R); for (const c of M.cops) dot(c.x, c.z, Math.floor(G.time * 4) % 2 ? '#ff2b2b' : '#2b6bff', R); }
  const tg = missionTargets();
  tg.forEach((t, i) => {
    const p = sc(t.x, t.z), col = 'rgb(' + Math.round(t.c[0] * 255) + ',' + Math.round(t.c[1] * 255) + ',' + Math.round(t.c[2] * 255) + ')';
    const rad = w / 2 - 8;
    let x = p[0], y = p[1];
    const dx = x - w / 2, dy = y - h / 2, dd = Math.hypot(dx, dy);
    if (!full && dd > rad) { x = w / 2 + dx / dd * rad; y = h / 2 + dy / dd * rad; }
    ctx.fillStyle = col; ctx.strokeStyle = '#000'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(x, y, i === 0 ? R + 2 : R - 1, 0, TAU); ctx.fill(); ctx.stroke();
  });
  if (NAV.on) {
    const p = sc(NAV.x, NAV.z); let x = p[0], y = p[1];
    const dx0 = x - w / 2, dy0 = y - h / 2, dd = Math.hypot(dx0, dy0), rad = w / 2 - 8;
    if (!full && dd > rad) { x = w / 2 + dx0 / dd * rad; y = h / 2 + dy0 / dd * rad; }
    ctx.fillStyle = '#ff3df2'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(x, y, R + 3, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, 2.5, 0, TAU); ctx.fill();
  }
  // игрок
  const pp = sc(P.x, P.z), hx = Math.sin(P.h), hz = Math.cos(P.h);
  let dx = T.a * hx + T.c * hz, dy = T.b * hx + T.d * hz; const dl = Math.hypot(dx, dy) || 1; dx /= dl; dy /= dl;
  const sz = full ? 11 : 9;
  ctx.fillStyle = '#fff'; ctx.strokeStyle = '#e63946'; ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(pp[0] + dx * sz, pp[1] + dy * sz);
  ctx.lineTo(pp[0] - dx * sz * 0.7 - dy * sz * 0.7, pp[1] - dy * sz * 0.7 + dx * sz * 0.7);
  ctx.lineTo(pp[0] - dx * sz * 0.7 + dy * sz * 0.7, pp[1] - dy * sz * 0.7 - dx * sz * 0.7);
  ctx.closePath(); ctx.fill(); ctx.stroke();
}
function drawFullMap() {
  const s = big.width / (2 * HALF + 60);
  drawMap(bigc, big.width, big.height, 0, 0, 0, -1, s, true);
}
let hudAcc = 0, lastSpeedTxt = '', mmAcc = 0;
function setText(el, t) { if (el._t !== t) { el._t = t; el.textContent = t; } }
function updateHUD(dt) {
  const car = P.car;
  const kmh = car ? Math.abs(car.vf) * 3.6 : P.speed * 3.6;
  setText($('speedNum'), String(Math.round(kmh * (S.set.mph ? 0.6214 : 1))));
  $('speedBar').style.width = (car ? clamp(Math.abs(car.vf) / (car.st.maxSpeed * 1.3), 0, 1) * 100 : 0) + '%';
  $('nitroFill').style.width = (car ? car.nitro * 100 : 0) + '%';
  if (car && !car.def.heli) carInit(car);
  $('fuelFill').style.width = (car && !car.def.heli ? car.fuel * 100 : 0) + '%'; dmgHud(car);
  document.body.dataset.mode = car ? 'car' : 'foot';
  $('speedfx').style.opacity = car ? clamp((Math.abs(car.vf) / car.st.maxSpeed - 0.75) * 3, 0, 1) * (car.nitroOn ? 1 : 0.5) : 0;
  // подсказки
  let a1 = null, jack = false;
  if (!(M && M.state === 'countdown')) {
    if (car) { if (Math.abs(car.vf) < 7) a1 = 'Выйти из машины'; }
    else { const nc = nearbyCar(); if (nc) { jack = nc.kind === 'traffic'; a1 = jack ? '🚨 Угнать машину' : 'Сесть в машину'; } else if (P.roof) a1 = '🛗 Спуститься на лифте'; }
  }
  const mk = nearbyMark();
  const tp = UI.touchMode;
  const pr = $('prompt');
  const lines = [];
  if (a1) lines.push(tp ? a1 : '[F] ' + a1);
  if (mk) lines.push(tp ? mk.label : '[E] ' + mk.label);
  setText(pr, lines.join('   •   ')); pr.style.display = lines.length && !tp ? 'block' : 'none';
  $('btnEnter').style.display = a1 && tp ? 'flex' : 'none'; setText($('btnEnter'), a1 ? (car ? '🚪 Выйти' : (jack ? '🚨 Угнать' : (P.roof && !nearbyCar() ? '🛗 Вниз' : '🚗 Сесть'))) : '');
  $('btnMarker').style.display = mk && tp ? 'flex' : 'none'; setText($('btnMarker'), mk ? mk.label : '');
  { const onFoot = !G.inHome, wd = wDef(), shootM = M && M.def.type === 'shootout';
    $('hpBox').style.display = (shootM || P.hp < 99) ? 'flex' : 'none';
    $('hpFill').style.width = clamp(P.hp, 0, 100) + '%'; setText($('hpTxt'), String(Math.max(0, Math.ceil(P.hp))));
    const ab = $('ammoBox'); ab.style.display = onFoot ? 'block' : 'none';
    setText(ab, wd.melee ? wd.icon + ' ' + wd.name : wd.icon + ' ' + wd.name + '   ' + wMag(wd.id) + ' / ' + (S.guns.ammo[wd.id] || 0) + (WS.reload > 0 ? '  ⟳' : '') + hudExtra(wd));
    $('hitFx').style.opacity = String(HITFX.flash * 0.9);
    const stEl = $('stars'), sk = WANT.stars + '|' + WANT.civ + '|' + WANT.cop + '|' + (WANT.heat > 8 ? Math.floor(G.time * 3) % 2 : 2) + '|' + (WANT.seen ? 1 : 0) + '|' + (WANT.heli ? 1 : 0) + '|' + WANT.blocks.length + '|' + Math.ceil(clamp(30 - WANT.heat, 0, 30));
    if (stEl.dataset.k !== sk) {
      stEl.dataset.k = sk; stEl.style.display = WANT.stars > 0 ? 'flex' : 'none';
      let h = ''; for (let k = 1; k <= 5; k++) h += '<i class="' + (k <= WANT.stars ? (WANT.heat > 8 && Math.floor(G.time * 3) % 2 ? 'dim' : 'on') : '') + '">★</i>';
      stEl.innerHTML = h + '<small>👤 ' + WANT.civ + ' · 👮 ' + WANT.cop + ' · ' + (WANT.seen ? '👁 видят' : '🔍 ' + Math.ceil(clamp(30 - WANT.heat, 0, 30)) + ' с') + (WANT.heli ? ' · 🚁' : '') + (WANT.blocks.length ? ' · 🚧' + WANT.blocks.length : '') + '</small>';
    } }
  // дрифт
  const db = $('driftBox');
  if (DR.cur > 20) { db.style.display = 'block'; setText(db, '🌀 ' + Math.round(DR.cur) + '  x' + DR.mult.toFixed(1)); db.classList.toggle('active', DR.active); } else db.style.display = 'none';
  // задание
  const mp = $('mPanel');
  if (M) {
    const def = M.def; let obj = '', prog = '';
    const needCar = def.needCar && !P.car;
    if (def.type === 'checkpoints') { obj = 'Проезжайте чекпоинты' + (def.minSpeed ? ' (≥' + def.minSpeed + ' км/ч)' : ''); prog = 'Чекпоинт ' + Math.min(M.idx + 1, M.pts.length) + ' из ' + M.pts.length; }
    else if (def.type === 'race') { obj = 'Приезжайте первым!'; prog = 'Позиция ' + (M.pos || 1) + ' из ' + (M.racers.length + 1) + ' · CP ' + Math.min(M.idx + 1, M.pts.length) + '/' + M.pts.length; }
    else if (def.type === 'delivery') { obj = def.stages[Math.min(M.stage, def.stages.length - 1)].t; prog = 'Этап ' + (M.stage + 1) + ' из ' + def.stages.length; }
    else if (def.type === 'collect') { obj = 'Собирайте золотые сферы'; prog = 'Сферы: ' + M.got + ' / ' + def.count; }
    else if (def.type === 'drift') { const tot = DR.total - M.drBase + DR.cur; obj = 'Дрифтуйте! (Пробел — ручник)'; prog = 'Очки: ' + Math.round(tot) + ' / ' + def.target; }
    else if (def.type === 'chase') { obj = 'Оторвитесь от полиции!'; prog = 'Арест: ' + Math.round(M.contact * 100) + '%'; }
    else if (def.type === 'shootout') { obj = 'Обезвредьте бандитов (Пробел — огонь)'; prog = 'Волна ' + (M.wave + 1) + ' из ' + M.waves.length + ' · осталось: ' + M.enemies.length; }
    if (needCar) obj = '⚠ Сядьте в машину!';
    mp.classList.add('active');
    $('mTitle').textContent = def.icon + ' ' + def.name;
    setText($('mObj'), obj); setText($('mProg'), prog);
    const tm = $('mTimer'); tm.style.display = def.time ? 'block' : 'none';
    setText(tm, (def.type === 'chase' ? 'Выжить: ' : '⏱ ') + fmtTime(M.left)); tm.classList.toggle('warn', M.left < 10 && M.state === 'run');
    $('mList').style.display = 'none';
    // метка расстояния до цели
    const t0 = missionTargets()[0], lb = $('lblObj');
    if (t0) { const p = project(t0.x, 6, t0.z); if (p && p.x > 0 && p.x < innerWidth && p.y > 0 && p.y < innerHeight) { lb.style.display = 'block'; lb.style.left = p.x + 'px'; lb.style.top = p.y + 'px'; setText(lb, Math.round(Math.hypot(t0.x - P.x, t0.z - P.z)) + ' м'); } else lb.style.display = 'none'; }
    else $('lblObj').style.display = 'none';
  } else {
    mp.classList.remove('active');
    $('mTitle').textContent = '📋 Задания'; setText($('mObj'), ''); setText($('mProg'), ''); $('mTimer').style.display = 'none';
    const next = MISSIONS.filter(m => !(S.missions[m.id] && S.missions[m.id].done)).slice(0, 3);
    const ml = $('mList'); ml.style.display = 'block';
    setText(ml, next.length ? next.map(m => m.icon + ' ' + m.name + ' — ' + fmtMoney(m.reward)).join('\n') : '👑 Все задания выполнены!');
    $('lblObj').style.display = 'none';
  }
  // подписи мировых меток
  for (const m of WORLD_MARKS) {
    if (m.int) continue;
    const el = LBL[m.id] || (LBL[m.id] = mkLbl(m));
    const p = project(m.x, 9, m.z);
    if (p && Math.hypot(m.x - P.x, m.z - P.z) < 120 && p.x > 0 && p.x < innerWidth && p.y > 60 && p.y < innerHeight) { el.style.display = 'block'; el.style.left = p.x + 'px'; el.style.top = p.y + 'px'; } else el.style.display = 'none';
  }
  // миникарта (реже)
  mmAcc += dt;
  if (mmAcc > 0.05) {
    mmAcc = 0;
    const yaw = CAM.yaw;
    drawMap(mmc, mm.width, mm.height, P.x, P.z, Math.sin(yaw), Math.cos(yaw), 0.6, false);
  }
}

