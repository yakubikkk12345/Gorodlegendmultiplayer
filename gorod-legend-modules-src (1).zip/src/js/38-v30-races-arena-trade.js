/* ===================== v30: ГОНКИ, КОМАНДНАЯ АРЕНА, ОБМЕН МАШИНАМИ ===================== */
const RACES = [
  { name: 'Центральное кольцо', start: [2, 2], pts: [[6, 2], [6, 6], [2, 6], [2, 2]], loop: true },
  { name: 'Большой круг', start: [0, 0], pts: [[8, 0], [8, 8], [0, 8], [0, 0]], loop: true },
  { name: 'Спринт по центру', start: [1, 1], pts: [[7, 1], [7, 4], [4, 4], [4, 7]], loop: false }
];
const RC = { state: '', joined: false, route: 0, laps: 1, n: 0, total: 0, pts: [], players: [], order: [], pos: {}, lock: false, t: 0, cd: 0, lastN: 99, host: 0, prev: null, finished: false, warnT: 0, inv: null };
const ARENA = { on: false, joined: false, team: -1, teams: {}, players: [], score: [0, 0], target: 10, host: 0, endAt: 0, prev: null, outT: 0, wantT: 0, R: 95, inv: null };
const TR = { out: null };
const TEAM_NAME = ['Красные', 'Синие'], TEAM_COL = ['#ff6b6b', '#6bb5ff'], TEAM_DOT = ['🔴', '🔵'];
function evBanner(id, html, btns, ttl) {
  const box = $('mpEv'); let el = document.getElementById('ev_' + id);
  if (!el) { el = document.createElement('div'); el.id = 'ev_' + id; el.className = 'evb'; box.appendChild(el); }
  el.innerHTML = '<div class="evt">' + html + '</div>';
  const row = document.createElement('div'); row.className = 'evr';
  (btns || []).forEach(b => {
    if (b.el) { row.appendChild(b.el); return; }
    const x = document.createElement('button'); x.className = 'btn small' + (b.pri ? ' primary' : ''); x.textContent = b.t;
    x.addEventListener('click', e => { e.stopPropagation(); b.fn(); }); row.appendChild(x);
  });
  el.appendChild(row); clearTimeout(el._t); if (ttl) el._t = setTimeout(() => evHide(id), ttl);
}
function evHide(id) { const el = document.getElementById('ev_' + id); if (el) { clearTimeout(el._t); el.remove(); } }
function v30Can(race) {
  if (G.mode !== 'play') return 'Сначала начните игру';
  if (G.inHome) return 'Выйдите из дома';
  if (M) return 'Завершите задание';
  if (P.hp <= 0) return 'Вы без сознания';
  if (RC.state || ARENA.on || RC.joined || ARENA.joined) return 'Вы уже участвуете в событии';
  if (race && CAR_BY_ID[S.sel] && CAR_BY_ID[S.sel].heli) return 'Для гонки выберите наземную машину';
  return '';
}
function v30Prev() { const o = OWN; return { x: P.x, z: P.z, h: P.h, hadOwn: !!o, ox: o ? o.x : 0, oz: o ? o.z : 0, oh: o ? o.h : 0, inOwn: !!(o && P.car === o) }; }
function v30Restore(pv) {
  if (!pv) return;
  if (P.car) exitCar(true);
  if (pv.hadOwn && OWN) { OWN.x = pv.ox; OWN.z = pv.oz; OWN.h = pv.oh; OWN.vx = OWN.vz = OWN.vf = OWN.vl = 0; }
  else if (!pv.hadOwn && OWN) removeCar(OWN);
  if (pv.inOwn && OWN) { seatPlayer(OWN); CAM.yaw = OWN.h; CAM.off = 0; }
  else { P.x = pv.x; P.z = pv.z; P.y = terrainY(P.x, P.z); P.h = pv.h; P.vis = true; }
}
function v30Prepare() { if (G.inHome) setHomeState(false); if (M) cleanupMission(); closeScreens(); clearWanted(); }
function fmtMs(ms) { const s = Math.max(0, ms) / 1000; return Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0') + '.' + String(Math.floor(s * 10) % 10); }
/* ---- гонка ---- */
function rcMarks() {
  if (RC.state !== 'run' && RC.state !== 'count') return;
  const L = RC.pts.length, c = [0.2, 0.9, 1], list = [];
  if (RC.n < RC.total) { const t = RC.pts[RC.n % L]; list.push({ x: t.x, z: t.z, r: 8, c }); }
  if (RC.n + 1 < RC.total) { const t = RC.pts[(RC.n + 1) % L]; list.push({ x: t.x, z: t.z, r: 8, c: [1, 1, 1] }); }
  MARK.list = list;
}
function rcTeleport(slot) {
  const r = RACES[RC.route], s = r.start, nx = nodeC(s[0]), nz = nodeC(s[1]);
  const d = dirToward(s, r.pts[0]), f = DIRS[d], rt = rightOf(d);
  const row = Math.floor(slot / 2), side = slot % 2, lat = side ? 5.2 : 1.9, bk = 7 + row * 9;
  RC.prev = v30Prev();
  const car = ensureOwn();
  car.x = nx - f[0] * bk + rt[0] * lat; car.z = nz - f[1] * bk + rt[1] * lat; car.h = Math.atan2(f[0], f[1]);
  if (car.fuel !== undefined) car.fuel = 1;
  seatPlayer(car); CAM.yaw = car.h; CAM.off = 0;
}
function rcReset() {
  RC.state = ''; RC.joined = false; RC.lock = false; RC.n = 0; RC.finished = false; RC.order = []; RC.pos = {}; RC.players = [];
  if (!M && !ARENA.on) MARK.list = [];
  showCountdown(''); evHide('rc'); evHide('rcinv'); evHide('rcres');
}
function rcEnd(results) {
  const me = results.find(r => r.id === MP.id), n = results.length;
  const prizes = [3000, 1800, 1000, 500];
  let prize = 0;
  if (me && me.place > 0 && n >= 2) { prize = prizes[me.place - 1] || 0; if (prize) addMoney(prize); }
  const rows = results.map((r, i) => (r.place ? r.place + '. ' : '— ') + mpEsc(r.name) + (r.place ? ' · ' + fmtMs(r.time) : ' · не финишировал')).join('<br>');
  evBanner('rcres', '<b>🏁 Результаты гонки</b><br>' + rows + (prize ? '<br>💰 Приз: ' + fmtMoney(prize) : (me && me.place && n < 2 ? '<br>Без соперников приза нет' : '')), [{ t: 'OK', fn: () => evHide('rcres') }], 12000);
  RC.state = 'done'; RC.lock = false; showCountdown(''); if (!M) MARK.list = [];
  setTimeout(() => { v30Restore(RC.prev); RC.prev = null; rcReset(); persist(); }, 6000);
}
function rcLobbyBanner() {
  if (!RC.joined || RC.state) return;
  const r = RACES[RC.route], host = RC.host === MP.id, names = RC.players.map(p => mpEsc(p.name)).join(', ');
  const btns = host ? [{ t: '▶ Старт', pri: true, fn: () => mpSend({ t: 'race-start' }) }, { t: 'Отмена', fn: () => mpSend({ t: 'race-cancel' }) }]
    : [{ t: 'Выйти', fn: () => { mpSend({ t: 'race-leave' }); RC.joined = false; evHide('rc'); } }];
  evBanner('rc', '<b>🏁 ' + mpEsc(r.name) + '</b> · кругов: ' + RC.laps + '<br>Участники (' + RC.players.length + '/4): ' + names + (host ? '<br><small>Нажмите «Старт», когда все готовы</small>' : '<br><small>Ждём старта от организатора…</small>'), btns, 0);
}
function rcJoin() {
  const why = v30Can(true); if (why) { toast('🏁 ' + why); SFX.err(); return; }
  RC.joined = true; mpSend({ t: 'race-join' }); evHide('rcinv'); closeScreens();
}
/* ---- арена ---- */
const ARENA_C = { x: nodeC(4), z: nodeC(4) };
function arenaMarks() {
  const list = [];
  for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; list.push({ x: ARENA_C.x + Math.cos(a) * (ARENA.R - 3), z: ARENA_C.z + Math.sin(a) * (ARENA.R - 3), r: 4, c: [1, 0.5, 0.1] }); }
  MARK.list = list;
}
function arenaSpawn() {
  const t = ARENA.team < 0 ? 0 : ARENA.team;
  P.x = ARENA_C.x + (t ? 70 : -70); P.z = ARENA_C.z + rand(-3, 3); P.y = terrainY(P.x, P.z);
  P.h = t ? -Math.PI / 2 : Math.PI / 2; CAM.yaw = P.h; CAM.off = 0; P.speed = 0; P.vis = true;
}
function arenaRefill() { for (const w of WEAPONS) if (!w.melee) { S.guns.own[w.id] = true; S.guns.ammo[w.id] = w.mag * 8; WS.mag[w.id] = w.mag; } }
function arenaRespawn() {
  P.downT = 0; P.lastSrc = null; P.hp = 100; HITFX.flash = 0; HITFX.lastHit = G.time;
  if (P.car) exitCar(true);
  arenaSpawn(); arenaRefill(); CB.inv = Math.max(CB.inv, 3); toast('☠ Возрождение на базе');
}
function arenaLobbyBanner() {
  if (!ARENA.joined || ARENA.on) return;
  const host = ARENA.host === MP.id;
  const col = t => ARENA.players.filter(p => p.team === t).map(p => mpEsc(p.name)).join(', ') || '—';
  const btns = host ? [{ t: '▶ Старт', pri: true, fn: () => mpSend({ t: 'arena-start' }) }, { t: 'Отмена', fn: () => mpSend({ t: 'arena-cancel' }) }]
    : [{ t: 'Выйти', fn: () => { mpSend({ t: 'arena-leave' }); ARENA.joined = false; evHide('ar'); } }];
  evBanner('ar', '<b>⚔ Командная арена</b> · до ' + ARENA.target + ' убийств<br>🔴 ' + col(0) + '<br>🔵 ' + col(1) + (host ? '<br><small>Нужно минимум 2 игрока</small>' : '<br><small>Ждём старта…</small>'), btns, 0);
}
function arenaJoin() {
  const why = v30Can(false); if (why) { toast('⚔ ' + why); SFX.err(); return; }
  ARENA.joined = true; mpSend({ t: 'arena-join' }); evHide('arinv'); closeScreens();
}
function arenaReset() {
  if (ARENA.on) {
    try { const b = JSON.parse(S.arenaBackup || 'null'); if (b) { S.guns = b.guns; WS.mag = b.mag; } } catch (e) { }
    delete S.arenaBackup;
    if (ARENA.pvpSaved !== undefined) { MP.pvp = ARENA.pvpSaved; ARENA.pvpSaved = undefined; $('mpPvp').checked = MP.pvp; }
    v30Restore(ARENA.prev); ARENA.prev = null; persist();
  }
  ARENA.on = false; ARENA.joined = false; ARENA.team = -1; ARENA.teams = {}; ARENA.players = []; ARENA.score = [0, 0];
  if (!M && !RC.state) MARK.list = [];
  evHide('ar'); evHide('arinv');
}
/* ---- обмен машинами ---- */
function carRec(id) { const r = S.cars[id]; return r ? JSON.parse(JSON.stringify(Object.assign({ id }, r))) : null; }
function cleanRec(r) {
  if (!r || !CAR_BY_ID[r.id]) return null;
  const u = {}; for (const k of ['eng', 'acc', 'tir', 'nit']) u[k] = clamp(+(r.u && r.u[k]) || 0, 0, 10);
  const o = { u, color: typeof r.color === 'string' ? r.color.slice(0, 9) : CAR_BY_ID[r.id].color };
  if (r.mods && typeof r.mods === 'object') o.mods = r.mods;
  if (typeof r.fuel === 'number') o.fuel = clamp(r.fuel, 0, 1);
  if (typeof r.dmg === 'number') o.dmg = clamp(r.dmg, 0, 1);
  return o;
}
function tradeAdd(r) { const c = cleanRec(r); if (!c || S.cars[r.id]) return false; S.cars[r.id] = c; persist(); return true; }
function tradeRemove(id) {
  if (!S.cars[id] || Object.keys(S.cars).length < 2) return false;
  if (S.sel === id) { const other = Object.keys(S.cars).find(k => k !== id); selectCar(other); }
  delete S.cars[id]; persist(); return true;
}
const carName = id => (CAR_BY_ID[id] ? CAR_BY_ID[id].name : id);
function tradeSend(to, d) { mpSend({ t: 'trade', to, d }); }
function tradeStart() {
  if (!mpConnected()) return;
  const to = +$('trPeer').value, id = $('trCar').value, kind = $('trKind').value;
  if (!to || !MP.peers.has(to)) { toast('🚗 Выберите друга из списка'); return; }
  if (!S.cars[id]) { toast('🚗 Выберите машину'); return; }
  if (Object.keys(S.cars).length < 2) { toast('🚗 Нельзя отдать единственную машину'); SFX.err(); return; }
  TR.out = { to, kind, rec: carRec(id) };
  tradeSend(to, { k: 'offer', kind, car: TR.out.rec });
  toast('🚗 Предложение отправлено: ' + MP.peers.get(to).name);
}
function tradeRecv(from, name, d) {
  const nm = mpEsc(name || 'Игрок'), id = 'tr' + from;
  if (d.k === 'offer') {
    if (!d.car || !CAR_BY_ID[d.car.id]) return;
    if (S.cars[d.car.id]) { tradeSend(from, { k: 'decline', why: 'У вас уже есть ' + carName(d.car.id) }); return; }
    if (d.kind === 'gift') {
      evBanner(id, '🎁 <b>' + nm + '</b> дарит вам машину<br><b>' + mpEsc(carName(d.car.id)) + '</b>', [
        { t: 'Принять', pri: true, fn: () => { evHide(id); tradeSend(from, { k: 'accept' }); } },
        { t: 'Отказаться', fn: () => { evHide(id); tradeSend(from, { k: 'decline' }); } }], 45000);
    } else {
      if (Object.keys(S.cars).length < 2) { tradeSend(from, { k: 'decline', why: 'У вас одна машина' }); return; }
      const sel = document.createElement('select'); sel.className = 'trsel';
      Object.keys(S.cars).forEach(c => { const o = document.createElement('option'); o.value = c; o.textContent = carName(c); sel.appendChild(o); });
      evBanner(id, '🔄 <b>' + nm + '</b> предлагает обмен: его<br><b>' + mpEsc(carName(d.car.id)) + '</b><br>Что отдадите вы?', [{ el: sel },
        { t: 'Предложить', pri: true, fn: () => { const rec = carRec(sel.value); if (!rec) return; evHide(id); tradeSend(from, { k: 'counter', car: rec }); toast('🔄 Ждём ответа'); } },
        { t: 'Отказаться', fn: () => { evHide(id); tradeSend(from, { k: 'decline' }); } }], 45000);
    }
  } else if (d.k === 'accept') {
    const o = TR.out; if (!o || o.to !== from || o.kind !== 'gift') return;
    if (!tradeRemove(o.rec.id)) { toast('🎁 Не получилось передать машину'); TR.out = null; tradeSend(from, { k: 'decline', why: 'Машина уже недоступна' }); return; }
    tradeSend(from, { k: 'give', car: o.rec }); TR.out = null; toast('🎁 Вы подарили ' + carName(o.rec.id));
  } else if (d.k === 'counter') {
    const o = TR.out; if (!o || o.to !== from || o.kind !== 'swap' || !d.car || !CAR_BY_ID[d.car.id]) return;
    if (S.cars[d.car.id]) { tradeSend(from, { k: 'decline', why: 'У оппонента уже есть ' + carName(d.car.id) }); TR.out = null; return; }
    evBanner(id, '🔄 <b>' + nm + '</b> предлагает за вашу<br><b>' + mpEsc(carName(o.rec.id)) + '</b><br>свою: <b>' + mpEsc(carName(d.car.id)) + '</b>', [
      { t: 'Согласиться', pri: true, fn: () => {
        evHide(id);
        if (!S.cars[o.rec.id] || !tradeAdd(d.car)) { toast('🔄 Обмен не удался'); tradeSend(from, { k: 'decline', why: 'Обмен не удался' }); TR.out = null; return; }
        tradeRemove(o.rec.id); tradeSend(from, { k: 'do', car: o.rec, take: d.car.id }); TR.out = null; toast('🔄 Обмен: теперь у вас ' + carName(d.car.id));
      } },
      { t: 'Отказать', fn: () => { evHide(id); TR.out = null; tradeSend(from, { k: 'decline' }); } }], 45000);
  } else if (d.k === 'give') {
    if (tradeAdd(d.car)) toast('🎁 Вам подарили ' + carName(d.car.id) + ' — она в гараже!'); else toast('🎁 Машину не удалось принять');
  } else if (d.k === 'do') {
    if (tradeAdd(d.car)) { tradeRemove(d.take); toast('🔄 Обмен: теперь у вас ' + carName(d.car.id)); } else toast('🔄 Обмен не удался');
  } else if (d.k === 'decline') {
    TR.out = null; toast('🚗 ' + (name || 'Игрок') + ' отказался' + (d.why ? ': ' + String(d.why).slice(0, 60) : ''));
  }
}
/* ---- сообщения сервера ---- */
function v30Msg(m) {
  switch (m.t) {
    case 'warn': toast('⚠ ' + (m.msg || '')); return true;
    case 'trade': if (m.d && typeof m.d === 'object') tradeRecv(m.from, m.name, m.d); return true;
    case 'race-open': {
      RC.route = m.route; RC.laps = m.laps; RC.host = m.host;
      if (m.host === MP.id) { RC.joined = true; rcLobbyBanner(); }
      else if (!RC.state && !ARENA.on) {
        evBanner('rcinv', '🏁 <b>' + mpEsc(m.hname) + '</b> собирает гонку<br>' + mpEsc(RACES[m.route].name) + ' · кругов: ' + m.laps + ' · приз до $3 000', [{ t: 'Участвовать', pri: true, fn: rcJoin }, { t: 'Нет', fn: () => evHide('rcinv') }], 40000);
        SFX.cp();
      }
      return true;
    }
    case 'race-lobby': RC.players = m.players; RC.host = m.host; rcLobbyBanner(); return true;
    case 'race-cancel': if (!RC.state) { RC.joined = false; evHide('rc'); evHide('rcinv'); toast('🏁 Заезд отменён'); } return true;
    case 'race-go': {
      evHide('rcinv');
      if (!RC.joined) return true;
      RC.route = m.route; RC.laps = m.laps; RC.players = m.players;
      const me = m.players.find(p => p.id === MP.id); if (!me) { RC.joined = false; evHide('rc'); return true; }
      v30Prepare(); evHide('rc');
      RC.pts = RACES[RC.route].pts.map(p => ({ x: nodeC(p[0]), z: nodeC(p[1]) }));
      RC.total = RC.pts.length * RC.laps; RC.n = 0; RC.finished = false; RC.order = m.players.map(p => p.id); RC.pos = {};
      P.hp = 100; HITFX.flash = 0;
      rcTeleport(me.slot); RC.state = 'count'; RC.lock = true; RC.cd = m.in / 1000; RC.lastN = 99; rcMarks();
      toast('🏁 ' + RACES[RC.route].name + ' · приготовьтесь!');
      return true;
    }
    case 'race-pos': RC.order = m.order; RC.pos = m.n || {}; return true;
    case 'race-fin':
      if (RC.state) { if (m.id === MP.id) { RC.finished = true; toast('🏁 Вы финишировали: ' + m.place + '-е место · ' + fmtMs(m.time)); SFX.go(); MARK.list = []; } else toast('🏁 ' + m.name + ' финишировал: ' + m.place + '-е место'); }
      return true;
    case 'race-end': if (RC.state && RC.joined) rcEnd(m.results); else rcReset(); return true;
    case 'arena-open':
      ARENA.target = m.target; ARENA.host = m.host;
      if (m.host === MP.id) { ARENA.joined = true; arenaLobbyBanner(); }
      else if (!RC.state && !ARENA.on) { evBanner('arinv', '⚔ <b>' + mpEsc(m.hname) + '</b> собирает командную арену<br>2 команды · до ' + m.target + ' убийств', [{ t: 'Участвовать', pri: true, fn: arenaJoin }, { t: 'Нет', fn: () => evHide('arinv') }], 60000); SFX.cp(); }
      return true;
    case 'arena-lobby': ARENA.players = m.players; ARENA.host = m.host; ARENA.teams = {}; m.players.forEach(p => ARENA.teams[p.id] = p.team); arenaLobbyBanner(); return true;
    case 'arena-cancel': if (!ARENA.on) { ARENA.joined = false; evHide('ar'); evHide('arinv'); toast('⚔ Арена отменена'); } return true;
    case 'arena-go': {
      evHide('arinv'); evHide('ar');
      if (!ARENA.joined) return true;
      ARENA.teams = {}; m.players.forEach(p => ARENA.teams[p.id] = p.team);
      if (ARENA.teams[MP.id] === undefined) { ARENA.joined = false; return true; }
      v30Prepare();
      ARENA.team = ARENA.teams[MP.id]; ARENA.target = m.target; ARENA.score = [0, 0]; ARENA.endAt = performance.now() + m.ms; ARENA.outT = 0;
      ARENA.prev = v30Prev(); if (P.car) exitCar(true);
      S.arenaBackup = JSON.stringify({ guns: S.guns, mag: WS.mag });
      arenaRefill(); S.guns.sel = 'smg'; WS.reload = 0;
      ARENA.pvpSaved = MP.pvp; MP.pvp = true; $('mpPvp').checked = true;
      ARENA.on = true; P.hp = 100; HITFX.flash = 0; CB.inv = Math.max(CB.inv, 3); arenaSpawn(); arenaMarks();
      toast('⚔ Вы в команде: ' + TEAM_NAME[ARENA.team]); SFX.go();
      return true;
    }
    case 'arena-score': ARENA.score = m.s; return true;
    case 'arena-end': {
      if (!ARENA.on) { arenaReset(); return true; }
      const win = m.winner, mine = ARENA.team, prize = win === -1 ? 700 : win === mine ? 1500 : 400;
      addMoney(prize);
      evBanner('arres', '<b>⚔ Арена окончена</b><br>' + TEAM_DOT[0] + ' ' + m.s[0] + ' : ' + m.s[1] + ' ' + TEAM_DOT[1] + '<br>' + (win === -1 ? 'Ничья' : win === mine ? '🏆 Ваша команда победила!' : 'Победили ' + TEAM_NAME[win].toLowerCase()) + '<br>💰 ' + fmtMoney(prize), [{ t: 'OK', fn: () => evHide('arres') }], 12000);
      arenaReset(); return true;
    }
  }
  return false;
}
function v30Abort() { if (ARENA.on || ARENA.joined) arenaReset(); if (RC.state || RC.joined) { v30Restore(RC.prev); RC.prev = null; rcReset(); } TR.out = null; $('evHud').style.display = 'none'; }
function mpFoe(p) { return !ARENA.on || (ARENA.teams[p.id] !== undefined && ARENA.teams[p.id] !== ARENA.team); }
function v30Tick(dt) {
  const hud = $('evHud'); let txt = '';
  if (RC.state === 'count') {
    RC.cd -= dt; const n = Math.ceil(RC.cd);
    if (n !== RC.lastN) { RC.lastN = n; if (n > 0) { showCountdown(String(n)); SFX.tick(); } else { showCountdown('GO!'); SFX.go(); } }
    if (RC.cd <= 0) { RC.state = 'run'; RC.lock = false; RC.t = 0; setTimeout(() => showCountdown(''), 700); }
    txt = '🏁 ' + RACES[RC.route].name;
  } else if (RC.state === 'run') {
    RC.t += dt;
    const car = P.car, L = RC.pts.length;
    if (!RC.finished && RC.n < RC.total) {
      const t = RC.pts[RC.n % L];
      if (car && Math.hypot(car.x - t.x, car.z - t.z) < 12) { RC.n++; mpSend({ t: 'race-cp', n: RC.n }); SFX.cp(); rcMarks(); }
      else if (!car && (RC.warnT -= dt) <= 0) { RC.warnT = 4; toast('🏁 Вернитесь в машину!'); }
    }
    const rank = Math.max(1, RC.order.indexOf(MP.id) + 1), lap = Math.min(RC.laps, Math.floor(RC.n / L) + 1);
    txt = '🏁 ' + rank + '/' + RC.players.length + ' · Круг ' + lap + '/' + RC.laps + ' · КП ' + (RC.n % L) + '/' + L + ' · ' + fmtMs(RC.t * 1000);
    if (RC.finished) txt = '🏁 Финиш! Ждём остальных…';
  } else if (RC.state === 'done') txt = '🏁 Гонка завершена';
  if (ARENA.on) {
    const left = ARENA.endAt - performance.now();
    txt = '⚔ ' + TEAM_DOT[0] + ' ' + ARENA.score[0] + ' : ' + ARENA.score[1] + ' ' + TEAM_DOT[1] + ' · до ' + ARENA.target + ' · ' + fmtMs(left).split('.')[0] + ' · вы: ' + TEAM_NAME[ARENA.team].toLowerCase();
    if (!P.car && !G.inHome) {
      const d = Math.hypot(P.x - ARENA_C.x, P.z - ARENA_C.z);
      if (d > ARENA.R) { ARENA.outT += dt; if (ARENA.outT > 5) { ARENA.outT = 0; arenaRespawn(); } else if (Math.floor(ARENA.outT * 2) !== Math.floor((ARENA.outT - dt) * 2)) toast('⚠ Вернитесь в арену! ' + Math.ceil(5 - ARENA.outT) + ' с'); } else ARENA.outT = 0;
    }
    if ((ARENA.wantT -= dt) <= 0) { ARENA.wantT = 1.5; clearWanted(); }
  }
  if (hud.textContent !== txt) hud.textContent = txt;
  hud.style.display = txt ? 'block' : 'none';
}
function v30Fill() {
  const sp = $('trPeer'), sc = $('trCar'); if (!sp || !sc) return;
  const peers = [...MP.peers.values()], sig = peers.map(p => p.id + p.name).join() + '|' + Object.keys(S.cars).join();
  if (sig === v30Fill.sig) return; v30Fill.sig = sig;
  const vp = sp.value, vc = sc.value;
  sp.innerHTML = peers.map(p => '<option value="' + p.id + '">' + mpEsc(p.name) + '</option>').join('') || '<option value="">— никого нет —</option>';
  sc.innerHTML = Object.keys(S.cars).map(id => '<option value="' + id + '">' + mpEsc(carName(id)) + '</option>').join('');
  if (vp) sp.value = vp; if (vc) sc.value = vc;
}
function v30Init() {
  try { if (S.arenaBackup) { const b = JSON.parse(S.arenaBackup); if (b) { S.guns = b.guns; WS.mag = b.mag; } delete S.arenaBackup; } } catch (e) { }
}


