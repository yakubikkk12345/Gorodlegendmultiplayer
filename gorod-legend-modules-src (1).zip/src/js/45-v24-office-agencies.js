/* ===================== v24: кабинет, спецслужбы и происшествия, зима, метро ===================== */
/* --- кабинет пентхауса: сбор доходов со всего --- */
function incomeSummary() {
  const rows = []; let total = 0;
  for (const k in S.biz) { const r = S.biz[k], b = BIZ_BY[k]; if (b && r && r.own) { const a = Math.floor(r.acc || 0); rows.push({ n: b.ico + ' ' + b.name, a, r, kind: 'biz' }); total += a; } }
  for (const p of PROPS) if (propOwn(p.id)) { const r = S.props[p.id], a = Math.floor(r.acc || 0); rows.push({ n: p.ico + ' ' + p.nm, a, r, kind: 'prop' }); total += a; }
  const safe = Math.floor(S.safe || 0); total += safe;
  return { rows, total, safe };
}
function officeGreet() {
  const v = incomeSummary();
  if (!v.rows.length) return 'Контора пока пуста: у вас нет ни бизнесов, ни недвижимости. Купите их — и доходы будут стекаться сюда.';
  return v.total >= 1 ? 'Господин босс, в кассах накопилось ' + fmtMoney(v.total) + ' (' + v.rows.length + ' объектов). Забираем всё разом?' : 'Все кассы пока пусты. Загляните позже — доходы копятся сами.';
}
function officeOptions() {
  const v = incomeSummary();
  return [
    { t: v.total >= 1 ? '💰 Забрать всё — ' + fmtMoney(v.total) : '💰 Пока нечего забирать', dis: v.total < 1, fn: () => {
      const w = incomeSummary(); let n = 0, cb = 0, cp = 0;
      const sf = Math.floor(S.safe || 0); if (sf > 0) { n += sf; S.safe = (S.safe || 0) - sf; }
      for (const r of w.rows) { const a = Math.floor(r.r.acc || 0); if (a > 0) { r.r.acc = 0; n += a; if (r.kind === 'biz') cb++; else cp++; } }
      if (n > 0) { addMoney(n); persist(); SFX.cash(); S.flags.officeCol = (S.flags.officeCol || 0) + 1; }
      say('Собрано ' + fmtMoney(n) + ': бизнесов — ' + cb + ', объектов недвижимости — ' + cp + '. Деньги в вашем кармане.');
    } },
    { t: '📊 Отчёт по доходам', fn: () => { const w = incomeSummary(); say(w.rows.length ? 'В сейфе ' + fmtMoney(w.safe) + ' из ' + fmtMoney(Math.round(safeCap())) + '. Объекты: ' + w.rows.map(r => r.n).join(' · ') + '. Всего к выдаче: ' + fmtMoney(w.total) + '.' : 'Пока нечего показать: нет ни бизнесов, ни недвижимости.'); } },
    { t: '❓ Как это работает?', fn: () => say('Все бизнесы и недвижимость теперь присылают доходы прямо в сейф этого кабинета. Они копятся сами, даже пока вас нет (до 15–20 минут дохода). Отсюда их можно забрать все сразу, не объезжая город.') },
    byeOpt()
  ];
}
Object.assign(NPC, { office: { ico: '💼', name: 'Контора', role: 'Кабинет на 11 этаже', greet: [''], tips: [] } });

/* --- зима --- */
const WINTER = { get on() { const m = S && S.set ? (S.set.season || 'winter') : 'winter'; if (m === 'winter') return true; if (m === 'summer') return false; const mo = new Date().getMonth(); return mo === 11 || mo <= 1; } };
function winterEnv() {
  const d = 1 - ENV.night;
  ENV.top = mix3(ENV.top, [0.78, 0.83, 0.9], 0.35 * d); ENV.bot = mix3(ENV.bot, [0.86, 0.89, 0.93], 0.4 * d); ENV.sky = mix3(ENV.sky, [0.8, 0.85, 0.92], 0.3 * d);
  ENV.fogFar = Math.min(ENV.fogFar, 560);
}
const FLAKES = [];
function drawSnowfall(dt) {
  const on = G.mode === 'play' && !G.inHome && !UI.studio;
  if (!on) { if (rainCv.style.display !== 'none') rainCv.style.display = 'none'; return; }
  rainCv.style.display = 'block';
  const w = window.innerWidth, h = window.innerHeight;
  if (rainCv.width !== w) rainCv.width = w; if (rainCv.height !== h) rainCv.height = h;
  const n = Math.round(300 * (0.18 + 0.82 * WX.rain));
  while (FLAKES.length < n) FLAKES.push({ x: Math.random() * w, y: Math.random() * h, v: 45 + Math.random() * 80, r: 1 + Math.random() * 2, ph: Math.random() * 6 });
  FLAKES.length = n;
  rainCtx.clearRect(0, 0, w, h); rainCtx.fillStyle = 'rgba(255,255,255,0.85)';
  const t = G.time;
  for (const f of FLAKES) {
    f.y += f.v * dt; f.x += (Math.sin(t * 1.3 + f.ph) * 22 - 8) * dt;
    if (f.y > h + 4) { f.y = -6; f.x = Math.random() * w; }
    if (f.x < -6) f.x = w + 4;
    rainCtx.fillRect(f.x, f.y, f.r, f.r);
  }
}
function buildSnow() {
  const S2 = new GeoSet(), W = [0.95, 0.96, 1, 1];
  S2.g().flat(-(EDGE + 14), -(EDGE + 14), EDGE + 14, EDGE + 14, -0.06, [0.92, 0.94, 0.98, 1]);
  for (let bi = 0; bi < GRID; bi++) for (let bj = 0; bj < GRID; bj++) {
    const cx = bc(bi), cz = bc(bj);
    if (blockType[bi] && blockType[bi][bj] === 'park') S2.g().flat(cx - 29, cz - 29, cx + 29, cz + 29, 0.27, [0.9, 0.93, 0.97, 1]);
    S2.g().flat(cx - 32, cz - 32, cx + 32, cz + 32, 0.175, W);
    if (bi === HOME_B && bj === HOME_B) S2.g().flat(cx - 30, cz - 30, cx + 30, cz + 30, 0.27, [0.9, 0.93, 0.97, 1]);
    if (blockType[bi] && blockType[bi][bj] === 'park') S2.g().flat(cx - 29, cz - 29, cx + 29, cz + 29, 0.27, [0.9, 0.93, 0.97, 1]);
  }
  for (const b of boxes) {
    if (b.h < 2.5 || b.x1 - b.x0 < 5 || b.z1 - b.z0 < 5 || Math.abs(b.x0) > HALF + 80 || Math.abs(b.z0) > HALF + 80) continue;
    S2.g().box(b.x0 - 0.15, b.h, b.z0 - 0.15, b.x1 + 0.15, b.h + 0.35, b.z1 + 0.15, W, false, true);
  }
  return S2.done();
}

/* --- метро --- */
const METRO = [
  { id: 'm1', nm: 'Центральная', b: [7, 8], s: [1, -1] }, { id: 'm2', nm: 'Северная', b: [3, 2], s: [-1, 1] }, { id: 'm3', nm: 'Восточная', b: [12, 8], s: [1, 1] },
  { id: 'm4', nm: 'Южная', b: [9, 13], s: [-1, -1] }, { id: 'm5', nm: 'Западная', b: [1, 12], s: [1, -1] }, { id: 'm6', nm: 'Окраина', b: [14, 14], s: [-1, -1] },
  { id: 'm7', nm: 'Набережная', b: [3, 8], s: [1, 1] }, { id: 'm8', nm: 'Деловой квартал', b: [11, 10], s: [-1, 1] }, { id: 'm9', nm: 'Новый город', b: [13, 1], s: [-1, 1] }
];
const METRO_AT = {}; METRO.forEach(m => { METRO_AT[m.b.join(',')] = m; m.x = bc(m.b[0]) + 29.4 * m.s[0]; m.z = bc(m.b[1]) + 29.4 * m.s[1]; m.px = bc(m.b[0]) + 30.6 * m.s[0]; m.pz = bc(m.b[1]) + 24.5 * m.s[1]; });
const METRO_FARE = 25, MS = { cur: null };
function buildMetroEntrance(WORLD, cx, cz, m) {
  const G = WORLD.g(), x = m.x, z = m.z, white = [1, 1, 1, 1], blue = [0.1, 0.35, 0.85, 1];
  G.box(x - 1.5, 0.16, z - 1.5, x + 1.5, 0.5, z + 1.5, [0.25, 0.27, 0.32, 1], false, true);
  G.box(x - 1.2, 0.5, z - 1.2, x + 1.2, 2.6, z + 1.2, [0.2, 0.22, 0.28, 1], false, true);
  G.box(x - 0.7, 0.5, z - 1.25, x + 0.7, 2.2, z - 1.2, [0.04, 0.05, 0.08, 1], false, true);
  G.box(x - 1.7, 2.6, z - 1.7, x + 1.7, 2.8, z + 1.7, [0.55, 0.8, 0.95, 1], false, true);
  G.box(x - 0.12, 2.8, z - 0.12, x + 0.12, 5.2, z + 0.12, [0.7, 0.7, 0.75, 1], false, true);
  G.box(x - 1.1, 5.2, z - 0.15, x + 1.1, 6.9, z + 0.15, blue, false, true);
  G.box(x - 0.15, 5.2, z - 1.1, x + 0.15, 6.9, z + 1.1, blue, false, true);
  for (const q of [[-0.8, -0.55, 5.4, 6.7], [0.55, 0.8, 5.4, 6.7], [-0.55, -0.3, 6.3, 6.7], [-0.3, -0.1, 6.0, 6.3], [-0.1, 0.1, 5.7, 6.0], [0.1, 0.3, 6.0, 6.3], [0.3, 0.55, 6.3, 6.7]])
    G.box(x + q[0], q[2], z - 0.2, x + q[1], q[3], z + 0.2, white, false, true);
  boxes.push({ x0: x - 1.7, x1: x + 1.7, z0: z - 1.7, z1: z + 1.7, h: 2.8 });
}
for (const m of METRO) WORLD_MARKS.push({ id: 'metro_' + m.id, x: m.x, z: m.z, c: [0.3, 0.55, 1], label: '🚇 МЕТРО «' + m.nm.toUpperCase() + '»: ВОЙТИ', short: '🚇 ' + m.nm, dot: '#3a86ff', fn: 'metroUse', st: m, r: 5, br: 3 });
Object.assign(NPC, { metro: { ico: '🚇', name: 'Метро', role: 'Касса станции', greet: [''], tips: [] } });
HOME_FN.metroUse = function (m) {
  if (P.car) { toast('🚇 Выйдите из машины, чтобы спуститься в метро'); SFX.err(); return; }
  MS.cur = m.st; openTalk('metro'); say('Станция «' + m.st.nm + '». Билет на любой перегон — ' + fmtMoney(METRO_FARE) + '. Куда едем?');
};
function metroOptions() {
  const here = MS.cur, o = [];
  for (const m of METRO) {
    if (m === here) continue;
    const d = Math.hypot(m.x - here.x, m.z - here.z);
    o.push({ t: '🚇 «' + m.nm + '» — ' + fmtMoney(METRO_FARE) + ' · ' + Math.round(d / 10) * 10 + ' м', fn: () => {
      if (WANT.stars > 0) { SFX.err(); say('С розыском в метро не пускают. Сначала оторвитесь от полиции.'); return; }
      if (S.money < METRO_FARE) { SFX.err(); say('Не хватает на билет.'); return; }
      S.money -= METRO_FARE; refreshMoney(true); SFX.buy(); closeScreens();
      S.flags.metro = (S.flags.metro || 0) + 1; persist();
      fadeThen(() => {
        P.x = m.px; P.z = m.pz; P.y = terrainY(P.x, P.z); P.speed = 0; P.h = Math.atan2(m.x - m.px, m.z - m.pz) + Math.PI;
        CAM.yaw = P.h; CAM.pitch = 0.3; dayT = (dayT + d / 1500 * DAY_LEN * 0.02) % DAY_LEN;
        toast('🚇 Станция «' + m.nm + '»');
      });
    } });
  }
  o.push(byeOpt());
  return o;
}

/* --- спецслужбы и происшествия --- */
const AMB_DEF = Object.assign({}, CAR_BY_ID.van, { id: 'amb', name: 'Скорая', color: '#f6f6f6', siren: true, stripe: [0.85, 0.12, 0.15, 1] });
const FIRE_DEF = Object.assign({}, CAR_BY_ID.van, { id: 'fire', name: 'Пожарная', color: '#d62323', siren: true, fire: true, stripe: [1, 1, 1, 1], shape: Object.assign({}, CAR_BY_ID.van.shape, { L: 6.4, H: 1.15 }) });
const INC = { list: [], t: 40, em: 8 };
const emLook = (shirt, pants, hair, f, hs, ty, sh) => setLook({ pants: hexRGB(pants), shirt: hexRGB(shirt), skin: hexRGB('#e0ac86'), hair: hexRGB(hair), dark: [0.05, 0.05, 0.05], shoe: hexRGB('#1a1a1a'), lips: hexRGB('#c43a62') }, { f, hs, bt: 'pants', ty, sh });
const FIREMAN = () => emLook('#f0a800', '#2b2b2b', '#c0262d', false, 'm1', 'jacket', 0.34);
const MEDIC = f => emLook('#2fa84f', '#f2f2f2', '#3a2415', f, f ? 'f1' : 'm0', 'tee', 0.1);
const COPMAN = () => emLook('#2f5fd0', '#1b2438', '#10182b', false, 'm1', 'jacket', 0.2);
function incSpawn(type) {
  let ok = false, f, rt, bx = 0, bz = 0, i, j, d;
  for (let tries = 0; tries < 60 && !ok; tries++) {
    const ci = Math.round((P.x + HALF) / PITCH), cj = Math.round((P.z + HALF) / PITCH);
    i = clamp(ci + Math.floor(rand(-3, 4)), 1, GRID - 1); j = clamp(cj + Math.floor(rand(-3, 4)), 1, GRID - 1);
    d = Math.floor(Math.random() * 4); f = DIRS[d]; rt = rightOf(d); const t = 24 + Math.random() * 24;
    bx = nodeC(i) + f[0] * t; bz = nodeC(j) + f[1] * t;
    const dp = Math.hypot(bx - P.x, bz - P.z);
    ok = dp > 60 && dp < 260 && !INC.list.some(k => Math.hypot(k.x - bx, k.z - bz) < 90);
  }
  if (!ok) return null;
  const at = (al, lat) => ({ x: bx + f[0] * al + rt[0] * lat, z: bz + f[1] * al + rt[1] * lat });
  const h0 = Math.atan2(f[0], f[1]);
  const car = (def, p, h, col) => { const c = makeCar(def, 'wreck', col || def.color); c.x = p.x; c.z = p.z; c.h = h; c.vx = c.vz = c.vf = c.vl = 0; c.spd = 0; inc.cars.push(c); return c; };
  const face = (a, b) => Math.atan2(b.x - a.x, b.z - a.z);
  const inc = { type, x: bx + rt[0] * 9, z: bz + rt[1] * 9, life: 110, pt: 0, cars: [], hum: [], mark: null, helped: false, out: false };
  const dist = Math.round(Math.hypot(bx - P.x, bz - P.z) / 10) * 10;
  if (type === 'fire') {
    const vp = at(0, 9.6); inc.x = vp.x; inc.z = vp.z;
    car(pick([CAR_BY_ID.hatch, CAR_BY_ID.sedan, CAR_BY_ID.suv]), vp, h0 + 0.15, '#2a2a2e');
    car(FIRE_DEF, at(-8.5, LANE), h0);
    for (const [al, lat] of [[-3.5, 6.2], [-5.5, 7.4]]) { const p = at(al, lat); inc.hum.push({ x: p.x, z: p.z, h: face(p, vp), look: FIREMAN(), job: 'hose' }); }
    inc.life = 100;
    toast('🔥 Пожар! Горит машина — ' + dist + ' м от вас. Пожарные уже на месте, им можно помочь');
  } else if (type === 'med') {
    const vp = at(0, 7.6); inc.x = vp.x; inc.z = vp.z;
    car(AMB_DEF, at(-6.5, LANE + 0.5), h0);
    const vl = genPedLook(['#3a86ff', '#ffd60a', '#ff4fa3', '#2ecc71']);
    inc.hum.push({ x: vp.x, z: vp.z, h: h0 + 1.2, look: vl, fall: 1 });
    for (const [al, lat, fm] of [[2.2, 6.6, true], [-1.6, 6.2, false]]) { const p = at(al, lat); inc.hum.push({ x: p.x, z: p.z, h: face(p, vp), look: MEDIC(fm) }); }
    inc.life = 100;
    toast('🚑 Человеку стало плохо — ' + dist + ' м от вас. Скорая на месте, можно помочь');
  } else {
    const vp = at(0, 7.6); inc.x = vp.x; inc.z = vp.z;
    car(POLICE_DEF, at(-5.5, LANE + 0.3), h0 + 0.1, '#f5f5f5');
    for (const [al, lat] of [[-1.5, 6.4], [1.5, 6.0]]) { const p = at(al, lat); inc.hum.push({ x: p.x, z: p.z, h: face(p, vp), look: COPMAN() }); }
    inc.hum.push({ x: vp.x, z: vp.z, h: h0 + Math.PI / 2, look: genPedLook(['#8a8a8a', '#c0392b']) });
    inc.life = 70;
  }
  if (type !== 'arrest') {
    inc.mark = { id: 'inc_' + (INC.n = (INC.n || 0) + 1), x: inc.x, z: inc.z, c: [1, 0.7, 0.1], label: type === 'fire' ? '🧯 ПОМОЧЬ ПОЖАРНЫМ' : '🩹 ПОМОЧЬ ПОСТРАДАВШЕМУ', short: type === 'fire' ? '🔥 Пожар' : '🚑 Помощь', dot: type === 'fire' ? '#ff5a1f' : '#ff4d6d', fn: 'incHelp', inc, r: 6, br: 3 };
    WORLD_MARKS.push(inc.mark);
  }
  INC.list.push(inc);
  return inc;
}
function incRemove(inc) {
  for (const c of inc.cars) removeCar(c);
  if (inc.mark) { const k = WORLD_MARKS.indexOf(inc.mark); if (k >= 0) WORLD_MARKS.splice(k, 1); inc.mark = null; }
  const k = INC.list.indexOf(inc); if (k >= 0) INC.list.splice(k, 1);
}
function incClear() { for (const inc of INC.list.slice()) incRemove(inc); }
HOME_FN.incHelp = function (m) {
  const inc = m.inc; if (!inc || inc.helped) return;
  inc.helped = true;
  const rw = inc.type === 'fire' ? 250 : 200;
  addMoney(rw); SFX.cash(); S.flags.helped = (S.flags.helped || 0) + 1; persist();
  if (inc.type === 'fire') { inc.out = true; inc.life = Math.min(inc.life, 8); toast('🧯 Вы помогли потушить огонь: +' + fmtMoney(rw)); }
  else { inc.life = Math.min(inc.life, 10); if (inc.hum[0]) inc.hum[0].fall = 0; toast('🩹 Пострадавшему оказали помощь: +' + fmtMoney(rw)); }
  const k = WORLD_MARKS.indexOf(inc.mark); if (k >= 0) WORLD_MARKS.splice(k, 1); inc.mark = null;
};
function emPatrol() {
  for (const def of [AMB_DEF, FIRE_DEF]) {
    if (cars.some(c => c.def === def && c.kind === 'traffic')) continue;
    const c = makeCar(def, 'traffic', def.color); placeTraffic(c, true); c.ai.maxSp = 21;
  }
}
function v24Tick(dt) {
  if (G.mode !== 'play') { if (INC.list.length) incClear(); return; }
  if (G.inHome) return;
  if ((INC.em -= dt) <= 0) { INC.em = 25; emPatrol(); }
  INC.t -= dt;
  if (INC.t <= 0) {
    INC.t = 70 + Math.random() * 70;
    if (INC.list.length < 2 && !(M && M.state === 'countdown') && !(M && M.def && M.def.type === 'chase')) { const r = Math.random(); incSpawn(r < 0.4 ? 'fire' : r < 0.8 ? 'med' : 'arrest'); }
  }
  let nearest = 1e9;
  for (let k = INC.list.length - 1; k >= 0; k--) {
    const inc = INC.list[k]; inc.life -= dt;
    const dc = Math.hypot(inc.x - CAM.x, inc.z - CAM.z); nearest = Math.min(nearest, dc);
    if (dc < 170 && (inc.pt -= dt) <= 0) {
      inc.pt = 0.07;
      if (inc.type === 'fire') {
        const c0 = inc.cars[0];
        if (!inc.out) {
          emit(inc.x + rand(-0.7, 0.7), 0.7 + rand(0, 0.5), inc.z + rand(-0.5, 0.5), rand(-0.4, 0.4), rand(3, 4.6), rand(-0.4, 0.4), 0.7, 0.7, 1.7, 1, 0.55, 0.1, 0.9, true);
          emit(inc.x, 1.7, inc.z, rand(-0.5, 0.5), rand(1.5, 2.6), rand(-0.5, 0.5), 2.6, 0.8, 3, 0.16, 0.16, 0.18, 0.55, false);
        } else if (c0 && Math.random() < 0.5) emit(inc.x, 1.2, inc.z, rand(-0.3, 0.3), rand(1, 1.8), rand(-0.3, 0.3), 2, 0.6, 2.2, 0.5, 0.5, 0.52, 0.4, false);
        for (const h of inc.hum) if (h.job === 'hose') { const dx = inc.x - h.x, dz = inc.z - h.z, l = Math.hypot(dx, dz) || 1; emit(h.x + dx / l * 0.5, 1.5, h.z + dz / l * 0.5, dx / l * 6.2 + rand(-0.3, 0.3), 3.2, dz / l * 6.2 + rand(-0.3, 0.3), 0.6, 0.14, 0.26, 0.7, 0.85, 1, 0.8, true); }
      }
    }
    if (inc.life <= 0 || (dc > 700)) { if (dc < 300 && inc.type === 'fire' && !inc.helped) toast('🚒 Пожар потушен пожарными'); incRemove(inc); }
  }
  if (!WANT.cars.length && !(M && M.def && M.def.type === 'chase')) {
    let near = nearest;
    for (const c of cars) if (c.def.siren && c.kind === 'traffic') near = Math.min(near, Math.hypot(c.x - CAM.x, c.z - CAM.z));
    auSiren(near < 120 ? clamp(1 - near / 120, 0, 1) * 0.7 : 0);
  }
}
function drawIncHumans() {
  for (const inc of INC.list) for (const h of inc.hum) {
    const d = visible(h.x, h.z, 2, 110); if (!d) continue;
    drawHuman(h.x, terrainY(h.x, h.z), h.z, h.h, 0, 0, h.look, d > 38, 1, null, h.fall || 0);
  }
}
ACH.push({ id: 'a37', ico: '🧯', t: 'Герой города', d: 'Помогите службам спасения 5 раз', r: 1500, f: () => (S.flags.helped || 0) >= 5 });
ACH.push({ id: 'a38', ico: '🚇', t: 'Подземка', d: 'Проедьте на метро 5 раз', r: 800, f: () => (S.flags.metro || 0) >= 5 });
ACH.push({ id: 'a39', ico: '💼', t: 'Владелец империи', d: 'Соберите доходы в кабинете пентхауса', r: 1000, f: () => (S.flags.officeCol || 0) >= 1 });


