/* ===================== 17. ОБНОВЛЕНИЕ ИГРЫ ===================== */
function updatePlay(dt) {
  const raw = readInput();
  const locked = (M && M.state === 'countdown') || RC.lock;
  const inp = (locked || P.downT > 0) ? ZERO_INP : raw;
  // камера клавишами Q/E
  const rot = (keys.KeyQ ? 1 : 0) - (keys.KeyE ? 1 : 0);
  if (rot) { if (P.car) { CAM.off += rot * 1.8 * dt; CAM.lastDrag = performance.now(); } else CAM.yaw += rot * 1.9 * dt; }
  if (!P.car) updateWalk(dt, inp);
  updateCars(dt, inp);
  const c = P.car;
  if (c) {
    P.x = c.x; P.z = c.z; P.y = c.y; P.h = c.h;
    S.stats.dist += Math.abs(c.vf) * dt;
    if (c.nitroOn && Math.random() < dt * 60) {
      const f = [Math.sin(c.h), Math.cos(c.h)];
      emit(c.x - f[0] * (c.L / 2 + 0.4), 0.5, c.z - f[1] * (c.L / 2 + 0.4), -f[0] * 6 + rand(-1, 1), rand(0, 1.5), -f[1] * 6 + rand(-1, 1), 0.35, 0.3, 0.05, 1, 0.55, 0.15, 0.9, true);
    }
    auEngine(true, clamp(Math.abs(c.vf) / c.st.maxSpeed, 0, 1.3), inp.gas, c.nitroOn);
  } else auEngine(false, 0, 0, false);
  updateDrift(dt);
  updateCombat(dt, inp);
  updateWanted(dt);
  recycleTraffic(dt);
  updatePickups(dt);
  updateMission(dt);
  if (!(M && M.def.type === 'chase') && !WANT.cars.length) auSiren(0);
  updatePeds(dt); updateParticles(dt);
  S.stats.time += dt;
  G.saveT += dt;
  if (G.saveT > 10) { G.saveT = 0; S.pos = G.inHome ? ((G.int && G.int.ret) || homeDoorPos()) : { x: P.x, z: P.z }; persist(); }
}

