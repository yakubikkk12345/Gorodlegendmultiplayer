/* ===================== РОЗЫСК / УБИЙСТВА / ПОЛИЦИЯ ===================== */
const WANT = { civ: 0, cop: 0, stars: 0, heat: 0, units: [], cars: [], spT: 0, carT: 0, crime: 0, blocks: [], heli: null, zone: null, seen: false, blkT: 3 };
const COP_LOOK = { pants: hexRGB('#1b2438'), shirt: hexRGB('#2f5fd0'), skin: hexRGB('#e0ac86'), hair: hexRGB('#10182b'), dark: [0.04, 0.04, 0.06] };
function clearWanted(msg) {
  WANT.units.length = 0;
  for (const c of WANT.cars) removeCar(c);
  WANT.cars.length = 0;
  for (const b of WANT.blocks) for (const c of b.cars) removeCar(c);
  WANT.blocks.length = 0; WANT.heli = null; WANT.zone = null; WANT.seen = false; WANT.crime = 0; WANT.blkT = 3;
  const had = WANT.stars > 0;
  WANT.civ = WANT.cop = WANT.stars = 0; WANT.heat = 0;
  if (msg && had) toast('✅ Розыск снят');
}
function wantedKill(kind) {
  if (kind === 'cop') WANT.cop++; else WANT.civ++;
  WANT.heat = 0;
  const c = WANT.civ, p = WANT.cop;
  let st = 0;
  if (c >= 1) st = 1; if (p >= 1) st = 2; if (c >= 10 || p >= 5) st = 3; if (c >= 20 || p >= 10) st = 4; if (c >= 50 || p >= 25) st = 5;
  if (WANT.crime) st = Math.max(st, WANT.crime);
  if (M) return;
  if (st > WANT.stars) { WANT.stars = st; toast('🚨 Розыск: ' + '★'.repeat(st)); SFX.err(); }
}
function killPed(p, car) {
  if (p.dead) return;
  p.dead = 0.001; p.fall = 0; p.hp = 0;
  for (let k = 0; k < 6; k++) emit(p.x, 0.6 + Math.random(), p.z, rand(-2, 2), rand(0.5, 2.5), rand(-2, 2), 0.6, 0.3, 1.0, 0.8, 0.25, 0.25, 0.7, false);
  if (car) { SFX.hit(); CAM.shake = Math.max(CAM.shake, 0.2); }
  addMoney(20);
  wantedKill('civ');
}
function damagePed(p, dmg) {
  if (p.thief) { thiefCaught(p); return; }
  if (p.hp === undefined) p.hp = 30;
  p.hp -= dmg; SFX.hit(); sparks(p.x, 1.2, p.z, [1, 0.3, 0.3]);
  if (p.hp <= 0) killPed(p, false);
}
function damageCop(e, dmg) {
  e.hp -= dmg; e.hit = 0.1; SFX.hit(); sparks(e.x, 1.2, e.z, [1, 0.4, 0.3]);
  if (e.hp > 0) return;
  const i = WANT.units.indexOf(e); if (i >= 0) WANT.units.splice(i, 1);
  for (let k = 0; k < 7; k++) emit(e.x, 1 + Math.random(), e.z, rand(-2, 2), rand(0.5, 2.5), rand(-2, 2), 0.7, 0.3, 1.2, 0.85, 0.85, 0.9, 0.6, false);
  addMoney(150); wantedKill('cop');
  toast('👮 Полицейский убит +$150');
}
function playerDown() {
  if (PJ.on) pjFail('Вас вывели из строя');
  if (ARENA.on) { arenaRespawn(); return; }
  const cop = P.lastSrc === 'cop', pvp = P.lastSrc === 'pvp';
  const fine = Math.min(S.money, 1000);
  S.money -= fine; clearWanted();
  if (P.car) exitCar(true);
  const base = cop ? POLST : HOSP;
  P.x = base.x; P.z = base.z - 20; P.y = terrainY(P.x, P.z); P.speed = 0; P.h = 0; CAM.yaw = 0; CAM.off = 0;
  P.hp = cop ? 100 : 60; HITFX.flash = 0; HITFX.lastHit = G.time; P.downT = 0; P.lastSrc = null;
  if (pvp) CB.inv = Math.max(CB.inv, 3);
  toast(cop ? '🚓 Вас обезвредила полиция. Штраф ' + fmtMoney(fine) : pvp ? '☠ Вас убили. Вы в больнице. Лечение ' + fmtMoney(fine) : '🏥 Вы в больнице. Лечение ' + fmtMoney(fine));
  persist(); refreshMoney(false);
}
function carHitPlayer(dt) {
  if (P.carHitT > 0) P.carHitT -= dt;
  if (P.downT > 0) P.downT -= dt;
  if (P.car || G.inHome || P.hp <= 0 || P.carHitT > 0) return;
  for (const c of cars) {
    const spd = Math.hypot(c.vx || 0, c.vz || 0);
    if (spd < 3.5 || c.def.heli) continue;
    const dx = P.x - c.x, dz = P.z - c.z;
    if (Math.abs(dx) > 6 || Math.abs(dz) > 6) continue;
    const fx = Math.sin(c.h), fz = Math.cos(c.h);
    const al = dx * fx + dz * fz, lat = dx * fz - dz * fx;
    if (Math.abs(al) < c.L / 2 + 0.45 && Math.abs(lat) < c.W / 2 + 0.45) {
      const dmg = clamp((spd - 2.5) * 3.4, 8, 90);
      hurtPlayer(dmg, c.kind === 'police' ? 'cop' : 'car');
      P.carHitT = 0.8; P.downT = 0.9;
      const k = 2.2 / Math.max(spd, 1); P.x += (c.vx || 0) * k; P.z += (c.vz || 0) * k; pushCircle(P, 0.6);
      CAM.shake = Math.max(CAM.shake, 0.5); SFX.hit();
      for (let q = 0; q < 5; q++) emit(P.x, 0.8 + Math.random(), P.z, rand(-2, 2), rand(0.5, 2.5), rand(-2, 2), 0.5, 0.25, 0.9, 0.9, 0.9, 0.9, 0.6, false);
      break;
    }
  }
}
function spawnCop() {
  const ang = Math.random() * TAU, r = rand(42, 66);
  const st = WANT.stars;
  const e = { x: clamp(P.x + Math.cos(ang) * r, -EDGE, EDGE), z: clamp(P.z + Math.sin(ang) * r, -EDGE, EDGE), h: 0, hp: 50 + st * 9, maxhp: 50 + st * 9, cd: rand(1.0, 2.2), ph: Math.random() * 6, amp: 0,
    sp: rand(4.0, 5.2), pref: rand(8, 15), sdir: Math.random() < 0.5 ? 1 : -1, sflip: rand(1, 3), hit: 0, boss: false, sc: 1, cop: true, look: COP_LOOK,
    gun: { id: st >= 4 ? pick(['smg', 'rifle']) : st === 3 ? 'smg' : 'pistol', aim: 0, kick: 0, reload: 0 }, dmg: rand(4, 6) + st * 0.7, rate: rand(1.0, 1.6) };
  pushCircle(e, 0.6);
  WANT.units.push(e);
}
function spawnCopCar() {
  let i, j, g = 0;
  do { i = Math.floor(Math.random() * (GRID + 1)); j = Math.floor(Math.random() * (GRID + 1)); const d = Math.hypot(nodeC(i) - P.x, nodeC(j) - P.z); if (d > 90 && d < 220) break; } while (g++ < 40);
  const opts = validDirs(i, j, Math.floor(Math.random() * 4));
  const cp = makeCar(POLICE_DEF, 'police', '#f5f5f5');
  initNavAI(cp, 'police', i, j, opts[0], 2, 44 + WANT.stars * 2, 14);
  cp.ai.hold = false;
  WANT.cars.push(cp);
}
