/* ===== Жизнь города: прохожие, события, такси, кафе ===== */
const JOB = { state: 'idle', px: 0, pz: 0, dx: 0, dz: 0, t: 0, limit: 0, dist: 0, ped: null, nocar: 0 };
const EV = { t: 70, thief: null, thT: 0, wallet: null, wT: 0 };
const THIEF_LOOK = { pants: hexRGB('#1a1a1c'), shirt: hexRGB('#0d0d10'), skin: hexRGB('#c68e6b'), hair: hexRGB('#111111'), dark: [0.05, 0.05, 0.06] };
const PED_NAMES = ['Алексей', 'Мария', 'Дмитрий', 'Ольга', 'Иван', 'Наталья', 'Сергей', 'Анна', 'Павел', 'Елена', 'Игорь', 'Татьяна', 'Роман', 'Юлия'];
const PED_LINES = [
  'Город сегодня шумный, правда?', 'Говорят, в баре «Крот» всегда есть работа для смелых.', 'Не гоняйте тут, у нас дети гуляют.',
  'Видели новый клуб «Неон»? Там такие вечеринки!', 'Если нужны деньги — подработайте в таксопарке.', 'Кафе «Вкусно» — лучшие хот-доги в городе.',
  'Я бы купил АЗС, да денег нет. Эх...', 'Слышал, вертолёт можно купить в автосалоне. Мечта!', 'В больнице работает отличный врач, Анна.',
  'Осторожнее с полицией: они не прощают лишних звёзд.', 'Видел, как кто-то обронил кошелёк у перекрёстка. Ищите!', 'Оружейный на углу — не для слабонервных.',
  'Хороший день для прогулки.', 'Мой кузен гоняет на спортбайке. Говорит, быстрее ветра.', 'Тут постоянно что-то происходит. Скучать не приходится.'
];
const PED_RAIN = ['Ну и ливень! Дороги как каток.', 'Забыл зонт, вот же беда.', 'В дождь за рулём — аккуратнее, тормозной путь длиннее!'];
const PED_NIGHT = ['Поздновато гуляете... Ночью тут небезопасно.', 'Ночью клубы работают на полную.', 'Красиво тут по ночам, правда?'];
function pedSnapToLoop(p) {
  const bi = clamp(Math.floor((p.x + HALF) / PITCH), 0, GRID - 1), bj = clamp(Math.floor((p.z + HALF) / PITCH), 0, GRID - 1), H = 30;
  const lx = clamp(p.x - bc(bi), -H, H), lz = clamp(p.z - bc(bj), -H, H);
  let s;
  if (Math.abs(lz) >= Math.abs(lx)) s = lz < 0 ? lx + H : 120 + (H - lx); else s = lx > 0 ? 60 + (lz + H) : 180 + (H - lz);
  p.bi = bi; p.bj = bj; p.s = s % 240;
}
function talkPed(p) {
  if (!p || p.dead) return;
  p.talk = 4.5; p.name = p.name || pick(PED_NAMES);
  p.h = Math.atan2(P.x - p.x, P.z - p.z);
  S.flags.talks = (S.flags.talks || 0) + 1;
  let line = pick(PED_LINES);
  if (WANT.stars > 0 && Math.random() < 0.5) line = 'Говорят, за вами охотится полиция... Я ничего не видел.';
  else if (WX.rain > 0.4 && Math.random() < 0.6) line = pick(PED_RAIN);
  else if (ENV.night > 0.6 && Math.random() < 0.6) line = pick(PED_NIGHT);
  const r = Math.random();
  if (r < 0.12) { const g = 20 + Math.floor(Math.random() * 5) * 20; addMoney(g); SFX.cash(); line += ' (Сунул вам ' + fmtMoney(g) + ' на кофе.)'; }
  toast('💬 ' + p.name + ': «' + line + '»');
  SFX.click(); persist();
}
function jobRandPoint(ax, az, dmin, dmax) {
  for (let k = 0; k < 40; k++) {
    const vertical = Math.random() < 0.5, line = 1 + Math.floor(Math.random() * (GRID - 1)), pos = (Math.random() - 0.5) * (HALF * 2 - 60);
    const x = vertical ? nodeC(line) + 10 : pos, z = vertical ? pos : nodeC(line) + 10, d = Math.hypot(x - ax, z - az);
    if (d >= dmin && d <= dmax) return [x, z];
  }
  return [clamp(ax + 150, -HALF + 20, HALF - 20), az];
}
/* --- вор --- */
function thiefStart() {
  const c = peds.filter(p => !p.dead && !p.fixed && !p.thief && !p.talk && Math.hypot(p.x - P.x, p.z - P.z) > 45 && Math.hypot(p.x - P.x, p.z - P.z) < 120);
  if (!c.length) { EV.t = 20; return; }
  const p = pick(c), sn = navSnap(p.x, p.z), ends = navEnds(sn).map(id => ({ id, q: navPt(id) }));
  ends.sort((a, b) => Math.hypot(b.q[0] - P.x, b.q[1] - P.z) - Math.hypot(a.q[0] - P.x, a.q[1] - P.z));
  const e = ends[0];
  p.thief = true; p.look0 = p.look; p.look = THIEF_LOOK;
  p.ci = Math.floor(e.id / NAVN); p.cj = e.id % NAVN; p.pi = -1; p.pj = -1; p.tgt = e.q;
  EV.thief = p; EV.thT = 0;
  toast('🚨 Вор украл сумку! Догоните его — оранжевая метка на карте (80 с).');
}
function thiefStep(p, dt) {
  const sp = 7.2;
  const dx = p.tgt[0] - p.x, dz = p.tgt[1] - p.z, d = Math.hypot(dx, dz);
  if (d < 1.5) {
    let best = null, bs = -1;
    for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const ni = p.ci + di, nj = p.cj + dj;
      if (ni < 0 || nj < 0 || ni > GRID || nj > GRID || (ni === p.pi && nj === p.pj)) continue;
      const sc = Math.hypot(nodeC(ni) - P.x, nodeC(nj) - P.z) + Math.random() * 70;
      if (sc > bs) { bs = sc; best = [ni, nj]; }
    }
    if (best) { p.pi = p.ci; p.pj = p.cj; p.ci = best[0]; p.cj = best[1]; p.tgt = [nodeC(best[0]), nodeC(best[1])]; }
  } else { p.x += dx / d * sp * dt; p.z += dz / d * sp * dt; p.h = Math.atan2(dx, dz); p.ph += sp * dt * 2.4; }
  const px = P.car ? P.car.x : P.x, pz = P.car ? P.car.z : P.z, dd = Math.hypot(p.x - px, p.z - pz);
  if (G.mode === 'play' && !G.inHome && ((P.car && Math.abs(P.car.vf) > 3 && dd < 2.8) || (!P.car && dd < 1.7))) thiefCaught(p);
}
function thiefEnd(p) { p.thief = false; p.look = p.look0 || p.look; EV.thief = null; pedSnapToLoop(p); }
function thiefCaught(p) {
  if (!p.thief) return;
  const r = 250 + Math.floor(Math.random() * 6) * 50;
  thiefEnd(p); p.panic = 5;
  addMoney(r); SFX.cash(); S.flags.thief = (S.flags.thief || 0) + 1; persist();
  toast('🎒 Вор пойман! Сумка возвращена: +' + fmtMoney(r));
}
function thiefEscape() { if (EV.thief) { thiefEnd(EV.thief); toast('Вор скрылся. Сумку не вернуть...'); } }
/* --- кошелёк --- */
function walletStart() {
  const q = jobRandPoint(P.x, P.z, 70, 160), c = { x: q[0], z: q[1], v: 200 + Math.floor(Math.random() * 5) * 100, t: 0, wallet: true };
  cash.push(c); EV.wallet = c; EV.wT = 0;
  toast('👛 Кто-то обронил кошелёк — ищите жёлтую метку на карте.');
}
/* --- такси --- */
function jobFail(msg) {
  const p = JOB.ped; JOB.state = 'idle'; JOB.ped = null;
  if (p) { p.fixed = false; if (!p.dead) pedSnapToLoop(p); }
  navClear(true); if (msg) toast(msg);
}
function taxiStart() {
  if (JOB.state !== 'idle') { toast('🚕 У вас уже есть заказ'); return; }
  if (M) { toast('Сначала завершите задание'); return; }
  const c = peds.filter(p => !p.dead && !p.fixed && !p.thief);
  if (!c.length) { toast('Свободных пассажиров нет'); return; }
  const sx = P.car ? P.car.x : P.x, sz = P.car ? P.car.z : P.z, p = pick(c), q = jobRandPoint(sx, sz, 120, 380);
  p.fixed = true; p.x = q[0]; p.z = q[1]; p.h = Math.random() * TAU; p.ph = 0;
  JOB.state = 'pickup'; JOB.t = 0; JOB.px = q[0]; JOB.pz = q[1]; JOB.ped = p; JOB.nocar = 0;
  navSet(q[0], q[1], true);
  toast(P.car ? '🚕 Заказ принят! Подъезжайте к пассажиру.' : '🚕 Заказ принят! Сядьте в машину и езжайте к пассажиру.');
}
function jobTick(dt) {
  if (JOB.state === 'idle') return;
  JOB.t += dt;
  const c = P.car, x = c ? c.x : P.x, z = c ? c.z : P.z;
  if (JOB.state === 'pickup') {
    if (!JOB.ped || JOB.ped.dead) { jobFail('🚕 Пассажир пострадал — заказ отменён'); return; }
    if (JOB.t > 180) { jobFail('🚕 Пассажир ушёл — заказ отменён'); return; }
    if (c && !(c.alt > 1) && Math.hypot(JOB.px - x, JOB.pz - z) < 12 && Math.abs(c.vf) < 6) {
      const p = JOB.ped; p.fixed = false;
      for (let k = 0; k < 20; k++) { p.bi = Math.floor(Math.random() * GRID); p.bj = Math.floor(Math.random() * GRID); if (Math.hypot(bc(p.bi) - x, bc(p.bj) - z) > 150) break; }
      p.s = Math.random() * 240; JOB.ped = null;
      const q = jobRandPoint(JOB.px, JOB.pz, 250, 520);
      JOB.dx = q[0]; JOB.dz = q[1]; JOB.dist = Math.hypot(q[0] - JOB.px, q[1] - JOB.pz); JOB.limit = JOB.dist / 10 + 30; JOB.t = 0; JOB.state = 'ride';
      navSet(q[0], q[1], true); SFX.door();
      toast('🚕 Пассажир сел. Везите по адресу — маршрут на карте.');
    }
  } else if (JOB.state === 'ride') {
    if (!c) { if ((JOB.nocar += dt) > 25) { jobFail('🚕 Вы бросили пассажира — заказ отменён'); return; } } else JOB.nocar = 0;
    if (c && !(c.alt > 1) && Math.hypot(JOB.dx - x, JOB.dz - z) < 12 && Math.abs(c.vf) < 6) {
      let pay = 100 + Math.round(JOB.dist * 0.55); const fast = JOB.t < JOB.limit;
      if (fast) pay = Math.round(pay * 1.35);
      JOB.state = 'idle'; navClear(true);
      addMoney(pay); SFX.cash(); S.flags.taxi = (S.flags.taxi || 0) + 1; persist();
      toast('🚕 Пассажир доставлен: +' + fmtMoney(pay) + (fast ? ' (быстро — чаевые!)' : ''));
      return;
    }
  }
  if (NAV.on && JOB.state !== 'idle') {
    const d = Math.round(NAV.dist);
    setText($('navBox'), (JOB.state === 'pickup' ? '🚕 К пассажиру: ' : '🚕 Везём: ') + d + ' м' + (JOB.state === 'ride' ? ' · ⏱ ' + Math.max(0, Math.ceil(JOB.limit - JOB.t)) + ' с' : ''));
  }
}
function taxiGreet() { return JOB.state === 'idle' ? 'Таксопарк слушает! Водители нужны всегда. Берёте заказ?' : 'У вас уже есть заказ. Пассажир ждёт!'; }
function taxiOptions() {
  const o = [];
  if (JOB.state === 'idle') o.push({ t: '🚕 Взять заказ', fn: () => { closeScreens(); taxiStart(); } });
  else o.push({ t: '❌ Отменить заказ', fn: () => { jobFail(); say('Отменили. Но репутацию не вернуть...'); } });
  o.push({ t: '📊 Моя статистика', fn: () => say('Выполнено заказов: ' + (S.flags.taxi || 0) + '. Оплата зависит от расстояния, плюс 35% за быструю доставку.') });
  o.push({ t: '❓ Как это работает?', fn: () => say('Подъезжайте к пассажиру (метка) и остановитесь рядом, затем везите по адресу. Навигатор проложит путь сам.') });
  o.push(byeOpt());
  return o;
}
function foodOptions() {
  const o = [], menu = [['🌭 Хот-дог', 20, 25], ['🍔 Бургер-комбо', 60, 60], ['☕ Кофе', 12, 10]];
  for (const m of menu) o.push({ t: m[0] + ' — ' + fmtMoney(m[1]) + ' (+' + m[2] + ' здоровья)', dis: P.hp >= 99 || S.money < m[1], fn: () => { S.money -= m[1]; P.hp = Math.min(100, P.hp + m[2]); S.flags.food = (S.flags.food || 0) + 1; persist(); SFX.buy(); refreshMoney(true); say('Приятного аппетита!'); } });
  o.push({ t: '🗣 Какие новости?', fn: () => say(pick(PED_LINES)) });
  o.push(byeOpt());
  return o;
}
function lifeTick(dt) {
  if (G.mode !== 'play' || G.inHome) return;
  if (!M && JOB.state === 'idle' && !EV.thief && !EV.wallet) {
    if ((EV.t -= dt) <= 0) { EV.t = 150 + Math.random() * 150; if (Math.random() < 0.6) thiefStart(); else walletStart(); }
  }
  if (EV.thief && (EV.thT += dt) > 80) thiefEscape();
  if (EV.wallet) {
    const w = EV.wallet;
    if (w.t > 0) { const i = cash.indexOf(w); if (i >= 0) cash.splice(i, 1); EV.wallet = null; S.flags.wallet = (S.flags.wallet || 0) + 1; toast('👛 Кошелёк найден!'); persist(); }
    else if ((EV.wT += dt) > 160) { const i = cash.indexOf(w); if (i >= 0) cash.splice(i, 1); EV.wallet = null; }
  }
  jobTick(dt);
}
const BZ = { t: 0 };
function bizTick(dt) {
  v16Tick(dt);
  v17Tick(dt);
  v18Tick(dt);
  v19Tick(dt);
  v20Tick(dt);
  v21Tick(dt);
  v24Tick(dt);
  v25Tick(dt);
  let any = false;
  for (const k in S.biz) { const r = S.biz[k], b = BIZ_BY[k]; if (b && r && r.own) { bizAdd(r, b, dt); any = true; } }
  if (any && (BZ.t += dt) > 30) { BZ.t = 0; persist(); }
}
function tick(dt) {
  G.time += dt;
  resize();
  updateEnv(dt);
  if (UI.studio) { renderStudio(dt); return; }
  if (G.mode === 'play' && !G.paused) { updatePlay(dt); bizTick(dt); navTick(dt); extraTick(dt); lifeTick(dt); }
  if (G.mode === 'play' || MP.ws) mpTick(dt);
  if (G.mode === 'play' && !G.paused) v31Tick(dt);
  if (G.mode === 'play' && MP.ws) v30Tick(dt);
  else if (G.mode === 'menu') { if (INC.list.length) incClear(); updateCars(dt, null); updatePeds(dt); updateParticles(dt); }
  updateCamera(dt);
  STATS.draws = 0;
  drawScene();
  if (G.mode === 'play') { updateHUD(dt); mpHud(); v28Hud(dt); }
}
function frame(now) {
  requestAnimationFrame(frame);
  let dt = (now - lastT) / 1000; lastT = now;
  if (!(dt > 0)) return;
  dt = Math.min(dt, 0.05);
  fpsAcc += dt; fpsN++;
  if (!document.hidden && G.mode !== 'loading') {
    adaptT += dt; adaptN++;
    if (adaptT > 1.6) {
      const f = adaptN / adaptT; adaptT = 0; adaptN = 0;
      if (adaptSkip > 0) adaptSkip--;
      else if (f < 40 && G.scale > 0.5) { G.scale = Math.max(0.5, G.scale - (f < 28 ? 0.15 : 0.08)); adaptSkip = 1; }
      else if (f > 57 && G.scale < 1) { G.scale = Math.min(1, G.scale + 0.05); adaptSkip = 1; }
    }
  } else { adaptT = 0; adaptN = 0; }
  if (fpsAcc > 0.5) { if (S.set.fps) $('fps').textContent = Math.round(fpsN / fpsAcc) + ' FPS · ' + STATS.draws + ' dc'; fpsAcc = 0; fpsN = 0; }
  try { tick(dt); } catch (e) { if (!errShown) { errShown = true; console.error('tick error', e); } }
}

