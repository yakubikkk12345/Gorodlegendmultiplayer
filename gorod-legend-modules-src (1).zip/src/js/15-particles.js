/* ===================== 11. ЧАСТИЦЫ ===================== */
const PART_MAX = 260, parts = [];
const PVB = gl.createBuffer(), PIB = gl.createBuffer();
const PV = new Float32Array(PART_MAX * 9 * 12);
{
  const idx = new Uint16Array(PART_MAX * 24);
  for (let k = 0; k < PART_MAX; k++) for (let s = 0; s < 8; s++) { const o = k * 24 + s * 3, b = k * 9; idx[o] = b; idx[o + 1] = b + 1 + s; idx[o + 2] = b + 1 + (s + 1) % 8; }
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, PIB); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);
  gl.bindBuffer(gl.ARRAY_BUFFER, PVB); gl.bufferData(gl.ARRAY_BUFFER, PV.byteLength, gl.DYNAMIC_DRAW);
}
function emit(x, y, z, vx, vy, vz, life, s0, s1, r, g, b, a, add) {
  if (parts.length >= PART_MAX) parts.shift();
  parts.push({ x, y, z, vx, vy, vz, life, max: life, s0, s1, r, g, b, a, add });
}
function updateParticles(dt) {
  for (let i = parts.length - 1; i >= 0; i--) {
    const p = parts[i]; p.life -= dt;
    if (p.life <= 0) { parts.splice(i, 1); continue; }
    p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
    if (!p.add) { p.vx *= 0.97; p.vz *= 0.97; }
    else p.vy -= 6 * dt;
  }
}
const SIN8 = [], COS8 = [];
for (let i = 0; i < 8; i++) { SIN8.push(Math.sin(i / 8 * TAU)); COS8.push(Math.cos(i / 8 * TAU)); }
function drawParticles(add) {
  let n = 0;
  const rx = VIEW[0], ry = VIEW[4], rz = VIEW[8], ux = VIEW[1], uy = VIEW[5], uz = VIEW[9];
  for (const p of parts) {
    if (p.add !== add) continue;
    const t = 1 - p.life / p.max, s = lerp(p.s0, p.s1, t), al = p.a * (1 - t) * (add ? 1 : Math.min(1, (1 - t) * 2));
    let o = n * 108;
    // центр
    PV[o++] = p.x; PV[o++] = p.y; PV[o++] = p.z; PV[o++] = 0; PV[o++] = 1; PV[o++] = 0; PV[o++] = p.r; PV[o++] = p.g; PV[o++] = p.b; PV[o++] = al; PV[o++] = 0; PV[o++] = 0;
    for (let k = 0; k < 8; k++) {
      const cx = COS8[k] * s, cy = SIN8[k] * s;
      PV[o++] = p.x + rx * cx + ux * cy; PV[o++] = p.y + ry * cx + uy * cy; PV[o++] = p.z + rz * cx + uz * cy;
      PV[o++] = 0; PV[o++] = 1; PV[o++] = 0; PV[o++] = p.r; PV[o++] = p.g; PV[o++] = p.b; PV[o++] = 0; PV[o++] = 0; PV[o++] = 0;
    }
    n++;
  }
  if (!n) return;
  gl.bindBuffer(gl.ARRAY_BUFFER, PVB);
  gl.bufferSubData(gl.ARRAY_BUFFER, 0, PV.subarray(0, n * 108));
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, PIB);
  gl.vertexAttribPointer(0, 3, gl.FLOAT, false, STRIDE, 0); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, STRIDE, 12);
  gl.vertexAttribPointer(2, 4, gl.FLOAT, false, STRIDE, 24); gl.vertexAttribPointer(3, 2, gl.FLOAT, false, STRIDE, 40);
  gl.uniformMatrix4fv(U.uM, false, IDENT);
  gl.uniform3f(U.uTint, 1, 1, 1); gl.uniform1f(U.uAlpha, 1); gl.uniform1f(U.uUnlit, add ? 2 : 1); gl.uniform1f(U.uUseTex, 0);
  gl.drawElements(gl.TRIANGLES, n * 24, gl.UNSIGNED_SHORT, 0);
  STATS.draws++;
}

