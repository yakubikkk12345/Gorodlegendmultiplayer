/* ===================== v34: КАЗИНО+ (покер для игроков, VIP, охрана, ограбление, джекпот) И РАСКЛАДКА УПРАВЛЕНИЯ ===================== */
{
  const CTL = window.__CTL;
  const PAD_DEF = { jump: 0, act: 1, reload: 2, enter: 3, wnext: 4, nade: 5, aim: 6, fire: 7, map: 8, pause: 9, run: 10, aimmode: 11, radio: 12, call: 13, wprev: 14, wnext2: 15, fmode: 16 };
  const PADN = ['A', 'B', 'X', 'Y', 'LB', 'RB', 'LT', 'RT', 'Back', 'Start', 'L3', 'R3', '↑', '↓', '←', '→', 'Home'];
  const PA = [['jump', 'Прыжок / ручник'], ['act', 'Действие / нитро'], ['reload', 'Перезарядка / гудок'], ['enter', 'Сесть / выйти'], ['fire', 'Огонь / газ (триггер)'], ['aim', 'Прицел / тормоз (триггер)'],
    ['nade', 'Граната / огонь из машины'], ['wnext', 'Оружие вперёд'], ['wnext2', 'Оружие вперёд (вторая)'], ['wprev', 'Оружие назад'], ['run', 'Бег (вкл/выкл)'], ['aimmode', 'Режим прицела'],
    ['radio', 'Радио'], ['call', 'Вызвать машину'], ['map', 'Карта'], ['pause', 'Пауза'], ['fmode', 'Режим стрельбы']];
  const KA = [['fwd', 'Вперёд', 'KeyW'], ['back', 'Назад', 'KeyS'], ['left', 'Влево', 'KeyA'], ['right', 'Вправо', 'KeyD'], ['space', 'Ручник / огонь пешком', 'Space'], ['sprint', 'Бег / нитро', 'ShiftLeft'],
    ['fire', 'Огонь', 'KeyG'], ['jump', 'Прыжок', 'KeyX'], ['mark', 'Действие (метки)', 'KeyE'], ['enter', 'Сесть / выйти', 'KeyF'], ['reload', 'Перезарядка / сброс авто', 'KeyR'], ['call', 'Вызвать машину', 'KeyC'],
    ['horn', 'Гудок', 'KeyH'], ['radio', 'Радио', 'KeyN'], ['aim', 'Режим прицела', 'KeyY'], ['zoom', 'Зум', 'KeyU'], ['spec', 'Спецдействие', 'KeyZ'], ['nade', 'Граната', 'KeyQ'],
    ['c4', 'Взрывчатка C4', 'KeyB'], ['map', 'Карта', 'KeyM'], ['jobs', 'Задания', 'KeyJ'], ['wheel', 'Колесо оружия (удерживать)', 'Tab'], ['fmode', 'Режим стрельбы', 'KeyK'], ['holster', 'Убрать / достать оружие', 'KeyT']];
  const kcode = id => CTL.keys[id] || (KA.find(a => a[0] === id) || [])[2];
  const KN = { Space: 'Пробел', ShiftLeft: 'Shift', ShiftRight: 'Shift (прав.)', ControlLeft: 'Ctrl', AltLeft: 'Alt', Tab: 'Tab', Enter: 'Enter', Backspace: '⌫', ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→' };
  const kname = c => KN[c] || String(c || '?').replace(/^Key/, '').replace(/^Digit/, '').replace(/^Numpad/, 'Num ');

  /* ---------- переназначение клавиш ---------- */
  let U2D = {}, SUP = new Set();
  function rebuild() {
    U2D = {}; SUP = new Set(); const used = new Set();
    for (const a of KA) { const u = kcode(a[0]); U2D[u] = a[2]; used.add(u); }
    for (const a of KA) if (!used.has(a[2])) SUP.add(a[2]);
  }
  rebuild();
  function onKey(e) {
    if (e.__syn) return;
    if (CTL.listen && CTL.listen.t === 'k') {
      e.preventDefault(); e.stopImmediatePropagation();
      if (e.type === 'keydown' && !e.repeat) {
        const L = CTL.listen; CTL.listen = null;
        if (e.code !== 'Escape' && !/^F\d+$/.test(e.code)) L.cb(e.code); else renderCtl();
      }
      return;
    }
    if (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName || '')) return;
    const c = e.code, d = U2D[c];
    if (d === undefined) { if (SUP.has(c)) { e.preventDefault(); e.stopImmediatePropagation(); } return; }
    if (d === c) return;
    e.preventDefault(); e.stopImmediatePropagation();
    const ne = new KeyboardEvent(e.type, { code: d, key: e.key, repeat: e.repeat, shiftKey: e.shiftKey, ctrlKey: e.ctrlKey, altKey: e.altKey, bubbles: true, cancelable: true });
    ne.__syn = true; window.dispatchEvent(ne);
  }
  window.addEventListener('keydown', onKey, true); window.addEventListener('keyup', onKey, true);
  function setKey(id, code) {
    const mine = kcode(id), other = KA.find(a => a[0] !== id && kcode(a[0]) === code);
    if (other) { CTL.keys[other[0]] = mine; if (mine === other[2]) delete CTL.keys[other[0]]; }
    CTL.keys[id] = code; if (code === KA.find(a => a[0] === id)[2]) delete CTL.keys[id];
    CTL.save(); rebuild(); renderCtl();
  }
  function setPad(id, idx) {
    const other = Object.keys(CTL.pad).find(k => k !== id && CTL.pad[k] === idx);
    if (other) CTL.pad[other] = CTL.pad[id];
    CTL.pad[id] = idx; CTL.save(); renderCtl();
  }

  /* ---------- экран настроек управления ---------- */
  const st = document.createElement('style');
  st.textContent = '.ctl-h{margin:14px 0 4px;font-size:15px;color:#ffd60a}.ctl-row{display:flex;justify-content:space-between;align-items:center;gap:8px;margin:4px 0;font-size:14px}'
    + '.ctl-btn{min-width:104px;padding:6px 10px !important;font-size:13px !important}.ctl-btn.lis{outline:2px solid #ffd60a;animation:ctlb .6s infinite alternate}@keyframes ctlb{to{opacity:.55}}'
    + '#heist .panel{text-align:center}#hsBar{position:relative;height:34px;background:#222;border-radius:8px;overflow:hidden;margin:12px 0}#hsZone{position:absolute;top:0;bottom:0;background:rgba(46,204,113,.65)}'
    + '#hsNeedle{position:absolute;top:0;bottom:0;width:4px;margin-left:-2px;background:#fff}.hs-l{display:inline-block;margin:0 6px;font-size:26px}'
    + '.pk-seat{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:4px 0;padding:3px 6px;border-radius:8px}.pk-seat.turn{outline:2px solid #ffd60a}.pk-seat .cas-card{padding:4px;min-width:30px;font-size:15px}';
  document.head.appendChild(st);
  const sc = document.querySelector('#settings .scroll'), fsb = sc && sc.querySelector('[data-act="fullscreen"]');
  if (sc && fsb) fsb.insertAdjacentHTML('beforebegin',
    '<div id="ctlBox"><h4 class="ctl-h">🎮 Управление</h4>'
    + '<label class="set">Геймпад: чувствительность стика <input type="range" id="ctSens" min="0.4" max="2.5" step="0.1"></label>'
    + '<label class="set">Геймпад: мёртвая зона <input type="range" id="ctDz" min="0.05" max="0.4" step="0.01"></label>'
    + '<label class="set">Инверсия камеры по вертикали <input type="checkbox" id="ctInvY"></label>'
    + '<label class="set">Инверсия камеры по горизонтали <input type="checkbox" id="ctInvX"></label>'
    + '<h4 class="ctl-h">⌨ Клавиатура (нажмите кнопку, затем клавишу)</h4><div id="ctlKeys"></div>'
    + '<h4 class="ctl-h">🎮 Кнопки геймпада (нажмите, затем кнопку на геймпаде)</h4><div id="ctlPad"></div>'
    + '<button class="btn" id="ctlReset">↺ Сбросить раскладку</button></div>');
  function renderCtl() {
    const box = $('ctlBox'); if (!box) return;
    const L = CTL.listen;
    $('ctSens').value = CTL.padSens; $('ctDz').value = CTL.dz; $('ctInvY').checked = CTL.invY; $('ctInvX').checked = CTL.invX;
    $('ctlKeys').innerHTML = KA.map(a => {
      const lis = L && L.t === 'k' && L.id === a[0], ch = !!CTL.keys[a[0]];
      return '<div class="ctl-row"><span>' + a[1] + '</span><button class="btn ctl-btn' + (lis ? ' lis' : '') + '" data-ctl="k:' + a[0] + '"' + (ch ? ' style="color:#ffd60a"' : '') + '>' + (lis ? 'нажмите клавишу…' : kname(kcode(a[0]))) + '</button></div>';
    }).join('');
    $('ctlPad').innerHTML = PA.map(a => {
      const lis = L && L.t === 'p' && L.id === a[0], ch = CTL.pad[a[0]] !== PAD_DEF[a[0]];
      return '<div class="ctl-row"><span>' + a[1] + '</span><button class="btn ctl-btn' + (lis ? ' lis' : '') + '" data-ctl="p:' + a[0] + '"' + (ch ? ' style="color:#ffd60a"' : '') + '>' + (lis ? 'нажмите кнопку…' : PADN[CTL.pad[a[0]]]) + '</button></div>';
    }).join('');
  }
  if (sc && fsb) {
    const box = $('ctlBox');
    box.addEventListener('click', e => {
      if (e.target.id === 'ctlReset') { CTL.keys = {}; for (const k in PAD_DEF) CTL.pad[k] = PAD_DEF[k]; CTL.padSens = 1; CTL.dz = 0.17; CTL.invX = CTL.invY = false; CTL.listen = null; CTL.save(); rebuild(); renderCtl(); toast('Раскладка сброшена'); return; }
      const b = e.target.closest('[data-ctl]'); if (!b) return;
      auInit();
      const sp = b.dataset.ctl.split(':'), id = sp[1];
      if (CTL.listen && CTL.listen.t === sp[0] && CTL.listen.id === id) { CTL.listen = null; renderCtl(); return; }
      if (sp[0] === 'k') CTL.listen = { t: 'k', id, cb: code => setKey(id, code) };
      else {
        if (!(navigator.getGamepads && Array.from(navigator.getGamepads()).some(p => p && p.connected))) toast('Подключите геймпад и нажмите на нём любую кнопку');
        const L = CTL.listen = { t: 'p', id, cb: idx => setPad(id, idx) };
        setTimeout(() => { if (CTL.listen === L) { CTL.listen = null; renderCtl(); } }, 10000);
      }
      renderCtl();
    });
    box.addEventListener('input', e => {
      if (e.target.id === 'ctSens') CTL.padSens = +e.target.value; else if (e.target.id === 'ctDz') CTL.dz = +e.target.value;
      else if (e.target.id === 'ctInvY') CTL.invY = e.target.checked; else if (e.target.id === 'ctInvX') CTL.invX = e.target.checked; else return;
      CTL.save();
    });
  }

  /* ---------- подсказки [E]/[F] с учётом раскладки и геймпада ---------- */
  const keyHint = (kAct, pAct) => CTL.padActive() ? PADN[CTL.pad[pAct]] : kname(kcode(kAct));
  const st0 = setText;
  setText = function (el, t) {
    if (el && el.id === 'prompt' && typeof t === 'string' && t) t = t.replace('[F]', '[' + keyHint('enter', 'enter') + ']').replace('[E]', '[' + keyHint('mark', 'act') + ']');
    st0(el, t);
  };

  /* ================== КАЗИНО ================== */
  const PKM = { tbl: 0, st: [null, null], seated: -1, chips: 0, pend: 0, void: false, peeked: -1, tAt: 0 };
  const JP = { pool: 100000 };
  const VIPB = [10000, 50000, 200000, 500000], NORB = CAS_BETS.slice();
  const vipOk = () => { const r = S.biz && S.biz.casino; return !!(r && r.own && (r.lvl || 1) >= 3); };
  const setBets = list => { CAS_BETS.length = 0; CAS_BETS.push(...list); if (!CAS_BETS.includes(CAS.bet)) CAS.bet = list === VIPB ? list[0] : 100; };
  const cdv = c => c < 0 ? '<div class="cas-card back">?</div>' : pkCard({ v: c % 13 + 2, s: Math.floor(c / 13) }, false);
  const jpBanner = () => '<div class="cas-msg" id="jpBan" style="color:#7df9ff;font-weight:700">💎 ДЖЕКПОТ: ' + fmtMoney(JP.pool) + '</div>';
  const jpUpd = () => { const e = $('jpBan'); if (e) e.textContent = '💎 ДЖЕКПОТ: ' + fmtMoney(JP.pool); };
  function jpWinSelf(amt) { casPay(amt); toast('💎 ДЖЕКПОТ! +' + fmtMoney(amt)); CAS.msg = '💎 ДЖЕКПОТ ' + fmtMoney(amt) + '!'; if (UI.cur === 'casino' && !casBusy()) casRender(); }
  function jpBet(n) {
    if (MP.state === 'on') { mpSend({ t: 'jp-bet', n }); return; }
    let pool = (S.casJp || 100000) + Math.floor(n * 0.03);
    if (Math.random() < Math.min(0.004, Math.max(0.00002, n / 4e6))) { JP.pool = S.casJp = 100000; jpUpd(); jpWinSelf(pool); return; }
    S.casJp = JP.pool = pool; jpUpd();
  }

  // метки и вход
  HOME_FN.casinoVip = function () {
    if (!vipOk()) { toast('👑 VIP-зал открывается владельцу казино на 3 уровне'); SFX.err(); return; }
    CAS.vipOpen = true; CAS.tab = 'vip'; CAS.msg = ''; openScreen('casino');
  };
  const cp0 = HOME_FN.casinoPlay;
  HOME_FN.casinoPlay = function (m) {
    if (m.tab === 'pk' && MP.state === 'on') { PKM.tbl = m.id === 'cs_pk1' ? 1 : 0; m = Object.assign({}, m, { tab: 'pkm' }); }
    return cp0(m);
  };
  const ss0 = showScreen;
  showScreen = function (name) {
    if (name === 'casino') {
      CAS.vip = !!CAS.vipOpen && vipOk(); CAS.vipOpen = false; setBets(CAS.vip ? VIPB : NORB);
      if (CAS.tab === 'vip' && !CAS.vip) CAS.tab = 'slot';
      if (MP.state === 'on') mpSend({ t: 'jp-get' }); else JP.pool = S.casJp || 100000;
    }
    ss0(name);
    if (name === 'settings') renderCtl();
    if (name === 'casino') { const h = document.querySelector('#casino h3'); if (h) h.textContent = '🎰 Казино «Золотой дракон»' + (CAS.vip ? ' · 👑 VIP' : ''); }
    if (name === 'heist') heistInit();
  };
  const tb = document.querySelector('#casino .cas-tabs');
  if (tb) tb.insertAdjacentHTML('beforeend', '<button class="btn" data-act="cas-tab" data-tab="pkm">♠ Покер (игроки)</button><button class="btn" data-act="cas-tab" data-tab="vip">👑 VIP</button>');

  const tabsOn = () => document.querySelectorAll('#casino .cas-tabs .btn').forEach(b => b.classList.toggle('on', b.dataset.tab === CAS.tab));
  const cr1 = casRender;
  casRender = function () {
    if (CAS.tab === 'pkm') return renderPkm();
    if (CAS.tab === 'vip') return renderVip();
    cr1();
    if (CAS.tab === 'slot') { const b = $('casBody'); if (b) b.insertAdjacentHTML('afterbegin', jpBanner()); }
  };
  const ca1 = casAct;
  casAct = function (a, el) {
    if (el && el.dataset && el.dataset.m) return v34Act(el.dataset.m, el);
    const was = CAS.slot.spin;
    ca1(a, el);
    if (a === 'cas-slot' && !was && CAS.slot.spin) jpBet(CAS.bet);
  };

  /* ---------- VIP: автомат с высокими ставками ---------- */
  function renderVip() {
    tabsOn();
    $('casBets').innerHTML = CAS.vip ? '<span class="muted" style="align-self:center">Ставка:</span>' + CAS_BETS.map(x => '<button class="btn' + (x === CAS.bet ? ' on' : '') + '" data-act="cas-bet" data-v="' + x + '">$' + x / 1000 + 'k</button>').join('') : '';
    if (!CAS.vip) { $('casBody').innerHTML = '<p class="muted">👑 VIP-зал — для владельцев казино 3 уровня и выше. Зайдите через дверь с канатами в углу зала.</p>'; return; }
    const r = CAS.slot.r;
    $('casBody').innerHTML = jpBanner() + '<div class="cas-wheel" id="casWheel">' + r.join(' ') + '</div><p class="muted">VIP-автомат: три одинаковых ×8 (7️⃣ ×25), два одинаковых ×1,5. Рулетка, блэкджек и видеопокер во вкладках — со ставками VIP.</p>'
      + '<button class="btn pri" data-act="cas-pk" data-m="vslot">🎰 Крутить на $' + CAS.bet / 1000 + 'k</button><div class="cas-msg" id="casMsg">' + CAS.msg + '</div>';
  }

  /* ---------- покер с игроками ---------- */
  const PHASE = ['префлоп', 'флоп', 'тёрн', 'ривер'];
  function renderPkm() {
    tabsOn(); $('casBets').innerHTML = '';
    const b = $('casBody');
    if (MP.state !== 'on') { b.innerHTML = '<p class="muted">Покер с живыми игроками — в мультиплеере: меню → 🌐 Мультиплеер → войдите в комнату (до 4 игроков). Лимит-холдем, блайнды $250/$500, вход от $15 000. За столом против дилера — вкладка «♠ Холдем».</p>'; return; }
    const t = PKM.tbl, s = PKM.st[t];
    if (PKM.peeked !== t && PKM.seated !== t) { PKM.peeked = t; mpSend({ t: 'pk-peek', tbl: t }); }
    let h = '<div class="cas-row">' + [0, 1].map(i => '<button class="btn' + (i === t ? ' on' : '') + '" data-act="cas-pk" data-m="tbl" data-v="' + i + '">Стол ' + (i + 1) + '</button>').join('') + '</div>';
    if (!s) h += '<p class="muted">Загрузка стола…</p>';
    else {
      const me = s.you;
      h += '<div class="muted" style="font-size:13px">Лимит-холдем · блайнды $250/$500 · ставка $' + s.sz + (s.st === 'play' ? ' · ' + PHASE[s.street] : '') + '</div>';
      h += '<div>Банк: <b class="gold">' + fmtMoney(s.pot) + '</b> <span id="pkTimer" class="muted"></span></div>';
      h += '<div class="cas-cards">' + (s.board.length ? s.board.map(cdv).join('') : '<span class="muted">карты стола — после флопа</span>') + '</div>';
      h += s.seats.map((x, k) => !x ? '' : '<div class="pk-seat' + (k === s.cur && s.st === 'play' ? ' turn' : '') + '"><b>' + mpEsc(x.name) + (k === me ? ' (вы)' : '') + (k === s.dealer ? ' Ⓓ' : '') + '</b><span class="muted">' + fmtMoney(x.chips)
        + (x.put ? ' · ставка ' + fmtMoney(x.put) : '') + (x.folded ? ' · сброс' : '') + '</span>' + (x.hole ? x.hole.map(cdv).join('') : '') + (x.win ? ' <b class="gold">+' + fmtMoney(x.win) + '</b>' : '') + (x.hn ? ' <span class="muted">' + x.hn + '</span>' : '') + '</div>').join('');
      if (me < 0) {
        h += '<p class="muted">Сядьте за стол: вход от $15 000, раздача начинается, когда за столом двое.</p><div class="cas-row">'
          + [15000, 30000, 60000, 100000].map(a => '<button class="btn pri" data-act="cas-pk" data-m="buy" data-v="' + a + '"' + (S.money < a || PKM.pend ? ' disabled' : '') + '>Сесть на ' + fmtMoney(a) + '</button>').join('') + '</div>';
        h += '<div class="muted" style="font-size:12px">' + mpEsc(s.log || '') + '</div>';
      } else {
        const my = s.seats[me];
        if (s.st === 'play' && s.cur === me) {
          const need = s.bet - my.put;
          h += '<div class="cas-row"><button class="btn pri" data-act="cas-pk" data-m="act" data-v="call">' + (need ? 'Колл ' + fmtMoney(need) : 'Чек') + '</button><button class="btn" data-act="cas-pk" data-m="act" data-v="raise"' + (s.raises >= 4 ? ' disabled' : '') + '>Рейз +' + fmtMoney(s.sz) + '</button><button class="btn" data-act="cas-pk" data-m="act" data-v="fold">Фолд</button></div>';
        } else if (s.st === 'play') h += '<p class="muted">Ждём ход…</p>';
        h += '<div class="muted" style="font-size:12px">' + mpEsc(my.chips < s.min ? 'Мало фишек — докупите (нужно от ' + fmtMoney(s.min) + ')' : (s.log || '')) + '</div>';
        h += '<div class="cas-row">' + (s.st !== 'play' || !my.inHand ? [15000, 50000].map(a => '<button class="btn" data-act="cas-pk" data-m="add" data-v="' + a + '"' + (S.money < a ? ' disabled' : '') + '>+' + fmtMoney(a) + '</button>').join('') : '')
          + '<button class="btn" data-act="cas-pk" data-m="leave">🚪 Встать (забрать ' + fmtMoney(my.chips) + ')</button></div>';
      }
    }
    b.innerHTML = h + '<div class="cas-msg" id="casMsg">' + CAS.msg + '</div>';
  }
  setInterval(() => {
    const e = $('pkTimer'); const s = PKM.st[PKM.tbl];
    if (!e || !s) return;
    e.textContent = s.st === 'play' ? '⏱ ' + Math.ceil(Math.max(0, s.tleft - (performance.now() - PKM.tAt)) / 1000) + ' с' : '';
  }, 500);

  function v34Act(m, el) {
    const v = el.dataset.v; SFX.click();
    if (m === 'vslot') {
      if (casBusy() || !casTake(CAS.bet)) return;
      const SY = ['🍒', '🍋', '🔔', '🍉', '7️⃣', '⭐'], W = [3, 3, 3, 3, 1, 3];
      const pickS = () => { let x = Math.random() * 16; for (let i = 0; i < 6; i++) { x -= W[i]; if (x < 0) return SY[i]; } return SY[0]; };
      const fin = [pickS(), pickS(), pickS()], bet = CAS.bet; CAS.slot.spin = true; casMsg('Барабаны крутятся…'); let t = 0; const w = $('casWheel');
      jpBet(bet);
      const iv = setInterval(() => {
        t++; if (w) w.textContent = [0, 1, 2].map(() => SY[Math.floor(Math.random() * 6)]).join(' ');
        if (t >= 12) {
          clearInterval(iv); CAS.slot.spin = false; CAS.slot.r = fin; let k = 0;
          if (fin[0] === fin[1] && fin[1] === fin[2]) k = fin[0] === '7️⃣' ? 25 : 8; else if (fin[0] === fin[1] || fin[1] === fin[2] || fin[0] === fin[2]) k = 1.5;
          const pay = Math.round(k * bet); casPay(pay); CAS.msg = pay ? '🎉 Выигрыш ' + fmtMoney(pay) : 'Не повезло'; if (!pay) SFX.err();
          if (UI.cur === 'casino' && CAS.tab === 'vip') casRender();
        }
      }, 110);
      return;
    }
    if (m === 'tbl') { PKM.tbl = +v; PKM.peeked = -1; casRender(); return; }
    if (m === 'buy') {
      const a = +v; if (PKM.pend || MP.state !== 'on') return;
      if (S.money < a) { casMsg('Не хватает денег'); return; }
      S.money -= a; refreshMoney(false); persist(); PKM.pend = a; PKM.void = false; casMsg('Садимся за стол…');
      mpSend({ t: 'pk-sit', tbl: PKM.tbl, buy: a });
      setTimeout(() => {
        if (PKM.pend === a) { PKM.pend = 0; PKM.void = true; casPay(a); CAS.msg = 'Сервер не ответил (нужен server-7.js). Деньги возвращены.'; if (UI.cur === 'casino') casRender(); }
      }, 8000);
      return;
    }
    if (m === 'add') { const a = +v; if (S.money < a || MP.state !== 'on') return; S.money -= a; refreshMoney(false); persist(); mpSend({ t: 'pk-add', tbl: PKM.tbl, buy: a }); return; }
    if (m === 'act') { mpSend({ t: 'pk-act', tbl: PKM.tbl, a: v }); return; }
    if (m === 'leave') { mpSend({ t: 'pk-leave', tbl: PKM.tbl }); return; }
  }

  /* ---------- сообщения сервера ---------- */
  function srvMsg(m) {
    switch (m.t) {
      case 'pk-state': {
        PKM.st[m.tbl] = m; PKM.tAt = performance.now();
        if (m.you >= 0) { PKM.seated = m.tbl; PKM.chips = m.seats[m.you].chips; S.pkHeld = PKM.chips; if (m.st === 'show') persist(); } else if (PKM.seated === m.tbl) { PKM.seated = -1; PKM.chips = 0; }
        if (UI.cur === 'casino' && CAS.tab === 'pkm' && PKM.tbl === m.tbl) casRender();
        return true;
      }
      case 'pk-seat':
        if (PKM.void) { PKM.void = false; PKM.voidCash = true; mpSend({ t: 'pk-leave', tbl: m.tbl }); return true; }
        PKM.pend = 0; PKM.seated = m.tbl; CAS.msg = ''; return true;
      case 'pk-cash':
        if (PKM.voidCash) { PKM.voidCash = false; return true; }
        if (m.amt > 0) { casPay(m.amt); toast('♠ Вы забрали ' + fmtMoney(m.amt) + (m.msg ? ' · ' + m.msg : '')); }
        PKM.seated = -1; PKM.chips = 0; PKM.st[m.tbl] = null; PKM.peeked = -1; S.pkHeld = 0; persist();
        if (UI.cur === 'casino' && CAS.tab === 'pkm') { mpSend({ t: 'pk-peek', tbl: PKM.tbl }); casRender(); }
        return true;
      case 'pk-deny':
        PKM.pend = 0; if (m.refund > 0) casPay(m.refund); CAS.msg = m.msg || 'Нельзя'; toast('♠ ' + CAS.msg);
        if (UI.cur === 'casino' && CAS.tab === 'pkm') casRender();
        return true;
      case 'jp': JP.pool = m.pool; jpUpd(); return true;
      case 'jp-win':
        JP.pool = m.pool || 100000; jpUpd();
        if (m.id === MP.id) jpWinSelf(m.amt); else toast('💎 ' + m.name + ' сорвал джекпот ' + fmtMoney(m.amt) + '!');
        return true;
    }
    return false;
  }
  const vm0 = v30Msg;
  v30Msg = function (m) { return srvMsg(m) || vm0(m); };

  // потеря связи за столом: фишки возвращаются; возврат фишек после аварийного закрытия страницы
  setInterval(() => {
    if (PKM.seated >= 0 && !(MP.ws && MP.state === 'on')) {
      const c = PKM.chips; PKM.seated = -1; PKM.chips = 0; PKM.st = [null, null]; PKM.peeked = -1; S.pkHeld = 0;
      if (c > 0) { casPay(c); toast('♠ Связь потеряна — фишки (' + fmtMoney(c) + ') возвращены'); }
    }
  }, 1500);
  setTimeout(() => { if (S.pkHeld > 0 && PKM.seated < 0) { const c = S.pkHeld; S.pkHeld = 0; casPay(c); toast('♠ Фишки с покерного стола (' + fmtMoney(c) + ') возвращены'); } }, 3000);

  /* ---------- охрана и налёты ---------- */
  const bo1 = bizOptions;
  bizOptions = function (id) {
    const o = bo1(id); if (id !== 'casino') return o;
    const r = S.biz.casino, bye = o.pop();
    if (r && r.own) {
      const g = r.guards || 0;
      if (g < 4) {
        const cost = 30000 * (g + 1);
        o.push({ t: '💂 Нанять охранника №' + (g + 1) + ' — ' + fmtMoney(cost), dis: S.money < cost, fn: () => { S.money -= cost; r.guards = g + 1; persist(); SFX.buy(); refreshMoney(true); say('Охранник в зале. Налёты отбиваются с шансом ' + Math.round(Math.min(0.92, (g + 1) * 0.24) * 100) + '%.'); } });
      } else o.push({ t: '💂 Охрана: 4 из 4', dis: true, fn: () => { } });
      o.push({ t: '👑 VIP-зал: ' + ((r.lvl || 1) >= 3 ? 'открыт (дверь с канатами в углу)' : 'откроется на 3 уровне'), fn: () => say((r.lvl || 1) >= 3 ? 'VIP-зал — в правом дальнем углу. Там автомат со ставками до $500k, а рулетка и блэкджек принимают крупные ставки.' : 'Прокачайте казино до 3 уровня — и откроем VIP-зал.') });
    } else {
      const left = Math.ceil(((S.casHeistT || 0) - Date.now()) / 60000);
      o.push({ t: '🕶 Ограбление: вскрыть сейф' + (left > 0 ? ' (через ' + left + ' мин)' : ''), dis: left > 0, fn: () => openScreen('heist') });
    }
    o.push(bye); return o;
  };
  const RAID = { t: 540 + Math.random() * 240 };
  setInterval(() => {
    if (G.mode !== 'play' || G.paused) return;
    const r = S.biz && S.biz.casino; if (!r || !r.own) return;
    if ((RAID.t -= 1) > 0) return;
    RAID.t = 480 + Math.random() * 420;
    const g = r.guards || 0;
    if (Math.random() < Math.min(0.92, g * 0.24)) { toast('💂 Налёт на казино отбит — охрана сработала'); SFX.cash && SFX.cash(); return; }
    let loss = 0;
    if ((r.acc || 0) >= 1) { loss = Math.floor(r.acc * 0.3); r.acc -= loss; }
    else if ((S.safe || 0) >= 1) { loss = Math.min(40000, Math.floor(S.safe * 0.06)); S.safe -= loss; }
    toast(loss > 0 ? '🔫 Налёт на казино! Унесли ' + fmtMoney(loss) + (g ? '' : ' — наймите охрану у управляющего') : '🔫 На казино напали, но касса была пуста'); SFX.err(); persist();
  }, 1000);

  let GLOOK = null;
  const GPOS = [[-2.4, -6.8, 0], [2.4, -6.8, 0], [19, -0.8, -Math.PI / 2], [-19, 2, Math.PI / 2]];
  const dh1 = drawHomeScene;
  drawHomeScene = function () {
    dh1();
    if (!(G.int && G.int.kind === 'casino')) return;
    const r = S.biz && S.biz.casino, n = r && r.own ? Math.min(4, r.guards || 0) : 0; if (!n) return;
    if (!GLOOK) GLOOK = emLook('#111114', '#0a0a0d', '#1a1208', false, 'm1', 'jacket', 0.2);
    const O = INT.casino;
    for (let i = 0; i < n; i++) drawHuman(O.x + GPOS[i][0], 0, O.z + GPOS[i][1], GPOS[i][2], 0, 0, GLOOK, false, 1, null);
  };

  /* ---------- ограбление казино (мини-игра взлома сейфа) ---------- */
  const hs = document.createElement('div'); hs.id = 'heist'; hs.className = 'screen dim';
  hs.innerHTML = '<div class="panel narrow"><h3>🕶 Ограбление казино</h3><p class="muted" id="hsInfo"></p><div id="hsLocks"></div><div id="hsBar"><div id="hsZone"></div><div id="hsNeedle"></div></div>'
    + '<button class="btn pri" id="hsGo">⏹ СТОП (Пробел / A)</button><div class="cas-msg" id="hsMsg"></div><button class="btn" data-act="back" style="margin-top:8px">← Отступить</button></div>';
  document.body.appendChild(hs); SCREENS.push('heist');
  const HS = { on: false, lock: 0, alarm: 0, c: 0.5, w: 0.2, t0: 0, last: 0, done: false, pb: false };
  function hsRoll() { HS.w = [0.2, 0.15, 0.11][HS.lock] || 0.11; HS.c = 0.2 + Math.random() * 0.6; $('hsZone').style.left = ((HS.c - HS.w / 2) * 100) + '%'; $('hsZone').style.width = (HS.w * 100) + '%'; }
  function hsDraw() {
    $('hsLocks').innerHTML = [0, 1, 2].map(i => '<span class="hs-l">' + (i < HS.lock ? '🔓' : '🔒') + '</span>').join('') + '<span class="hs-l">' + '🚨'.repeat(HS.alarm) + '</span>';
    $('hsInfo').textContent = 'Остановите стрелку в зелёной зоне, чтобы вскрыть замок. Три промаха — сработает сигнализация.';
  }
  function heistInit() { HS.on = true; HS.lock = 0; HS.alarm = 0; HS.done = false; HS.t0 = performance.now(); HS.last = 0; $('hsMsg').textContent = ''; hsRoll(); hsDraw(); requestAnimationFrame(hsLoop); }
  function hsLoop(now) {
    if (!HS.on || UI.cur !== 'heist') { HS.on = false; return; }
    const sp = [3.2, 4.4, 5.8][HS.lock] || 5.8, u = 0.5 + 0.5 * Math.sin((now - HS.t0) / 1000 * sp);
    $('hsNeedle').style.left = (u * 100) + '%'; HS.u = u;
    const p = navigator.getGamepads ? Array.from(navigator.getGamepads()).find(x => x && x.connected) : null;
    const pr = !!(p && p.buttons[0] && p.buttons[0].pressed); if (pr && !HS.pb) hsPress(); HS.pb = pr;
    requestAnimationFrame(hsLoop);
  }
  function hsPress() {
    if (!HS.on || HS.done || performance.now() - HS.last < 160) return; HS.last = performance.now();
    if (Math.abs(HS.u - HS.c) <= HS.w / 2) {
      HS.lock++; SFX.click();
      if (HS.lock >= 3) {
        HS.done = true; HS.on = false; S.casHeistT = Date.now() + 15 * 60000;
        const gain = Math.round((60000 + Math.random() * 60000) / 1000) * 1000; addMoney(gain); SFX.cash(); crimeWanted(3, 'ограбление казино'); persist();
        $('hsMsg').textContent = '✅ Сейф вскрыт! +' + fmtMoney(gain) + '. Уходите — полиция уже едет.'; hsDraw();
        setTimeout(() => { if (UI.cur === 'heist') closeScreens(); }, 1600); return;
      }
      hsRoll();
    } else {
      HS.alarm++; SFX.err();
      if (HS.alarm >= 3) {
        HS.done = true; HS.on = false; S.casHeistT = Date.now() + 15 * 60000; crimeWanted(2, 'взлом казино'); persist();
        $('hsMsg').textContent = '🚨 Сигнализация! Бегите!'; hsDraw(); setTimeout(() => { if (UI.cur === 'heist') closeScreens(); }, 1400); return;
      }
    }
    hsDraw();
  }
  $('hsGo').addEventListener('click', hsPress);
  window.addEventListener('keydown', e => { if (HS.on && UI.cur === 'heist' && !CTL.listen && (e.code === 'Space' || e.code === 'Enter' || e.code === 'KeyE') && !e.repeat) { e.preventDefault(); hsPress(); } });
}


function scopeOk() { const id = S.guns.sel; return id === 'rifle' || id === 'sniper' || !!(S.guns.att && S.guns.att[id] && S.guns.att[id].scope); }
function zoomLevels() { const id = S.guns.sel; return (id === 'rifle' || id === 'sniper') ? 3 : 2; }
function hudExtra(wd) { return window.__FM && window.__FM.hud ? window.__FM.hud(wd) : ''; }
