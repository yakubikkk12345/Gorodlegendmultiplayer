/* ===================== 4. ЗВУК (WebAudio, без файлов) ===================== */
const AU = { ctx: null, sfx: null, mus: null, eng: null, siren: null, noise: null, step: 0, nextT: 0 };
function auVolumes() {
  if (!AU.ctx) return;
  AU.sfx.gain.value = S.set.sfx;
  AU.mus.gain.value = S.set.music * 0.5;
}
function auInit() {
  if (AU.ctx) { if (AU.ctx.state === 'suspended') AU.ctx.resume(); return; }
  const C = window.AudioContext || window.webkitAudioContext;
  if (!C) return;
  try {
    const ctx = AU.ctx = new C();
    AU.sfx = ctx.createGain(); AU.sfx.connect(ctx.destination);
    AU.mus = ctx.createGain(); AU.mus.connect(ctx.destination);
    auVolumes();
    const o1 = ctx.createOscillator(); o1.type = 'sawtooth';
    const o2 = ctx.createOscillator(); o2.type = 'square';
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 500;
    const g = ctx.createGain(); g.gain.value = 0;
    o1.connect(f); o2.connect(f); f.connect(g); g.connect(AU.sfx);
    o1.start(); o2.start();
    AU.eng = { o1, o2, f, g };
    const so = ctx.createOscillator(); so.type = 'square';
    const sg = ctx.createGain(); sg.gain.value = 0;
    so.connect(sg); sg.connect(AU.sfx); so.start();
    AU.siren = { so, sg };
    const len = ctx.sampleRate;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    AU.noise = buf;
    AU.rainSrc = ctx.createBufferSource(); AU.rainSrc.buffer = buf; AU.rainSrc.loop = true;
    const rbf = ctx.createBiquadFilter(); rbf.type = 'bandpass'; rbf.frequency.value = 2200; rbf.Q.value = 0.4;
    AU.rainG = ctx.createGain(); AU.rainG.gain.value = 0; AU.rainSrc.connect(rbf); rbf.connect(AU.rainG); AU.rainG.connect(AU.sfx); AU.rainSrc.start();
    AU.nextT = ctx.currentTime + 0.1;
    setInterval(musicTick, 90);
  } catch (e) { console.warn('audio', e); AU.ctx = null; }
}
function tone(freq, dur, type, vol, slide, delay) {
  if (!AU.ctx) return;
  const ctx = AU.ctx, t = ctx.currentTime + (delay || 0);
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type || 'sine';
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, slide), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol || 0.3, t + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(AU.sfx);
  o.start(t); o.stop(t + dur + 0.05);
}
function noiseBurst(dur, vol, freq, delay) {
  if (!AU.ctx || !AU.noise) return;
  const ctx = AU.ctx, t = ctx.currentTime + (delay || 0);
  const s = ctx.createBufferSource(); s.buffer = AU.noise;
  const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = freq || 1500;
  const g = ctx.createGain();
  g.gain.setValueAtTime(vol || 0.3, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(f); f.connect(g); g.connect(AU.sfx);
  s.start(t); s.stop(t + dur + 0.05);
}
const SFX = {
  click() { tone(660, 0.07, 'square', 0.12, 520); },
  back() { tone(440, 0.08, 'square', 0.1, 330); },
  coin() { tone(988, 0.09, 'square', 0.16); tone(1319, 0.18, 'square', 0.16, 0, 0.08); },
  cash() { tone(1200, 0.06, 'triangle', 0.18); tone(1800, 0.1, 'triangle', 0.14, 0, 0.05); },
  cp() { tone(660, 0.1, 'triangle', 0.25); tone(880, 0.1, 'triangle', 0.25, 0, 0.09); tone(1320, 0.2, 'triangle', 0.25, 0, 0.18); },
  crash(v) { const k = clamp(v / 18, 0.15, 1); noiseBurst(0.35, 0.45 * k, 900); tone(90, 0.25, 'sawtooth', 0.35 * k, 40); },
  nitro() { noiseBurst(0.6, 0.25, 3000); tone(200, 0.5, 'sawtooth', 0.12, 700); },
  horn() { tone(392, 0.35, 'square', 0.14); tone(494, 0.35, 'square', 0.14); },
  tick() { tone(520, 0.12, 'square', 0.2); },
  go() { tone(1040, 0.5, 'square', 0.25); },
  win() { [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.25, 'triangle', 0.28, 0, i * 0.13)); tone(1318, 0.6, 'triangle', 0.28, 0, 0.55); },
  lose() { [392, 330, 262, 196].forEach((f, i) => tone(f, 0.3, 'sawtooth', 0.2, 0, i * 0.18)); },
  door() { noiseBurst(0.12, 0.25, 700); tone(160, 0.1, 'square', 0.15, 90); },
  buy() { SFX.cash(); tone(1568, 0.25, 'triangle', 0.2, 0, 0.14); },
  err() { tone(180, 0.2, 'sawtooth', 0.18, 120); },
  skid() { noiseBurst(0.18, 0.06, 2500); },
  gun(id, v) {
    v = v === undefined ? 1 : v;
    if (id === 'shotgun') { noiseBurst(0.28, 0.5 * v, 1300); tone(100, 0.22, 'sawtooth', 0.26 * v, 40); }
    else if (id === 'rifle') { noiseBurst(0.2, 0.4 * v, 2200); tone(150, 0.16, 'sawtooth', 0.22 * v, 50); }
    else if (id === 'smg') { noiseBurst(0.07, 0.22 * v, 3000); tone(200, 0.05, 'square', 0.1 * v, 70); }
    else { noiseBurst(0.1, 0.28 * v, 2600); tone(190, 0.08, 'square', 0.13 * v, 60); }
  },
  hit() { tone(900, 0.04, 'square', 0.08); },
  punch() { noiseBurst(0.07, 0.22, 600); tone(130, 0.09, 'square', 0.14, 60); },
  hurt() { noiseBurst(0.12, 0.25, 700); tone(150, 0.18, 'sawtooth', 0.2, 70); },
  reload() { tone(420, 0.05, 'square', 0.1); tone(300, 0.06, 'square', 0.1, 0, 0.35); tone(600, 0.05, 'square', 0.12, 0, 0.7); }
};
function auEngine(active, ratio, thr, nitro) {
  if (!AU.ctx || !AU.eng) return;
  const t = AU.ctx.currentTime, e = AU.eng;
  const base = 38 + ratio * 150 + thr * 22 + (nitro ? 30 : 0);
  e.o1.frequency.setTargetAtTime(base, t, 0.05);
  e.o2.frequency.setTargetAtTime(base * 0.5, t, 0.05);
  e.f.frequency.setTargetAtTime(350 + ratio * 900 + thr * 400, t, 0.08);
  e.g.gain.setTargetAtTime(active ? 0.05 + thr * 0.07 + ratio * 0.04 : 0, t, 0.1);
}
function auSiren(level) {
  if (!AU.ctx || !AU.siren) return;
  const t = AU.ctx.currentTime;
  AU.siren.so.frequency.setTargetAtTime(750 + Math.sin(t * 6) * 260, t, 0.02);
  AU.siren.sg.gain.setTargetAtTime(level * 0.05, t, 0.1);
}
