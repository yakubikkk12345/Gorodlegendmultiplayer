/* ===================== 10. ИГРОК И ПЕШЕХОДЫ ===================== */
const P = { x: 10.5, z: 10.5, y: 0.16, h: 0, car: null, phase: 0, amp: 0, vis: false, speed: 0, hp: 100, aimT: 0 };
const CAM = { yaw: -2.35, pitch: 0.3, off: 0, lastDrag: 0, x: 0, y: 40, z: 0, tx: 0, ty: 0, tz: 0, fov: 1.05, shake: 0, orbit: 0.5, aimK: 0, aimB: 0, wasMan: false };

const HUMAN_PARTS = [
  // [mesh, px,py,pz, w,h,d, tintKey, limb(0 none,1 leg L,2 leg R,3 arm L,4 arm R)]
  ['L', -0.13, 0.82, 0, 0.2, 0.8, 0.22, 'pants', 1],
  ['L', 0.13, 0.82, 0, 0.2, 0.8, 0.22, 'pants', 2],
  ['C', 0, 0.8, 0, 0.5, 0.62, 0.28, 'shirt', 0],
  ['L', -0.34, 1.4, 0, 0.14, 0.6, 0.16, 'shirt', 3],
  ['L', 0.34, 1.4, 0, 0.14, 0.6, 0.16, 'shirt', 4],
  ['C', 0, 1.42, 0, 0.3, 0.3, 0.3, 'skin', 0],
  ['C', 0, 1.64, -0.01, 0.32, 0.1, 0.32, 'hair', 0],
  ['C', 0, 1.53, 0.15, 0.31, 0.07, 0.04, 'dark', 0]
];
const HM = newM(), PMX = newM(), WMX = newM();
const HUMAN_LOD = [['L', 0, 0.82, 0, 0.42, 0.8, 0.22, 'pants', 0], HUMAN_PARTS[2], HUMAN_PARTS[5]];
const GUNMODEL = {
  pistol: { two: false, m: 0.28, b: [[0, 0.02, 0.1, 0.05, 0.07, 0.26, 0.16, 0.16, 0.18], [0, -0.07, 0.02, 0.045, 0.13, 0.06, 0.1, 0.1, 0.11]] },
  smg: { two: true, m: 0.44, b: [[0, 0.02, 0.18, 0.06, 0.09, 0.4, 0.14, 0.14, 0.16], [0, -0.12, 0.14, 0.04, 0.17, 0.05, 0.1, 0.1, 0.1], [0, -0.06, 0.0, 0.045, 0.1, 0.06, 0.1, 0.1, 0.11], [0, 0.02, 0.42, 0.025, 0.025, 0.1, 0.08, 0.08, 0.08]] },
  shotgun: { two: true, m: 0.74, b: [[0, 0.03, 0.34, 0.05, 0.05, 0.8, 0.2, 0.2, 0.22], [0, -0.02, 0.28, 0.06, 0.06, 0.26, 0.45, 0.28, 0.14], [0, -0.03, -0.12, 0.06, 0.11, 0.3, 0.45, 0.28, 0.14]] },
  rifle: { two: true, m: 0.82, b: [[0, 0.03, 0.3, 0.06, 0.09, 0.8, 0.13, 0.15, 0.13], [0, -0.1, 0.22, 0.04, 0.16, 0.06, 0.1, 0.1, 0.1], [0, -0.04, -0.14, 0.06, 0.11, 0.3, 0.3, 0.3, 0.26], [0, 0.11, 0.3, 0.04, 0.05, 0.22, 0.08, 0.08, 0.1], [0, 0.03, 0.74, 0.025, 0.025, 0.14, 0.08, 0.08, 0.08]] }
};
GUNMODEL.bat = { two: false, m: 1.05, melee: true, b: [[0, 0, 0.05, 0.04, 0.04, 0.4, 0.3, 0.2, 0.1], [0, 0, 0.65, 0.09, 0.09, 0.8, 0.65, 0.45, 0.2]] };
GUNMODEL.knife = { two: false, m: 0.4, melee: true, b: [[0, 0, 0.07, 0.04, 0.05, 0.14, 0.15, 0.15, 0.17], [0, 0, 0.27, 0.015, 0.07, 0.26, 0.85, 0.87, 0.92]] };
const GFM = newM();
/* ---- v23: конструктор моделей людей (парень / девушка, причёски, одежда) ---- */
const PCACHE = {}, TM2 = newM(), PM3 = newM();
function setLook(look, d) { look._d = d; look._pk = (d.f ? 'f' : 'm') + '|' + d.hs + '|' + d.bt + '|' + d.ty + '|' + (d.sh || 0.1); return look; }
function hairParts(id) {
  const H = [], c = (x, y, z, w, h, d, k) => H.push(['C', x, y, z, w, h, d, k || 'hair', 0]);
  const both = (x, y, z, w, h, d, k) => { c(-x, y, z, w, h, d, k); c(x, y, z, w, h, d, k); };
  const fcap = () => c(0, 1.625, -0.01, 0.285, 0.1, 0.275);
  const bang = () => c(0, 1.585, 0.118, 0.27, 0.075, 0.04);
  const mcap = () => c(0, 1.64, -0.01, 0.32, 0.1, 0.32);
  switch (id) {
    case 'm0': mcap(); break;
    case 'm1': c(0, 1.68, -0.005, 0.31, 0.06, 0.31); break;
    case 'm2': mcap(); for (const x of [-0.09, 0, 0.09]) for (const z of [-0.07, 0.07]) c(x, 1.74, z, 0.07, 0.11, 0.07); break;
    case 'm3': mcap(); c(0, 1.18, -0.17, 0.32, 0.56, 0.05); both(0.165, 1.48, 0, 0.03, 0.26, 0.3); break;
    case 'm4': c(0, 1.7, -0.01, 0.07, 0.17, 0.3); break;
    case 'm5': break;
    case 'm6': mcap(); c(0, 1.78, -0.1, 0.13, 0.12, 0.13); break;
    case 'f0': fcap(); bang(); c(0, 1.0, -0.13, 0.30, 0.74, 0.07); both(0.145, 1.15, 0, 0.035, 0.55, 0.24); break;
    case 'f1': fcap(); bang(); c(0, 1.5, -0.125, 0.27, 0.2, 0.05); both(0.14, 1.55, 0, 0.03, 0.15, 0.2); c(0, 1.6, -0.17, 0.09, 0.05, 0.07, 'lips'); c(0, 1.12, -0.2, 0.08, 0.5, 0.08); break;
    case 'f2': fcap(); bang(); c(0, 1.3, -0.13, 0.32, 0.4, 0.07); both(0.15, 1.3, 0, 0.04, 0.38, 0.24); break;
    case 'f3': fcap(); c(0.04, 1.585, 0.118, 0.2, 0.06, 0.04); c(0, 1.72, -0.07, 0.15, 0.14, 0.15); both(0.14, 1.55, 0, 0.03, 0.15, 0.2); break;
    case 'f4': fcap(); bang(); for (const x of [-0.18, 0.18]) { c(x, 1.18, -0.03, 0.07, 0.46, 0.08); c(x, 1.62, -0.03, 0.08, 0.05, 0.09, 'lips'); } break;
    case 'f5': fcap(); c(0.05, 1.58, 0.118, 0.2, 0.08, 0.04); both(0.14, 1.52, 0, 0.03, 0.17, 0.22); c(0, 1.52, -0.125, 0.27, 0.17, 0.05); break;
    case 'f6': fcap(); bang(); c(0, 1.5, -0.125, 0.26, 0.2, 0.05); c(0, 1.0, -0.14, 0.08, 0.55, 0.08); c(0, 0.82, -0.14, 0.05, 0.2, 0.05); c(0, 1.55, -0.14, 0.09, 0.04, 0.09, 'lips'); break;
    case 'f7': fcap(); c(0.03, 1.585, 0.118, 0.24, 0.075, 0.04); c(0, 0.98, -0.14, 0.36, 0.76, 0.1); both(0.16, 1.1, 0, 0.06, 0.62, 0.26); break;
  }
  return H;
}
function buildHuman(d) {
  const f = !!d.f, bt = d.bt || 'pants', ty = d.ty || 'long', sh = d.sh || 0.1, A = [];
  if (!f) {
    const lk = bt === 'pants' ? 'pants' : 'skin';
    for (const s of [-1, 1]) {
      const li = s < 0 ? 1 : 2;
      A.push(['L', s * 0.13, 0.82, 0, 0.2, 0.8, 0.22, lk, li]);
      if (bt === 'shorts') A.push(['L', s * 0.13, 0.82, 0, 0.22, 0.34, 0.24, 'pants', li]);
      A.push(['L', s * 0.13, 0.82, 0.03, 0.23, sh, 0.32, 'shoe', li, 0.82 - sh]);
    }
    A.push(['C', 0, 0.8, 0, 0.5, 0.62, 0.28, 'shirt', 0]);
    if (ty === 'jacket') A.push(['C', 0, 0.8, 0.145, 0.04, 0.62, 0.02, 'dark', 0]);
    if (ty === 'hoodie') A.push(['C', 0, 1.36, -0.16, 0.36, 0.14, 0.1, 'shirt', 0]);
    for (const s of [-1, 1]) {
      const li = s < 0 ? 3 : 4, ax = s * 0.34;
      if (ty === 'tee' || ty === 'tank' || ty === 'crop') {
        A.push(['L', ax, 1.4, 0, 0.14, 0.6, 0.16, 'skin', li]);
        if (ty !== 'tank') A.push(['L', ax, 1.4, 0, 0.155, 0.24, 0.175, 'shirt', li]);
      } else {
        A.push(['L', ax, 1.4, 0, 0.14, 0.54, 0.16, 'shirt', li]);
        A.push(['L', ax, 1.4, 0, 0.125, 0.08, 0.145, 'skin', li, 0.52]);
      }
    }
    A.push(['C', 0, 1.42, 0, 0.3, 0.3, 0.3, 'skin', 0]);
    A.push(['C', 0, 1.53, 0.15, 0.31, 0.07, 0.04, 'dark', 0]);
  } else {
    const dress = bt === 'dress', skirt = bt === 'skirt', shorts = bt === 'shorts';
    const lk = bt === 'pants' ? 'pants' : 'skin';
    for (const s of [-1, 1]) {
      const li = s < 0 ? 1 : 2;
      A.push(['L', s * 0.085, 0.8, 0, 0.15, 0.78, 0.16, lk, li]);
      if (shorts) A.push(['L', s * 0.085, 0.8, 0, 0.17, 0.26, 0.19, 'pants', li]);
      A.push(['L', s * 0.085, 0.8, 0.03, 0.17, sh, 0.27, 'shoe', li, 0.8 - sh]);
    }
    if (skirt || dress) {
      const hem = dress ? 0.38 : 0.54, k = dress ? 'shirt' : 'pants';
      A.push(['C', 0, hem, 0, 0.5, 0.72 - hem, 0.32, k, 0]);
      A.push(['C', 0, 0.7, 0, 0.4, 0.16, 0.27, k, 0]);
    } else A.push(['C', 0, 0.7, 0, 0.38, 0.16, 0.25, 'pants', 0]);
    if (ty === 'crop') { A.push(['C', 0, 0.78, 0, 0.31, 0.34, 0.22, 'skin', 0]); A.push(['C', 0, 1.1, 0, 0.42, 0.28, 0.25, 'shirt', 0]); }
    else { A.push(['C', 0, 0.78, 0, 0.31, 0.22, 0.22, 'shirt', 0]); A.push(['C', 0, 0.98, 0, 0.42, 0.4, 0.25, 'shirt', 0]); }
    for (const s of [-1, 1]) {
      const li = s < 0 ? 3 : 4, ax = s * 0.285;
      if (ty === 'tank') A.push(['L', ax, 1.38, 0, 0.11, 0.6, 0.13, 'skin', li]);
      else if (ty === 'tee' || ty === 'crop') { A.push(['L', ax, 1.38, 0, 0.11, 0.6, 0.13, 'skin', li]); A.push(['L', ax, 1.38, 0, 0.125, 0.2, 0.145, 'shirt', li]); }
      else { A.push(['L', ax, 1.38, 0, 0.125, 0.54, 0.145, 'shirt', li]); A.push(['L', ax, 1.38, 0, 0.1, 0.09, 0.12, 'skin', li, 0.52]); }
    }
    A.push(['C', 0, 1.36, 0, 0.09, 0.09, 0.09, 'skin', 0]);
    A.push(['C', 0, 1.42, 0, 0.26, 0.28, 0.25, 'skin', 0]);
    for (const x of [-0.06, 0.06]) { A.push(['C', x, 1.55, 0.126, 0.045, 0.04, 0.02, 'dark', 0]); A.push(['C', x * 1.05, 1.585, 0.127, 0.065, 0.012, 0.022, 'dark', 0]); }
    A.push(['C', 0, 1.475, 0.126, 0.07, 0.025, 0.02, 'lips', 0]);
  }
  for (const p of hairParts(d.hs)) A.push(p);
  return A;
}
function drawHuman(x, y, z, yaw, phase, amp, look, lod, sc, gun, fall) {
  sc = sc || 1;
  const dsc = look._d, fem = !!(dsc && dsc.f);
  if (fem) sc *= 0.96;
  if (fall) mTRS(HM, x, y + fall * 0.12, z, yaw, fall * 1.5, 0, sc, sc, sc); else mTRS(HM, x, y, z, yaw, 0, 0, sc, sc * (look._sy || 1), sc);
  const gm = gun && !lod ? GUNMODEL[gun.id] : null;
  const pn = gun && gun.id === 'fist' ? (gun.kick || 0) : 0;
  const PT = look._pk ? (PCACHE[look._pk] || (PCACHE[look._pk] = buildHuman(dsc))) : HUMAN_PARTS;
  const AX = fem ? 0.285 : 0.34;
  let ra = 0, la = 0;
  if (gm) {
    const k = gun.kick || 0, aim = gun.aim || 0, rl = gun.reload || 0;
    ra = -(0.95 + aim * 0.55) - k * 0.12 + rl * 0.5;
    la = gm.two ? -(0.8 + aim * 0.45) + rl * 0.4 : null;
    if (gm.melee) ra = meleeArm(gun, k);
    else { const AP = gun.ap || 0; ra -= AP; if (la !== null) la -= AP; }
  }
  for (const p of (lod ? HUMAN_LOD : PT)) {
    let ang = 0;
    const lm = p[8];
    if (lm === 1 || lm === 4) ang = Math.sin(phase) * amp * 0.9;
    else if (lm === 2 || lm === 3) ang = -Math.sin(phase) * amp * 0.9;
    if (gm) { if (lm === 4) ang = ra; else if (lm === 3 && la !== null) ang = la; }
    if (pn > 0) { if (lm === 4) ang = -pn * 1.9; else if (lm === 3) ang = pn * 0.6; }
    if (p[9]) {
      mTRS(PMX, p[1], p[2], p[3], 0, ang, 0, 1, 1, 1);
      mTRS(TM2, 0, -p[9], 0, 0, 0, 0, p[4], p[5], p[6]);
      mMul(PM3, PMX, TM2); mMul(WMX, HM, PM3);
    } else {
      mTRS(PMX, p[1], p[2], p[3], 0, ang, 0, p[4], p[5], p[6]);
      mMul(WMX, HM, PMX);
    }
    const t = look[p[7]] || look.dark;
    drawMesh(p[0] === 'L' ? M_ULIMB : M_UCOL, WMX, t[0], t[1], t[2], 1, 0, false);
  }
  if (gm) {
    const k = gun.kick || 0;
    const hy = 1.4 - 0.6 * Math.cos(ra), hz = -0.6 * Math.sin(ra) - k * 0.06;
    mTRS(GFM, AX, hy, hz, 0, ra + Math.PI / 2 - k * 0.06, 0, 1, 1, 1);
    mMul(PMX, HM, GFM);
    for (const b of gunBoxes(gm, gun)) {
      mTRS(WMX, b[0], b[1], b[2], 0, 0, 0, b[3], b[4], b[5]);
      mMul(GFM, PMX, WMX);
      drawMesh(M_UCOL, GFM, b[6], b[7], b[8], 1, 0, false);
    }
    if (k > 0.55 && !gm.melee) {
      const f = 0.06 + k * 0.06;
      mTRS(WMX, 0, 0.03, gm.m + 0.06, 0, 0, 0, f, f, f * 1.8);
      mMul(GFM, PMX, WMX);
      drawMesh(M_UCOL, GFM, 1, 0.85, 0.3, 1, 1, false);
    }
  }
}
const PGUN = { id: 'pistol', aim: 0, kick: 0, reload: 0, ap: 0 };
function playerGun() {
  if (P.car || G.inHome || !S || !S.guns) return null;
  PGUN.id = S.guns.sel; return PGUN;
}
const PLAYER_LOOK = { pants: hexRGB('#23262e'), shirt: hexRGB('#c0392b'), skin: hexRGB('#e0ac86'), hair: hexRGB('#16110d'), dark: [0.03, 0.03, 0.03] };

const peds = [];
function applyPeds() {
  const want = (G.quality || QUAL.med).peds;
  const R = rng(99 + peds.length);
  while (peds.length < want) {
    const shirts = ['#3a86ff', '#2ecc71', '#ffd60a', '#ff4fa3', '#9b5de5', '#f1f1f1', '#ff7b00', '#00b4d8'];
    const bi = Math.floor(Math.random() * GRID), bj = Math.floor(Math.random() * GRID);
    peds.push({ bi, bj, s: Math.random() * 240, dir: Math.random() < 0.5 ? 1 : -1, sp: rand(1.2, 1.9), x: 0, z: 0, h: 0, ph: Math.random() * 6,
      look: genPedLook(shirts) });
  }
  peds.length = Math.min(peds.length, want);
}
function genPedLook(shirts) {
  const fem = Math.random() < 0.5, skin = pick(['#e0ac86', '#c68e6b', '#8d5a3b', '#f1c7a5', '#fbe0cf', '#5e3a24']);
  const L = { pants: hexRGB(pick(['#2b2d42', '#4a4e69', '#22333b', '#3d405b', '#7a1f3d', '#1a1a1f', '#3b6ea8'])), shirt: hexRGB(pick(shirts)), skin: hexRGB(skin),
    hair: hexRGB(pick(fem ? ['#16110d', '#5a3825', '#d9b36c', '#b5451b', '#3a2415', '#e3c07a', '#444', '#ff6fb5'] : ['#16110d', '#5a3825', '#d9b36c', '#444', '#3a2415'])),
    dark: [0.1, 0.1, 0.12], shoe: hexRGB(pick(['#111111', '#f2f2f2', '#4b2e1e', '#d7263d', '#2c3e6b'])), lips: hexRGB('#c43a62') };
  if (fem) return setLook(L, { f: true, hs: pick(['f0', 'f1', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7']), bt: pick(['pants', 'skirt', 'skirt', 'dress', 'shorts']), ty: pick(['tee', 'tank', 'crop', 'long']), sh: pick([0.1, 0.1, 0.34]) });
  return setLook(L, { f: false, hs: pick(['m0', 'm0', 'm1', 'm2', 'm3', 'm5', 'm6']), bt: pick(['pants', 'pants', 'pants', 'shorts']), ty: pick(['tee', 'long', 'jacket', 'hoodie', 'tank']), sh: 0.1 });
}
let pedRecT = 0;
function updatePeds(dt) {
  pedRecT += dt;
  if (pedRecT > 0.5 && !G.inHome) {
    pedRecT = 0;
    const pbi = clamp(Math.floor((P.x + HALF) / PITCH), 0, GRID - 1), pbj = clamp(Math.floor((P.z + HALF) / PITCH), 0, GRID - 1);
    let n = 0;
    for (const p of peds) {
      if (n >= 3) break;
      if (p.dead || p.fixed || p.thief) continue;
      if (Math.hypot(p.x - P.x, p.z - P.z) > 150 && Math.hypot(p.x - CAM.x, p.z - CAM.z) > 120) {
        p.bi = clamp(pbi + Math.floor(rand(-2, 3)), 0, GRID - 1); p.bj = clamp(pbj + Math.floor(rand(-2, 3)), 0, GRID - 1); p.s = Math.random() * 240; n++;
      }
    }
  }
  for (const p of peds) {
    if (p.drv) { drvStep(p, dt); continue; }
    if (p.dead) {
      p.dead += dt; p.fall = Math.min(1, (p.fall || 0) + dt * 4);
      if (p.dead > 14 && Math.hypot(p.x - CAM.x, p.z - CAM.z) > 40) {
        p.dead = 0; p.fall = 0; p.hp = 30; p.panic = 0;
        const pbi = clamp(Math.floor((P.x + HALF) / PITCH), 0, GRID - 1), pbj = clamp(Math.floor((P.z + HALF) / PITCH), 0, GRID - 1);
        p.bi = clamp(pbi + Math.floor(rand(-2, 3)), 0, GRID - 1); p.bj = clamp(pbj + Math.floor(rand(-2, 3)), 0, GRID - 1); p.s = Math.random() * 240;
      }
      continue;
    }
    if (p.fixed) continue;
    if (p.thief) { thiefStep(p, dt); continue; }
    if (p.talk > 0) { p.talk -= dt; p.h = Math.atan2(P.x - p.x, P.z - p.z); continue; }
    if (P.car && !P.car.def.heli && !G.inHome && Math.abs(P.car.vf) > 4 && Math.abs(p.x - P.car.x) < 2.2 && Math.abs(p.z - P.car.z) < 2.2 && Math.hypot(p.x - P.car.x, p.z - P.car.z) < 1.9) { killPed(p, true); continue; }
    const pm = p.panic > 0 ? 2.4 : 1; if (p.panic > 0) p.panic -= dt;
    p.s = (p.s + p.dir * p.sp * pm * dt + 240) % 240; p.ph += p.sp * pm * dt * 3.2;
    const cx = bc(p.bi), cz = bc(p.bj), s = p.s, H = 30;
    let x, z, hd;
    if (s < 60) { x = -H + s; z = -H; hd = Math.PI / 2; }
    else if (s < 120) { x = H; z = -H + (s - 60); hd = 0; }
    else if (s < 180) { x = H - (s - 120); z = H; hd = -Math.PI / 2; }
    else { x = -H; z = H - (s - 180); hd = Math.PI; }
    p.x = cx + x; p.z = cz + z; p.h = p.dir > 0 ? hd : hd + Math.PI;
  }
  for (let i = peds.length - 1; i >= 0; i--) if (peds[i].rm) peds.splice(i, 1);
}

