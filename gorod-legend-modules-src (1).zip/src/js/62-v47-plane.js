/* ===================== v47: САМОЛЁТ «СОКОЛ» — ангар на аэродроме, взлёт и посадка ===================== */
{
  const PLANE = { id: 'plane', name: 'Самолёт Сокол', price: 180000, speed: 82, accel: 16, handling: 1.1, grip: 2, color: '#f2f4f8', heli: true, plane: true,
    desc: 'Настоящий самолёт! Ангар на аэродроме (✈ на карте). W — газ, разгон до ~25 м/с, затем Shift — штурвал на себя (взлёт). Пробел — от себя. Ниже скорости срыва падает!',
    shape: { L: 8.2, W: 2.6, H: 1.2, cL: 1.8, cH: 0.9, cZ: 0.5, wr: 0.4 } };
  if (!CAR_BY_ID.plane) { CARS.push(PLANE); CARS.sort((a, b) => a.price - b.price); CAR_BY_ID.plane = PLANE; }
  const hm0 = heliMeshes;
  heliMeshes = function (def, colorHex, key) {
    if (!def.plane) return hm0(def, colorHex, key);
    const s = def.shape, y0 = s.wr * 0.8, col = hexRGB(colorHex).concat(1), acc = [0.12, 0.28, 0.62, 1], dark = [0.1, 0.1, 0.12, 1], glass = [0.1, 0.17, 0.26, 1];
    const body = new Geo(), lights = new Geo(), tail = new Geo(), B = (a, b, c, d, e, f, cl) => body.box(a, b, c, d, e, f, cl, false, true);
    B(-0.62, y0 + 0.35, -4.0, 0.62, y0 + 1.55, 2.7, col);                 // фюзеляж
    B(-0.5, y0 + 0.45, 2.7, 0.5, y0 + 1.4, 3.5, acc);                      // капот двигателя
    B(-0.5, y0 + 1.55, 0.2, 0.5, y0 + 2.15, 2.0, glass);                   // фонарь кабины
    B(-0.45, y0 + 1.55, -1.4, 0.45, y0 + 1.75, 0.2, col);
    B(-6.0, y0 + 0.95, -0.6, 6.0, y0 + 1.1, 1.3, col);                     // крыло
    B(-6.0, y0 + 0.95, -0.6, -4.8, y0 + 1.1, 1.3, acc); B(4.8, y0 + 0.95, -0.6, 6.0, y0 + 1.1, 1.3, acc);
    B(-2.4, y0 + 0.85, -4.1, 2.4, y0 + 0.98, -3.2, col);                   // стабилизатор
    B(-0.07, y0 + 1.1, -4.3, 0.07, y0 + 2.9, -3.0, acc);                   // киль
    B(-0.06, y0 + 0.5, 3.5, 0.06, y0 + 1.3, 3.65, dark); B(-1.2, y0 + 0.9, 3.55, 1.2, y0 + 1.0, 3.65, dark);   // винт (статичный «размытый»)
    for (const sx of [-1, 1]) { B(sx * 1.35 - 0.07, 0.06, 0.1, sx * 1.35 + 0.07, y0 + 0.9, 0.2, dark); B(sx * 1.35 - 0.16, 0.0, -0.1, sx * 1.35 + 0.16, 0.4, 0.5, dark); }
    B(-0.06, 0.06, 2.3, 0.06, y0 + 0.5, 2.4, dark); B(-0.13, 0.0, 2.1, 0.13, 0.32, 2.6, dark);
    lights.box(-6.0, y0 + 1.1, 0.4, -5.85, y0 + 1.2, 0.6, [1, 0.1, 0.1, 1], false, true); lights.box(5.85, y0 + 1.1, 0.4, 6.0, y0 + 1.2, 0.6, [0.1, 1, 0.2, 1], false, true);
    lights.box(-0.2, y0 + 0.5, 3.5, 0.2, y0 + 0.7, 3.55, [1, 0.97, 0.8, 1], false, true);
    tail.box(-0.1, y0 + 2.5, -4.35, 0.1, y0 + 2.8, -4.3, [1, 1, 1, 1], false, true);
    return MESH_CACHE[key] = { body: makeMesh(body), lights: makeMesh(lights), tail: makeMesh(tail), wheel: wheelMesh(s.wr) };
  };
  /* --- полёт --- */
  const sh0 = stepHeli;
  stepHeli = function (c, inp, dt) {
    if (!c.def.plane) return sh0(c, inp, dt);
    const st = c.st, drv = !!inp, VM = st.maxSpeed, VR = VM * 0.3, VS = VM * 0.22;
    if (c.alt === undefined) c.alt = 0; if (c.vv === undefined) c.vv = 0;
    const rf = roofInfo(c.x, c.z, 0.6), fl = rf ? rf.y : 0; c.fl = fl;
    if (c.alt < fl) { c.alt = fl; if (c.vv < 0) c.vv = 0; }
    const gnd = c.alt - fl < 0.15, fx = Math.sin(c.h), fz = Math.cos(c.h);
    let vf = Math.max(0, c.vx * fx + c.vz * fz);
    const gas = drv ? Math.max(0, inp.gas) : 0, br = drv ? Math.max(0, inp.brake) : 0, pull = drv && inp.nitro, push = drv && inp.hand;
    if (drv) c.steer += (inp.steer - c.steer) * Math.min(1, dt * 5); else c.steer *= 0.9;
    vf += st.accel * 1.25 * gas * Math.max(0, 1 - Math.pow(vf / VM, 2)) * dt;
    vf *= Math.exp(-(gnd ? (drv ? 0.22 : 1.2) : 0.06) * dt);
    const brk = gnd ? (br * 28 + (!drv ? 6 : 0)) : br * 9; vf = Math.max(0, vf - brk * dt);
    let tgt = 0;
    if (!gnd) {
      if (vf < VS) tgt = -(VS - vf) * 1.1 - 3;
      else tgt = pull ? Math.min(13, (vf - VS) * 0.8 + 2) : 0;
      if (push) tgt = Math.min(tgt, 0) - 11;
      if (!drv) tgt = -6;
    } else if (pull && vf >= VR) tgt = 6;
    c.vv += (tgt - c.vv) * Math.min(1, dt * (gnd ? 6 : 2.6));
    c.alt += c.vv * dt; if (c.alt > 450 && c.vv > 0) { c.alt = 450; c.vv = 0; }
    if (c.alt <= fl) {
      if (c.vv < -1 && c.alt < fl + 0.05 && !gnd) { const imp = -c.vv + (vf > VM * 0.75 ? 3 : 0); if (imp > 11) { crashFx(c, imp * 0.7); vf *= 0.4; } else if (imp > 4) { CAM.shake = Math.max(CAM.shake, 0.3); for (let i = 0; i < 8; i++) emit(c.x + rand(-1, 1), c.y + 0.2, c.z + rand(-1, 1), rand(-2, 2), rand(1, 3), rand(-2, 2), 0.6, 0.3, 0.9, 0.8, 0.75, 0.65, 0.6, false); } }
      c.alt = fl; c.vv = 0;
    }
    const tr = (c.alt - fl < 0.15) ? 0.7 * clamp(vf / 10, 0, 1) : 0.95 * clamp(vf / VS, 0.3, 1.2);
    c.h -= c.steer * tr * dt;
    const nfx = Math.sin(c.h), nfz = Math.cos(c.h);
    c.vx = nfx * vf; c.vz = nfz * vf; c.x += c.vx * dt; c.z += c.vz * dt; c.vf = vf; c.vl = 0; c.brake = br > 0.1; c.nitroOn = false;
    c.pp = clamp(-c.vv / Math.max(vf, 12) * 1.1, -0.4, 0.45);
  };
  const dc0 = drawCar;
  drawCar = function (c, dist) {
    if (c.def && c.def.plane) { const p = c.pitch, l = c.lean; c.pitch = c.pp || 0; c.lean = clamp(-c.steer * c.vf * 0.012, -0.5, 0.5); dc0(c, dist); c.pitch = p; c.lean = l; } else dc0(c, dist);
  };
  const ec0 = enterCar;
  enterCar = function (c) { const had = P.car; ec0(c); if (!had && P.car === c && c.def.plane) toast('✈ W — газ, S — тормоз, A/D — руль. Разгон до ~' + Math.round(c.st.maxSpeed * 0.3 * 3.6) + ' км/ч → Shift (штурвал на себя) — взлёт. Пробел — от себя. Не опускайте нос на скорости!'); };
  const xc0 = exitCar;
  exitCar = function (force) {
    const c = P.car;
    if (c && c.def.plane && !force && (Math.abs(c.vf) > 4 || (c.alt || 0) - (c.fl || 0) > 1.5)) { toast('✈ Сначала остановитесь на земле (S — тормоз)'); SFX.err(); return; }
    xc0(force);
  };
  /* --- ангар на аэродроме --- */
  const AX = bc(1), AZ = bc(11);
  WORLD_MARKS.push({ id: 'hangar', x: AX + 14, z: AZ - 24, r: 6, c: [0.8, 0.9, 1], br: 3, label: '✈ АНГАР: ПОДАТЬ САМОЛЁТ НА ПОЛОСУ', short: '✈ АНГАР', dot: '#cfe3ff', fn: 'hangar' });
  HOME_FN.hangar = function () {
    if (!S.cars.plane) { toast('✈ У вас нет самолёта — «Сокол» продаётся в автосалоне (' + fmtMoney(PLANE.price) + ')'); SFX.err(); return; }
    if (P.car && P.car.def.plane) { toast('✈ Вы уже в самолёте'); return; }
    if (S.sel !== 'plane') selectCar('plane');
    spawnOwn(AX, AZ - 25, 0);
    OWN.alt = 0; OWN.vv = 0; OWN.vx = OWN.vz = OWN.vf = OWN.vl = 0;
    SFX.click(); toast('✈ Самолёт подан на взлётную полосу. Подойдите и нажмите F');
  };
  /* --- приборы --- */
  const hud = document.createElement('div'); hud.id = 'planeHud';
  hud.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:calc(var(--safe-b,0px) + 86px);z-index:24;padding:5px 14px;border-radius:12px;background:rgba(8,14,26,.82);color:#e6f1ff;font:800 13px/1.35 system-ui,sans-serif;text-align:center;display:none;pointer-events:none';
  document.body.appendChild(hud);
  const v0 = v18Tick;
  v18Tick = function (dt) {
    v0(dt);
    const c = P.car;
    if (!c || !c.def.plane || G.mode !== 'play' || G.inHome) { hud.style.display = 'none'; return; }
    const VM = c.st.maxSpeed, VS = VM * 0.22, VR = VM * 0.3, h = Math.max(0, (c.alt || 0) - (c.fl || 0)), air = h > 0.5;
    if (h > 14 && !S.flags.planeFly) { S.flags.planeFly = 1; addMoney(500); toast('✈ Первый полёт! +$500'); persist(); }
    const warn = air && c.vf < VS * 1.15 ? '<br><span style="color:#ff6b6b">⚠ СРЫВ! Дайте газ, нос вниз (Пробел)</span>' : !air && c.vf >= VR ? '<br><span style="color:#6df09a">✔ Скорость взлёта — Shift!</span>' : '';
    hud.innerHTML = '✈ ' + Math.round(c.vf * 3.6) + ' км/ч · ⬆ ' + Math.round(h) + ' м' + (air ? '' : ' · на земле') + warn;
    hud.style.display = 'block';
    if (air && h > 3 && (c.fl || 0) === 0) { c.flown = (c.flown || 0) + c.vf * dt; if (c.flown > 3000 && !S.flags.plane3k) { S.flags.plane3k = 1; addMoney(2500); toast('✈ Налёт 3 км — бонус пилота +$2 500'); persist(); } }
  };
  window.__plane = { PLANE };
}
