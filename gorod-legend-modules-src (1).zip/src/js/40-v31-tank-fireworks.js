/* ===================== v31: танк, ёлка, салюты, телохранители ===================== */
const TK = { cd: 0 };
function tankFire(c) {
  if (TK.cd > 0) return; TK.cd = 1.5;
  const fx = Math.sin(c.h), fz = Math.cos(c.h); let d = 55, hit = false;
  for (let t = 10; t <= 70 && !hit; t += 3) {
    const x = c.x + fx * t, z = c.z + fz * t;
    for (const o of cars) if (o !== c && !o.def.heli && Math.hypot(o.x - x, o.z - z) < 4) { d = t; hit = true; break; }
    if (!hit) for (const e of WANT.units.concat(GANG.units, (M && M.enemies) || [])) if (Math.hypot(e.x - x, e.z - z) < 3) { d = t; hit = true; break; }
  }
  const bx = c.x + fx * d, bz = c.z + fz * d;
  SFX.crash(30); CAM.shake = Math.max(CAM.shake, 0.5);
  for (let i = 0; i < 10; i++) emit(c.x + fx * 4.8, 1.8, c.z + fz * 4.8, fx * rand(4, 12) + rand(-1, 1), rand(0, 2), fz * rand(4, 12) + rand(-1, 1), 0.5, 0.5, 2.2, 1, 0.7, 0.2, 1, true);
  setTimeout(() => { if (G.mode === 'play') boom(bx, bz, 13, 160, 'tank'); }, Math.round(d * 6));
  if (hit) crimeWanted(2, 'танк');
}

/* ---- v31: новогодняя ёлка, салюты ---- */
const XM = { m: null, x: nodeC(8) + 11, z: nodeC(8) + 11, fw: 6, ny: false };
function xmasMesh() {
  const g = new Geo(), x = XM.x, z = XM.z, gr = [0.05, 0.38, 0.14, 1], gr2 = [0.08, 0.46, 0.18, 1];
  g.box(x - 0.6, 0.1, z - 0.6, x + 0.6, 2.6, z + 0.6, [0.32, 0.2, 0.1, 1], false, true);
  const w = [7.2, 5.8, 4.4, 3.1, 1.8]; let y = 2.4;
  for (let i = 0; i < w.length; i++) { const h = w[i] / 2; g.box(x - h, y, z - h, x + h, y + 2.1, z + h, i % 2 ? gr2 : gr, false, true); y += 1.9; }
  g.box(x - 0.35, y, z - 0.35, x + 0.35, y + 0.7, z + 0.35, [1, 0.85, 0.2, 1], false, true);
  const lc = [[1, 0.2, 0.2, 1], [1, 0.9, 0.2, 1], [0.3, 0.6, 1, 1], [1, 0.4, 0.9, 1], [0.3, 1, 0.5, 1]]; let k = 0; y = 2.4;
  for (let i = 0; i < w.length; i++) { const h = w[i] / 2 + 0.08; for (const [sx, sz] of [[-1, -1], [1, -1], [1, 1], [-1, 1], [0, -1], [0, 1], [-1, 0], [1, 0]]) { const px = x + sx * h, pz = z + sz * h, c = lc[(k++) % 5]; g.box(px - 0.18, y + 0.9, pz - 0.18, px + 0.18, y + 1.26, pz + 0.18, c, false, true); } y += 1.9; }
  return makeMesh(g);
}
function firework(x, y, z) {
  const cols = [[1, 0.3, 0.3], [1, 0.85, 0.3], [0.4, 0.7, 1], [0.5, 1, 0.5], [1, 0.5, 0.95]], c = pick(cols), N = 30;
  for (let i = 0; i < N; i++) { const a = Math.random() * TAU, e = Math.acos(rand(-1, 1)), s = rand(9, 15); emit(x, y, z, Math.sin(e) * Math.cos(a) * s, Math.cos(e) * s * 0.8 + 3, Math.sin(e) * Math.sin(a) * s, rand(1.3, 2.1), 1.6, 0.2, c[0], c[1], c[2], 1, true); }
  SFX.crash && SFX.crash(18);
}
function v31Tick(dt) {
  if (G.mode !== 'play' || G.inHome) return;
  if (TK.cd > 0) TK.cd -= 0;   // (перезарядка танка уменьшается в основном цикле)
  guardsTick(dt); portTick(dt);
  if (!WINTER.on) return;
  const d = Math.hypot(P.x - XM.x, P.z - XM.z), now = new Date(), mo = now.getMonth(), dy = now.getDate();
  if (!XM.ny && ((mo === 11 && dy >= 31) || (mo === 0 && dy <= 2))) {
    XM.ny = true; const yr = String(mo === 11 ? now.getFullYear() + 1 : now.getFullYear());
    if (S.flags.nyGift !== yr) { S.flags.nyGift = yr; addMoney(5000); persist(); toast('🎄 С Новым годом! Подарок от города: ' + fmtMoney(5000)); XM.fw = 0.5; XM.salvo = 8; }
  }
  XM.fw -= dt;
  if (XM.fw <= 0 && d < 220) {
    const big = XM.salvo > 0; XM.salvo = Math.max(0, (XM.salvo || 0) - 1);
    XM.fw = big ? 0.7 : (ENV.night > 0.3 ? rand(3, 6) : rand(9, 16));
    const a = Math.random() * TAU, r = rand(5, 55); firework(XM.x + Math.cos(a) * r, rand(35, 60), XM.z + Math.sin(a) * r);
  }
}
function v31Draw() {
  if (G.mode !== 'play' || G.inHome) return;
  guardsDraw(); portDraw();
}
function v31Static() {
  if (G.mode !== 'play' || G.inHome) return;
  if (WINTER.on && Math.hypot(CAM.x - XM.x, CAM.z - XM.z) < 260) { if (!XM.m) XM.m = xmasMesh(); drawMesh(XM.m, IDENT, 1, 1, 1, 1, 0, false); }
  seaDraw();
}
/* ---- v31: телохранители ---- */
const GRD = { list: [], look: { pants: hexRGB('#14151a'), shirt: hexRGB('#1b1c22'), skin: hexRGB('#d9a07c'), hair: hexRGB('#0e0b09'), dark: [0.03, 0.03, 0.03] } };
const GUARD_PRICE = 8000, GUARD_MAX = 3;
function guardsSync() {
  const n = Math.min(GUARD_MAX, S.guards | 0);
  while (GRD.list.length > n) GRD.list.pop();
  while (GRD.list.length < n) GRD.list.push({ x: P.x + rand(-2, 2), z: P.z + rand(-2, 2), h: 0, ph: 0, amp: 0, cd: rand(0.2, 0.8), gun: { id: 'smg', aim: 0.25, kick: 0, reload: 0, ap: 0 }, hidden: !!P.car });
}
function guardsTick(dt) {
  if (G.mode !== 'play') return;
  if (GRD.list.length !== Math.min(GUARD_MAX, S.guards | 0)) guardsSync();
  const n = GRD.list.length; if (!n) return;
  const foes = []; if (M && M.enemies) for (const e of M.enemies) foes.push([e, damageEnemy]);
  for (const e of GANG.units) foes.push([e, damageGang]);
  if (WANT.stars > 0) for (const e of WANT.units) foes.push([e, damageCop]);
  GRD.list.forEach((g, i) => {
    if (P.car) { g.hidden = true; g.x = P.x; g.z = P.z; return; }
    if (g.hidden) { g.hidden = false; g.x = P.x + rand(-2, 2); g.z = P.z + rand(-2, 2); }
    const ang = P.h + Math.PI + (i - (n - 1) / 2) * 0.9, tx = P.x + Math.sin(ang) * 3, tz = P.z + Math.cos(ang) * 3;
    let dx = tx - g.x, dz = tz - g.z, d = Math.hypot(dx, dz);
    if (d > 60) { g.x = tx; g.z = tz; d = 0; dx = dz = 0; }
    g.amp = 0; let fh = null;
    if (d > 1.3) { const sp = Math.min(8.5, 3 + d * 1.3); g.x += dx / d * sp * dt; g.z += dz / d * sp * dt; g.ph += dt * sp * 1.7; g.amp = 0.9; fh = Math.atan2(dx, dz); pushCircle(g, 0.5); }
    let best = null, bd = 28; for (const [e] of foes) { const dd = Math.hypot(e.x - g.x, e.z - g.z); if (dd < bd) { bd = dd; best = e; } }
    g.cd -= dt; g.gun.aim += ((best ? 1 : 0.25) - g.gun.aim) * Math.min(1, dt * 8);
    if (best) {
      g.h = Math.atan2(best.x - g.x, best.z - g.z);
      if (g.cd <= 0) { g.cd = rand(0.45, 0.8); TRACERS.push({ x1: g.x + Math.sin(g.h) * 0.6, z1: g.z + Math.cos(g.h) * 0.6, x2: best.x, z2: best.z, t: 0.07, max: 0.07, c: [0.6, 0.85, 1] }); const f = foes.find(q => q[0] === best); if (f) f[1](best, 9); g.gun.kick = 1; }
    } else if (fh !== null) g.h = fh; else g.h = P.h;
    g.gun.kick = Math.max(0, g.gun.kick - dt * 6);
  });
}
function guardsDraw() {
  for (const g of GRD.list) { if (g.hidden) continue; const d = Math.hypot(g.x - CAM.x, g.z - CAM.z); if (d > 200) continue; drawHuman(g.x, terrainY(g.x, g.z), g.z, g.h, g.ph, g.amp, GRD.look, d > 38, 1, g.gun); }
}
function guardsRender() {
  const n = S.guards | 0;
  $('grdBody').innerHTML = '<p class="muted">Телохранители ходят за вами, стреляют по бандитам (и по полиции, пока вас ищут). В машине едут с вами. Цена найма — ' + fmtMoney(GUARD_PRICE) + ', максимум ' + GUARD_MAX + '. Сейчас: <b>' + n + '</b></p>'
    + '<div class="cas-row"><button class="btn pri" data-act="guard-hire"' + (n >= GUARD_MAX || S.money < GUARD_PRICE ? ' disabled' : '') + '>🛡 Нанять — ' + fmtMoney(GUARD_PRICE) + '</button><button class="btn" data-act="guard-fire"' + (n <= 0 ? ' disabled' : '') + '>Уволить одного</button></div>';
}

