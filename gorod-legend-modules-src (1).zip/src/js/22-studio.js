/* ===================== 18. СТУДИЯ (предпросмотр машины) ===================== */
const STUDIO = { ang: 0, def: CAR_BY_ID.hatch, color: '#e63946', fake: null, mods: null };
function renderStudio(dt) {
  STUDIO.ang += dt * 0.7;
  gl.disable(gl.SCISSOR_TEST);
  gl.viewport(0, 0, W, H);
  gl.clearColor(0.04, 0.05, 0.09, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  const el = UI.cur === 'garage' ? $('pvGarage') : $('pvShop');
  if (!el) return;
  const r = el.getBoundingClientRect();
  if (r.width < 10 || r.height < 10) return;
  const k = W / window.innerWidth;
  const rx = Math.floor(r.left * k), rw = Math.floor(r.width * k), rh = Math.floor(r.height * k), ry = Math.floor(H - (r.top + r.height) * k);
  gl.enable(gl.SCISSOR_TEST); gl.scissor(rx, ry, rw, rh); gl.viewport(rx, ry, rw, rh);
  gl.clearColor(0.09, 0.11, 0.19, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
  gl.useProgram(PROG);
  mPersp(PROJ, 0.7, rw / rh, 0.5, 100);
  const ex = 0, ey = 2.5, ez = -7.6;
  mLookAt(VIEW, ex, ey, ez, 0, 0.7, 0); mMul(VP, PROJ, VIEW);
  curBlend = ''; setPass('opaque');
  gl.uniformMatrix4fv(U.uVP, false, VP); gl.uniform3f(U.uCam, ex, ey, ez);
  gl.uniform3f(U.uSunDir, 0.4, 0.7, -0.6); gl.uniform3f(U.uSunCol, 0.8, 0.75, 0.65);
  gl.uniform3f(U.uSky, 0.55, 0.6, 0.72); gl.uniform3f(U.uGround, 0.28, 0.28, 0.34);
  gl.uniform1f(U.uFogNear, 50); gl.uniform1f(U.uFogFar, 90); gl.uniform3f(U.uFogCol, 0.09, 0.11, 0.19);
  gl.uniform1f(U.uNight, 0); gl.uniform1i(U.uTex, 0); gl.uniform1i(U.uTexE, 1);
  const def = STUDIO.def;
  if (!STUDIO.fake || STUDIO.fake.def !== def || STUDIO.fake.col !== STUDIO.color || STUDIO.fake.mk !== modKey(STUDIO.mods)) {
    STUDIO.fake = { def, col: STUDIO.color, mods: STUDIO.mods, mk: modKey(STUDIO.mods), meshes: carMeshes(def, STUDIO.color, STUDIO.mods), x: 0, y: 0, z: 0, h: 0, pitch: 0, lean: 0, roll: 0, steer: 0, brake: false, W: def.shape.W, L: def.shape.L, nitroOn: false };
  }
  const f = STUDIO.fake; f.h = STUDIO.ang; f.y = 0.02;
  drawCar(f, 0);
  setPass('alpha');
  mTRS(DM, 0, 0.0, 0, 0, 0, 0, 4.2, 1, 4.2); drawMesh(M_DISC, DM, 0.3, 0.55, 1, 2.2, 1, false);
  if (STUDIO.mods && STUDIO.mods.neon) { setPass('add'); const nc = hexRGB(STUDIO.mods.neon); mTRS(DM, 0, 0.05, 0, f.h, 0, 0, def.shape.W * 1.5, 1, def.shape.L * 0.85); drawMesh(M_GLOW, DM, nc[0], nc[1], nc[2], 0.85, 2, false); }
  setPass('opaque');
  gl.disable(gl.SCISSOR_TEST); gl.viewport(0, 0, W, H);
}

