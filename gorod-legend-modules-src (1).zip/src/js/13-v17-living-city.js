/* ===================== v17: ЖИВОЙ ГОРОД — светофоры, погода, звуки ===================== */
/* --- светофоры: axis 1 = движение вдоль z, axis 0 = вдоль x. 0 зелёный, 1 жёлтый, 2 красный --- */
const SIG_T = 26;
function sigState(i, j, axis) {
  const t = (G.time + i * 7 + j * 3) % SIG_T, a = axis === 1 ? t : (t + 13) % SIG_T;
  return a < 10.5 ? 0 : a < 13 ? 1 : 2;
}
function buildSignalPoles(SET) {
  const dk = [0.16, 0.17, 0.2, 1];
  for (let i = 0; i <= GRID; i++) for (let j = 0; j <= GRID; j++) {
    const nx = nodeC(i), nz = nodeC(j);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const px = nx + sx * 8.8, pz = nz + sz * 8.8;
      const gy = [0.9, 0.74, 0.14, 1], lt = [0.42, 0.43, 0.48, 1], hs = [0.07, 0.07, 0.09, 1];
      circles.push({ x: px, z: pz, r: 0.3 });   // столб — препятствие
      SET.g().box(px - 0.1, 0.16, pz - 0.1, px + 0.1, 5.2, pz + 0.1, [0.5, 0.52, 0.58, 1], false, true);
      for (const [rx, rz] of [[0.11, 0], [-0.11, 0], [0, 0.11], [0, -0.11]]) SET.g().box(px + rx - 0.03, 0.7, pz + rz - 0.03, px + rx + 0.03, 4.5, pz + rz + 0.03, [0.78, 0.8, 0.86, 1], false, true);
      SET.g().box(px - 0.26, 0.16, pz - 0.26, px + 0.26, 0.55, pz + 0.26, lt, false, true);        // основание
      SET.g().box(px - 0.15, 0.55, pz - 0.15, px + 0.15, 0.7, pz + 0.15, [0.3, 0.31, 0.35, 1], false, true);
      for (let b = 0; b < 4; b++) SET.g().box(px - 0.125, 1.0 + b * 0.5, pz - 0.125, px + 0.125, 1.25 + b * 0.5, pz + 0.125, b % 2 ? dk : gy, false, true);   // полосы
      SET.g().box(px - 0.19, 1.25, pz - 0.08, px + 0.19, 1.6, pz + 0.08, [0.6, 0.6, 0.65, 1], false, true);   // кнопка пешеходов
      SET.g().box(px - 0.4, 4.6, pz - 0.4, px + 0.4, 5.7, pz + 0.4, hs, false, true);
      SET.g().box(px - 0.46, 5.7, pz - 0.46, px + 0.46, 5.82, pz + 0.46, gy, false, true);         // козырёк-крыша
      SET.g().box(px - 0.46, 4.5, pz - 0.46, px + 0.46, 4.6, pz + 0.46, gy, false, true);
    }
  }
}
function sigHead(x, y, z, st) {
  const cols = [[1, 0.12, 0.1], [1, 0.8, 0.1], [0.1, 1, 0.3]], act = st === 2 ? 0 : st === 1 ? 1 : 2;
  for (let t = 0; t < 3; t++) {
    const c = cols[t], on = t === act, k = on ? 1 : 0.13;
    mTRS(DM, x, y + 0.3 - t * 0.3, z, 0, 0, 0, 0.27, 0.27, 0.27); drawMesh(M_UCOL, DM, c[0] * k, c[1] * k, c[2] * k, 1, 1, false);
  }
}
function drawSignals() {
  if (G.inHome) return;
  for (let i = 0; i <= GRID; i++) {
    const nx = nodeC(i); if (Math.abs(nx - CAM.x) > 150) continue;
    for (let j = 0; j <= GRID; j++) {
      const nz = nodeC(j); if (Math.abs(nz - CAM.z) > 150) continue;
      if (!visible(nx, nz, 14, 150)) continue;
      const s1 = sigState(i, j, 1), s0 = sigState(i, j, 0);
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
        const px = nx + sx * 8.8, pz = nz + sz * 8.8;
        sigHead(px, 5.15, pz - sz * 0.5, s1);
        sigHead(px - sx * 0.5, 5.15, pz, s0);
      }
    }
  }
}
/* скорость, до которой трафик должен снизиться перед красным (99 — ограничения нет) */
function lightStop(c) {
  if (c.kind !== 'traffic') return 99;
  const fx = Math.sin(c.h), fz = Math.cos(c.h), alongX = Math.abs(fx) > Math.abs(fz), sg = (alongX ? fx : fz) >= 0 ? 1 : -1;
  const pos = alongX ? c.x : c.z, u = (pos + HALF) / PITCH;
  const k = sg > 0 ? Math.ceil(u - 0.0001) : Math.floor(u + 0.0001);
  if (k < 0 || k > GRID) return 99;
  const al = (nodeC(k) - pos) * sg;
  if (al < 15 || al > 55) return 99;
  const line = clamp(Math.round(((alongX ? c.z : c.x) + HALF) / PITCH), 0, GRID);
  const st = sigState(alongX ? k : line, alongX ? line : k, alongX ? 0 : 1);
  if (st === 0) return 99;
  if (st === 1 && al < 15 + (c.spd || 0) * 1.3) return 99;
  return Math.max(0, (al - 15 - 1.2) * 1.6);
}

/* --- погода: гроза и туман --- */
function weatherFog() {
  const f = WX.fog; if (f < 0.01) return;
  const g = ENV.night < 0.5 ? [0.72, 0.75, 0.78] : [0.09, 0.1, 0.13];
  ENV.top = mix3(ENV.top, g, f * 0.8); ENV.bot = mix3(ENV.bot, g, f * 0.9); ENV.sky = mix3(ENV.sky, g, f * 0.5);
  ENV.fogNear = lerp(ENV.fogNear, 8, f); ENV.fogFar = lerp(ENV.fogFar, 150, f);
}
function weatherStorm(r) {
  if (WX.storm) {
    const k = 1 - 0.3 * r;
    ENV.top = ENV.top.map(v => v * k); ENV.bot = ENV.bot.map(v => v * k); ENV.sunCol = ENV.sunCol.map(v => v * (1 - 0.35 * r));
  }
  const f = WX.flash;
  if (f > 0.01) {
    ENV.top = mix3(ENV.top, [1, 1, 1], f * 0.7); ENV.bot = mix3(ENV.bot, [0.9, 0.93, 1], f * 0.7); ENV.sky = mix3(ENV.sky, [1, 1, 1], f * 0.5);
    ENV.sunCol = ENV.sunCol.map(v => v + f * 0.7);
  }
}
function lightning() {
  WX.flash = 1;
  if (Math.random() < 0.5) WX.re = 0.17;
  noiseBurst(0.12, 0.3, 5000, 0);
  const d = 0.35 + Math.random() * 2.6, v = 0.9;
  noiseBurst(2.4, v, 170, d); tone(52, 1.8, 'sawtooth', 0.28, 26, d); noiseBurst(0.7, 0.5, 600, d + 0.1);
}

/* --- радио: кнопка и клавиша --- */
function radioPillEl() {
  let e = document.getElementById('radioPill');
  if (!e) {
    e = document.createElement('div'); e.id = 'radioPill';
    e.style.cssText = 'position:fixed;left:50%;top:112px;transform:translateX(-50%);padding:5px 12px;border-radius:20px;background:rgba(10,12,20,.78);color:#fff;font:600 12px system-ui,sans-serif;z-index:25;cursor:pointer;display:none;border:1px solid rgba(255,255,255,.18);user-select:none;touch-action:manipulation;white-space:nowrap';
    e.addEventListener('click', ev => { ev.stopPropagation(); auInit(); radioNext(); });
    document.body.appendChild(e);
  }
  return e;
}

/* --- звуки города --- */
const CS = { t: 8, rainOn: 0 };
function citySound() {
  const night = ENV.night, calm = WX.rain < 0.25;
  const r = Math.random();
  if (r < 0.3) {   // далёкая сирена
    for (let k = 0; k < 3; k++) { tone(650, 0.75, 'triangle', 0.03, 950, k * 1.5); tone(950, 0.75, 'triangle', 0.03, 650, k * 1.5 + 0.75); }
  } else if (r < 0.6) {   // гудки
    const n = 1 + Math.floor(Math.random() * 3);
    for (let k = 0; k < n; k++) { tone(420, 0.2, 'square', 0.035, 0, k * 0.32); tone(530, 0.2, 'square', 0.03, 0, k * 0.32); }
  } else if (night > 0.5 && calm) {   // сверчки
    for (let k = 0; k < 7; k++) tone(4300 + Math.random() * 200, 0.035, 'sine', 0.018, 0, k * 0.07);
  } else if (night < 0.4 && calm) {   // птицы
    const n = 2 + Math.floor(Math.random() * 3);
    for (let k = 0; k < n; k++) tone(2500 + Math.random() * 500, 0.09, 'sine', 0.03, 3600, k * 0.14);
  } else tone(95, 1.6, 'sine', 0.03, 120, 0);   // гул вдали
}
function v17Tick(dt) {
  const play = G.mode === 'play' && !G.paused;
  // туман
  WX.fogT -= dt;
  if (WX.fogT <= 0) {
    if (WX.fogTgt) { WX.fogTgt = 0; WX.fogT = 100 + Math.random() * 160; toast('🌤 Туман рассеялся'); }
    else if (Math.random() < 0.3) { WX.fogTgt = 1; WX.fogT = 70 + Math.random() * 70; toast('🌫 Опустился туман — видимость падает'); }
    else WX.fogT = 60 + Math.random() * 90;
  }
  WX.fog += clamp(WX.fogTgt - WX.fog, -dt * 0.04, dt * 0.04);
  // молнии
  WX.flash = Math.max(0, WX.flash - dt * 3.4);
  if (WX.re > 0) { WX.re -= dt; if (WX.re <= 0) WX.flash = 0.75; }
  if (WX.storm && WX.rain > 0.5 && play) {
    WX.flashT -= dt;
    if (WX.flashT <= 0) { WX.flashT = 3.5 + Math.random() * 8; lightning(); }
    if (P.car && Math.abs(P.car.vf) > 8 && !G.inHome) S.flags.storm = 1;
  }
  // фон: дождь и ветер
  if (AU.rainG && AU.ctx) {
    const vol = play ? WX.rain * (WX.storm ? 0.22 : 0.12) * (G.inHome ? 0.35 : 1) : 0;
    AU.rainG.gain.setTargetAtTime(vol * S.set.sfx, AU.ctx.currentTime, 0.5);
  }
  // звуки города
  if (play && !G.inHome && AU.ctx) {
    CS.t -= dt;
    if (CS.t <= 0) { CS.t = 9 + Math.random() * 18; citySound(); }
  }
  // радио-плашка
  const pill = radioPillEl(), show = play && !G.inHome && !!P.car && UI.cur === null;
  if (show) { const tx = '📻 ' + RADIO[radioIdx()].n + '  ·  N'; if (pill.textContent !== tx) pill.textContent = tx; }
  pill.style.display = show ? 'block' : 'none';
}

function obstacleSpeed(c, dt) {
  const ai = c.ai, fx = Math.sin(c.h), fz = Math.cos(c.h), rx = -fz, rz = fx, look = 10 + c.spd * 0.9;
  let best = 99, wk = false;
  for (let k = 0; k < cars.length; k++) {
    const o = cars[k];
    if (o === c || o.kind === 'racer' || o.kind === 'police') continue;
    const dx = o.x - c.x, dz = o.z - c.z, al = dx * fx + dz * fz;
    if (al < 1 || al > look) continue;
    const lat = Math.abs(dx * rx + dz * rz);
    if (lat > 2.4) continue;
    if (o.kind !== 'traffic' && o.driver !== 'player' && Math.abs(o.vx) + Math.abs(o.vz) < 0.5 && lat > 1.9) continue;
    const gap = al - (c.L + o.L) / 2;
    if (o.kind === 'wreck') wk = true;
    best = Math.min(best, Math.max(0, (gap - 2.5) * 1.6));
  }
  if (best < 1.5) ai.blocked += dt; else ai.blocked = Math.max(0, ai.blocked - dt * 2);
  if (ai.blocked > (wk ? 24 : 3.5)) { ai.ignoreT = 3; ai.blocked = 0; }
  const ls = lightStop(c);
  if (ai.ignoreT > 0) { ai.ignoreT -= dt; return ls; }
  return Math.min(best, ls);
}
function stepAI(c, dt) {
  const ai = c.ai;
  if (c.hitT > 0) c.hitT -= dt;
  if (!ai.wps.length) aiPlan(c);
  let wp = ai.wps[0], des = ai.maxSp;
  if (wp) {
    let dist = Math.hypot(wp.x - c.x, wp.z - c.z);
    if (dist < Math.max(4.5, c.spd * 0.22)) {
      ai.wps.shift(); if (!ai.wps.length) aiPlan(c);
      wp = ai.wps[0]; dist = wp ? Math.hypot(wp.x - c.x, wp.z - c.z) : 0;
    }
    if (wp && wp.sp !== undefined) des = Math.min(des, Math.sqrt(wp.sp * wp.sp + 2 * 10 * Math.max(0, dist - 4)));
  }
  if (c.kind === 'traffic') des = Math.min(des, obstacleSpeed(c, dt));
  if (c.hitT > 0 || ai.hold) des = 0;
  c.spd += clamp(des - c.spd, -26 * dt, ai.acc * dt);
  if (c.spd < 0) c.spd = 0;
  if (wp) {
    const tgt = Math.atan2(wp.x - c.x, wp.z - c.z), dh = wrapA(tgt - c.h), rate = clamp(c.spd / 4.5, 0.5, 2.6);
    c.h += clamp(dh, -rate * dt, rate * dt);
  }
  const fx = Math.sin(c.h), fz = Math.cos(c.h);
  c.vx = fx * c.spd; c.vz = fz * c.spd; c.vf = c.spd; c.vl = 0;
  c.x += c.vx * dt; c.z += c.vz * dt;
  c.brake = des < c.spd - 1;
}
function placeTraffic(c, nearP) {
  const ci = nearP ? Math.round((P.x + HALF) / PITCH) : 0, cj = nearP ? Math.round((P.z + HALF) / PITCH) : 0;
  let i, j, d, t, f, rt, tries = 0;
  for (;;) {
    if (nearP) { i = clamp(ci + Math.floor(rand(-3, 4)), 0, GRID); j = clamp(cj + Math.floor(rand(-3, 4)), 0, GRID); }
    else { i = Math.floor(Math.random() * (GRID + 1)); j = Math.floor(Math.random() * (GRID + 1)); }
    d = Math.floor(Math.random() * 4); tries++;
    f = DIRS[d]; rt = rightOf(d); t = 18 + Math.random() * 30;
    const okGrid = !(i + f[0] < 0 || j + f[1] < 0 || i + f[0] > GRID || j + f[1] > GRID);
    const px = nodeC(i) + f[0] * t + rt[0] * LANE, pz = nodeC(j) + f[1] * t + rt[1] * LANE;
    if (okGrid && (!nearP || Math.hypot(px - CAM.x, pz - CAM.z) > 95) || tries > 80) break;
  }
  c.x = nodeC(i) + f[0] * t + rt[0] * LANE; c.z = nodeC(j) + f[1] * t + rt[1] * LANE; c.h = Math.atan2(f[0], f[1]);
  c.vx = c.vz = c.vf = c.vl = 0; c.spd = 8; c.hitT = 0;
  c.ai = { mode: 'traffic', wps: [], i: Math.min(GRID, Math.max(0, i + f[0])), j: Math.min(GRID, Math.max(0, j + f[1])), d, maxSp: rand(11, 17), acc: 5, blocked: 0, ignoreT: 0 };
  const bx = nodeC(c.ai.i), bz = nodeC(c.ai.j);
  c.ai.wps.push({ x: bx - f[0] * 14 + rt[0] * LANE, z: bz - f[1] * 14 + rt[1] * LANE });
}
function spawnTraffic() {
  const def = pick([CAR_BY_ID.hatch, CAR_BY_ID.sedan, CAR_BY_ID.van, CAR_BY_ID.taxi, CAR_BY_ID.suv, CAR_BY_ID.coupe, CAR_BY_ID.pickup, CAR_BY_ID.classic]);
  const c = makeCar(def, 'traffic', def.taxi ? '#ffd60a' : pick(COLORS));
  placeTraffic(c, false);
  return c;
}
let recT = 0;
function recycleTraffic(dt) {
  recT += dt; if (recT < 0.5) return; recT = 0;
  if (G.inHome) return;
  for (const c of cars) {
    if (c.kind !== 'traffic') continue;
    const dp = Math.hypot(c.x - P.x, c.z - P.z), dc = Math.hypot(c.x - CAM.x, c.z - CAM.z);
    if (dp > 230 && dc > 120) { placeTraffic(c, true); break; }
  }
}
function applyTraffic() {
  const q = G.quality || QUAL.med, mult = [0.4, 1, 1.5][S.set.traffic] || 1;
  const want = Math.round(q.traffic * mult);
  let have = cars.filter(c => c.kind === 'traffic');
  while (have.length < want) have.push(spawnTraffic());
  while (have.length > want) removeCar(have.pop());
}
function spawnParked(n) {
  const defs = [CAR_BY_ID.hatch, CAR_BY_ID.van, CAR_BY_ID.taxi, CAR_BY_ID.sedan, CAR_BY_ID.suv, CAR_BY_ID.coupe, CAR_BY_ID.muscle];
  const R = rng(4242);
  for (let k = 0; k < n; k++) {
    const def = defs[Math.floor(R() * defs.length)];
    const c = makeCar(def, 'parked', def.taxi ? '#ffd60a' : COLORS[Math.floor(R() * COLORS.length)]);
    const vertical = R() < 0.5, line = Math.floor(R() * (GRID + 1)), seg = Math.floor(R() * GRID), t = 20 + R() * 40, sg = R() < 0.5 ? 1 : -1;
    if (vertical) { c.x = nodeC(line) + sg * 6.6; c.z = nodeC(seg) + t; c.h = sg > 0 ? 0 : Math.PI; }
    else { c.z = nodeC(line) + sg * 6.6; c.x = nodeC(seg) + t; c.h = sg > 0 ? -Math.PI / 2 : Math.PI / 2; }
    // правая сторона: при движении вдоль +z правый борт = -x
    c.y = 0;
  }
}
function spawnOwn(x, z, h) {
  if (OWN) { const was = P.car === OWN; removeCar(OWN); if (was) P.car = null; }
  const u = S.cars[S.sel].u, def = CAR_BY_ID[S.sel];
  const c = makeCar(def, 'own', S.cars[S.sel].color, u, S.cars[S.sel].mods);
  c.x = x; c.z = z; c.h = h; OWN = c; c.recId = S.sel;
  return c;
}
function refreshOwnStats() { if (OWN) { OWN.st = statsFor(OWN.def, S.cars[S.sel].u); } }

