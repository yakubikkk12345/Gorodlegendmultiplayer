/* ===================== v18: КАЧЕСТВО И УДОБСТВО — слоты сохранений, подсказки ===================== */
function slotInfo(n) {
  let s = null;
  if (n === SLOT) s = S;
  else { try { const raw = localStorage.getItem(slotKey(n)); if (raw) s = JSON.parse(raw); } catch (e) { } }
  if (!s || !s.started) return null;
  const done = Object.keys(s.missions || {}).filter(k => s.missions[k] && s.missions[k].done).length;
  return { money: s.money || 0, cars: Object.keys(s.cars || {}).length, done, ch: (s.story && s.story.ch) || 0 };
}
function renderSlots() {
  if ($('codeBox')) $('codeBox').style.display = 'none';
  let h = '';
  for (let n = 1; n <= 3; n++) {
    const inf = slotInfo(n), cur = n === SLOT;
    h += '<div class="card"><div class="c-body"><b>' + (cur ? '▶ ' : '') + 'Слот ' + n + (cur ? ' — активный' : '') + '</b><small>' +
      (inf ? fmtMoney(inf.money) + ' · машин: ' + inf.cars + ' · заданий: ' + inf.done + ' · сюжет: ' + inf.ch + '/' + STORY.length : 'Пусто') + '</small></div>' +
      '<div style="display:flex;gap:6px;flex-wrap:wrap">' +
      (inf ? (cur ? '' : '<button class="btn small" data-act="slot-load" data-slot="' + n + '">Загрузить</button>') : '<button class="btn small" data-act="slot-new" data-slot="' + n + '">Играть</button>') +
      (inf ? '<button class="btn small danger" data-act="slot-del" data-slot="' + n + '">🗑</button>' : '') + '</div></div>';
  }
  $('slotList').innerHTML = h;
}
function slotCatchUp() {
  const offs = Math.min(1200, Math.max(0, (Date.now() - (S.bizT || Date.now())) / 1000));
  for (const p of PROPS) if (propOwn(p.id)) propAdd(p.id, offs);
}
function reloadSlot() {
  const set = S.set; S = loadSave(); S.set = set;
  WS.mag = {}; WS.reload = 0; OWN && removeCar(OWN); OWN = null; DR.total = 0;
  slotCatchUp(); refreshMoney(false);
}
function switchSlot(n) {
  persist();
  if (G.mode === 'play') toMenu();
  SLOT = n; try { localStorage.setItem('gorod_legend_slot', String(n)); } catch (e) { }
  reloadSlot();
}
function exportSave() {
  persist();
  try {
    const blob = new Blob([JSON.stringify(S)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'gorod-legend-slot' + SLOT + '.json';
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800);
    toast('📤 Слот ' + SLOT + ' сохранён в файл');
  } catch (e) { toast('❌ Не удалось экспортировать'); SFX.err(); }
}
function showCodeBox(paste, text) {
  const box = $('codeBox'), tx = $('codeTx'); if (!box) return;
  box.style.display = 'block'; tx.value = text || '';
  $('codeApply').style.display = paste ? '' : 'none';
  tx.placeholder = paste ? 'Вставьте код сохранения сюда и нажмите «Применить»' : '';
  setTimeout(() => { try { tx.focus(); if (!paste) tx.select(); } catch (e) { } }, 50);
}
function copySaveCode() {
  persist();
  const code = encodeSaveCode(S);
  showCodeBox(false, code);
  try { navigator.clipboard.writeText(code).then(() => toast('📋 Код скопирован'), () => toast('Скопируйте код из поля вручную')); }
  catch (e) { toast('Скопируйте код из поля вручную'); }
}
function applyCodeBox() {
  const s = decodeSaveCode($('codeTx').value);
  if (!s) { toast('❌ Код не похож на сохранение'); SFX.err(); return; }
  askConfirm('Заменить сохранение в слоте ' + SLOT + ' кодом (' + fmtMoney(s.money) + ')?', () => { showCodeBox(false); importSave(s); });
}
function importSave(s) {
  if (G.mode === 'play') toMenu();
  try { localStorage.setItem(slotKey(SLOT), JSON.stringify(s)); } catch (e) { }
  reloadSlot(); persist(); showScreen('slots'); toast('📥 Сохранение загружено в слот ' + SLOT); SFX.buy();
}
$('slotFile').addEventListener('change', ev => {
  const f = ev.target.files[0]; ev.target.value = ''; if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    let s = null;
    try { s = JSON.parse(r.result); if (!s || s.v !== 1 || typeof s.money !== 'number' || !s.cars) throw 0; } catch (e) { toast('❌ Файл не похож на сохранение'); SFX.err(); return; }
    askConfirm('Заменить сохранение в слоте ' + SLOT + ' файлом «' + f.name + '» (' + fmtMoney(s.money) + ')?', () => importSave(s));
  };
  r.readAsText(f);
});
HOME_FN.noop = function () { };

/* --- подсказки новичку --- */
const HN = { moved: 0, driven: 0, lx: undefined, lz: 0, okT: 0, last: '' };
const HINTS = [
  { id: 'move', t: '🚶 Ходьба: W A S D или стрелки (на телефоне — левый джойстик). Shift — бег. На ПК: кликните по игре — мышь захватится и будет крутить камеру, Esc — отпустить', ok: () => HN.moved > 14 },
  { id: 'car', t: '🚗 Подойдите к своей машине (она рядом с домом) и нажмите F, чтобы сесть', ok: () => !!S.flags.hCar },
  { id: 'drive', t: '🏎 W / S — газ и тормоз, A / D — руль, Пробел — ручник, Shift — нитро', ok: () => HN.driven > 120 },
  { id: 'radio', t: '📻 Клавиша N — сменить радиостанцию, H — сигнал', ok: () => (S.flags.radioN || 0) > 0, car: true },
  { id: 'map', t: '🗺 Нажмите M — карта города. Тап по карте строит маршрут', ok: () => !!S.flags.hMap },
  { id: 'missions', t: '📋 Нажмите J — задания. Начните с «Пицца на вынос»: метка у дома', ok: () => !!S.flags.hMis || doneCount() > 0 },
  { id: 'shops', t: '🛒 Деньги тратьте в автосалоне, оружейном и тюнинг-центре — зайдите в любой на метке (E)', ok: () => !!S.flags.hShop }
];
function hintEl() {
  let e = document.getElementById('hintBox');
  if (!e) {
    e = document.createElement('div'); e.id = 'hintBox';
    e.style.cssText = 'position:fixed;left:50%;top:150px;transform:translateX(-50%);max-width:min(520px,90vw);padding:7px 14px;border-radius:14px;background:rgba(10,16,34,.82);color:#fff;font:600 13px/1.35 system-ui,sans-serif;z-index:24;display:none;border:1px solid rgba(255,210,63,.55);text-align:center;pointer-events:none';
    e.innerHTML = '<span id="hintTx"></span> <b id="hintX" style="margin-left:8px;opacity:.65;cursor:pointer;pointer-events:auto">✕</b>';
    e.querySelector('#hintX').addEventListener('click', ev => { ev.stopPropagation(); S.set.hints = false; persist(); toast('💡 Подсказки отключены — включить можно в настройках'); });
    document.body.appendChild(e);
  }
  return e;
}
function hintTick(dt) {
  const px = P.car ? P.car.x : P.x, pz = P.car ? P.car.z : P.z;
  if (HN.lx !== undefined) { const d = Math.hypot(px - HN.lx, pz - HN.lz); if (d < 40) { if (P.car) HN.driven += d; else HN.moved += d; } }
  HN.lx = px; HN.lz = pz;
  if (P.car) S.flags.hCar = 1;
  if (UI.cur === 'mapScreen') S.flags.hMap = 1;
  if (UI.cur === 'missions') S.flags.hMis = 1;
  if (G.inHome && G.int && G.int.kind !== 'home') S.flags.hShop = 1;
  if (typeof S.flags.hints !== 'object' || !S.flags.hints) S.flags.hints = {};
  const fl = S.flags.hints; let cur = null;
  for (const h of HINTS) {
    if (fl[h.id]) continue;
    if (h.ok()) { fl[h.id] = 1; HN.okT = 1.6; continue; }
    if (h.car && !P.car) continue;
    cur = h; break;
  }
  if (HN.okT > 0) HN.okT -= dt;
  const on = S.set.hints !== false && G.mode === 'play' && !G.paused && !G.inHome && !M && UI.cur === null && doneCount() < 3;
  const el = hintEl(), txt = HN.okT > 0 ? '✔ Отлично!' : cur ? cur.t : '';
  if (txt !== HN.last) { HN.last = txt; document.getElementById('hintTx').textContent = txt; }
  el.style.display = on && txt ? 'block' : 'none';
}
function v18Tick(dt) {
  hintTick(dt);
  const u = document.getElementById('speedUnit'); if (u) setText(u, S.set.mph ? 'mph' : 'км/ч');
}

