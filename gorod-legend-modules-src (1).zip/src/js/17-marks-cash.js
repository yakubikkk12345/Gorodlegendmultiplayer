/* ===================== 13. МЕТКИ, СФЕРЫ, ДЕНЬГИ ===================== */
const WORLD_MARKS = [
  { id: 'garage', int: true, x: INX + 7.4, z: INZ + 0.6, r: 2.6, label: '🔧 ГАРАЖ', act: 'garage' },
  { id: 'gunA', x: bc(3 + BO), z: bc(1 + BO) - 12, c: [1, 0.3, 0.3], label: '🔫 ВОЙТИ В ОРУЖЕЙНЫЙ', short: '🔫 ОРУЖЕЙНЫЙ', dot: '#ff4d4d', fn: 'enterShop', kind: 'gun', r: 6, br: 3 },
  { id: 'gunB', x: bc(8 + BO), z: bc(10 + BO) - 12, c: [1, 0.3, 0.3], label: '🔫 ВОЙТИ В ОРУЖЕЙНЫЙ', short: '🔫 ОРУЖЕЙНЫЙ', dot: '#ff4d4d', fn: 'enterShop', kind: 'gun', r: 6, br: 3 },
  { id: 'carA', x: bc(2 + BO), z: bc(7 + BO) - 12, c: [0.2, 1, 0.5], label: '🚘 ВОЙТИ В АВТОСАЛОН', short: '🚘 АВТОСАЛОН', dot: '#3dff8a', fn: 'enterShop', kind: 'car', r: 6, br: 3 },
  { id: 'carB', x: bc(10 + BO), z: bc(2 + BO) - 12, c: [0.2, 1, 0.5], label: '🚘 ВОЙТИ В АВТОСАЛОН', short: '🚘 АВТОСАЛОН', dot: '#3dff8a', fn: 'enterShop', kind: 'car', r: 6, br: 3 },
  { id: 'hosp', x: HOSP.x, z: HOSP.z - 12, c: [1, 0.3, 0.4], label: '🏥 ВОЙТИ В БОЛЬНИЦУ', short: '🏥 БОЛЬНИЦА', dot: '#ff7a95', fn: 'enterShop', kind: 'hosp', r: 6, br: 3 },
  { id: 'polst', x: POLST.x, z: POLST.z - 12, c: [0.3, 0.5, 1], label: '🚓 ВОЙТИ В УЧАСТОК', short: '🚓 УЧАСТОК', dot: '#4a86ff', fn: 'enterShop', kind: 'pol', r: 6, br: 3 },
  { id: 'home', x: 40, z: 25, c: [1, 0.8, 0.2], label: '🏠 ВОЙТИ В ДОМ', short: '🏠 МОЙ ДОМ', dot: '#ffd23f', fn: 'enterHome', r: 6, br: 2.6 },
  { id: 'tv', int: true, x: INX, z: INZ + 6.1, r: 2.2, label: '📺 СМОТРЕТЬ ТВ', fn: 'watchTV' },
  { id: 'bed', int: true, x: INX - 7.2, z: INZ + 2.9, r: 2.8, label: '🛏 ЛЕЧЬ СПАТЬ', fn: 'sleep' },
  { id: 'ward', int: true, x: INX + 7.5, z: INZ + 5.4, r: 2.6, label: '👔 ГАРДЕРОБ', fn: 'wardrobe' },
  { id: 'door', int: true, x: INX, z: INZ - 6.3, r: 2.6, label: '🚪 ВЫЙТИ НА УЛИЦУ', fn: 'leaveHome' }
];
for (const k of ['gun', 'car', 'hosp', 'pol', 'tune', 'club', 'cloth', 'salon']) {
  const o = INT[k];
  WORLD_MARKS.push({ id: 'talk_' + k, int: true, x: o.x, z: o.z - 0.4, r: 3.2, label: '💬 ПОГОВОРИТЬ: ' + SELLERS[k].name, fn: 'talk', kind: k });
  WORLD_MARKS.push({ id: 'door_' + k, int: true, x: o.x, z: o.z - 6.3, r: 2.6, label: '🚪 ВЫЙТИ НА УЛИЦУ', fn: 'leaveShop' });
}
for (const k in BIZ_BLK) {
  const b = BIZ_BLK[k], ij = k.split(',').map(Number);
  WORLD_MARKS.push({ id: 'biz_' + b.id, x: bc(ij[0]) + 14, z: bc(ij[1]) + 6, c: b.mc, label: b.id === 'boss' ? '📞 ПОГОВОРИТЬ С КРОТОМ' : b.ico + ' ' + b.short + ': ПОГОВОРИТЬ', short: b.ico + ' ' + b.short, dot: b.dot, fn: 'bizTalk', kind: b.id, r: 5, br: 3 });
}
const cash = [];
(function genCash() {
  const R = rng(31337);
  for (let k = 0; k < 150; k++) {
    const vertical = R() < 0.5, line = Math.floor(R() * (GRID + 1)), pos = (R() - 0.5) * (HALF * 2 - 40);
    const x = vertical ? nodeC(line) + (R() - 0.5) * 8 : pos, z = vertical ? pos : nodeC(line) + (R() - 0.5) * 8;
    cash.push({ x, z, v: 50 + Math.floor(R() * 4) * 25, t: 0 });
  }
})();
const MARK = { list: [], orbs: [], beamAlpha: 1 };   // list: [{x,z,r,c}], orbs: [{x,z,got}]
function drawBeamAt(x, z, r, h, c, a) {
  const y = terrainY(x, z);
  const cd = Math.hypot(CAM.x - x, CAM.z - z);
  a *= clamp((cd - r) / 7, 0, 1) * 0.8;
  if (a < 0.01) return;
  mTRS(DM, x, y, z, 0, 0, 0, r, h, r); drawMesh(M_BEAM, DM, c[0], c[1], c[2], a, 2, false);
  mTRS(DM, x, y + 0.08, z, 0, 0, 0, r, 1, r); drawMesh(M_RING, DM, c[0], c[1], c[2], a * 1.4, 2, false);
}
function drawMarkers() {
  const pulse = 0.75 + 0.25 * Math.sin(G.time * 4);
  for (const m of WORLD_MARKS) { if (G.mode !== 'play' || m.int) continue; if (visible(m.x, m.z, 10, 260)) drawBeamAt(m.x, m.z, m.br || 5, 40, m.c, 0.9 * pulse); }
  if (G.mode !== 'play') return;
  if (NAV.on && !G.inHome) drawBeamAt(NAV.x, NAV.z, 3, 70, [1, 0.24, 0.95], 0.85 * pulse);
  if (EV.wallet && !G.inHome) drawBeamAt(EV.wallet.x, EV.wallet.z, 2, 40, [1, 0.85, 0.2], 0.8 * pulse);
  if (EV.thief && !G.inHome) drawBeamAt(EV.thief.x, EV.thief.z, 1.5, 30, [1, 0.4, 0.1], 0.9 * pulse);
  for (let k = 0; k < MARK.list.length; k++) {
    const m = MARK.list[k]; drawBeamAt(m.x, m.z, m.r * (k === 0 ? 1 : 0.7), k === 0 ? 90 : 40, m.c, (k === 0 ? 1 : 0.45) * pulse);
  }
}
function drawPickups() {
  if (G.mode !== 'play') return;
  const t = G.time;
  for (const o of MARK.orbs) {
    if (o.got) continue; if (!visible(o.x, o.z, 4, 220)) continue;
    mTRS(DM, o.x, terrainY(o.x, o.z) + 1.8 + Math.sin(t * 3 + o.x) * 0.3, o.z, t * 2, 0, 0, 1.4, 1.4, 1.4);
    drawMesh(M_OCTA, DM, 1, 0.8, 0.1, 1, 1, false);
  }
  for (const c of cash) {
    if (c.t > 0) continue; if (!visible(c.x, c.z, 3, 130)) continue;
    mTRS(DM, c.x, 1.2 + Math.sin(t * 3 + c.z) * 0.15, c.z, t * 2.5, 0, 0, 0.8, 0.8, 0.8);
    drawMesh(M_OCTA, DM, 0.2, 1, 0.45, 1, 1, false);
  }
}
function drawPickupGlow() { /* свечение рисуется внутри drawMarkers для сфер */ }

