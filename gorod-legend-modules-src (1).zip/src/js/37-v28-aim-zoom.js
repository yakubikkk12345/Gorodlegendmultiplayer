/* ===================== v28: ПРИЦЕЛ, ЗУМ, ВОДИТЕЛИ ===================== */
function aimManual() { return !P.car && !G.inHome && !wDef().melee && (S.set.aim === 'manual' || WS.zoomLvl > 0); }
function aimToggle() {
  S.set.aim = S.set.aim === 'manual' ? 'auto' : 'manual';
  toast(S.set.aim === 'manual' ? '🎯 Ручной прицел: мышь/палец — вверх и вниз' : '🎯 Авто-прицел'); SFX.click(); persist();
}
const ZOOM_FOV = [1.05, 0.40, 0.14];
function zoomToggle() {
  if (!scopeOk() || P.car || G.inHome) { toast('🔍 Зум: винтовка, снайперка или оружие с прицелом'); return; }
  WS.resume = 0; WS.zoomLvl = (WS.zoomLvl + 1) % zoomLevels(); if (WS.zoomLvl) WS.zf = ZOOM_FOV[WS.zoomLvl];
  toast(WS.zoomLvl === 0 ? '🔍 Без зума' : WS.zoomLvl === 1 ? '🔍 Зум ×3' : '🔍 Зум ×8'); SFX.click();
}
function zoomTick(dt) {
  const ok = !P.car && !G.inHome && scopeOk() && P.hp > 0;
  if (!ok) { WS.zoomLvl = 0; WS.resume = 0; }
  if (WS.resume && WS.resumeT > 0) { WS.resumeT -= dt; if (WS.resumeT <= 0) { WS.zoomLvl = WS.resume; WS.zf = ZOOM_FOV[WS.zoomLvl]; WS.resume = 0; } }
  const tgt = WS.zoomLvl > 0 ? 1 : 0;
  WS.zoom += (tgt - WS.zoom) * Math.min(1, dt * 12);
  if (Math.abs(WS.zoom - tgt) < 0.01) WS.zoom = tgt;
}
function aimRay() {
  const hd = Math.hypot(CAM.x - CAM.tx, CAM.z - CAM.tz) || 0.001, pd = Math.atan2(CAM.y - CAM.ty, hd);
  return { ex: CAM.x, ey: CAM.y, ez: CAM.z, pd, dx: Math.sin(CAM.yaw), dz: Math.cos(CAM.yaw) };
}
function aimUp() { return clamp(-Math.atan2(CAM.y - CAM.ty, Math.hypot(CAM.x - CAM.tx, CAM.z - CAM.tz)), -1.1, 1.1); }
function v28Hud(dt) {
  const gun = !P.car && !G.inHome && P.hp > 0 && !wDef().melee;
  const man = gun && aimManual();
  $('xhair').style.display = man && WS.zoom < 0.4 ? 'block' : 'none';
  $('scope').style.opacity = String(+(clamp((WS.zoom - 0.5) * 2, 0, 1)).toFixed(2));
  const z = $('btnZoom'); if (z) z.style.display = scopeOk() ? '' : 'none';
  const a = $('btnAim'); if (a) a.classList.toggle('on', S.set.aim === 'manual');
  PGUN.ap += ((man ? aimUp() : 0) - PGUN.ap) * Math.min(1, (dt || 0.016) * 10);
}
function v28Init() {
  document.querySelectorAll('[data-v28]').forEach(b => b.addEventListener('pointerdown', e => {
    e.preventDefault(); auInit(); if (b.dataset.v28 === 'aim') aimToggle(); else zoomToggle();
  }));
}
function spawnDriver(c) {
  const rx = Math.cos(c.h), rz = -Math.sin(c.h);
  const shirts = ['#3a86ff', '#2ecc71', '#ffd60a', '#ff4fa3', '#9b5de5', '#f1f1f1', '#ff7b00', '#00b4d8'];
  const side = Math.random() < 0.5 ? -1 : 1;
  const a = Math.atan2(rx * side, rz * side) + rand(-0.6, 0.6);
  peds.push({ drv: true, fixed: true, x: c.x + rx * side * 1.7, z: c.z + rz * side * 1.7, h: a, vx: Math.sin(a), vz: Math.cos(a), t: 0, ph: 0, hp: 30, look: genPedLook(shirts), panic: 6 });
}
function drvStep(p, dt) {
  if (p.dead) { p.dead += dt; p.fall = Math.min(1, (p.fall || 0) + dt * 4); if (p.dead > 8) p.rm = true; return; }
  p.t += dt;
  if (p.t > 12) { p.rm = true; return; }
  if (p.t < 0.6) return;
  const sp = 4.6, nx = p.x + p.vx * sp * dt, nz = p.z + p.vz * sp * dt;
  let hit = false;
  for (let k = 0; k < boxes.length; k++) { const b = boxes[k]; if (b.h > 1.4 && nx > b.x0 - 0.4 && nx < b.x1 + 0.4 && nz > b.z0 - 0.4 && nz < b.z1 + 0.4) { hit = true; break; } }
  if (hit) { const a = Math.atan2(p.vx, p.vz) + (Math.random() < 0.5 ? 1 : -1) * 1.3; p.vx = Math.sin(a); p.vz = Math.cos(a); }
  else { p.x = nx; p.z = nz; }
  p.h = Math.atan2(p.vx, p.vz); p.ph += sp * dt * 3.2;
}

