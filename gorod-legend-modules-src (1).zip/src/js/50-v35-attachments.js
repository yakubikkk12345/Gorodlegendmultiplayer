/* ===================== v35: ОБВЕСЫ, НОВОЕ ОРУЖИЕ, РЕЖИМЫ СТРЕЛЬБЫ, КОЛЕСО ОРУЖИЯ, МАГАЗИН, СТИЛЬ ===================== */
{
  /* ---------- новое оружие ---------- */
  const NEW = [
    { id: 'machete', name: 'Мачете', icon: '🗡️', price: 1200, dmg: 40, pellets: 1, rate: 0.36, mag: 1, reload: 0, spread: 0, range: 3.0, ammoPack: 0, packPrice: 0, minAmmo: 0, melee: true },
    { id: 'katana', name: 'Катана', icon: '⚔️', price: 4500, dmg: 58, pellets: 1, rate: 0.30, mag: 1, reload: 0, spread: 0, range: 3.3, ammoPack: 0, packPrice: 0, minAmmo: 0, melee: true },
    { id: 'sniper', name: 'Снайперская винтовка', icon: '🔭', price: 16000, dmg: 130, pellets: 1, rate: 1.25, mag: 5, reload: 2.4, spread: 0.002, range: 260, ammoPack: 10, packPrice: 450, minAmmo: 20 },
    { id: 'gl', name: 'Гранатомёт', icon: '🚀', price: 14000, dmg: 110, pellets: 1, rate: 1.1, mag: 6, reload: 3.0, spread: 0.02, range: 75, ammoPack: 6, packPrice: 480, minAmmo: 12 }
  ];
  for (const w of NEW) { WEAPONS.push(w); WBY[w.id] = w; }
  GUNMODEL.machete = { two: false, m: 0.55, melee: true, b: [[0, 0, 0.07, 0.04, 0.05, 0.16, 0.2, 0.12, 0.06], [0, 0, 0.46, 0.012, 0.09, 0.62, 0.8, 0.82, 0.86]] };
  GUNMODEL.katana = { two: false, m: 0.7, melee: true, b: [[0, 0, 0.1, 0.035, 0.045, 0.26, 0.1, 0.1, 0.12], [0, 0, 0.25, 0.1, 0.014, 0.03, 0.85, 0.7, 0.2], [0, 0, 0.82, 0.01, 0.05, 1.1, 0.9, 0.92, 0.96]] };
  GUNMODEL.sniper = { two: true, m: 0.9, b: [[0, 0.03, 0.34, 0.05, 0.08, 1.0, 0.1, 0.12, 0.1], [0, -0.1, 0.18, 0.04, 0.14, 0.06, 0.08, 0.08, 0.08], [0, -0.03, -0.16, 0.06, 0.12, 0.34, 0.14, 0.16, 0.12], [0, 0.11, 0.3, 0.05, 0.06, 0.34, 0.06, 0.06, 0.07], [0, 0.03, 0.92, 0.03, 0.03, 0.14, 0.05, 0.05, 0.06]] };
  GUNMODEL.gl = { two: true, m: 0.72, b: [[0, 0.02, 0.3, 0.14, 0.14, 0.7, 0.2, 0.22, 0.18], [0, 0.02, 0.62, 0.17, 0.17, 0.08, 0.1, 0.1, 0.1], [0, -0.1, 0.12, 0.04, 0.14, 0.05, 0.1, 0.1, 0.1], [0, -0.03, -0.12, 0.05, 0.1, 0.3, 0.14, 0.14, 0.14]] };
  const g2 = SFX.gun;
  SFX.gun = function (id, v) {
    v = v === undefined ? 1 : v;
    if (id === 'sniper') { noiseBurst(0.24, 0.5 * v, 1800); tone(110, 0.26, 'sawtooth', 0.28 * v, 40); return; }
    if (id === 'gl') { noiseBurst(0.18, 0.35 * v, 900); tone(70, 0.22, 'square', 0.25 * v, 35); return; }
    g2(id, v);
  };
  if (window.__RECOIL) window.__RECOIL.sniper = { p: 0.09, y: 0.004, b: 0.1, s: 0.35 };

  const CLS = { fist: 'melee', bat: 'melee', knife: 'melee', machete: 'melee', katana: 'melee', pistol: 'pistol', smg: 'smg', shotgun: 'shotgun', kalash: 'ar', sigsg: 'ar', rifle: 'rifle', sniper: 'rifle', gl: 'heavy' };
  const CLN = { melee: 'Ближний бой', pistol: 'Пистолеты', smg: 'Пистолеты-пулемёты', shotgun: 'Дробовики', ar: 'Автоматы', rifle: 'Винтовки', heavy: 'Тяжёлое' };
  const CLO = ['melee', 'pistol', 'smg', 'shotgun', 'ar', 'rifle', 'heavy'];
  const DESC = {
    bat: 'Тяжёлый удар, хорошо добивает ослабленных.', knife: 'Быстрый и тихий клинок.', machete: 'Тяжелее ножа, быстрее биты.', katana: 'Самый быстрый и острый клинок в городе.',
    pistol: 'Надёжный запасной ствол.', smg: 'Высокий темп огня, короткие дистанции.', shotgun: 'Страшен вблизи: семь дробин за выстрел.', rifle: 'Зум ×3 и ×8, точный выстрел.',
    kalash: 'Мощный автомат с заметной отдачей.', sigsg: 'Точный и послушный автомат.', sniper: 'Один выстрел — одна цель. Зум ×3 и ×8, огромная дальность.', gl: 'Взрывные гранаты: радиус поражения 7 м. Осторожно вблизи.'
  };

  /* ---------- обвесы ---------- */
  const ATT = [
    { id: 'scope', ico: '🔭', name: 'Оптический прицел', price: 2500, desc: 'Зум ×3 · точность +20%' },
    { id: 'supp', ico: '🔇', name: 'Глушитель', price: 1800, desc: 'Тихие выстрелы: прохожие не паникуют издалека · урон −8%' },
    { id: 'mag', ico: '📦', name: 'Расширенный магазин', price: 2200, desc: 'Магазин ×1,5' },
    { id: 'laser', ico: '🔴', name: 'Лазерный целеуказатель', price: 1500, desc: 'Красный луч · точность +20% от бедра' }
  ];
  const att = id => (S.guns.att && S.guns.att[id]) || {};
  const isGun = w => w && !w.melee && w.id !== 'fist';
  const attOk = (w, a) => isGun(w) && w.id !== 'gl' && (a === 'scope' || a === 'laser' ? w.id !== 'rifle' && w.id !== 'sniper' : true);
  let attSig = '';
  function applyAtt() {
    S.guns.att = S.guns.att || {}; S.guns.attOwn = S.guns.attOwn || {};
    for (const w of WEAPONS) {
      if (!isGun(w) || w.id === 'gl') continue;
      if (!w.b0) w.b0 = { mag: w.mag, spread: w.spread, dmg: w.dmg };
      const a = att(w.id);
      w.mag = Math.round(w.b0.mag * (a.mag ? 1.5 : 1));
      w.spread = w.b0.spread * (a.scope ? 0.8 : 1) * (a.laser ? 0.8 : 1);
      w.dmg = Math.round(w.b0.dmg * (a.supp ? 0.92 : 1));
      if (WS.mag[w.id] !== undefined && WS.mag[w.id] > w.mag) { S.guns.ammo[w.id] = (S.guns.ammo[w.id] || 0) + (WS.mag[w.id] - w.mag); WS.mag[w.id] = w.mag; }
    }
  }
  function attAct(wid, aid) {
    const w = WBY[wid], A = ATT.find(x => x.id === aid); if (!w || !A || !S.guns.own[wid] || !attOk(w, aid)) return;
    S.guns.att = S.guns.att || {}; S.guns.attOwn = S.guns.attOwn || {};
    const k = wid + ':' + aid, cur = S.guns.att[wid] = S.guns.att[wid] || {};
    if (!S.guns.attOwn[k]) {
      if (S.money < A.price) { SFX.err(); toast('Не хватает денег'); return; }
      S.money -= A.price; S.guns.attOwn[k] = true; cur[aid] = true; SFX.buy(); refreshMoney(true); toast(A.ico + ' ' + A.name + ' установлен');
    } else { cur[aid] = !cur[aid]; SFX.click(); toast(A.ico + ' ' + A.name + (cur[aid] ? ': установлен' : ': снят')); }
    applyAtt(); persist(); renderGunshop();
  }

  /* ---------- режимы стрельбы ---------- */
  const FMS = { smg: ['auto', 'burst', 'semi'], kalash: ['auto', 'burst', 'semi'], sigsg: ['auto', 'burst', 'semi'] };
  const FMN = { auto: 'АВТО', burst: 'ОЧЕРЕДЬ ×3', semi: 'ОДИНОЧНЫЙ' };
  const fmOf = id => (S.guns.fm && S.guns.fm[id]) || 'auto';
  const FM = window.__FM = { held: false, burst: 0, prev: false,
    hud(wd) { if (wd.melee) return ''; const a = att(wd.id); let s = ''; if (FMS[wd.id]) s += '  ' + FMN[fmOf(wd.id)].replace(' ×3', ''); if (a.scope) s += ' 🔭'; if (a.supp) s += ' 🔇'; if (a.mag) s += ' 📦'; if (a.laser) s += ' 🔴'; return s; } };
  function fmToggle() {
    const d = wDef(), list = FMS[d.id];
    if (!list) { toast('У этого оружия один режим огня'); return; }
    S.guns.fm = S.guns.fm || {}; S.guns.fm[d.id] = list[(list.indexOf(fmOf(d.id)) + 1) % list.length]; FM.burst = 0; FM.held = false;
    toast('🔁 Режим огня: ' + FMN[fmOf(d.id)]); SFX.click(); persist(); whRefresh();
  }
  window.__fmToggle = fmToggle;

  /* ---------- гранатомёт ---------- */
  function glFire(d) {
    if (WS.reload > 0 || WS.cd > 0) return;
    if (wMag(d.id) <= 0) {
      if (S.guns.ammo[d.id] > 0) reloadWeapon(); else if (G.time - WS.dryT > 0.9) { WS.dryT = G.time; SFX.err(); toast('Нет гранат для гранатомёта!'); }
      return;
    }
    WS.mag[d.id]--; WS.cd = d.rate;
    const man = aimManual(); let ang = P.h, vr = null;
    if (man) { ang = CAM.yaw; vr = aimRay(); } else { const tg = pickTarget(d.range); if (tg) ang = Math.atan2(tg.x - P.x, tg.z - P.z); }
    P.h = ang; P.aimT = 0.35; PGUN.kick = 1;
    const mx = P.x + Math.sin(ang) * 0.8, mz = P.z + Math.cos(ang) * 0.8, r = traceRay(mx, mz, ang, d.range, true, vr), dist = Math.hypot(r.x - mx, r.z - mz);
    for (let i = 0; i < 8; i++) { const t = i / 8 * 0.3; emit(mx + (r.x - mx) * t, 1.35, mz + (r.z - mz) * t, rand(-0.3, 0.3), rand(0, 0.6), rand(-0.3, 0.3), 0.6, 0.4, 1.0, 0.75, 0.75, 0.75, 0.6, false); }
    TRACERS.push({ x1: mx, z1: mz, x2: r.x, z2: r.z, t: 0.18, max: 0.18, c: [1, 0.6, 0.2] });
    SFX.gun('gl', 1); CAM.shake = Math.max(CAM.shake, 0.3);
    if (man) CAM.pitch = clamp(CAM.pitch - 0.04, -0.95, 0.95);
    if (r.kind === 'cop') crimeWanted(2, 'гранатомёт'); else if (r.kind === 'ped') crimeWanted(1, 'гранатомёт');
    setTimeout(() => { if (G.mode === 'play') boom(r.x, r.z, 7, d.dmg, 'gl'); }, Math.round(dist * 10) + 60);
    if (wMag(d.id) <= 0 && S.guns.ammo[d.id] > 0) reloadWeapon();
  }

  const ps1 = playerShoot;
  playerShoot = function () {
    if (P.car && P.car.def.tank) return ps1();
    const d = wDef();
    if (d.melee) return ps1();
    if (d.id === 'gl') return P.car ? ps1() : glFire(d);
    WS.supp = !!att(d.id).supp;
    const list = FMS[d.id], m = list && !P.car ? fmOf(d.id) : 'auto';
    if (m === 'semi' && FM.held) return;
    if (m === 'burst' && FM.burst <= 0) return;
    const b = wMag(d.id); ps1();
    if (wMag(d.id) < b) { if (m === 'semi') FM.held = true; else if (m === 'burst') { FM.burst--; if (FM.burst <= 0) FM.held = true; } }
  };
  const LZG = { x1: 0, y1: 1, z1: 0, x2: 0, y2: 1, z2: 0, t: 0, max: 0.07, w: 0.32, c: [1, 0.05, 0.05] };
  const LZB = window.__LZB = { x1: 0, z1: 0, x2: 0, z2: 0, t: 0, max: 0.07, c: [1, 0.1, 0.1] };
  const uc2 = updateCombat; let lt = 0, lz = 0;
  updateCombat = function (dt, inp) {
    const f = !!inp.fire, edge = f && !FM.prev; FM.prev = f; if (!f) FM.held = false;
    const d0 = wDef(), mode = FMS[d0.id] && !P.car ? fmOf(d0.id) : 'auto';
    if (mode === 'burst' && edge && !FM.held) FM.burst = 3;
    uc2(dt, inp);
    if (FM.burst > 0) {
      if (mode !== 'burst' || wMag(d0.id) <= 0 || P.car || G.inHome || P.hp <= 0) FM.burst = 0;
      else if (!f && WS.cd <= 0 && WS.reload <= 0) playerShoot();
    }
    if ((lt += dt) > 0.5) { lt = 0; const sg = JSON.stringify(S.guns.att || 0); if (sg !== attSig) { attSig = sg; applyAtt(); } }
    // лазерный луч: из дула туда, куда смотрит ствол (и от бедра, и в режиме прицела)
    const d = wDef(), a = att(d.id);
    if (a.laser && isGun(d) && (P.aimT > 0 || aimManual()) && !P.car && !G.inHome && P.hp > 0 && !(WS.zoom > 0.85)) {
      const man = aimManual(), ang = man ? CAM.yaw : P.h, vr = man ? aimRay() : null;
      const gmL = (typeof GUNMODEL !== 'undefined' && GUNMODEL[d.id]) || { m: 0.7 };
      const lat = 0.34 * (man ? 1 - WS.zoom * WS.zoom * (3 - 2 * WS.zoom) : 1), fw = 0.6 + (gmL.m || 0.7) + (att(d.id).supp ? 0.2 : 0);
      const mx = P.x + Math.sin(ang) * fw + Math.cos(ang) * lat, mz = P.z + Math.cos(ang) * fw - Math.sin(ang) * lat;
      const r = traceRay(mx, mz, ang, Math.min(d.range, 60), true, vr);
      LZB.x1 = mx; LZB.z1 = mz; LZB.x2 = r.x; LZB.z2 = r.z;
      LZB.y1 = P.y + 1.36;
      if (vr) LZB.y2 = Math.max(0.05, vr.ey - Math.tan(vr.pd) * ((r.x - vr.ex) * vr.dx + (r.z - vr.ez) * vr.dz)); else LZB.y2 = LZB.y1;
      const pu = 0.8 + 0.2 * Math.sin(performance.now() / 90);
      LZB.w = 0.05; LZB.c = [1, 0.08 + 0.1 * pu, 0.1]; LZB.t = LZB.max;
      LZG.x1 = LZB.x1; LZG.y1 = LZB.y1; LZG.z1 = LZB.z1; LZG.x2 = LZB.x2; LZG.y2 = LZB.y2; LZG.z2 = LZB.z2; LZG.t = LZG.max * 0.28 * pu;
      if (TRACERS.indexOf(LZG) < 0) TRACERS.push(LZG);
      if (TRACERS.indexOf(LZB) < 0) TRACERS.push(LZB);
    }
  };

  /* ---------- колесо оружия ---------- */
  const WH = { open: false, list: [], sel: 0, vx: 0, vy: 0, cx: 0, cy: 0, sticky: false, touch: false, R: 150 };
  const whEl = document.createElement('div'); whEl.id = 'wheel';
  whEl.innerHTML = '<div id="whRing"></div><div id="whCenter"><div id="whIco"></div><div id="whName"></div><div id="whInfo"></div><button id="whFm" class="btn small">🔁 Режим огня</button></div>';
  document.body.appendChild(whEl);
  const whCenter = $('whCenter');
  function whList() { return WEAPONS.filter(w => S.guns.own[w.id]).sort((a, b) => CLO.indexOf(CLS[a.id]) - CLO.indexOf(CLS[b.id]) || WEAPONS.indexOf(a) - WEAPONS.indexOf(b)); }
  function whOpen(touch, sticky) {
    if (WH.open || G.mode !== 'play' || UI.cur !== null || P.hp <= 0) return;
    const l = WH.list = whList(); if (l.length < 2) { toast('Купите оружие в оружейном магазине'); return; }
    WH.open = true; WH.touch = !!touch; WH.sticky = !!sticky; WH.vx = WH.vy = 0;
    const ix = l.findIndex(w => w.id === S.guns.sel); WH.sel = ix < 0 ? 0 : ix;
    const W = innerWidth, H = innerHeight; WH.cx = W / 2; WH.cy = H / 2;
    WH.R = clamp(l.length * 12 + 70, 120, Math.min(W, H) / 2 - 52);
    $('whRing').innerHTML = l.map((w, i) => {
      const a = i / l.length * TAU, x = Math.sin(a) * WH.R, y = -Math.cos(a) * WH.R;
      return '<button class="wh-s" data-wi="' + i + '" style="transform:translate(calc(-50% + ' + x.toFixed(1) + 'px),calc(-50% + ' + y.toFixed(1) + 'px))"><span>' + w.icon + '</span><small>' + w.name + '</small></button>';
    }).join('');
    whEl.classList.toggle('sticky', WH.sticky); whEl.style.display = 'block'; whRefresh(); SFX.click();
  }
  function whClose(apply) {
    if (!WH.open) return; WH.open = false; whEl.style.display = 'none';
    const w = WH.list[WH.sel]; if (apply && w) selectWeapon(w.id);
  }
  function whRefresh() {
    if (!WH.open) return;
    document.querySelectorAll('#whRing .wh-s').forEach((b, i) => b.classList.toggle('on', i === WH.sel));
    const w = WH.list[WH.sel]; if (!w) return;
    $('whIco').textContent = w.icon; $('whName').textContent = w.name;
    const a = att(w.id), eq = S.guns.sel === w.id;
    $('whInfo').textContent = (w.melee ? 'Ближний бой' : 'Патроны ' + (eq ? wMag(w.id) : (WS.mag[w.id] || 0)) + ' / ' + (S.guns.ammo[w.id] || 0)) + (FMS[w.id] ? ' · ' + FMN[fmOf(w.id)] : '') + (a.scope ? ' 🔭' : '') + (a.supp ? ' 🔇' : '') + (a.mag ? ' 📦' : '') + (a.laser ? ' 🔴' : '');
    $('whFm').style.display = FMS[w.id] && eq ? '' : 'none';
  }
  function whPoint(dx, dy) {
    if (Math.hypot(dx, dy) < 34 || !WH.list.length) return;
    const n = WH.list.length, a = (Math.atan2(dx, -dy) + TAU) % TAU, i = Math.round(a / (TAU / n)) % n;
    if (i !== WH.sel) { WH.sel = i; whRefresh(); SFX.tick && SFX.tick(); }
  }
  window.__wheel = { open: () => whOpen(false, false), close: ap => whClose(ap), stick: (x, y) => { if (Math.hypot(x, y) > 0.4) whPoint(x * 100, y * 100); }, isOpen: () => WH.open, fm: fmToggle };
  window.addEventListener('keydown', e => {
    if (e.code !== 'Tab') return;
    e.preventDefault(); if (e.repeat || (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName || ''))) return; whOpen(false, false);
  });
  window.addEventListener('keyup', e => { if (e.code === 'Tab') { e.preventDefault(); whClose(true); } });
  window.addEventListener('keydown', e => { if (e.code === 'KeyK' && !e.repeat && G.mode === 'play' && UI.cur === null && !(e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName || ''))) fmToggle(); });
  window.addEventListener('mousemove', e => {
    if (!WH.open) return; e.stopImmediatePropagation();
    if (document.pointerLockElement) {
      WH.vx += e.movementX; WH.vy += e.movementY; const h = Math.hypot(WH.vx, WH.vy); if (h > 140) { WH.vx *= 140 / h; WH.vy *= 140 / h; } whPoint(WH.vx, WH.vy);
    } else whPoint(e.clientX - WH.cx, e.clientY - WH.cy);
  }, true);
  window.addEventListener('pointermove', e => { if (WH.open && WH.touch && e.pointerType !== 'mouse') whPoint(e.clientX - WH.cx, e.clientY - WH.cy); });
  window.addEventListener('pointerup', e => { if (WH.open && WH.touch && !WH.sticky) whClose(true); });
  whEl.addEventListener('pointerdown', e => {
    const s = e.target.closest('.wh-s');
    if (s) { WH.sel = +s.dataset.wi; whClose(true); e.preventDefault(); return; }
    if (e.target.id === 'whFm') { fmToggle(); e.preventDefault(); return; }
    if (WH.sticky) whClose(false);
  });
  document.querySelectorAll('[data-tap="weapon"]').forEach(b => b.addEventListener('pointerdown', e => {
    e.stopImmediatePropagation(); e.preventDefault(); auInit();
    const tm = setTimeout(() => { done = true; whOpen(true, false); }, 320); let done = false;
    const up = () => { clearTimeout(tm); window.removeEventListener('pointerup', up, true); window.removeEventListener('pointercancel', up, true); if (!done) cycleWeapon(); };
    window.addEventListener('pointerup', up, true); window.addEventListener('pointercancel', up, true);
  }, true));
  const ab = $('ammoBox'); if (ab) ab.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); auInit(); WH.open ? whClose(false) : whOpen(true, true); });

  /* ---------- оружейный магазин ---------- */
  const GS = { sel: '' };
  const bar = (lab, v, txt) => '<div class="gs-b"><span>' + lab + '</span><i><u style="width:' + Math.round(clamp(v, 0.03, 1) * 100) + '%"></u></i><b>' + txt + '</b></div>';
  function tile(w) {
    const own = !!S.guns.own[w.id], eq = S.guns.sel === w.id;
    return '<button class="gs-t' + (GS.sel === w.id ? ' sel' : '') + (own ? ' own' : '') + '" data-gsel="' + w.id + '"><span class="gs-i">' + w.icon + '</span><span class="gs-n">' + w.name + '</span><span class="gs-p">' + (eq ? 'В руках' : own ? 'Есть' : fmtMoney(w.price)) + '</span></button>';
  }
  function detail(w) {
    const own = !!S.guns.own[w.id], eq = S.guns.sel === w.id, gun = isGun(w), a = att(w.id);
    let h = '<div class="gs-hd"><span class="gs-big">' + w.icon + '</span><div><h3>' + w.name + '</h3><div class="tags"><span class="tag">' + CLN[CLS[w.id]] + '</span>' + (own ? '<span class="tag gold">' + (eq ? 'В руках' : 'Куплено') + '</span>' : '') + '</div></div></div>';
    h += '<p class="gs-d">' + (DESC[w.id] || '') + '</p>';
    const per = (w.dmg) * (w.pellets || 1), shots = 1 / w.rate;
    h += bar('Урон', gun ? per / 130 : w.dmg / 60, w.pellets > 1 ? w.dmg + '×' + w.pellets : String(w.dmg));
    h += bar('Темп', gun ? shots / 12 : shots / 4, shots.toFixed(1) + '/с');
    if (gun) h += bar('Точность', 1 - clamp(w.spread / 0.15, 0, 1), w.spread <= 0.01 ? 'отличная' : w.spread <= 0.03 ? 'хорошая' : w.spread <= 0.07 ? 'средняя' : 'низкая');
    h += bar('Дальность', gun ? w.range / 260 : w.range / 3.5, gun ? w.range + ' м' : w.range.toFixed(1) + ' м');
    if (gun) h += bar('Магазин', w.mag / 30, String(w.mag));
    h += '<div class="gs-act">';
    if (!own) h += '<button class="btn primary" data-gbuy="' + w.id + '"' + (S.money < w.price ? ' disabled' : '') + '>Купить · ' + fmtMoney(w.price) + '</button>';
    else {
      if (!eq) h += '<button class="btn primary" data-gequip="' + w.id + '">В руки</button>';
      if (gun) h += '<button class="btn" data-gammo="' + w.id + '"' + (S.money < w.packPrice ? ' disabled' : '') + '>+' + w.ammoPack + ' патр. · ' + fmtMoney(w.packPrice) + '</button><span class="gs-am">Патронов: ' + ((S.guns.ammo[w.id] || 0) + (WS.mag[w.id] || 0)) + '</span>';
    }
    h += '</div>';
    if (own && FMS[w.id]) h += '<div class="gs-d">Режим огня: <b>' + FMN[fmOf(w.id)] + '</b> — клавиша K, колесо оружия или Home на геймпаде.</div>';
    if (gun && w.id !== 'gl') {
      h += '<h4 class="gs-h">Обвесы</h4><div class="gs-ag">' + ATT.map(A => {
        const ok = attOk(w, A.id), has = !!(S.guns.attOwn && S.guns.attOwn[w.id + ':' + A.id]), on = !!a[A.id];
        let btn;
        if (!ok) btn = '<button class="btn small" disabled>' + ((A.id === 'scope' || A.id === 'laser') ? 'Встроен' : '—') + '</button>';
        else if (!own) btn = '<button class="btn small" disabled>Сначала купите оружие</button>';
        else if (has) btn = '<button class="btn small' + (on ? ' primary' : '') + '" data-att="' + w.id + '|' + A.id + '">' + (on ? 'Снять' : 'Установить') + '</button>';
        else btn = '<button class="btn small" data-att="' + w.id + '|' + A.id + '"' + (S.money < A.price ? ' disabled' : '') + '>' + fmtMoney(A.price) + '</button>';
        return '<div class="gs-a' + (on ? ' on' : '') + (ok ? '' : ' off') + '"><span class="gs-ai">' + A.ico + '</span><div><b>' + A.name + '</b><small>' + A.desc + '</small></div>' + btn + '</div>';
      }).join('') + '</div>';
    }
    return h;
  }
  renderGunshop = function () {
    const el = $('gunList'); if (!el) return;
    if (!GS.sel || !WBY[GS.sel] || GS.sel === 'fist') GS.sel = S.guns.sel && S.guns.sel !== 'fist' ? S.guns.sel : 'pistol';
    el.classList.add('gs');
    const ws = WEAPONS.filter(w => w.id !== 'fist'); let list = '';
    for (const c of CLO) { const g = ws.filter(w => CLS[w.id] === c); if (g.length) list += '<div class="gs-h">' + CLN[c] + '</div>' + g.map(tile).join(''); }
    const lp = el.querySelector('.gs-list'), dp = el.querySelector('.gs-det'), ls = lp ? lp.scrollTop : 0, ds = dp ? dp.scrollTop : 0;
    el.innerHTML = '<div class="gs-list">' + list + '</div><div class="gs-det">' + detail(WBY[GS.sel]) + '<h4 class="gs-h">Снаряжение</h4>' + expCards() + '</div>';
    el.querySelector('.gs-list').scrollTop = ls; el.querySelector('.gs-det').scrollTop = ds;
  };
  $('gunList').addEventListener('click', e => {
    const t = e.target.closest('[data-gsel]'); if (t) { GS.sel = t.dataset.gsel; SFX.click(); renderGunshop(); return; }
    const a = e.target.closest('[data-att]'); if (a) { const p = a.dataset.att.split('|'); attAct(p[0], p[1]); }
  });

  /* ---------- стиль меню и экранов ---------- */
  const st = document.createElement('style');
  st.textContent = `
.screen.show .panel{animation:panelIn .3s cubic-bezier(.2,.9,.3,1.15) both}@keyframes panelIn{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
.panel{box-shadow:0 18px 60px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,255,255,.08)}
.ps-head{padding-bottom:10px;border-bottom:1px solid var(--line)}.ps-head h2{letter-spacing:.3px}
.card:hover{border-color:rgba(255,255,255,.28);background:rgba(255,255,255,.08)}
.btn:focus-visible,button:focus-visible{outline:3px solid var(--acc);outline-offset:2px}
.btn.primary:active{transform:scale(.96)}
body.touch .btn{min-height:46px}body.touch .btn.small{min-height:40px}
.scroll::-webkit-scrollbar-thumb{background:linear-gradient(var(--acc),var(--acc2));opacity:.6}
.panel input[type=checkbox]{appearance:none;-webkit-appearance:none;width:48px;height:27px;border-radius:27px;background:rgba(255,255,255,.18);position:relative;cursor:pointer;transition:background .2s;flex:none;border:0}
.panel input[type=checkbox]::after{content:"";position:absolute;top:3px;left:3px;width:21px;height:21px;border-radius:50%;background:#fff;transition:transform .2s;box-shadow:0 2px 6px rgba(0,0,0,.4)}
.panel input[type=checkbox]:checked{background:var(--acc)}.panel input[type=checkbox]:checked::after{transform:translateX(21px)}
.panel input[type=range]{accent-color:var(--acc);height:24px}
.panel select{background:rgba(255,255,255,.08);border:1px solid var(--line);border-radius:10px;color:var(--txt);padding:8px 10px}
#menu .btn{padding:16px 14px;font-size:17px;font-weight:700;border-radius:14px}
#menu .btn.primary{font-size:19px}
#ammoBox{pointer-events:auto;cursor:pointer;padding:6px 12px;font-size:14px;border:1px solid rgba(255,255,255,.14)}
#wheel{position:fixed;inset:0;display:none;z-index:45;background:radial-gradient(circle at center,rgba(5,8,16,.2) 0,rgba(5,8,16,.72) 70%);backdrop-filter:blur(2px);touch-action:none}
#whRing{position:absolute;left:50%;top:50%;width:0;height:0}
.wh-s{position:absolute;left:0;top:0;width:82px;min-height:66px;padding:6px 4px;border:1px solid var(--line);border-radius:16px;background:rgba(16,22,38,.9);color:var(--txt);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;transition:background .12s,border-color .12s,box-shadow .12s}
.wh-s span{font-size:26px;line-height:1}.wh-s small{font-size:10.5px;line-height:1.1;text-align:center;color:var(--mut);max-width:76px}
.wh-s.on{background:linear-gradient(180deg,#ffc233,#ff8c1a);color:#1a0f00;border-color:transparent;box-shadow:0 0 28px rgba(255,160,40,.65);z-index:2}.wh-s.on small{color:#3a2400}
#whCenter{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(210px,40vmin);text-align:center;pointer-events:none}
#whCenter button{pointer-events:auto;margin-top:6px}
#whIco{font-size:44px;line-height:1.1}#whName{font-weight:800;font-size:17px}#whInfo{color:var(--mut);font-size:13px;margin-top:3px}
.gs{display:grid !important;grid-template-columns:minmax(210px,290px) 1fr;gap:14px;overflow:hidden !important;flex-direction:row}
#gunshop .panel{width:min(96vw,980px);height:min(92vh,640px)}
.gs-list,.gs-det{overflow-y:auto;min-height:0;padding-right:4px;touch-action:pan-y}
.gs-h{margin:10px 0 6px;font-size:12px;letter-spacing:.8px;text-transform:uppercase;color:var(--mut);font-weight:700}.gs-list .gs-h:first-child{margin-top:0}
.gs-t{display:flex;align-items:center;gap:10px;width:100%;margin:0 0 6px;padding:9px 12px;border:1px solid var(--line);border-radius:12px;background:rgba(255,255,255,.05);text-align:left;transition:background .15s,border-color .15s}
.gs-t:hover{background:rgba(255,255,255,.1)}.gs-t.sel{border-color:var(--acc);background:rgba(255,183,3,.12)}
.gs-i{font-size:24px;width:30px;text-align:center}.gs-n{flex:1;font-weight:700;font-size:14px}.gs-p{font-size:12px;color:var(--gold);font-weight:700}.gs-t.own .gs-p{color:#5ee08a}
.gs-hd{display:flex;align-items:center;gap:14px}.gs-hd h3{margin:0 0 6px;font-size:22px}.gs-big{font-size:54px;line-height:1}
.gs-d{color:var(--mut);font-size:13.5px;margin:8px 0}
.gs-b{display:grid;grid-template-columns:84px 1fr 78px;align-items:center;gap:10px;margin:7px 0;font-size:13px}
.gs-b i{display:block;height:8px;border-radius:8px;background:rgba(255,255,255,.1);overflow:hidden}.gs-b u{display:block;height:100%;border-radius:8px;background:linear-gradient(90deg,var(--cyan),var(--acc))}.gs-b b{text-align:right;font-size:12.5px}
.gs-act{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:14px 0 4px}.gs-am{color:var(--mut);font-size:13px}
.gs-ag{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:8px}
.gs-a{display:flex;flex-wrap:wrap;align-items:center;gap:8px 10px;padding:10px;border:1px solid var(--line);border-radius:12px;background:rgba(255,255,255,.04)}.gs-a.on{border-color:var(--acc);background:rgba(255,183,3,.08)}.gs-a.off{opacity:.45}
.gs-a div{flex:1;min-width:120px}.gs-a>.btn{flex:1 1 100%}.gs-a small{display:block;color:var(--mut);font-size:11.5px;margin-top:2px}.gs-ai{font-size:24px}
@media (max-width:720px){.gs{grid-template-columns:1fr;grid-template-rows:auto 1fr}.gs-list{display:flex;gap:6px;overflow-x:auto;overflow-y:hidden;padding-bottom:6px}.gs-list .gs-h{display:none}.gs-t{width:auto;flex:none;margin:0;flex-direction:column;gap:2px;min-width:92px;text-align:center}.gs-n{font-size:12px}#gunshop .panel{height:94vh}}`;
  document.head.appendChild(st);
  applyAtt();
}


