/* ===================== 14. ВВОД ===================== */
const keys = {};
const touch = { jx: 0, jy: 0, left: 0, right: 0, gas: 0, brake: 0, hand: 0, nitro: 0, run: 0, fire: 0, jump: 0 };
const ZERO_INP = { x: 0, y: 0, steer: 0, gas: 0, brake: 0, hand: true, nitro: false, run: false, fire: false };
function readInput() {
  const k = keys;
  let ix = (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0) + touch.jx;
  let iy = (k.KeyW || k.ArrowUp ? 1 : 0) - (k.KeyS || k.ArrowDown ? 1 : 0) + touch.jy;
  ix = clamp(ix, -1, 1); iy = clamp(iy, -1, 1);
  const steer = clamp(ix + touch.right - touch.left, -1, 1);
  return {
    x: ix, y: iy, steer,
    gas: Math.max(iy > 0 ? iy : 0, touch.gas), brake: Math.max(iy < 0 ? -iy : 0, touch.brake),
    hand: !!(k.Space || touch.hand), nitro: !!(k.ShiftLeft || k.ShiftRight || touch.nitro),
    run: !!(k.ShiftLeft || k.ShiftRight || touch.run),
    fire: !!((k.Space && !P.car) || k.KeyG || touch.fire || WS.mf),
    jump: !!(k.KeyX || touch.jump)
  };
}

