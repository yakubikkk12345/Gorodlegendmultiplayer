/* ===================== v27: МУЛЬТИПЛЕЕР (общий город, до 4 игроков) ===================== */
const MP = { ws: null, state: 'off', id: 0, room: '', col: '#fff', peers: new Map(), sendT: 0, pingT: 0, ping: 0, chatOpen: false, pvp: true, err: '', cfg: { name: '', url: '', link: '' }, pend: '' };
const MP_KEY = 'gl_mp_cfg';
function mpLoadCfg() {
  try { const j = JSON.parse(localStorage.getItem(MP_KEY) || '{}'); if (j && typeof j === 'object') Object.assign(MP.cfg, j); } catch (e) { }
  if (MP.cfg.pvp === false) MP.pvp = false;
  if (!MP.cfg.name) MP.cfg.name = (TG && TG.initDataUnsafe && TG.initDataUnsafe.user && (TG.initDataUnsafe.user.first_name || TG.initDataUnsafe.user.username)) || 'Игрок' + (100 + Math.floor(Math.random() * 900));
  if (!MP.cfg.url) MP.cfg.url = location.protocol === 'https:' ? '' : 'ws://localhost:8080';
  try {
    const q = new URLSearchParams(location.search);
    if (q.get('srv')) MP.cfg.url = q.get('srv');
    const r = q.get('room') || (TG && TG.initDataUnsafe && TG.initDataUnsafe.start_param) || '';
    if (r) MP.pend = String(r).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
  } catch (e) { }
}
function mpSaveCfg() { try { localStorage.setItem(MP_KEY, JSON.stringify(MP.cfg)); } catch (e) { } }
function mpEsc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function mpConnected() { return MP.state === 'on'; }
function mpConnect(create, tryN) {
  tryN = tryN || 0; MP.gen = (tryN ? MP.gen : (MP.gen || 0) + 1);
  if (MP.ws) mpDisconnect(true);
  const name = ($('mpName').value || '').trim().slice(0, 16) || 'Игрок';
  let url = ($('mpUrl').value || '').trim();
  const room = ($('mpRoom').value || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
  const link = ($('mpLink').value || '').trim();
  if (!url && location.protocol.startsWith('http') && location.hostname !== 'localhost') url = location.host;
  if (!url) { mpStatus('Укажите адрес сервера (wss://…)', true); return; }
  if (!/^wss?:\/\//i.test(url)) url = (location.protocol === 'http:' ? 'ws://' : 'wss://') + url.replace(/^https?:\/\//i, '');
  if (location.protocol === 'https:' && /^ws:\/\//i.test(url) && !/^ws:\/\/(localhost|127\.)/i.test(url)) { mpStatus('Для https-страницы нужен wss:// адрес', true); return; }
  if (!create && !room) { mpStatus('Введите код комнаты или нажмите «Создать»', true); return; }
  MP.cfg = { name, url, link, pvp: MP.pvp }; mpSaveCfg();
  let ws;
  try { ws = new WebSocket(url); } catch (e) { mpStatus('Неверный адрес сервера', true); return; }
  MP.ws = ws; MP.state = 'connecting'; MP.err = ''; const gen = MP.gen; mpStatus(tryN ? 'Сервер просыпается, пробуем снова… (' + tryN + '/5)' : 'Подключаемся…');
  ws.onopen = () => { ws.send(JSON.stringify({ t: 'join', name, room, create: !!create, uid: (window.__v40 && window.__v40.LB.uid) || '' })); };
  ws.onmessage = ev => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } mpMsg(m); };
  ws.onerror = () => { if (MP.ws === ws && MP.state === 'connecting') MP.err = 'Не удалось подключиться к серверу'; };
  ws.onclose = () => {
    if (MP.ws !== ws) return;
    const was = MP.state === 'on';
    if (!was && !MP.err && tryN < 5 && gen === MP.gen) { MP.ws = null; MP.state = 'off'; mpStatus('Сервер просыпается (бесплатный Render спит ~1 мин)… попытка ' + (tryN + 1) + '/5'); setTimeout(() => { if (gen === MP.gen && !MP.ws && !mpConnected()) mpConnect(create, tryN + 1); }, 8000); return; }
    mpReset();
    if (was) toast('🌐 Соединение потеряно');
    mpStatus(MP.err || (was ? 'Соединение потеряно' : 'Не удалось подключиться'), true);
  };
}
function mpReset() {
  MP.ws = null; MP.state = 'off'; MP.id = 0; MP.room = ''; v30Abort();
  for (const p of MP.peers.values()) if (p.lbl) p.lbl.remove();
  MP.peers.clear(); mpChatUI(); mpRender();
}
function mpDisconnect(silent) {
  MP.gen = (MP.gen || 0) + 1;
  const ws = MP.ws; MP.ws = null;
  if (ws) { try { ws.close(); } catch (e) { } }
  mpReset(); if (!silent) { mpStatus('Отключено'); toast('🌐 Вы вышли из комнаты'); }
}
function mpSend(o) { if (MP.ws && MP.ws.readyState === 1) MP.ws.send(JSON.stringify(o)); }
function mpAddPeer(id, name, col, s) {
  const p = { id, name, col, tx: 0, ty: 0, tz: 0, th: 0, x: 0, y: 0, z: 0, h: 0, ph: 0, am: 0, car: null, cc: null, st: 0, sp: 0, pi: 0, ro: 0, n: 0, b: 0, v: 0, got: false, fake: null, look: Object.assign({}, PLAYER_LOOK, { shirt: hexRGB(col) }), lbl: null, wr: 0 };
  MP.peers.set(id, p); if (s) mpApply(p, s); return p;
}
function mpApply(p, s) {
  p.hp = s.hp; p.pv = s.pv; p.wp = s.wp; p.ar = s.ar; p.sh = s.sh;
  p.tx = s.x; p.ty = s.y; p.tz = s.z; p.th = s.h; p.am = s.am; p.st = s.st; p.sp = s.sp; p.pi = s.pi; p.ro = s.ro; p.n = s.n; p.b = s.b; p.v = s.v; p.car = s.car; p.cc = s.cc; p.tph = s.ph;
  if (!p.got) { p.got = true; p.x = p.tx; p.y = p.ty; p.z = p.tz; p.h = p.th; p.ph = s.ph; }
}
function mpChatLine(name, col, text, sys) {
  const box = $('mpLog'); if (!box) return;
  const d = document.createElement('div'); d.className = 'mpl' + (sys ? ' sys' : '');
  d.innerHTML = sys ? mpEsc(text) : '<b style="color:' + mpEsc(col || '#fff') + '">' + mpEsc(name) + ':</b> ' + mpEsc(text);
  box.appendChild(d);
  while (box.children.length > 7) box.removeChild(box.firstChild);
  setTimeout(() => { d.classList.add('out'); setTimeout(() => d.remove(), 600); }, sys ? 6000 : 12000);
}
function mpMsg(m) {
  if (v30Msg(m)) return;
  if (m.t === 'welcome') {
    MP.state = 'on'; MP.id = m.id; MP.room = m.room; MP.col = m.col; MP.err = '';
    (m.players || []).forEach(p => mpAddPeer(p.id, p.name, p.col, p.s));
    $('mpRoom').value = m.room;
    mpStatus('Вы в комнате ' + m.room); mpChatUI(); mpRender();
    toast('🌐 Комната ' + m.room + ' · игроков: ' + (MP.peers.size + 1));
    mpChatLine('', '', 'Вы в комнате ' + m.room + '. Нажмите T, чтобы написать в чат.', true);
  } else if (m.t === 'err') {
    MP.err = m.msg || 'Ошибка'; mpStatus(MP.err, true); toast('🌐 ' + MP.err);
    const ws = MP.ws; MP.ws = null; MP.state = 'off'; try { ws && ws.close(); } catch (e) { }
  } else if (m.t === 'join') {
    mpAddPeer(m.id, m.name, m.col, null); toast('🌐 ' + m.name + ' присоединился'); mpChatLine('', '', m.name + ' в городе', true); mpRender();
  } else if (m.t === 'leave') {
    const p = MP.peers.get(m.id); if (p && p.lbl) p.lbl.remove(); MP.peers.delete(m.id);
    toast('🌐 ' + (m.name || 'Игрок') + ' вышел'); mpChatLine('', '', (m.name || 'Игрок') + ' покинул город', true); mpRender();
  } else if (m.t === 's') {
    const p = MP.peers.get(m.id); if (p && m.s) mpApply(p, m.s);
  } else if (m.t === 'chat') {
    mpChatLine(m.name, m.col, m.text, false);
  } else if (m.t === 'hurt') {
    if (!MP.pvp || G.mode !== 'play' || G.inHome || G.paused || P.hp <= 0) return;
    MP.lastBy = m.from;
    hurtPlayer(Math.min(45, +m.dmg || 0) * (P.car ? 0.5 : 1), 'pvp');
  } else if (m.t === 'kill') {
    mpChatLine('', '', m.kname ? '☠ ' + m.kname + ' убил ' + m.vname : '☠ ' + m.vname + ' погиб', true);
    const v = MP.peers.get(m.victim);
    if (v && v.got) for (let k = 0; k < 8; k++) emit(v.x, 0.6 + Math.random(), v.z, rand(-2, 2), rand(0.5, 2.5), rand(-2, 2), 0.6, 0.3, 1.0, 0.8, 0.25, 0.25, 0.7, false);
    if (m.killer && m.killer === MP.id) { addMoney(200); toast('☠ Вы убили ' + m.vname + ' +$200'); }
  } else if (m.t === 'pong') {
    MP.ping = Math.round(performance.now() - (+m.ts || 0)); mpRender();
  }
}
function mpStatus(t, bad) { const e = $('mpStatus'); if (e) { e.textContent = t; e.style.color = bad ? '#ff8a8a' : '#9fe7ff'; } }
function mpRender() {
  const on = mpConnected();
  const l = $('mpList'); if (!l) return;
  if (on) {
    l.innerHTML = '<div class="mprow"><span class="mpdot" style="background:' + mpEsc(MP.col) + '"></span><b>' + mpEsc(MP.cfg.name) + '</b> (вы)</div>' +
      [...MP.peers.values()].map(p => '<div class="mprow"><span class="mpdot" style="background:' + mpEsc(p.col) + '"></span>' + mpEsc(p.name) + '</div>').join('') +
      '<div class="mprow" style="color:var(--mut)">Игроков: ' + (MP.peers.size + 1) + '/4 · пинг ' + (MP.ping || '—') + ' мс</div>';
  } else l.innerHTML = '<div class="mprow" style="color:var(--mut)">Вы не в комнате</div>';
  $('mpOff').style.display = on ? 'none' : 'block'; $('mpOn').style.display = on ? 'block' : 'none';
  if (on) v30Fill();
}
function mpInviteUrl() {
  const code = MP.room, link = (MP.cfg.link || '').trim();
  if (link) return link + (link.indexOf('?') >= 0 ? '&' : '?') + 'startapp=' + code;
  const q = new URLSearchParams(); q.set('room', code);
  if (MP.cfg.url) q.set('srv', MP.cfg.url);
  return location.origin + location.pathname + '?' + q.toString();
}
function mpHit(p, dmg) {
  if (!mpConnected() || !MP.pvp || !p.pv || !mpFoe(p)) return;
  mpSend({ t: 'hit', id: p.id, dmg: Math.round(dmg) });
  SFX.hit(); sparks(p.x, 1.2, p.z, [1, 0.3, 0.3]);
}
function mpDied() { if (mpConnected()) mpSend({ t: 'died', by: MP.lastBy || 0 }); MP.lastBy = 0; }
function mpInvite() {
  if (!mpConnected()) return;
  const url = mpInviteUrl(), text = '🌐 Го в «Город легенд»! Код комнаты: ' + MP.room;
  if (TG && TG.openTelegramLink) { try { TG.openTelegramLink('https://t.me/share/url?url=' + encodeURIComponent(url) + '&text=' + encodeURIComponent(text)); return; } catch (e) { } }
  if (navigator.share) { navigator.share({ title: 'Город легенд', text, url }).catch(() => { }); return; }
  try { navigator.clipboard.writeText(text + '\n' + url); toast('📋 Приглашение скопировано'); } catch (e) { toast('Код комнаты: ' + MP.room); }
}
function mpChatUI() { const b = $('mpChatBtn'); if (b) b.style.display = mpConnected() && G.mode === 'play' ? 'block' : 'none'; if (!mpConnected()) mpChatClose(); }
function mpChatOpen() {
  if (!mpConnected() || G.mode !== 'play' || UI.cur !== null) return;
  MP.chatOpen = true; for (const k in keys) keys[k] = false;
  const w = $('mpIn'); w.style.display = 'block'; w.value = ''; setTimeout(() => w.focus(), 30);
}
function mpChatClose() { MP.chatOpen = false; const w = $('mpIn'); if (w) { w.style.display = 'none'; w.blur(); } }
function mpInit() {
  mpLoadCfg();
  const w = $('mpIn');
  w.addEventListener('keydown', e => {
    e.stopPropagation();
    if (e.key === 'Enter') { const t = w.value.trim(); if (t) mpSend({ t: 'chat', text: t }); mpChatClose(); }
    else if (e.key === 'Escape') mpChatClose();
  });
  w.addEventListener('blur', () => { setTimeout(() => { if (document.activeElement !== w) mpChatClose(); }, 100); });
  window.addEventListener('keydown', e => {
    if (e.code === 'KeyT' && !e.repeat && !MP.chatOpen && e.target && !/INPUT|SELECT|TEXTAREA/.test(e.target.tagName) && mpConnected()) { e.preventDefault(); mpChatOpen(); }
  });
  $('mpChatBtn').addEventListener('pointerdown', e => { e.preventDefault(); mpChatOpen(); });
  $('mpPvp').addEventListener('change', () => { MP.pvp = $('mpPvp').checked; MP.cfg.pvp = MP.pvp; mpSaveCfg(); if (mpConnected()) toast(MP.pvp ? '⚔ PvP включён' : '🕊 PvP выключен'); });
  if (MP.pend) setTimeout(() => toast('🌐 Приглашение в комнату ' + MP.pend + ' — откройте «Мультиплеер»'), 2500);
}
function mpFillScreen() {
  $('mpPvp').checked = MP.pvp; $('mpName').value = MP.cfg.name; $('mpUrl').value = MP.cfg.url; $('mpLink').value = MP.cfg.link || '';
  if (!mpConnected()) { if (MP.pend && !$('mpRoom').value) $('mpRoom').value = MP.pend; }
  mpRender();
}
const MPV = { car: null, cache: {} };
function mpFake(p) {
  const def = CAR_BY_ID[p.car]; if (!def) return null;
  const col = p.cc || def.color, key = def.id + col;
  let f = p.fake;
  if (!f || f.key !== key) {
    f = p.fake = { key, def, col, meshes: carMeshes(def, col), x: 0, y: 0, z: 0, h: 0, pitch: 0, lean: 0, roll: 0, steer: 0, brake: false, W: def.shape.W, L: def.shape.L, nitroOn: false, dmg: 0, driver: 'remote' };
  }
  return f;
}
function mpTick(dt) {
  if (!MP.ws) return;
  if (MP.state === 'on') {
    const k = Math.min(1, dt * 11);
    for (const p of MP.peers.values()) {
      if (!p.got) continue;
      p.x += (p.tx - p.x) * k; p.y += (p.ty - p.y) * k; p.z += (p.tz - p.z) * k;
      let dh = p.th - p.h; dh = Math.atan2(Math.sin(dh), Math.cos(dh)); p.h += dh * k;
      if (p.car) { p.wr += p.sp * dt; } else { p.ph += (p.am > 0.05 ? Math.max(4, p.am * 8) : 0) * dt; }
    }
    MP.sendT -= dt;
    if (MP.sendT <= 0) {
      MP.sendT = 1 / 15;
      const c = P.car, m = { t: 's', v: (G.mode === 'play' && !G.inHome) ? 1 : 0, x: +P.x.toFixed(2), y: +P.y.toFixed(2), z: +P.z.toFixed(2), h: +P.h.toFixed(3), ph: +P.phase.toFixed(2), am: +(P.amp || 0).toFixed(2), hp: Math.max(0, Math.round(P.hp)), pv: MP.pvp ? 1 : 0, wp: (!P.car && S.guns.sel) || '', ar: +(!P.car && aimManual() ? aimUp() : 0).toFixed(2), sh: (P.aimT > 0 || (!P.car && aimManual())) ? 1 : 0 };
      if (!P.car && aimManual()) m.h = +CAM.yaw.toFixed(3);
      if (c) { m.car = c.def.id; m.cc = c.col; m.x = +c.x.toFixed(2); m.y = +c.y.toFixed(2); m.z = +c.z.toFixed(2); m.h = +c.h.toFixed(3); m.st = +(c.steer || 0).toFixed(2); m.sp = +(c.vf || 0).toFixed(1); m.pi = +(c.pitch || 0).toFixed(3); m.ro = +(c.lean || 0).toFixed(3); m.n = c.nitroOn ? 1 : 0; m.b = c.brake ? 1 : 0; }
      if (G.mode === 'play') mpSend(m);
    }
    MP.pingT -= dt; if (MP.pingT <= 0) { MP.pingT = 4; mpSend({ t: 'ping', ts: performance.now() }); }
  }
}
function mpVisible(p) { return MP.state === 'on' && p.got && p.v && G.mode === 'play' && !G.inHome; }
function mpDraw() {
  if (MP.state !== 'on' || G.mode !== 'play' || G.inHome) return;
  for (const p of MP.peers.values()) {
    if (!mpVisible(p)) continue;
    const d = Math.hypot(p.x - CAM.x, p.z - CAM.z); if (d > 300) continue;
    if (p.car) {
      const f = mpFake(p); if (!f) continue;
      f.x = p.x; f.y = p.y; f.z = p.z; f.h = p.h; f.steer = p.st; f.pitch = p.pi; f.lean = p.ro; f.roll = p.wr / (f.def.shape.wr || 0.35); f.brake = !!p.b; f.nitroOn = !!p.n;
      drawCar(f, d);
    } else {
      let gun = null;
      if (p.wp && GUNMODEL[p.wp]) { gun = p.gun || (p.gun = { id: '', aim: 0, kick: 0, reload: 0, ap: 0 }); gun.id = p.wp; gun.aim += ((p.sh ? 1 : 0.25) - gun.aim) * 0.2; gun.ap = p.ar || 0; }
      drawHuman(p.x, p.y, p.z, p.h, p.ph, p.am, p.look, d > 38, 1, gun);
    }
  }
}
function mpShadow() {
  if (MP.state !== 'on' || G.mode !== 'play' || G.inHome) return;
  for (const p of MP.peers.values()) {
    if (!mpVisible(p)) continue;
    if (p.car) { const f = p.fake; if (!f || f.def.heli && p.y - terrainY(p.x, p.z) > 3) continue; mTRS(DM, p.x, (f.def.heli ? terrainY(p.x, p.z) : p.y) + 0.04, p.z, p.h, 0, 0, f.W * 0.75, 1, f.L * 0.62); }
    else mTRS(DM, p.x, p.y + 0.04, p.z, 0, 0, 0, 0.55, 1, 0.55);
    drawMesh(M_DISC, DM, 1, 1, 1, 1, 1, false);
  }
}
function mpDots(dot, R) {
  if (MP.state !== 'on') return;
  for (const p of MP.peers.values()) { if (!p.got || !p.v) continue; dot(p.x, p.z, '#000', R + 2); dot(p.x, p.z, ARENA.on && ARENA.teams[p.id] !== undefined ? TEAM_COL[ARENA.teams[p.id]] : p.col, R); }
}
function mpHud() {
  const layer = $('lblObj').parentNode;
  for (const p of MP.peers.values()) {
    const show = mpVisible(p);
    if (!show) { if (p.lbl) p.lbl.style.display = 'none'; continue; }
    const pr = project(p.x, p.y + (p.car ? 3.2 : 2.2) + (p.car && p.car && CAR_BY_ID[p.car] && CAR_BY_ID[p.car].heli ? 1.5 : 0), p.z);
    if (!p.lbl) { p.lbl = document.createElement('div'); p.lbl.className = 'wlabel mpn'; p.lbl.style.borderColor = p.col; p.lbl.style.color = p.col; layer.appendChild(p.lbl); }
    const lt = p.name + (p.hp != null ? '  ❤' + p.hp : '') + (p.pv ? ' ⚔' : '');
    if (p.lblT !== lt) { p.lblT = lt; p.lbl.textContent = lt; }
    const tc = ARENA.on && ARENA.teams[p.id] !== undefined ? TEAM_COL[ARENA.teams[p.id]] : p.col;
    if (p.lblC !== tc) { p.lblC = tc; p.lbl.style.color = tc; p.lbl.style.borderColor = tc; }
    const dd = Math.hypot(p.x - P.x, p.z - P.z);
    if (pr && dd < 160 && pr.x > 0 && pr.x < innerWidth && pr.y > 40 && pr.y < innerHeight) { p.lbl.style.display = 'block'; p.lbl.style.left = pr.x + 'px'; p.lbl.style.top = pr.y + 'px'; } else p.lbl.style.display = 'none';
  }
}

