/* ===================== v31: порт, заказы, контрабанда ===================== */
const PJ = { on: false, offers: null, offT: 0, tx: 0, tz: 0, t: 0, reward: 0, kind: '', name: '' };
const PORT = { get x() { const b = BIZ_BY.port; return bc(b.blk[0]); }, get z() { const b = BIZ_BY.port; return bc(b.blk[1]); } };
const portOwn = () => !!(S.biz.port && S.biz.port.own);
function portGreet() {
  if (PJ.on) return 'Груз в пути, времени в обрез: ' + Math.max(0, Math.ceil(PJ.t)) + ' с. Не подведи!';
  if (!portOwn()) return 'Порт «Гавань» продаётся. Но работа есть для каждого: бери заказ, вози грузы — платим на месте. Хозяевам порта — на 50% больше.';
  const a = Math.floor((S.biz.port.acc || 0));
  return 'Хозяин на причале! ' + (a >= 1 ? 'В кассе уже ' + fmtMoney(a) + '. ' : '') + 'Есть заказы — для хозяина оплата выше на 50%.';
}
function portMakeOffers() {
  const mult = portOwn() ? 1.5 : 1, R = Math.random;
  const dest = () => { let x, z, k = 0; do { x = nodeC(1 + Math.floor(R() * (GRID - 1))); z = nodeC(1 + Math.floor(R() * (GRID - 1))); k++; } while (Math.hypot(x - PORT.x, z - PORT.z) < 260 && k < 50); return { x, z }; };
  const mk = (kind, name, ico, lo, hi, tm, desc) => { const d = dest(), dist = Math.hypot(d.x - PORT.x, d.z - PORT.z); return { kind, name, ico, desc, tx: d.x, tz: d.z, t: Math.round(tm + dist / 14), reward: Math.round((lo + R() * (hi - lo)) * mult / 50) * 50 }; };
  return [mk('cargo', 'Обычный груз', '📦', 1800, 2600, 60, 'Спокойная доставка без полиции.'), mk('fast', 'Срочный рефрижератор', '🧊', 3200, 4500, 30, 'Скоропортящийся груз: время жмёт.'), mk('smug', 'Контрабанда', '🕶', 6500, 9500, 40, 'Полиция в курсе: сразу 2★ розыска.')];
}
function portOptions() {
  const o = [];
  if (PJ.on) {
    o.push({ t: '📍 Куда везти? (маршрут показан на карте)', fn: () => { navSet(PJ.tx, PJ.tz, true); say('Маршрут обновлён. Осталось ' + Math.ceil(PJ.t) + ' с.'); } });
    o.push({ t: '❌ Отказаться от заказа (штраф ' + fmtMoney(300) + ')', fn: () => { S.money = Math.max(0, S.money - 300); pjFail('Вы отказались от заказа'); say('Ладно, в следующий раз.'); refreshMoney(false); } });
    return o;
  }
  if (!PJ.offers || Date.now() - PJ.offT > 120000 || PJ.offOwn !== portOwn()) { PJ.offers = portMakeOffers(); PJ.offT = Date.now(); PJ.offOwn = portOwn(); }
  for (const f of PJ.offers) o.push({ t: f.ico + ' ' + f.name + ' — ' + fmtMoney(f.reward) + ' · ' + f.t + ' с', fn: () => pjStart(f) });
  return o;
}
function pjStart(f) {
  if (PJ.on) return;
  Object.assign(PJ, { on: true, tx: f.tx, tz: f.tz, t: f.t, reward: f.reward, kind: f.kind, name: f.name, offers: null });
  navSet(f.tx, f.tz, true); closeScreens();
  if (f.kind === 'smug') { crimeWanted(2, 'контрабанда'); toast('🕶 Груз погружен. Полиция в курсе — уходите от погони!'); } else toast(f.ico + ' Груз погружен. Садитесь в машину и везите!');
  SFX.buy();
}
function pjFail(why) { if (!PJ.on) return; PJ.on = false; PJ.offers = null; navClear(true); $('pjBox').style.display = 'none'; toast('⚓ Заказ провален: ' + why); SFX.err(); }
function portTick(dt) {
  const bx = $('pjBox');
  if (PJ.on) {
    PJ.t -= dt; const car = P.car, px = car ? car.x : P.x, pz = car ? car.z : P.z, d = Math.hypot(px - PJ.tx, pz - PJ.tz);
    bx.style.display = 'block'; bx.textContent = '⚓ ' + PJ.name + ' · ⏱ ' + Math.max(0, Math.ceil(PJ.t)) + ' с' + (car ? '' : ' · сядьте в машину!');
    if (car && !car.def.heli && d < 14) {
      PJ.on = false; PJ.offers = null; navClear(true); bx.style.display = 'none'; addMoney(PJ.reward); SFX.cash();
      S.flags.portJobs = (S.flags.portJobs || 0) + 1; persist(); toast('⚓ Груз доставлен! +' + fmtMoney(PJ.reward) + ' (заказов: ' + S.flags.portJobs + ')');
    } else if (PJ.t <= 0) pjFail('время вышло');
  } else if (bx.style.display !== 'none') bx.style.display = 'none';
}
/* жители порта: докеры патрулируют склад, бригадир стоит у конторы */
const PW = { look: { pants: hexRGB('#1f2f4f'), shirt: hexRGB('#ff8c1a'), skin: hexRGB('#d9a07c'), hair: hexRGB('#f2c81d'), dark: [0.03, 0.03, 0.03] }, boss: { pants: hexRGB('#2b2b30'), shirt: hexRGB('#f2f2f2'), skin: hexRGB('#caa07a'), hair: hexRGB('#fafafa'), dark: [0.03, 0.03, 0.03] }, list: null };
function portInit() {
  const cx = PORT.x, cz = PORT.z, seg = [[-6, -25, -6, -8], [6, -8, 6, -25], [-25, -6, -10, -6], [10, 6, 25, 6], [-6, 8, -6, 21], [25, -4, 10, -4]];
  PW.list = seg.map((s, i) => ({ a: [cx + s[0], cz + s[1]], b: [cx + s[2], cz + s[3]], u: Math.random(), dir: 1, wait: 0, h: 0, ph: Math.random() * 6, amp: 0, sp: 1.4 + Math.random() * 0.5 }));
  PW.list.push({ stand: [cx - 12, cz + 14], face: 0, ph: 0, amp: 0, h: Math.PI }); PW.list.push({ stand: [cx - 3, cz - 22], face: 0, ph: 0, amp: 0, h: Math.PI / 2 });
}
function portDraw() {
  const cx = PORT.x, cz = PORT.z, d = Math.hypot(cx - CAM.x, cz - CAM.z); if (d > 230) return;
  if (!PW.list) portInit();
  const dt = 1 / 60;
  for (const w of PW.list) {
    if (w.stand) { drawHuman(w.stand[0], terrainY(w.stand[0], w.stand[1]), w.stand[1], w.h, 0, 0, PW.look, d > 120, 1, null); continue; }
    if (w.wait > 0) { w.wait -= dt; w.amp = 0; }
    else {
      const L = Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]) || 1; w.u += w.dir * w.sp * dt / L; w.amp = 0.9; w.ph += dt * w.sp * 3.2;
      if (w.u >= 1 || w.u <= 0) { w.u = Math.min(1, Math.max(0, w.u)); w.dir = -w.dir; w.wait = 2 + Math.random() * 3; }
    }
    const x = w.a[0] + (w.b[0] - w.a[0]) * w.u, z = w.a[1] + (w.b[1] - w.a[1]) * w.u;
    w.h = Math.atan2((w.b[0] - w.a[0]) * w.dir, (w.b[1] - w.a[1]) * w.dir);
    drawHuman(x, terrainY(x, z), z, w.h, w.ph, w.amp, PW.look, d > 120, 1, null);
  }
  drawHuman(cx + 14, terrainY(cx + 14, cz + 8.5), cz + 8.5, Math.atan2(P.x - (cx + 14), P.z - (cz + 8.5)), 0, 0, PW.boss, d > 120, 1, null);
}

/* ---- v31: море вокруг города, корабли и лодки ---- */
const SEA = { m: null, ships: null };
function seaBuild() {
  const g = new GeoSet(), W = 4200, T = 300, y = -0.03, A = [0.08, 0.40, 0.66, 1], B = [0.10, 0.45, 0.72, 1], SAND = [0.86, 0.78, 0.56, 1], E = EDGE, E2 = EDGE + 14;
  const tiles = (x0, z0, x1, z1, T) => { let k = 0; for (let x = x0; x < x1; x += T) { for (let z = z0, j = k; z < z1; z += T, j++) g.g().flat(x, z, Math.min(x + T, x1), Math.min(z + T, z1), y, (j & 1) ? A : B); k++; } };
  const N = E + 420;   // у берега плитки мелкие (туман считается по вершинам), дальше крупные
  tiles(-N, E2, N, N, 35); tiles(-N, -N, N, -E2, 35); tiles(-N, -E2, -E2, E2, 35); tiles(E2, -E2, N, E2, 35);
  tiles(-W, N, W, W, T); tiles(-W, -W, W, -N, T); tiles(-W, -N, -N, N, T); tiles(N, -N, W, N, T);
  const s = -0.05;   // песчаный пляж вдоль берега
  for (let t = -E2; t < E2; t += 35) { const t2 = Math.min(t + 35, E2); g.g().flat(t, E, t2, E2, s, SAND); g.g().flat(t, -E2, t2, -E, s, SAND); if (t >= -E && t2 <= E) { g.g().flat(-E2, t, -E, t2, s, SAND); g.g().flat(E, t, E2, t2, s, SAND); } }
  SEA.m = g.done();
}
function shipMesh(kind) {
  const g = new Geo(), box = (a, b, c, d, e, f, col) => g.box(a, b, c, d, e, f, col, false, true);
  if (kind === 'cargo') {
    const hull = [0.55, 0.12, 0.1, 1], deck = [0.75, 0.75, 0.78, 1], pal = [[0.8, 0.2, 0.18, 1], [0.15, 0.4, 0.75, 1], [0.9, 0.65, 0.1, 1], [0.2, 0.6, 0.3, 1]];
    box(-8, 0, -34, 8, 6, 30, hull); box(-6.5, 0, 30, 6.5, 6, 38, hull); box(-4, 0, 38, 4, 6, 44, hull); box(-1.6, 0, 44, 1.6, 6, 48, hull);
    box(-8.2, 5.6, -34, 8.2, 6.2, 30, deck);
    for (let r = 0; r < 6; r++) for (let c = 0; c < 3; c++) for (let h = 0; h < 1 + ((r + c) % 3); h++) box(-6.5 + c * 4.4, 6.2 + h * 2.6, -30 + r * 9, -2.5 + c * 4.4, 8.8 + h * 2.6, -23 + r * 9, pal[(r + c + h) % 4]);
    box(-6, 6.2, -34, 6, 17, -26, [0.95, 0.95, 0.97, 1]); box(-6.4, 13, -33, 6.4, 15, -27, [0.15, 0.2, 0.28, 1]); box(-1.2, 17, -31, 1.2, 22, -29, [0.8, 0.2, 0.18, 1]);
  } else if (kind === 'yacht') {
    box(-2.2, 0, -7, 2.2, 1.8, 6, [0.95, 0.95, 0.97, 1]); box(-1, 0, 6, 1, 1.8, 9, [0.9, 0.9, 0.93, 1]); box(-2.25, 0.5, -7, 2.25, 0.7, 6, [0.15, 0.3, 0.6, 1]);
    box(-1.7, 1.8, -5, 1.7, 3.4, 1, [0.2, 0.55, 0.8, 1]); box(-1.3, 3.4, -4.4, 1.3, 3.6, 0.4, [0.95, 0.95, 0.97, 1]);
  } else {
    box(-1.4, 0, -4.5, 1.4, 1.1, 3.5, [0.95, 0.95, 0.97, 1]); box(-0.8, 0, 3.5, 0.8, 1.1, 5.5, [0.95, 0.95, 0.97, 1]); box(-0.1, 1.1, -0.5, 0.1, 11, -0.3, [0.4, 0.3, 0.2, 1]);
    box(-0.04, 2, -0.2, 0.04, 10.2, 3.6, [1, 0.95, 0.85, 1]); box(-0.04, 2, -4.2, 0.04, 9.4, -0.8, [0.9, 0.3, 0.25, 1]);
  }
  return makeMesh(g);
}
function seaDraw() {
  if (G.mode !== 'play' || G.inHome) return;
  if (!SEA.m) { seaBuild(); SEA.ships = [{ m: shipMesh('cargo'), x: -900, z: 1300, v: 6, yaw: Math.PI / 2, ph: 0, x0: -1800, x1: 1800, ln: 1 }, { m: shipMesh('cargo'), x: 1200, z: -1100, v: -5, yaw: -Math.PI / 2, ph: 2, x0: -1800, x1: 1800 }, { m: shipMesh('yacht'), cx: PORT.x + 70, cz: EDGE + 120, r: 70, a: 0, sp: 0.07, ph: 1 }, { m: shipMesh('sail'), cx: -300, cz: EDGE + 220, r: 110, a: 2, sp: 0.04, ph: 3 }, { m: shipMesh('sail'), cx: 420, cz: EDGE + 160, r: 80, a: 4, sp: -0.05, ph: 5 }, { m: shipMesh('yacht'), cx: 900, cz: 300, r: 130, a: 1, sp: 0.05, ph: 4 }]; }
  const t = G.time, k = 0.97 + 0.04 * Math.sin(t * 0.7);
  for (const m of SEA.m) drawMesh(m, IDENT, k * 0.98, k, k * 1.02, 1, 0, false);
  for (const s of SEA.ships) {
    let x, z, yaw;
    if (s.r) { x = s.cx + Math.cos(s.a + s.sp * t) * s.r; z = s.cz + Math.sin(s.a + s.sp * t) * s.r; yaw = Math.atan2(-Math.sin(s.a + s.sp * t) * s.sp, Math.cos(s.a + s.sp * t) * s.sp); }
    else { const span = s.x1 - s.x0, u = ((s.x - s.x0 + s.v * t) % (span * 2) + span * 2) % (span * 2); x = s.x0 + (u < span ? u : span * 2 - u); z = s.z; yaw = (u < span) === (s.v > 0) ? Math.PI / 2 : -Math.PI / 2; }
    if (Math.hypot(x - CAM.x, z - CAM.z) > 1500) continue;
    mTRS(DM, x, -0.1 + Math.sin(t * 0.9 + s.ph) * 0.18, z, yaw, Math.sin(t * 0.7 + s.ph) * 0.02, Math.sin(t * 0.8 + s.ph) * 0.03, 1, 1, 1); drawMesh(s.m, DM, 1, 1, 1, 1, 0, false);
  }
}

