/* ===================== v16: ОГРАБЛЕНИЯ, ТЮНИНГ, НЕДВИЖИМОСТЬ — данные ===================== */
const STORE_TYPES = {
  mini: { name: 'Мини-маркет', ico: '🏪', lo: 300, hi: 700, stars: 1, dur: 6, dot: '#2dd36f' },
  jewel: { name: 'Ювелирный', ico: '💎', lo: 1200, hi: 2800, stars: 2, dur: 8, dot: '#7ee0ff' },
  bank: { name: 'Банк', ico: '🏦', lo: 4000, hi: 8000, stars: 3, dur: 11, dot: '#ffd23f' }
};
const STORES = [
  { id: 's1', t: 'mini', b: [0, 3], nm: 'Мини-маркет «Ромашка»' },
  { id: 's2', t: 'mini', b: [1, 9], nm: 'Мини-маркет «У дома»' },
  { id: 's3', t: 'mini', b: [14, 11], nm: 'Мини-маркет «Круглосуточный»' },
  { id: 's4', t: 'mini', b: [15, 14], nm: 'Мини-маркет «Орбита»' },
  { id: 's5', t: 'mini', b: [3, 0], nm: 'Мини-маркет «Лавка Гоши»' },
  { id: 's6', t: 'mini', b: [9, 1], nm: 'Мини-маркет «Продукты 24»' },
  { id: 's7', t: 'mini', b: [12, 15], nm: 'Мини-маркет «Копеечка»' },
  { id: 's8', t: 'mini', b: [6, 15], nm: 'Мини-маркет «Звезда»' },
  { id: 'j1', t: 'jewel', b: [1, 6], nm: 'Ювелирный «Бриллиант»' },
  { id: 'j2', t: 'jewel', b: [14, 2], nm: 'Ювелирный «Золотое руно»' },
  { id: 'j3', t: 'jewel', b: [5, 14], nm: 'Ювелирный «Сапфир»' },
  { id: 'j4', t: 'jewel', b: [11, 6], nm: 'Ювелирный «Рубин»' },
  { id: 'k1', t: 'bank', b: [7, 5], nm: 'Банк «Столичный»' },
  { id: 'k2', t: 'bank', b: [12, 12], nm: 'Банк «Народный»' },
  { id: 'k3', t: 'bank', b: [3, 4], nm: 'Банк «Северный»' }
];
const STORE_AT = {}; STORES.forEach(s => STORE_AT[s.b.join(',')] = s);
const TUNE_BLK = [5, 9], ESTATE_BLK = [9, 9], CLUB_BLK = [6, 12], CLUB_KEY = CLUB_BLK.join(',');
const TUNE_KEY = TUNE_BLK.join(','), ESTATE_KEY = ESTATE_BLK.join(',');
const CLOTHES = [{ id: 'cA', b: [8, 10], nm: 'Бутик «Силуэт»', v: 0 }, { id: 'cB', b: [10, 3], nm: 'Магазин одежды «Street»', v: 1 }];
const SALONS = [{ id: 'sA', b: [10, 8], nm: 'Салон красоты «Локон»', v: 0 }, { id: 'sB', b: [4, 13], nm: 'Салон «Стиль»', v: 1 }];
const CLOTH_AT = {}, SALON_AT = {}; CLOTHES.forEach(c => CLOTH_AT[c.b.join(',')] = c); SALONS.forEach(c => SALON_AT[c.b.join(',')] = c);
const GARAGE_BAYS = 40, GARAGE_BASE = 8;
const PROPS = [
  { id: 'flat', nm: 'Квартира с парковкой', ico: '🏢', b: [12, 10], price: 18000, slots: 3, rate: 250 },
  { id: 'house', nm: 'Дом с гаражом', ico: '🏡', b: [3, 12], price: 55000, slots: 4, rate: 800 },
  { id: 'villa', nm: 'Вилла с подземным гаражом', ico: '🏰', b: [14, 5], price: 140000, slots: 5, rate: 2000 },
  { id: 'tower', nm: 'Пентхаус «Небо»', ico: '🌆', b: [6, 6], price: 320000, slots: 2, rate: 5200 },
  /* v48: гаражи-стоянки — только парковка (без квартиры), много мест */
  { id: 'park1', nm: 'Подземный паркинг «Центр»', ico: '🅿', b: [5, 6], price: 30000, slots: 4, rate: 400, park: 1, col: [0.45, 0.47, 0.52], col2: [0.2, 0.55, 0.95] },
  { id: 'park2', nm: 'Автобокс «Северный»', ico: '🚘', b: [9, 6], price: 60000, slots: 6, rate: 900, park: 1, col: [0.62, 0.42, 0.3], col2: [0.95, 0.55, 0.15] },
  { id: 'park3', nm: 'Гараж-склад «Западный»', ico: '🏭', b: [2, 5], price: 95000, slots: 8, rate: 1500, park: 1, col: [0.4, 0.5, 0.42], col2: [0.2, 0.8, 0.45] },
  { id: 'park4', nm: 'Автомузей «Ретро»', ico: '🏛', b: [4, 4], price: 180000, slots: 10, rate: 3500, park: 1, col: [0.85, 0.8, 0.7], col2: [0.75, 0.2, 0.2] },
  { id: 'park5', nm: 'Элитный ангар «Платина»', ico: '💎', b: [10, 9], price: 320000, slots: 12, rate: 6500, park: 1, col: [0.22, 0.24, 0.3], col2: [0.85, 0.85, 0.95] }
];
const PROP_AT = {}; PROPS.forEach(p => PROP_AT[p.b.join(',')] = p);
/* проверка: ни один блок не занят дважды */
function blkAudit() {
  const seen = {}, dup = [];
  const add = (k, who) => { if (seen[k]) dup.push(k + ': ' + seen[k] + ' / ' + who); else seen[k] = who; };
  add(HOME_B + ',' + HOME_B, 'home'); add(HOSP_BLK.join(','), 'hosp'); add(POL_BLK.join(','), 'pol');
  SHOP_BLKS.forEach(q => add(q.b.join(','), q.id));
  for (const k in BIZ_BLK) add(k, 'biz ' + BIZ_BLK[k].id);
  add((GRID / 2 - 1) + ',' + (GRID / 2 - 1), 'tower');
  STORES.forEach(s => add(s.b.join(','), s.id)); add(TUNE_KEY, 'tune'); add(ESTATE_KEY, 'estate'); add(CLUB_KEY, 'club');
  PROPS.forEach(p => add(p.b.join(','), p.id));
  CLOTHES.forEach(c => add(c.b.join(','), c.id)); SALONS.forEach(c => add(c.b.join(','), c.id));
  const parkClash = []; for (const k in seen) if (PARKS.has(k) && !BIZ_BLK[k]) parkClash.push(k + ' ' + seen[k]);
  return { dup, parkClash, total: Object.keys(seen).length, seen };
}



/* ---- Бизнесы и бар Крота: здание в парке ---- */
function buildKiosk(WORLD, cx, cz, b) {
  const G = WORLD.g(), x0 = cx + 8, x1 = cx + 20, z0 = cz + 10, z1 = cz + 20;
  const dark = [0.1, 0.1, 0.12, 1], glass = [0.55, 0.78, 0.95, 1];
  G.box(x0, 0.2, z0, x1, 7, z1, b.col, true, true);
  G.box(x0 - 0.5, 7, z0 - 0.5, x1 + 0.5, 7.5, z1 + 0.5, [0.25, 0.25, 0.3, 1], false, true);
  G.box(x0 + 0.5, 7.5, z0 - 0.2, x1 - 0.5, 9.2, z0 + 0.4, [1, 0.95, 0.8, 1], false, true);
  G.box(x0 + 1, 7.8, z0 - 0.4, x1 - 1, 8.9, z0 - 0.2, b.col.map((v, i) => i < 3 ? Math.min(1, v * 1.4 + 0.1) : 1), false, true);
  G.box(cx + 12.5, 0.2, z0 - 0.3, cx + 15.5, 3.6, z0, dark, false, true);
  G.box(x0 + 1, 1.5, z0 - 0.3, x0 + 4.5, 4.5, z0, glass, false, true);
  G.box(x1 - 4.5, 1.5, z0 - 0.3, x1 - 1, 4.5, z0, glass, false, true);
  boxes.push({ x0, x1, z0, z1, h: 7 });
  if (b.id === 'gas') {
    G.box(x0 - 1, 5.2, z0 - 7, x1 + 1, 5.8, z0 - 1, [0.9, 0.9, 0.92, 1], false, true);
    for (const px of [x0 + 1, x1 - 1]) G.box(px - 0.25, 0.2, z0 - 7, px + 0.25, 5.2, z0 - 6.5, [0.7, 0.7, 0.72, 1], false, true);
    for (const px of [cx + 11, cx + 17]) { G.box(px - 0.5, 0.2, z0 - 5.4, px + 0.5, 1.7, z0 - 4.4, [0.85, 0.15, 0.15, 1], false, true); boxes.push({ x0: px - 0.5, x1: px + 0.5, z0: z0 - 5.4, z1: z0 - 4.4, h: 1.7 }); }
  } else if (b.id === 'wash') {
    G.box(x0 - 1, 0.2, z0 - 8, x0, 4.5, z0 - 1, [0.3, 0.55, 0.8, 1], false, true);
    G.box(x1, 0.2, z0 - 8, x1 + 1, 4.5, z0 - 1, [0.3, 0.55, 0.8, 1], false, true);
    G.box(x0 - 1, 4.5, z0 - 8, x1 + 1, 5.2, z0 - 1, [0.3, 0.55, 0.8, 1], false, true);
  } else if (b.id === 'port') {
    const R2 = rng(777), pal = [[0.8, 0.2, 0.18, 1], [0.15, 0.4, 0.75, 1], [0.9, 0.65, 0.1, 1], [0.2, 0.6, 0.3, 1], [0.55, 0.55, 0.6, 1], [0.7, 0.35, 0.1, 1]];
    G.box(cx - 31, 0.2, cz - 31, cx + 31, 0.32, cz + 22, [0.36, 0.37, 0.4, 1], false, true);
    for (const [qx, qz] of [[-1, -1], [1, -1], [-1, 1]]) for (let r = 0; r < 3; r++) for (let c = 0; c < 2; c++) {
      const bx = cx + qx * (9 + c * 8) - (qx > 0 ? 0 : 6) - (qx > 0 ? 0 : 0), bz = cz + qz * (9 + r * 6.2) - (qz > 0 ? 0 : 2.6);
      const x0c = qx > 0 ? bx : bx, hh = R2() < 0.4 ? 5.0 : 2.5, col = pal[Math.floor(R2() * pal.length)];
      if (qx > 0 && qz > 0) continue;
      if (qz > 0 && r > 0) continue;
      G.box(x0c, 0.24, bz, x0c + 6, 0.24 + hh, bz + 2.6, col, true, true);
      for (let k = 0; k < 4; k++) G.box(x0c + 0.3 + k * 1.5, 0.3, bz - 0.02, x0c + 0.4 + k * 1.5, hh + 0.1, bz + 2.62, [col[0] * 0.7, col[1] * 0.7, col[2] * 0.7, 1], false, true);
      boxes.push({ x0: x0c, x1: x0c + 6, z0: bz, z1: bz + 2.6, h: hh });
    }
    G.box(cx - 31, 0.18, cz + 22, cx + 31, 0.5, cz + 32, [0.1, 0.35, 0.6, 1], false, true);          // вода
    G.box(cx + 4, 0.24, cz + 20, cx + 10, 0.6, cz + 31, [0.5, 0.4, 0.28, 1], false, true);           // пирс
    G.box(cx - 24, 0.5, cz + 25, cx - 12, 1.5, cz + 29, [0.85, 0.85, 0.88, 1], false, true);         // катер
    G.box(cx - 21, 1.5, cz + 25.6, cx - 16, 3, cz + 28.4, [0.2, 0.55, 0.8, 1], false, true);
    for (const lx of [-25, -9]) { G.box(cx + lx, 0.24, cz + 16, cx + lx + 1, 17, cz + 17, [0.95, 0.75, 0.1, 1], false, true); boxes.push({ x0: cx + lx, x1: cx + lx + 1, z0: cz + 16, z1: cz + 17, h: 17 }); }
    G.box(cx - 26, 17, cz + 15.5, cx - 7, 18.2, cz + 31, [0.95, 0.75, 0.1, 1], false, true);          // кран
    G.box(cx - 17, 14, cz + 28, cx - 15, 17, cz + 29, [0.15, 0.15, 0.15, 1], false, true);
  } else if (b.id === 'club') {
    G.box(x0 + 2, 9.2, z0 + 1, x0 + 2.5, 12, z0 + 1.5, [0.9, 0.2, 0.8, 1], false, true);
    G.box(x1 - 2.5, 9.2, z0 + 1, x1 - 2, 12, z0 + 1.5, [0.2, 0.9, 0.9, 1], false, true);
  }
}
/* ---- Больница и полицейский участок ---- */
function buildCivic(WORLD, cx, cz, kind) {
  const hosp = kind === 'hosp';
  const G = WORLD.g();
  const wall = hosp ? [0.93, 0.94, 0.96, 1] : [0.34, 0.4, 0.56, 1];
  const H = hosp ? 26 : 15;
  const x0 = cx - 24, x1 = cx + 24, z0 = cz - 4, z1 = cz + 24;
  G.box(cx - 31, 0.16, cz - 31, cx + 31, 0.2, cz - 4, [0.7, 0.7, 0.72, 1], false, true);              // площадка
  G.box(x0, 0.16, z0, x1, H, z1, wall, true, true);                                                    // корпус
  G.box(x0 - 0.6, 3.6, z0 - 0.6, x1 + 0.6, 4.4, z1 + 0.6, hosp ? [0.2, 0.5, 0.85, 1] : [0.95, 0.95, 0.98, 1], false, true);  // пояс
  G.box(x0 - 0.8, H, z0 - 0.8, x1 + 0.8, H + 1.2, z1 + 0.8, [0.45, 0.46, 0.5, 1], false, true);        // карниз
  G.box(cx - 3.4, 0.16, z0 - 0.35, cx + 3.4, 4.2, z0, [0.16, 0.26, 0.36, 1], false, true);             // двери
  G.box(cx - 7, 4.4, z0 - 7, cx + 7, 4.9, z0, [0.95, 0.95, 0.97, 1], false, true);                     // козырёк
  G.box(cx - 7, 0.2, z0 - 7, cx - 6.5, 4.4, z0 - 6.5, [0.85, 0.85, 0.88, 1], false, true);
  G.box(cx + 6.5, 0.2, z0 - 7, cx + 7, 4.4, z0 - 6.5, [0.85, 0.85, 0.88, 1], false, true);
  if (hosp) {
    const red = [0.86, 0.1, 0.13, 1];
    G.box(cx - 1.4, 15, z0 - 0.5, cx + 1.4, 22.5, z0, red, false, true);                               // красный крест
    G.box(cx - 4.1, 17.5, z0 - 0.5, cx + 4.1, 20, z0, red, false, true);
    G.box(cx - 8, 4.9, z0 - 0.4, cx + 8, 6.0, z0, [0.86, 0.1, 0.13, 1], false, true);                  // вывеска над входом
    G.box(cx - 7, H + 1.2, cz + 8, cx + 7, H + 1.45, cz + 20, [0.35, 0.36, 0.4, 1], false, true);       // вертолётная площадка
    G.box(cx - 3.2, H + 1.45, cz + 10, cx - 2.4, H + 1.5, cz + 18, [1, 1, 1, 1], false, true);
    G.box(cx + 2.4, H + 1.45, cz + 10, cx + 3.2, H + 1.5, cz + 18, [1, 1, 1, 1], false, true);
    G.box(cx - 3.2, H + 1.45, cz + 13.6, cx + 3.2, H + 1.5, cz + 14.4, [1, 1, 1, 1], false, true);
  } else {
    G.box(cx - 8, 4.9, z0 - 0.4, cx + 8, 6.0, z0, [0.15, 0.3, 0.75, 1], false, true);                   // вывеска
    G.box(cx - 2, 8.5, z0 - 0.4, cx + 2, 12.5, z0, [0.95, 0.8, 0.2, 1], false, true);                   // жёлтый щит
    G.box(cx - 1, 9.5, z0 - 0.7, cx + 1, 11.5, z0 - 0.4, [0.15, 0.3, 0.75, 1], false, true);
    G.box(cx + 18, H + 1.2, cz + 10, cx + 18.5, H + 14, cz + 10.5, [0.7, 0.7, 0.72, 1], false, true);    // антенна
    G.box(cx - 20, H + 1.2, z0, cx - 14, H + 2.4, z0 + 1.5, [0.9, 0.1, 0.1, 1], false, true);           // мигалки
    G.box(cx - 14, H + 1.2, z0, cx - 8, H + 2.4, z0 + 1.5, [0.1, 0.25, 0.95, 1], false, true);
    G.box(cx - 28, 0.2, z0 - 8, cx - 27.6, 9, z0 - 7.6, [0.8, 0.8, 0.82, 1], false, true);              // флагшток
    G.box(cx - 27.6, 6.5, z0 - 8, cx - 24, 9, z0 - 7.7, [0.2, 0.3, 0.8, 1], false, true);
  }
  boxes.push({ x0, x1, z0, z1, h: H });
}

/* ---- Магазины оружия и машин ---- */
function buildShopBuilding(WORLD, cx, cz, kind) {
  const G = WORLD.g(), gun = kind === 'gun';
  const x0 = cx - 20, x1 = cx + 20, z0 = cz - 4, z1 = cz + 18, H = gun ? 11 : 9;
  G.box(cx - 31, 0.16, cz - 31, cx + 31, 0.2, cz - 4, gun ? [0.5, 0.5, 0.53, 1] : [0.74, 0.74, 0.76, 1], false, true);
  G.box(x0, 0.16, z0, x1, H, z1, gun ? [0.34, 0.33, 0.36, 1] : [0.9, 0.9, 0.93, 1], true, true);
  G.box(x0 - 0.5, H, z0 - 0.5, x1 + 0.5, H + 0.9, z1 + 0.5, [0.2, 0.2, 0.23, 1], false, true);
  if (gun) {
    G.box(cx - 10, 0.2, z0 - 0.3, cx - 3, 4.4, z0, [0.15, 0.17, 0.22, 1], false, true);
    G.box(cx + 3, 0.2, z0 - 0.3, cx + 10, 4.4, z0, [0.15, 0.17, 0.22, 1], false, true);
    G.box(cx - 2, 0.2, z0 - 0.4, cx + 2, 3.6, z0, [0.3, 0.15, 0.1, 1], false, true);
    G.box(cx - 12, 5.2, z0 - 0.5, cx + 12, 8.2, z0, [0.75, 0.1, 0.1, 1], false, true);
    G.box(cx - 0.4, 5.6, z0 - 0.8, cx + 0.4, 7.8, z0 - 0.5, [1, 1, 1, 1], false, true);
    G.box(cx - 2.2, 6.4, z0 - 0.8, cx + 2.2, 7.0, z0 - 0.5, [1, 1, 1, 1], false, true);
    for (const sx of [-15, 15]) { G.box(cx + sx - 2.5, 0.2, z0 - 3.5, cx + sx + 2.5, 1.2, z0 - 2, [0.55, 0.5, 0.35, 1], false, true); boxes.push({ x0: cx + sx - 2.5, x1: cx + sx + 2.5, z0: z0 - 3.5, z1: z0 - 2, h: 1.2 }); }
  } else {
    G.box(cx - 17, 0.2, z0 - 0.3, cx + 17, 6, z0, [0.3, 0.52, 0.78, 1], false, true);
    G.box(cx - 14, 6.6, z0 - 0.5, cx + 14, 8.6, z0, [0.1, 0.55, 0.3, 1], false, true);
    G.box(cx - 6, 7.1, z0 - 0.8, cx + 6, 8.1, z0 - 0.5, [1, 1, 1, 1], false, true);
    const cc = [[0.85, 0.15, 0.15], [0.15, 0.4, 0.85], [0.95, 0.75, 0.1]];
    for (let k = 0; k < 3; k++) {
      const px = cx - 16 + k * 16, pz = z0 - 9;
      G.box(px - 2.1, 0.5, pz - 0.95, px + 2.1, 1.3, pz + 0.95, cc[k].concat([1]), false, true);
      G.box(px - 1.1, 1.3, pz - 0.8, px + 1.0, 2.0, pz + 0.8, [0.25, 0.3, 0.38, 1], false, true);
      G.box(px - 2.0, 0.2, pz - 0.9, px - 1.5, 0.6, pz - 0.5, [0.05, 0.05, 0.05, 1], false, true);
      G.box(px + 1.5, 0.2, pz + 0.5, px + 2.0, 0.6, pz + 0.9, [0.05, 0.05, 0.05, 1], false, true);
      boxes.push({ x0: px - 2.1, x1: px + 2.1, z0: pz - 0.95, z1: pz + 0.95, h: 1.6 });
    }
  }
  boxes.push({ x0, x1, z0, z1, h: H });
}

/* ---- v16: здания — магазины для ограбления, тюнинг-центр, агентство, недвижимость ---- */
function buildStoreBuilding(WORLD, cx, cz, s) {
  const G = WORLD.g(), T = s.t, dark = [0.12, 0.12, 0.14, 1], glass = [0.55, 0.78, 0.95, 1];
  const wallC = { mini: [0.93, 0.93, 0.9, 1], jewel: [0.36, 0.22, 0.46, 1], bank: [0.82, 0.8, 0.74, 1] }[T];
  const trim = { mini: [0.1, 0.72, 0.34, 1], jewel: [0.55, 0.9, 1, 1], bank: [0.95, 0.78, 0.2, 1] }[T];
  const H = { mini: 7, jewel: 9, bank: 14 }[T], hw = { mini: 17, jewel: 15, bank: 20 }[T];
  const x0 = cx - hw, x1 = cx + hw, z0 = cz - 4, z1 = cz + 18;
  G.box(cx - 31, 0.16, cz - 31, cx + 31, 0.2, cz - 4, [0.6, 0.6, 0.62, 1], false, true);
  G.box(x0, 0.16, z0, x1, H, z1, wallC, true, true);
  G.box(x0 - 0.5, H, z0 - 0.5, x1 + 0.5, H + 0.8, z1 + 0.5, [0.22, 0.22, 0.26, 1], false, true);
  G.box(x0 + 2, 0.4, z0 - 0.3, cx - 4, H * 0.6, z0, glass, false, true);
  G.box(cx + 4, 0.4, z0 - 0.3, x1 - 2, H * 0.6, z0, glass, false, true);
  G.box(cx - 2, 0.2, z0 - 0.4, cx + 2, 3.6, z0, dark, false, true);
  G.box(x0 + 1, H * 0.66, z0 - 0.6, x1 - 1, H * 0.66 + 2.4, z0, trim, false, true);
  if (T === 'mini') {
    const n = 10, w = (x1 - x0 - 2) / n;
    for (let k = 0; k < n; k++) G.box(x0 + 1 + k * w, 4.1, z0 - 3.4, x0 + 1 + (k + 1) * w, 4.5, z0 - 0.1, k % 2 ? [1, 1, 1, 1] : [0.1, 0.72, 0.34, 1], false, true);
    G.box(cx + 8, 0.2, z0 - 1.6, cx + 12, 2.2, z0 - 0.8, [0.85, 0.15, 0.15, 1], false, true);   // автомат с напитками
  } else if (T === 'jewel') {
    G.box(cx - 2, H + 0.8, cz + 3, cx + 2, H + 3.4, cz + 7, [0.6, 0.9, 1, 1], false, true);
    G.box(cx - 1, H + 3.4, cz + 4, cx + 1, H + 5, cz + 6, [0.85, 0.97, 1, 1], false, true);
    G.box(x0 + 3, 0.2, z0 - 1.2, x0 + 4.2, 3.4, z0 - 0.1, [0.9, 0.78, 0.25, 1], false, true);
    G.box(x1 - 4.2, 0.2, z0 - 1.2, x1 - 3, 3.4, z0 - 0.1, [0.9, 0.78, 0.25, 1], false, true);
  } else {
    G.box(x0 - 1, H - 1.6, z0 - 4.2, x1 + 1, H, z0, [0.9, 0.88, 0.82, 1], false, true);
    for (let k = -3; k <= 3; k++) {
      if (k === 0) continue;
      const px = cx + k * 5.4;
      G.box(px - 0.7, 0.2, z0 - 3.6, px + 0.7, H - 1.6, z0 - 2.2, [0.93, 0.91, 0.85, 1], false, true);
      boxes.push({ x0: px - 0.7, x1: px + 0.7, z0: z0 - 3.6, z1: z0 - 2.2, h: H - 1.6 });
    }
    G.box(cx - 5, 0.2, z0 - 7, cx + 5, 0.9, z0 - 4.4, [0.55, 0.55, 0.58, 1], false, true);       // ступени
    G.box(cx - 12, H + 0.8, cz + 3, cx + 12, H + 1.8, cz + 12, [0.35, 0.36, 0.4, 1], false, true);
  }
  boxes.push({ x0, x1, z0, z1, h: H });
}
function buildTuneShop(WORLD, cx, cz) {
  const G = WORLD.g(), x0 = cx - 24, x1 = cx + 24, z0 = cz - 4, z1 = cz + 20, H = 10;
  const neon = [[1, 0.2, 0.8, 1], [0.1, 0.9, 1, 1], [1, 0.6, 0.1, 1]];
  G.box(cx - 31, 0.16, cz - 31, cx + 31, 0.2, cz - 4, [0.28, 0.28, 0.32, 1], false, true);
  G.box(x0, 0.16, z0, x1, H, z1, [0.2, 0.21, 0.26, 1], true, true);
  G.box(x0 - 0.5, H, z0 - 0.5, x1 + 0.5, H + 0.9, z1 + 0.5, [0.1, 0.1, 0.13, 1], false, true);
  for (let k = -1; k <= 1; k++) {
    const bx = cx + k * 14;
    G.box(bx - 5, 0.2, z0 - 0.3, bx + 5, 5.5, z0, [0.32, 0.34, 0.4, 1], false, true);
    for (let s = 0; s < 4; s++) G.box(bx - 5, 1.1 + s * 1.15, z0 - 0.5, bx + 5, 1.25 + s * 1.15, z0 - 0.3, [0.18, 0.19, 0.23, 1], false, true);
    G.box(bx - 5.4, 5.5, z0 - 0.6, bx + 5.4, 5.95, z0, neon[k + 1], false, true);
    G.box(bx - 5.4, 0.2, z0 - 0.6, bx - 5, 5.5, z0, neon[k + 1], false, true);
    G.box(bx + 5, 0.2, z0 - 0.6, bx + 5.4, 5.5, z0, neon[k + 1], false, true);
  }
  G.box(cx - 13, 6.6, z0 - 0.7, cx + 13, 9.4, z0, [0.04, 0.04, 0.07, 1], false, true);
  for (let k = 0; k < 5; k++) G.box(cx - 11 + k * 4.6, 7.1, z0 - 0.9, cx - 8.6 + k * 4.6, 8.9, z0 - 0.7, neon[k % 3], false, true);
  for (const sx of [-20, 20]) {          // шины у входа
    for (let k = 0; k < 3; k++) { G.box(cx + sx - 1.1, 0.2 + k * 0.7, z0 - 5, cx + sx + 1.1, 0.9 + k * 0.7, z0 - 2.8, [0.07, 0.07, 0.08, 1], false, true); }
    boxes.push({ x0: cx + sx - 1.1, x1: cx + sx + 1.1, z0: z0 - 5, z1: z0 - 2.8, h: 2.3 });
  }
  boxes.push({ x0, x1, z0, z1, h: H });
}
/* ---- v23: магазины одежды и салоны красоты — здания ---- */
function mannequinExt(G, x, z, col, dress) {
  G.box(x - 1.3, 0.2, z - 1.0, x + 1.3, 0.55, z + 1.0, [0.95, 0.95, 0.97, 1], false, true);
  G.box(x - 0.08, 0.55, z - 0.08, x + 0.08, 1.4, z + 0.08, [0.7, 0.7, 0.74, 1], false, true);
  if (dress) G.cone(x, 0.9, z, 0.85, 1.3, 9, col);
  else { G.box(x - 0.32, 1.0, z - 0.14, x - 0.04, 2.1, z + 0.14, [0.2, 0.22, 0.3, 1], false, true); G.box(x + 0.04, 1.0, z - 0.14, x + 0.32, 2.1, z + 0.14, [0.2, 0.22, 0.3, 1], false, true); }
  G.box(x - 0.42, 2.0, z - 0.2, x + 0.42, 2.95, z + 0.2, col.concat ? [col[0], col[1], col[2], 1] : col, false, true);
  G.box(x - 0.08, 2.95, z - 0.08, x + 0.08, 3.12, z + 0.08, [0.9, 0.86, 0.82, 1], false, true);
  G.box(x - 0.2, 3.12, z - 0.2, x + 0.2, 3.58, z + 0.2, [0.92, 0.88, 0.84, 1], false, true);
  boxes.push({ x0: x - 1.3, x1: x + 1.3, z0: z - 1.0, z1: z + 1.0, h: 3.6 });
}
function buildClothStore(WORLD, cx, cz, v) {
  const G = WORLD.g(), x0 = cx - 18, x1 = cx + 18, z0 = cz - 4, z1 = cz + 18, H = 9;
  const wall = v ? [0.86, 0.82, 0.95, 1] : [0.99, 0.86, 0.92, 1], acc = v ? [0.34, 0.2, 0.66, 1] : [0.92, 0.22, 0.52, 1];
  const glass = [0.6, 0.82, 0.95, 1], white = [1, 1, 1, 1];
  G.box(cx - 31, 0.16, cz - 31, cx + 31, 0.2, cz - 4, [0.74, 0.72, 0.75, 1], false, true);
  G.box(x0, 0.16, z0, x1, H, z1, wall, true, true);
  G.box(x0 - 0.5, H, z0 - 0.5, x1 + 0.5, H + 0.8, z1 + 0.5, acc, false, true);
  G.box(x0 + 2, 0.4, z0 - 0.3, cx - 4, 5.6, z0, glass, false, true);
  G.box(cx + 4, 0.4, z0 - 0.3, x1 - 2, 5.6, z0, glass, false, true);
  G.box(cx - 2, 0.2, z0 - 0.4, cx + 2, 3.6, z0, [0.12, 0.12, 0.14, 1], false, true);
  G.box(x0 + 1, 5.7, z0 - 0.5, x1 - 1, 5.9, z0, acc, false, true);
  G.box(cx - 12, 6.3, z0 - 0.7, cx + 12, 8.8, z0, acc, false, true);
  G.box(cx - 11.2, 6.6, z0 - 0.95, cx + 11.2, 8.5, z0 - 0.7, white, false, true);
  G.cone(cx - 7.5, 6.8, z0 - 1.5, 1.3, 1.5, 10, acc);                                  // платье
  G.box(cx - 8.0, 8.0, z0 - 1.5, cx - 7.0, 8.4, z0 - 1.2, acc, false, true);
  G.cone(cx, 6.8, z0 - 1.5, 1.8, 1.6, 3, [0.25, 0.25, 0.3]);                              // вешалка
  G.box(cx - 0.12, 8.3, z0 - 1.4, cx + 0.12, 8.5, z0 - 1.2, [0.25, 0.25, 0.3, 1], false, true);
  G.box(cx + 6.0, 7.5, z0 - 1.5, cx + 9.0, 8.4, z0 - 1.2, acc, false, true);            // футболка
  G.box(cx + 5.4, 7.5, z0 - 1.5, cx + 6.0, 7.9, z0 - 1.2, acc, false, true);
  G.box(cx + 9.0, 7.5, z0 - 1.5, cx + 9.6, 7.9, z0 - 1.2, acc, false, true);
  G.box(cx + 6.5, 6.8, z0 - 1.5, cx + 8.5, 7.5, z0 - 1.2, acc, false, true);
  const n = 12, w = (x1 - x0 - 2) / n;
  for (let k = 0; k < n; k++) G.box(x0 + 1 + k * w, 4.1, z0 - 3.4, x0 + 1 + (k + 1) * w, 4.5, z0 - 0.1, k % 2 ? white : acc, false, true);
  mannequinExt(G, cx - 11.5, z0 - 6.0, v ? [0.2, 0.5, 0.9] : [0.9, 0.2, 0.35], !v);
  mannequinExt(G, cx + 11.5, z0 - 6.0, v ? [0.95, 0.75, 0.15] : [0.3, 0.7, 0.55], v ? false : true);
  boxes.push({ x0, x1, z0, z1, h: H });
}
function buildSalon(WORLD, cx, cz, v) {
  const G = WORLD.g(), x0 = cx - 16, x1 = cx + 16, z0 = cz - 4, z1 = cz + 18, H = 8;
  const wall = v ? [0.95, 0.9, 0.82, 1] : [0.82, 0.94, 0.94, 1], acc = v ? [0.55, 0.15, 0.2, 1] : [0.1, 0.6, 0.64, 1];
  const glass = [0.62, 0.84, 0.96, 1], white = [1, 1, 1, 1], red = [0.85, 0.12, 0.2, 1], blue = [0.15, 0.3, 0.8, 1];
  G.box(cx - 31, 0.16, cz - 31, cx + 31, 0.2, cz - 4, [0.72, 0.72, 0.72, 1], false, true);
  G.box(x0, 0.16, z0, x1, H, z1, wall, true, true);
  G.box(x0 - 0.5, H, z0 - 0.5, x1 + 0.5, H + 0.8, z1 + 0.5, acc, false, true);
  G.box(x0 + 2, 0.4, z0 - 0.3, cx - 4, 5.2, z0, glass, false, true);
  G.box(cx + 4, 0.4, z0 - 0.3, x1 - 2, 5.2, z0, glass, false, true);
  G.box(cx - 2, 0.2, z0 - 0.4, cx + 2, 3.6, z0, [0.12, 0.12, 0.14, 1], false, true);
  G.box(cx - 11, 5.7, z0 - 0.7, cx + 11, 7.8, z0, acc, false, true);
  G.box(cx - 8.5, 6.9, z0 - 0.95, cx + 8.5, 7.3, z0 - 0.7, white, false, true);               // гребень
  for (let k = 0; k < 15; k++) G.box(cx - 8.5 + k * 1.1, 6.0, z0 - 0.95, cx - 8.15 + k * 1.1, 6.9, z0 - 0.7, white, false, true);
  const n = 10, w = (x1 - x0 - 2) / n;
  for (let k = 0; k < n; k++) G.box(x0 + 1 + k * w, 4.1, z0 - 3.0, x0 + 1 + (k + 1) * w, 4.5, z0 - 0.1, k % 2 ? white : acc, false, true);
  for (const sx of [-6.5, 6.5]) {                                                              // барбер-шесты
    const px = cx + sx, pz = z0 - 1.6;
    G.box(px - 0.55, 0.2, pz - 0.55, px + 0.55, 0.5, pz + 0.55, [0.2, 0.2, 0.24, 1], false, true);
    for (let k = 0; k < 9; k++) G.box(px - 0.38, 0.5 + k * 0.42, pz - 0.38, px + 0.38, 0.5 + (k + 1) * 0.42, pz + 0.38, [red, white, blue][k % 3], false, true);
    G.cone(px, 4.28, pz, 0.5, 0.6, 8, [0.8, 0.8, 0.85]);
    boxes.push({ x0: px - 0.55, x1: px + 0.55, z0: pz - 0.55, z1: pz + 0.55, h: 4.3 });
  }
  boxes.push({ x0, x1, z0, z1, h: H });
}
function buildEstateAgency(WORLD, cx, cz) {
  const G = WORLD.g(), x0 = cx - 18, x1 = cx + 18, z0 = cz - 4, z1 = cz + 18, H = 10;
  G.box(cx - 31, 0.16, cz - 31, cx + 31, 0.2, cz - 4, [0.7, 0.72, 0.74, 1], false, true);
  G.box(x0, 0.16, z0, x1, H, z1, [0.94, 0.94, 0.96, 1], true, true);
  G.box(x0 - 0.5, H, z0 - 0.5, x1 + 0.5, H + 0.9, z1 + 0.5, [0.2, 0.4, 0.75, 1], false, true);
  G.box(x0 + 2, 0.4, z0 - 0.3, cx - 4, 6, z0, [0.55, 0.78, 0.95, 1], false, true);
  G.box(cx + 4, 0.4, z0 - 0.3, x1 - 2, 6, z0, [0.55, 0.78, 0.95, 1], false, true);
  G.box(cx - 2, 0.2, z0 - 0.4, cx + 2, 3.6, z0, [0.2, 0.4, 0.75, 1], false, true);
  G.box(cx - 12, 6.6, z0 - 0.6, cx + 12, 9.2, z0, [0.2, 0.4, 0.75, 1], false, true);
  G.box(cx - 10, 7, z0 - 0.8, cx + 10, 8.8, z0 - 0.6, [1, 1, 1, 1], false, true);
  G.box(cx - 3, H + 0.9, cz + 3, cx + 3, H + 4.4, cz + 9, [0.95, 0.8, 0.3, 1], false, true);    // значок «домик» на крыше
  G.cone(cx, H + 4.4, cz + 6, 5, 4, 4, [0.85, 0.25, 0.2]);
  for (const sx of [-12, 12]) {                                                                   // таблички «Продаётся»
    G.box(cx + sx - 0.1, 0.2, z0 - 6, cx + sx + 0.1, 2.4, z0 - 5.8, [0.5, 0.5, 0.55, 1], false, true);
    G.box(cx + sx - 1.4, 1.6, z0 - 6.2, cx + sx + 1.4, 2.8, z0 - 6, [0.85, 0.15, 0.15, 1], false, true);
  }
  boxes.push({ x0, x1, z0, z1, h: H });
}
function buildPropertyBuilding(WORLD, cx, cz, p) {
  const G = WORLD.g(), dark = [0.14, 0.14, 0.17, 1], glass = [0.55, 0.78, 0.95, 1], z0 = cz - 4;
  G.box(cx - 28.8, 0.16, cz - 28.8, cx + 28.8, 0.2, cz + 28.8, [0.25, 0.52, 0.27, 1], false, true);                // газон
  G.box(cx - 28.8, 0.2, cz - 28.8, cx + 28.8, 0.22, cz - 4, [0.55, 0.55, 0.58, 1], false, true);                 // подъезд
  G.box(cx - 1.6, 0.22, cz - 28.8, cx + 1.6, 0.25, cz - 4, [0.72, 0.65, 0.5, 1], false, true);
  let x0, x1, z1, H;
  if (p.id === 'flat') {
    x0 = cx - 17; x1 = cx + 17; z1 = cz + 20; H = 17;
    G.box(x0, 0.16, z0, x1, H, z1, [0.82, 0.74, 0.64, 1], true, true);
    G.box(x0 - 0.6, H, z0 - 0.6, x1 + 0.6, H + 1, z1 + 0.6, [0.4, 0.3, 0.28, 1], false, true);
    for (let f = 0; f < 3; f++) for (let k = -3; k <= 3; k++) { if (f === 0 && Math.abs(k) < 2) continue; G.box(cx + k * 4.4 - 1.4, 3.8 + f * 4.4, z0 - 0.3, cx + k * 4.4 + 1.4, 6.2 + f * 4.4, z0, glass, false, true); G.box(cx + k * 4.4 - 1.8, 3.6 + f * 4.4, z0 - 1.4, cx + k * 4.4 + 1.8, 3.9 + f * 4.4, z0, [0.3, 0.3, 0.34, 1], false, true); }
  } else if (p.id === 'house') {
    x0 = cx - 15; x1 = cx + 15; z1 = cz + 16; H = 8;
    G.box(x0, 0.16, z0, x1, H, z1, [0.9, 0.86, 0.76, 1], true, true);
    G.box(x0 - 1, H, z0 - 1, x1 + 1, H + 0.7, z1 + 1, [0.45, 0.2, 0.16, 1], false, true);
    G.box(x0 + 3, H + 0.7, z0 + 1, x1 - 3, H + 2.2, z1 - 1, [0.5, 0.22, 0.18, 1], false, true);
    G.box(x0 + 6, H + 2.2, z0 + 3, x1 - 6, H + 3.6, z1 - 3, [0.55, 0.25, 0.2, 1], false, true);
    G.box(x0 + 2, 2.2, z0 - 0.3, x0 + 6, 5.6, z0, glass, false, true);
    G.box(cx - 2, 0.2, z0 - 0.4, cx + 2, 3.4, z0, [0.4, 0.22, 0.12, 1], false, true);
  } else if (p.id === 'villa') {
    x0 = cx - 24; x1 = cx + 24; z1 = cz + 22; H = 10;
    G.box(x0, 0.16, z0, x1, H, z1, [0.97, 0.95, 0.9, 1], true, true);
    G.box(x0 - 1, H, z0 - 1, x1 + 1, H + 1, z1 + 1, [0.7, 0.45, 0.3, 1], false, true);
    for (let k = -2; k <= 2; k++) { G.box(cx + k * 6 - 0.8, 0.2, z0 - 4, cx + k * 6 + 0.8, H - 0.5, z0 - 2.4, [1, 1, 1, 1], false, true); }
    G.box(cx - 15, H - 0.5, z0 - 4.6, cx + 15, H + 0.6, z0, [0.9, 0.88, 0.82, 1], false, true);
    G.box(cx - 2.5, 0.2, z0 - 0.4, cx + 2.5, 4.2, z0, [0.3, 0.2, 0.12, 1], false, true);
  } else if (p.park) {
    x0 = cx - 23; x1 = cx + 23; z1 = cz + 20; H = 8;
    G.box(x0, 0.16, z0, x1, H, z1, p.col.concat([1]), true, true);
    G.box(x0 - 0.6, H, z0 - 0.6, x1 + 0.6, H + 0.8, z1 + 0.6, [0.2, 0.2, 0.24, 1], false, true);
    G.box(x0, H - 2.4, z0 - 0.5, x1, H - 0.4, z0, p.col2.concat([1]), false, true);                       // вывеска-лента
    for (let k = 0; k < 4; k++) { const dx = x0 + 5 + k * 11; G.box(dx - 3.6, 0.2, z0 - 0.35, dx + 3.6, 4.6, z0, [0.72, 0.74, 0.78, 1], false, true); for (let s = 0; s < 5; s++) G.box(dx - 3.6, 0.7 + s * 0.8, z0 - 0.45, dx + 3.6, 0.78 + s * 0.8, z0 - 0.35, [0.5, 0.52, 0.56, 1], false, true); }
    for (let k = 0; k < 8; k++) G.box(cx - 24 + k * 6.6, 0.22, cz - 24, cx - 23.8 + k * 6.6, 0.24, cz - 8, [0.95, 0.85, 0.25, 1], false, true);   // разметка парковки
    G.box(cx + 18, H + 0.8, cz + 2, cx + 18.8, H + 7, cz + 2.8, [0.7, 0.7, 0.72, 1], false, true);
  } else {
    x0 = cx - 17; x1 = cx + 17; z1 = cz + 22; H = 62;
    G.box(x0, 0.16, z0, x1, H, z1, [0.28, 0.46, 0.66, 1], true, true);
    for (let f = 0; f < 11; f++) G.box(x0 - 0.1, 5 + f * 5, z0 - 0.3, x1 + 0.1, 5.4 + f * 5, z0, [0.7, 0.85, 0.98, 1], false, true);
    G.box(x0 + 3, H, z0 + 3, x1 - 3, H + 5, z1 - 3, [0.95, 0.8, 0.3, 1], false, true);
    { const hy = H + 5, pz = cz + 9, w = [1, 1, 1, 1], yl = [1, 0.85, 0.15, 1];
      G.box(cx - 7, hy, pz - 7, cx + 7, hy + 0.12, pz + 7, [0.24, 0.24, 0.27, 1], false, true);
      G.box(cx - 7, hy + 0.12, pz - 7, cx + 7, hy + 0.15, pz - 6.6, w, false, true); G.box(cx - 7, hy + 0.12, pz + 6.6, cx + 7, hy + 0.15, pz + 7, w, false, true);
      G.box(cx - 7, hy + 0.12, pz - 6.6, cx - 6.6, hy + 0.15, pz + 6.6, w, false, true); G.box(cx + 6.6, hy + 0.12, pz - 6.6, cx + 7, hy + 0.15, pz + 6.6, w, false, true);
      G.box(cx - 2.4, hy + 0.12, pz - 3, cx - 1.6, hy + 0.17, pz + 3, yl, false, true); G.box(cx + 1.6, hy + 0.12, pz - 3, cx + 2.4, hy + 0.17, pz + 3, yl, false, true); G.box(cx - 2.4, hy + 0.12, pz - 0.4, cx + 2.4, hy + 0.17, pz + 0.4, yl, false, true);
      for (const sx of [-6.4, 6.4]) for (const sz of [-6.4, 6.4]) G.box(cx + sx - 0.25, hy + 0.12, pz + sz - 0.25, cx + sx + 0.25, hy + 0.7, pz + sz + 0.25, [1, 0.2, 0.2, 1], false, true);
      G.box(cx + 12, hy, cz + 1, cx + 12.8, hy + 11, cz + 1.8, [0.7, 0.7, 0.72, 1], false, true); }
    G.box(cx - 8, 4.4, z0 - 6, cx + 8, 4.9, z0, [0.95, 0.8, 0.3, 1], false, true);
    G.box(cx - 8, 0.2, z0 - 6, cx - 7.4, 4.4, z0 - 5.4, [0.9, 0.9, 0.92, 1], false, true);
    G.box(cx + 7.4, 0.2, z0 - 6, cx + 8, 4.4, z0 - 5.4, [0.9, 0.9, 0.92, 1], false, true);
  }
  // гаражная дверь с жёлтым кантом (справа от входа)
  const gx = cx + (p.id === 'villa' ? 14 : 8.5), gw = p.id === 'tower' ? 4.5 : 4.2;
  G.box(gx - gw, 0.2, z0 - 0.45, gx + gw, 3.8, z0, [0.7, 0.72, 0.76, 1], false, true);
  for (let s = 0; s < 4; s++) G.box(gx - gw, 0.8 + s * 0.85, z0 - 0.55, gx + gw, 0.9 + s * 0.85, z0 - 0.45, [0.5, 0.52, 0.56, 1], false, true);
  G.box(gx - gw - 0.3, 3.8, z0 - 0.6, gx + gw + 0.3, 4.1, z0, [0.95, 0.75, 0.15, 1], false, true);
  boxes.push(p.id === 'tower' ? { x0, x1, z0, z1, h: H + 5, hl: H, up: { x0: x0 + 3, x1: x1 - 3, z0: z0 + 3, z1: z1 - 3, h: H + 5 }, nt: true } : { x0, x1, z0, z1, h: H, nt: true });
}
const GARAGE_INT = { x: INX + 1800, z: INZ };
function bayPos(i) {
  const row = Math.floor(i / 10), k = i % 10, side = k < 5 ? -1 : 1, kk = k % 5;   // 4 ряда по 10 мест (v48)
  return { x: side * (5.4 + kk * 4.8), z: [5.4, -5.2, 13.2, 23.8][row], h: [Math.PI, 0, 0, Math.PI][row] };
}
function bayFront(i) { const p = bayPos(i); return p.z + (p.h > 1 ? -2.6 : 2.6); }          // линия «носа» машины
function bayMarkZ(i) { const p = bayPos(i); return bayFront(i) + (p.h > 1 ? -0.9 : 1.0); }
function buildGarageInterior(OX, OZ) {
  const S1 = new GeoSet(), S2 = new GeoSet();
  const B = (x0, y0, z0, x1, y1, z1, c, coll) => {
    S1.g().box(OX + x0, y0, OZ + z0, OX + x1, y1, OZ + z1, c.length === 3 ? c.concat([1]) : c, false, true);
    if (coll) boxes.push({ x0: OX + x0, x1: OX + x1, z0: OZ + z0, z1: OZ + z1, h: y1 });
  };
  const GL = (x0, y0, z0, x1, y1, z1, c) => S2.g().box(OX + x0, y0, OZ + z0, OX + x1, y1, OZ + z1, c.concat([1]), false, true);
  const wall = [0.3, 0.31, 0.35];
  B(-90, -0.4, -90, 90, -0.05, 90, [0.04, 0.04, 0.06]);
  B(-28, -0.2, -8, 28, 0, 28, [0.4, 0.41, 0.45]);
  B(-28.6, -0.2, 28, 28.6, 3.8, 28.6, wall, true); B(-28.6, -0.2, -8.6, 28.6, 3.8, -8, wall, true);
  B(-28.6, -0.2, -8, -28, 3.8, 28, wall, true); B(28, -0.2, -8, 28.6, 3.8, 28, wall, true);
  B(-28, 0, 27.9, 28, 0.3, 28, [0.12, 0.12, 0.14]); B(-28, 0, -8, 28, 0.3, -7.9, [0.12, 0.12, 0.14]);
  for (let i = 0; i < GARAGE_BAYS; i++) {
    const p = bayPos(i);
    for (const sx of [-2.35, 2.35]) B(p.x + sx - 0.05, 0, p.z - 2.6, p.x + sx + 0.05, 0.012, p.z + 2.6, [0.95, 0.8, 0.2]);
    B(p.x - 2.35, 0, bayFront(i) - 0.05, p.x + 2.35, 0.012, bayFront(i) + 0.05, [0.95, 0.8, 0.2]);
  }
  B(-27, 0, -0.06, 27, 0.01, 0.06, [0.9, 0.9, 0.9]); B(-27, 0, 18.44, 27, 0.01, 18.56, [0.9, 0.9, 0.9]); B(-27, 0, 8.5, 27, 0.01, 8.62, [0.35, 0.36, 0.4]);
  GL(-26, 2.5, 27.93, 26, 2.9, 27.98, [0.5, 0.82, 1]); GL(-26, 2.5, -7.98, -3, 2.9, -7.93, [0.5, 0.82, 1]); GL(3, 2.5, -7.98, 26, 2.9, -7.93, [0.5, 0.82, 1]);
  GL(-27.97, 1.4, -4, -27.92, 2.6, 4, [1, 0.35, 0.8]); GL(27.92, 1.4, -4, 27.97, 2.6, 4, [0.2, 0.9, 1]);
  B(-1.7, 0, -8.0, 1.7, 3.0, -7.9, [0.95, 0.95, 0.92]); B(-1.3, 0, -8.0, 1.3, 2.75, -7.78, [0.38, 0.22, 0.12]); B(0.8, 1.2, -7.85, 1.0, 1.4, -7.7, [0.95, 0.8, 0.2]);
  return { lit: S1.done(), glow: S2.done() };
}

/* ---- Дом игрока: фасад ---- */
function buildHomeExterior(WORLD, cx, cz, R, greens) {
  const G = WORLD.g(), wall = [0.88, 0.62, 0.45, 1], roof = [0.55, 0.16, 0.14, 1], fence = [0.93, 0.93, 0.9, 1];
  G.box(cx - 28.8, 0.16, cz - 28.8, cx + 28.8, 0.2, cz + 28.8, [0.24, 0.52, 0.26, 1], false, true);                 // газон
  G.box(cx - 1.6, 0.2, cz - 28.8, cx + 1.6, 0.23, cz - 10, [0.72, 0.65, 0.5, 1], false, true);                  // дорожка к двери
  G.box(cx - 18, 0.2, cz - 10, cx + 18, 0.22, cz - 6, [0.5, 0.5, 0.53, 1], false, true);                       // площадка
  G.box(cx - 18, 0.2, cz - 10, cx + 18, 7.5, cz + 16, wall, true, true);                                      // стены 36x26
  G.box(cx - 19, 7.5, cz - 11, cx + 19, 8.4, cz + 17, roof, false, true);                                     // крыша
  G.box(cx - 14, 8.4, cz - 7, cx + 14, 9.9, cz + 13, roof, false, true);
  G.box(cx - 9, 9.9, cz - 3, cx + 9, 11.2, cz + 9, roof, false, true);
  G.box(cx + 6, 11.2, cz - 1, cx + 8, 13.6, cz + 1, [0.55, 0.3, 0.25, 1], false, true);                       // труба
  G.box(cx - 2.0, 0.2, cz - 10.3, cx + 2.0, 3.4, cz - 10.0, [0.95, 0.95, 0.92, 1], false, true);              // рама двери
  G.box(cx - 1.6, 0.2, cz - 10.6, cx + 1.6, 3.1, cz - 10.02, [0.36, 0.2, 0.1, 1], false, true);               // дверь
  G.box(cx + 1.0, 1.4, cz - 10.75, cx + 1.3, 1.7, cz - 10.55, [0.95, 0.8, 0.2, 1], false, true);             // ручка
  G.box(cx + 9, 0.2, cz - 10.5, cx + 17, 4.0, cz - 10.0, [0.7, 0.72, 0.76, 1], false, true);                   // гаражные ворота
  for (let s = 0; s < 4; s++) G.box(cx + 9, 0.8 + s * 0.85, cz - 10.65, cx + 17, 0.9 + s * 0.85, cz - 10.5, [0.5, 0.52, 0.56, 1], false, true);
  G.box(cx + 8.7, 4.0, cz - 10.7, cx + 17.3, 4.3, cz - 10.0, [0.95, 0.75, 0.15, 1], false, true);
  G.box(cx - 3.5, 0.2, cz - 12.4, cx + 3.5, 0.5, cz - 10.0, [0.62, 0.62, 0.65, 1], false, true);              // крыльцо
  G.box(cx - 3.5, 3.4, cz - 12.4, cx + 3.5, 3.7, cz - 10.0, roof, false, true);                               // козырёк
  G.box(cx - 3.5, 0.5, cz - 12.4, cx - 3.2, 3.4, cz - 12.1, fence, false, true);
  G.box(cx + 3.2, 0.5, cz - 12.4, cx + 3.5, 3.4, cz - 12.1, fence, false, true);
  G.box(cx - 24, 0.2, cz - 25, cx - 23.7, 1.4, cz - 24.7, [0.35, 0.35, 0.4, 1], false, true);                  // почтовый ящик
  G.box(cx - 24.3, 1.4, cz - 25.3, cx - 23.4, 1.9, cz - 24.4, [0.8, 0.15, 0.15, 1], false, true);
  // забор с калиткой
  const F = (x0, z0, x1, z1) => { G.box(x0, 0.2, z0, x1, 1.1, z1, fence, false, true); boxes.push({ x0, x1, z0, z1, h: 1.1 }); };
  F(cx - 28.5, cz - 28.5, cx - 2.6, cz - 28.25); F(cx + 2.6, cz - 28.5, cx + 28.5, cz - 28.25);
  F(cx - 28.5, cz - 28.5, cx - 28.25, cz + 28.5); F(cx + 28.25, cz - 28.5, cx + 28.5, cz + 28.5);
  F(cx - 28.5, cz + 28.25, cx + 28.5, cz + 28.5);
  // стены дома — препятствие
  boxes.push({ x0: cx - 18, x1: cx + 18, z0: cz - 10, z1: cz + 16, h: 11 });
  // деревья во дворе
  const T = [[-24, -20], [24, -20], [-25, 22], [25, 22], [-24, 2], [24, 2]];
  for (const t of T) {
    const tx = cx + t[0], tz = cz + t[1], g = greens[Math.floor(R() * 3)], h = 4 + R() * 2, w = 2 + R() * 0.8, GG = WORLD.g();
    GG.box(tx - 0.25, 0.2, tz - 0.25, tx + 0.25, 1.9, tz + 0.25, [0.4, 0.27, 0.16, 1], false, true);
    GG.cone(tx, 1.5, tz, w, h * 0.65, 7, g);
    GG.cone(tx, 1.5 + h * 0.4, tz, w * 0.72, h * 0.6, 7, [g[0] * 1.1, g[1] * 1.1, g[2] * 1.1]);
    circles.push({ x: tx, z: tz, r: 0.8 });
  }
}
/* ---- Дом игрока: интерьер (стоит далеко от города) ---- */
function buildInterior() {
  const S1 = new GeoSet(), S2 = new GeoSet();   // S1 — освещаемая геометрия, S2 — светящиеся панели
  const B = (x0, y0, z0, x1, y1, z1, c, coll) => {
    S1.g().box(INX + x0, y0, INZ + z0, INX + x1, y1, INZ + z1, c.length === 3 ? c.concat([1]) : c, false, true);
    if (coll) boxes.push({ x0: INX + x0, x1: INX + x1, z0: INZ + z0, z1: INZ + z1, h: y1 });
  };
  const GL = (x0, y0, z0, x1, y1, z1, c) => S2.g().box(INX + x0, y0, INZ + z0, INX + x1, y1, INZ + z1, c.concat([1]), false, true);
  const wood = [0.55, 0.38, 0.22], dark = [0.2, 0.14, 0.1], wallC = [0.88, 0.82, 0.72];
  B(-70, -0.4, -70, 70, -0.05, 70, [0.04, 0.04, 0.06]);               // тёмный фон вокруг
  B(-10, -0.2, -8, 10, 0, 8, [0.64, 0.47, 0.32]);                      // пол
  for (let i = -9; i <= 9; i += 2) B(i - 0.03, 0, -8, i + 0.03, 0.005, 8, [0.5, 0.35, 0.22]);   // доски
  S1.g().flat(INX - 4.4, INZ - 0.4, INX + 4.4, INZ + 5.4, 0.02, [0.55, 0.16, 0.2, 1]);          // ковёр
  S1.g().flat(INX - 3.9, INZ + 0.1, INX + 3.9, INZ + 4.9, 0.025, [0.78, 0.65, 0.3, 1]);
  B(-10.6, -0.2, 8, 10.6, 3.4, 8.6, wallC, true); B(-10.6, -0.2, -8.6, 10.6, 3.4, -8, wallC, true);
  B(-10.6, -0.2, -8, -10, 3.4, 8, wallC, true); B(10, -0.2, -8, 10.6, 3.4, 8, wallC, true);
  B(-10, 0, 7.9, 10, 0.3, 8, dark); B(-10, 0, -8, 10, 0.3, -7.9, dark);
  // кровать
  B(-9.4, 0, 4.0, -5.0, 0.45, 7.9, [0.35, 0.22, 0.12], true); B(-9.3, 0.45, 4.1, -5.1, 0.85, 7.8, [0.93, 0.93, 0.96]);
  B(-9.3, 0.85, 4.1, -5.1, 0.97, 6.3, [0.2, 0.36, 0.72]); B(-9.1, 0.85, 7.0, -7.5, 1.08, 7.7, [1, 1, 1]); B(-7.0, 0.85, 7.0, -5.4, 1.08, 7.7, [1, 1, 1]);
  B(-9.4, 0.45, 7.8, -5.0, 1.8, 7.95, [0.35, 0.22, 0.12]);
  B(-4.6, 0, 6.6, -3.6, 0.6, 7.8, wood, true); B(-4.4, 0.6, 6.8, -3.8, 1.5, 7.4, [0.9, 0.9, 0.7]);   // тумба и лампа
  // гардероб
  B(5.4, 0, 7.0, 9.6, 3.0, 7.9, [0.45, 0.3, 0.18], true); B(7.45, 0.1, 6.92, 7.55, 2.9, 7.0, dark);
  B(7.2, 1.3, 6.88, 7.35, 1.7, 6.95, [0.9, 0.8, 0.3]); B(7.65, 1.3, 6.88, 7.8, 1.7, 6.95, [0.9, 0.8, 0.3]);
  // ТВ-зона
  B(-2.4, 0, 7.0, 2.4, 0.7, 7.9, wood, true); B(-1.7, 0.9, 7.55, 1.7, 2.7, 7.8, [0.04, 0.04, 0.06]);
  GL(-1.55, 1.0, 7.5, 1.55, 2.6, 7.55, [0.3, 0.5, 0.85]);
  // диван и стол
  B(-3.2, 0, 1.0, 3.2, 0.55, 2.7, [0.25, 0.36, 0.56], true); B(-3.2, 0.55, 1.0, 3.2, 1.5, 1.35, [0.22, 0.32, 0.5]);
  B(-3.5, 0, 1.0, -3.2, 0.95, 2.7, [0.2, 0.3, 0.48]); B(3.2, 0, 1.0, 3.5, 0.95, 2.7, [0.2, 0.3, 0.48]);
  B(-1.5, 0, 3.6, 1.5, 0.5, 5.0, wood, true); B(-0.4, 0.5, 4.1, 0.4, 0.62, 4.5, [0.9, 0.2, 0.2]);
  // кухня
  B(-9.9, 0, -6.4, -8.6, 1.0, 0.6, [0.78, 0.78, 0.8], true); B(-10, 1.0, -6.5, -8.5, 1.08, 0.7, [0.22, 0.22, 0.26]);
  B(-9.9, 0, -7.8, -8.6, 2.3, -6.5, [0.95, 0.95, 0.97], true); B(-8.65, 1.2, -6.9, -8.58, 1.6, -6.8, [0.4, 0.4, 0.45]);
  // обеденный стол и стулья
  B(3.6, 0.78, -4.8, 7.2, 0.9, -2.2, wood); B(3.8, 0, -4.6, 4.0, 0.78, -4.4, dark); B(6.8, 0, -4.6, 7.0, 0.78, -4.4, dark);
  B(3.8, 0, -2.6, 4.0, 0.78, -2.4, dark); B(6.8, 0, -2.6, 7.0, 0.78, -2.4, dark);
  boxes.push({ x0: INX + 3.6, x1: INX + 7.2, z0: INZ - 4.8, z1: INZ - 2.2, h: 0.9 });
  B(4.2, 0, -5.8, 5.0, 0.5, -5.0, [0.7, 0.3, 0.25]); B(5.8, 0, -5.8, 6.6, 0.5, -5.0, [0.7, 0.3, 0.25]);
  // торшер и растение
  B(4.4, 0, 3.4, 4.6, 1.7, 3.6, [0.4, 0.4, 0.45], true); GL(4.1, 1.7, 3.1, 4.9, 2.25, 3.9, [1, 0.9, 0.6]);
  B(8.6, 0, -7.3, 9.4, 0.6, -6.5, [0.62, 0.32, 0.22], true);
  S1.g().cone(INX + 9, 0.6, INZ - 6.9, 0.95, 2.1, 7, [0.2, 0.55, 0.25]);
  // верстак (гараж)
  B(8.3, 0, -1.4, 9.8, 1.0, 2.6, [0.45, 0.47, 0.52], true); B(8.4, 1.0, -0.6, 9.4, 1.35, 0.6, [0.85, 0.15, 0.15]); B(8.5, 1.0, 1.2, 9.3, 1.12, 2.2, [0.9, 0.9, 0.2]);
  // выход
  B(-1.7, 0, -8.0, 1.7, 3.0, -7.9, [0.95, 0.95, 0.92]); B(-1.3, 0, -8.0, 1.3, 2.75, -7.78, [0.38, 0.22, 0.12]); B(0.8, 1.2, -7.85, 1.0, 1.4, -7.7, [0.95, 0.8, 0.2]);
  // окна (светящиеся панели)
  GL(-6.5, 1.3, 7.93, -3.0, 2.8, 7.98, [0.72, 0.86, 1]); GL(-9.97, 1.4, -5.2, -9.92, 2.8, -1.6, [0.72, 0.86, 1]);
  GL(9.92, 1.4, -2.2, 9.97, 2.8, 2.2, [0.72, 0.86, 1]); GL(-8.2, 1.4, -7.98, -4.2, 2.8, -7.93, [0.72, 0.86, 1]); GL(4.2, 1.4, -7.98, 8.2, 2.8, -7.93, [0.72, 0.86, 1]);
  circles.push({ x: INX + 9, z: INZ - 6.9, r: 0.8 });
  return { lit: S1.done(), glow: S2.done() };
}
function buildAptRoom(OX, OZ, th, opt) {
  const S1 = new GeoSet(), S2 = new GeoSet();   // S1 — освещаемая геометрия, S2 — светящиеся панели
  const B = (x0, y0, z0, x1, y1, z1, c, coll) => {
    S1.g().box(OX + x0, y0, OZ + z0, OX + x1, y1, OZ + z1, c.length === 3 ? c.concat([1]) : c, false, true);
    if (coll) boxes.push({ x0: OX + x0, x1: OX + x1, z0: OZ + z0, z1: OZ + z1, h: y1 });
  };
  const GL = (x0, y0, z0, x1, y1, z1, c) => S2.g().box(OX + x0, y0, OZ + z0, OX + x1, y1, OZ + z1, c.concat([1]), false, true);
  const wood = [0.55, 0.38, 0.22], dark = [0.2, 0.14, 0.1], wallC = th.wl;
  B(-70, -0.4, -70, 70, -0.05, 70, [0.04, 0.04, 0.06]);               // тёмный фон вокруг
  B(-10, -0.2, -8, 10, 0, 8, th.fl);                      // пол
  for (let i = -9; i <= 9; i += 2) B(i - 0.03, 0, -8, i + 0.03, 0.005, 8, th.bd);   // доски
  S1.g().flat(OX - 4.4, OZ - 0.4, OX + 4.4, OZ + 5.4, 0.02, th.c1);          // ковёр
  S1.g().flat(OX - 3.9, OZ + 0.1, OX + 3.9, OZ + 4.9, 0.025, th.c2);
  B(-10.6, -0.2, 8, 10.6, 3.4, 8.6, wallC, true); B(-10.6, -0.2, -8.6, 10.6, 3.4, -8, wallC, true);
  B(-10.6, -0.2, -8, -10, 3.4, 8, wallC, true); B(10, -0.2, -8, 10.6, 3.4, 8, wallC, true);
  B(-10, 0, 7.9, 10, 0.3, 8, dark); B(-10, 0, -8, 10, 0.3, -7.9, dark);
  // кровать
  B(-9.4, 0, 4.0, -5.0, 0.45, 7.9, [0.35, 0.22, 0.12], true); B(-9.3, 0.45, 4.1, -5.1, 0.85, 7.8, [0.93, 0.93, 0.96]);
  B(-9.3, 0.85, 4.1, -5.1, 0.97, 6.3, [0.2, 0.36, 0.72]); B(-9.1, 0.85, 7.0, -7.5, 1.08, 7.7, [1, 1, 1]); B(-7.0, 0.85, 7.0, -5.4, 1.08, 7.7, [1, 1, 1]);
  B(-9.4, 0.45, 7.8, -5.0, 1.8, 7.95, [0.35, 0.22, 0.12]);
  B(-4.6, 0, 6.6, -3.6, 0.6, 7.8, wood, true); B(-4.4, 0.6, 6.8, -3.8, 1.5, 7.4, [0.9, 0.9, 0.7]);   // тумба и лампа
  // гардероб
  B(5.4, 0, 7.0, 9.6, 3.0, 7.9, [0.45, 0.3, 0.18], true); B(7.45, 0.1, 6.92, 7.55, 2.9, 7.0, dark);
  B(7.2, 1.3, 6.88, 7.35, 1.7, 6.95, [0.9, 0.8, 0.3]); B(7.65, 1.3, 6.88, 7.8, 1.7, 6.95, [0.9, 0.8, 0.3]);
  // ТВ-зона
  B(-2.4, 0, 7.0, 2.4, 0.7, 7.9, wood, true); B(-1.7, 0.9, 7.55, 1.7, 2.7, 7.8, [0.04, 0.04, 0.06]);
  GL(-1.55, 1.0, 7.5, 1.55, 2.6, 7.55, [0.3, 0.5, 0.85]);
  // диван и стол
  B(-3.2, 0, 1.0, 3.2, 0.55, 2.7, [0.25, 0.36, 0.56], true); B(-3.2, 0.55, 1.0, 3.2, 1.5, 1.35, [0.22, 0.32, 0.5]);
  B(-3.5, 0, 1.0, -3.2, 0.95, 2.7, [0.2, 0.3, 0.48]); B(3.2, 0, 1.0, 3.5, 0.95, 2.7, [0.2, 0.3, 0.48]);
  B(-1.5, 0, 3.6, 1.5, 0.5, 5.0, wood, true); B(-0.4, 0.5, 4.1, 0.4, 0.62, 4.5, [0.9, 0.2, 0.2]);
  // кухня
  B(-9.9, 0, -6.4, -8.6, 1.0, 0.6, [0.78, 0.78, 0.8], true); B(-10, 1.0, -6.5, -8.5, 1.08, 0.7, [0.22, 0.22, 0.26]);
  B(-9.9, 0, -7.8, -8.6, 2.3, -6.5, [0.95, 0.95, 0.97], true); B(-8.65, 1.2, -6.9, -8.58, 1.6, -6.8, [0.4, 0.4, 0.45]);
  // обеденный стол и стулья
  B(3.6, 0.78, -4.8, 7.2, 0.9, -2.2, wood); B(3.8, 0, -4.6, 4.0, 0.78, -4.4, dark); B(6.8, 0, -4.6, 7.0, 0.78, -4.4, dark);
  B(3.8, 0, -2.6, 4.0, 0.78, -2.4, dark); B(6.8, 0, -2.6, 7.0, 0.78, -2.4, dark);
  boxes.push({ x0: OX + 3.6, x1: OX + 7.2, z0: OZ - 4.8, z1: OZ - 2.2, h: 0.9 });
  B(4.2, 0, -5.8, 5.0, 0.5, -5.0, [0.7, 0.3, 0.25]); B(5.8, 0, -5.8, 6.6, 0.5, -5.0, [0.7, 0.3, 0.25]);
  // торшер и растение
  B(4.4, 0, 3.4, 4.6, 1.7, 3.6, [0.4, 0.4, 0.45], true); GL(4.1, 1.7, 3.1, 4.9, 2.25, 3.9, [1, 0.9, 0.6]);
  B(8.6, 0, -7.3, 9.4, 0.6, -6.5, [0.62, 0.32, 0.22], true);
  S1.g().cone(OX + 9, 0.6, OZ - 6.9, 0.95, 2.1, 7, [0.2, 0.55, 0.25]);
  const up = !!(opt && opt.fl > 1);
  if (!up) {
  B(8.3, 0, -1.4, 9.8, 1.0, 2.6, [0.45, 0.47, 0.52], true); B(8.4, 1.0, -0.6, 9.4, 1.35, 0.6, [0.85, 0.15, 0.15]); B(8.5, 1.0, 1.2, 9.3, 1.12, 2.2, [0.9, 0.9, 0.2]);
  }
  if (!up) {
  B(-1.7, 0, -8.0, 1.7, 3.0, -7.9, [0.95, 0.95, 0.92]); B(-1.3, 0, -8.0, 1.3, 2.75, -7.78, [0.38, 0.22, 0.12]); B(0.8, 1.2, -7.85, 1.0, 1.4, -7.7, [0.95, 0.8, 0.2]);
  }
  // окна (светящиеся панели)
  GL(-6.5, 1.3, 7.93, -3.0, 2.8, 7.98, [0.72, 0.86, 1]); GL(-9.97, 1.4, -5.2, -9.92, 2.8, -1.6, [0.72, 0.86, 1]);
  GL(9.92, 1.4, -2.2, 9.97, 2.8, 2.2, [0.72, 0.86, 1]); GL(-8.2, 1.4, -7.98, -4.2, 2.8, -7.93, [0.72, 0.86, 1]); GL(4.2, 1.4, -7.98, 8.2, 2.8, -7.93, [0.72, 0.86, 1]);
  circles.push({ x: OX + 9, z: OZ - 6.9, r: 0.8 });
  const stairs = (x0, x1, col) => { for (let k = 0; k < 7; k++) B(x0, 0, -7.9 + k * 0.38, x1, 0.3 * (k + 1), -7.9 + (k + 1) * 0.38, col); boxes.push({ x0: OX + x0, x1: OX + x1, z0: OZ - 7.9, z1: OZ - 5.2, h: 2 }); GL(x0 + 0.1, 2.1, -7.85, x1 - 0.1, 2.2, -7.8, [1, 0.85, 0.4]); };
  if (opt && opt.fl < opt.n) stairs(-6.6, -3.8, [0.55, 0.4, 0.28]);
  if (up) stairs(-1.5, 1.5, [0.5, 0.5, 0.56]);
  return { lit: S1.done(), glow: S2.done() };
}
/* ---- Интерьеры: оружейный, автосалон, больница, участок ---- */
const DISPLAY = [['coupe', -7, -3], ['sport', 7, -3], ['super', -7.2, 4.6], ['hyper', 7.2, 4.6]];
/* ---- v23: интерьеры магазина одежды и салона ---- */
function buildClothInterior(B, GL, S1, OX, OZ) {
  const pal = [[0.85, 0.2, 0.3], [0.2, 0.45, 0.85], [0.95, 0.75, 0.15], [0.25, 0.7, 0.45], [0.6, 0.3, 0.75], [0.95, 0.95, 0.95], [0.1, 0.1, 0.12], [1, 0.5, 0.7]];
  const chrome = [0.75, 0.77, 0.8], wood = [0.78, 0.62, 0.45], mir = [0.72, 0.86, 1];
  const rack = (x, z0, len, seed) => {
    B(x - 0.04, 0, z0, x + 0.04, 1.6, z0 + 0.08, chrome); B(x - 0.04, 0, z0 + len - 0.08, x + 0.04, 1.6, z0 + len, chrome);
    B(x - 0.03, 1.55, z0, x + 0.03, 1.62, z0 + len, chrome);
    boxes.push({ x0: OX + x - 0.35, x1: OX + x + 0.35, z0: OZ + z0, z1: OZ + z0 + len, h: 1.6 });
    for (let k = 0; k < Math.floor(len / 0.3) - 1; k++) { const zz = z0 + 0.15 + k * 0.3; B(x - 0.22, 0.6 + (k % 3) * 0.08, zz, x + 0.22, 1.52, zz + 0.14, pal[(k * 3 + seed) % pal.length]); }
  };
  rack(-8.8, -6.2, 3.6, 1); rack(-6.6, -6.2, 3.6, 2); rack(-8.8, -1.8, 3.4, 4); rack(6.2, -6.2, 4.6, 3);
  for (const sx of [-1, 1]) {                                                    // столы со стопками одежды
    const a = sx * 2.4, b = sx * 4.8, lo = Math.min(a, b), hi = Math.max(a, b);
    B(lo, 0, -5.8, hi, 0.8, -4.4, [0.93, 0.88, 0.82], true);
    for (let k = 0; k < 3; k++) B(lo + 0.15 + k * 0.75, 0.8, -5.6 + (k % 2) * 0.3, lo + 0.8 + k * 0.75, 0.8 + 0.12 + k * 0.05, -4.7, pal[(k + (sx > 0 ? 4 : 0)) % pal.length]);
  }
  const mq = (x, z, col, dress) => {
    B(x - 0.4, 0, z - 0.4, x + 0.4, 0.1, z + 0.4, [0.85, 0.85, 0.88]);
    B(x - 0.04, 0.1, z - 0.04, x + 0.04, 1.2, z + 0.04, [0.7, 0.7, 0.74]);
    if (dress) S1.g().cone(OX + x, 0.5, OZ + z, 0.42, 0.85, 9, col);
    else { B(x - 0.15, 0.4, z - 0.07, x - 0.01, 1.0, z + 0.07, [0.2, 0.22, 0.3]); B(x + 0.01, 0.4, z - 0.07, x + 0.15, 1.0, z + 0.07, [0.2, 0.22, 0.3]); }
    B(x - 0.2, 1.0, z - 0.1, x + 0.2, 1.5, z + 0.1, col);
    B(x - 0.035, 1.5, z - 0.035, x + 0.035, 1.58, z + 0.035, [0.9, 0.88, 0.85]);
    B(x - 0.1, 1.58, z - 0.1, x + 0.1, 1.8, z + 0.1, [0.92, 0.9, 0.86]);
    circles.push({ x: OX + x, z: OZ + z, r: 0.5 });
  };
  mq(-5.8, 4.6, [0.9, 0.25, 0.45], true); mq(5.8, 4.2, [0.2, 0.45, 0.85], false); mq(-3.6, 5.4, [0.95, 0.75, 0.2], true);
  // зеркало и подиум
  GL(-9.97, 0.5, 3.0, -9.92, 2.7, 6.0, mir); B(-9.0, 0, 3.2, -7.4, 0.25, 5.8, [0.95, 0.6, 0.78]);
  // примерочные
  const part = [0.93, 0.82, 0.86], cur = [0.85, 0.25, 0.5];
  B(8.3, 0, -6.2, 10, 2.5, -6.1, part, true); B(8.3, 0, -3.4, 10, 2.5, -3.3, part, true); B(8.3, 0, -0.6, 10, 2.5, -0.5, part, true);
  B(8.25, 0.15, -6.1, 8.35, 2.35, -4.7, cur); B(8.25, 0.15, -3.3, 8.35, 2.35, -1.9, [0.4, 0.3, 0.75]);
  GL(9.92, 0.5, -5.6, 9.97, 2.2, -4.0, mir); GL(9.92, 0.5, -2.8, 9.97, 2.2, -1.2, mir);
  // обувная стенка
  B(9.6, 0, 2.6, 9.9, 2.4, 6.9, wood, true);
  const sc = [[0.9, 0.9, 0.92], [0.85, 0.15, 0.2], [0.1, 0.1, 0.12], [0.95, 0.5, 0.7], [0.3, 0.45, 0.85]];
  for (let L = 0; L < 4; L++) { const y = 0.3 + L * 0.6; B(8.9, y, 2.6, 9.6, y + 0.05, 6.9, wood); for (let k = 0; k < 5; k++) B(9.0, y + 0.05, 2.8 + k * 0.8, 9.55, y + 0.24, 3.4 + k * 0.8, sc[(k + L) % 5]); }
  // задняя стена: полки со стопками
  for (let L = 0; L < 3; L++) { const y = 0.5 + L * 0.8; B(-9.5, y, 7.3, 9.5, y + 0.05, 7.9, wood); for (let k = 0; k < 12; k++) B(-9.2 + k * 1.55, y + 0.05, 7.35, -8.0 + k * 1.55, y + 0.35, 7.85, pal[(k + L * 2) % pal.length]); }
  GL(-4, 2.4, 7.93, 4, 3.2, 7.98, [1, 0.45, 0.78]);
  B(9.0, 0, -7.6, 9.8, 0.6, -6.8, [0.62, 0.32, 0.22], true); S1.g().cone(OX + 9.4, 0.6, OZ - 7.2, 0.8, 1.8, 7, [0.2, 0.55, 0.25]);
}
function buildSalonInterior(B, GL, S1, OX, OZ) {
  const red = [0.85, 0.15, 0.22], chrome = [0.75, 0.77, 0.8], mir = [0.72, 0.86, 1], wood = [0.78, 0.62, 0.45];
  for (let i = 0; i < 10; i++) for (let j = 0; j < 8; j++) if ((i + j) % 2 === 0) B(-10 + i * 2, 0, -8 + j * 2, -8 + i * 2, 0.007, -6 + j * 2, [0.2, 0.62, 0.66]);
  const bot = [[0.9, 0.3, 0.5], [0.3, 0.7, 0.9], [0.95, 0.8, 0.2], [0.4, 0.8, 0.5], [0.7, 0.4, 0.9]];
  for (const zc of [-5.4, -2.6, 0.2]) {                                         // кресла у зеркал
    GL(-9.97, 1.0, zc - 1.0, -9.92, 2.9, zc + 1.0, mir);
    B(-9.9, 0.95, zc - 1.1, -9.35, 1.02, zc + 1.1, [0.95, 0.95, 0.96]);
    for (let k = 0; k < 5; k++) B(-9.8, 1.02, zc - 0.9 + k * 0.4, -9.55, 1.2 + (k % 2) * 0.08, zc - 0.7 + k * 0.4, bot[k]);
    B(-9.4, 0.08, zc - 0.35, -8.9, 0.3, zc + 0.35, chrome);
    B(-8.4, 0, zc - 0.2, -8.0, 0.55, zc + 0.2, chrome);
    B(-8.7, 0.55, zc - 0.5, -7.7, 0.8, zc + 0.5, red);
    B(-7.9, 0.8, zc - 0.5, -7.6, 1.75, zc + 0.5, red);
    B(-8.7, 0.8, zc - 0.55, -7.9, 1.05, zc - 0.45, chrome); B(-8.7, 0.8, zc + 0.45, -7.9, 1.05, zc + 0.55, chrome);
    boxes.push({ x0: OX - 9.4, x1: OX - 7.6, z0: OZ + zc - 0.55, z1: OZ + zc + 0.55, h: 1.2 });
  }
  for (const zc of [-5.0, -2.2]) {                                              // мойки
    B(8.6, 0, zc - 0.7, 9.9, 0.85, zc + 0.7, [0.95, 0.95, 0.97], true);
    GL(8.75, 0.85, zc - 0.5, 9.7, 0.88, zc + 0.5, [0.5, 0.82, 0.95]);
    B(9.7, 0.88, zc - 0.05, 9.85, 1.15, zc + 0.05, chrome);
    B(7.3, 0.4, zc - 0.5, 8.4, 0.62, zc + 0.5, [0.15, 0.17, 0.22]); B(6.9, 0.62, zc - 0.5, 7.3, 1.2, zc + 0.5, [0.15, 0.17, 0.22]);
    boxes.push({ x0: OX + 6.9, x1: OX + 8.4, z0: OZ + zc - 0.5, z1: OZ + zc + 0.5, h: 1.2 });
  }
  B(8.0, 0, 3.2, 9.9, 0.5, 6.8, [0.85, 0.4, 0.6], true); B(9.5, 0.5, 3.2, 9.9, 1.1, 6.8, [0.85, 0.4, 0.6]);   // диван
  B(6.6, 0, 4.2, 7.6, 0.45, 5.8, [0.3, 0.2, 0.15], true); B(6.8, 0.45, 4.6, 7.2, 0.48, 5.2, [0.9, 0.9, 0.9]);
  for (let L = 0; L < 3; L++) { const y = 1.0 + L * 0.6; B(-9, y - 0.04, 7.3, 9, y, 7.9, wood); for (let k = 0; k < 16; k++) B(-8.6 + k * 1.1, y, 7.4, -8.3 + k * 1.1, y + 0.28 + ((k + L) % 3) * 0.1, 7.7, bot[(k + L) % 5]); }
  GL(-3, 2.9, 7.93, 3, 3.4, 7.98, [0.3, 0.95, 0.9]); GL(-3, 0.3, 7.93, 3, 0.5, 7.98, [1, 0.45, 0.78]);
  B(-9.6, 0, 6.2, -8.8, 0.6, 7.0, [0.62, 0.32, 0.22], true); S1.g().cone(OX - 9.2, 0.6, OZ + 6.6, 0.8, 1.8, 7, [0.2, 0.55, 0.25]);
}
function buildShopInterior(kind, OX, OZ) {
  const S1 = new GeoSet(), S2 = new GeoSet();
  const B = (x0, y0, z0, x1, y1, z1, c, coll) => {
    S1.g().box(OX + x0, y0, OZ + z0, OX + x1, y1, OZ + z1, c.length === 3 ? c.concat([1]) : c, false, true);
    if (coll) boxes.push({ x0: OX + x0, x1: OX + x1, z0: OZ + z0, z1: OZ + z1, h: y1 });
  };
  const GL = (x0, y0, z0, x1, y1, z1, c) => S2.g().box(OX + x0, y0, OZ + z0, OX + x1, y1, OZ + z1, c.concat([1]), false, true);
  const pal = {
    gun: { fl: [0.3, 0.27, 0.25], wl: [0.4, 0.37, 0.34], ct: [0.35, 0.22, 0.12], tp: [0.2, 0.2, 0.22] },
    car: { fl: [0.8, 0.8, 0.83], wl: [0.93, 0.93, 0.96], ct: [0.2, 0.4, 0.7], tp: [0.95, 0.95, 0.97] },
    hosp: { fl: [0.86, 0.9, 0.92], wl: [0.92, 0.95, 0.97], ct: [0.95, 0.95, 0.97], tp: [0.3, 0.6, 0.85] },
    pol: { fl: [0.4, 0.42, 0.46], wl: [0.3, 0.37, 0.55], ct: [0.3, 0.2, 0.12], tp: [0.55, 0.55, 0.6] },
    tune: { fl: [0.2, 0.21, 0.25], wl: [0.15, 0.16, 0.2], ct: [0.8, 0.35, 0.1], tp: [0.12, 0.12, 0.15] },
    club: { fl: [0.16, 0.12, 0.12], wl: [0.2, 0.14, 0.14], ct: [0.8, 0.45, 0.12], tp: [0.09, 0.08, 0.1] },
    cloth: { fl: [0.9, 0.84, 0.8], wl: [0.98, 0.9, 0.94], ct: [0.95, 0.55, 0.75], tp: [0.99, 0.99, 0.99] },
    salon: { fl: [0.92, 0.93, 0.95], wl: [0.74, 0.9, 0.92], ct: [0.15, 0.62, 0.66], tp: [0.98, 0.98, 0.98] }
  }[kind];
  const dark = [0.12, 0.12, 0.14], wood = [0.45, 0.28, 0.14];
  B(-70, -0.4, -70, 70, -0.05, 70, [0.04, 0.04, 0.06]);
  B(-10, -0.2, -8, 10, 0, 8, pal.fl);
  const st = [pal.fl[0] * 0.8, pal.fl[1] * 0.8, pal.fl[2] * 0.8];
  for (let i = -9; i <= 9; i += 2) B(i - 0.03, 0, -8, i + 0.03, 0.005, 8, st);
  B(-10.6, -0.2, 8, 10.6, 3.4, 8.6, pal.wl, true); B(-10.6, -0.2, -8.6, 10.6, 3.4, -8, pal.wl, true);
  B(-10.6, -0.2, -8, -10, 3.4, 8, pal.wl, true); B(10, -0.2, -8, 10.6, 3.4, 8, pal.wl, true);
  B(-10, 0, 7.9, 10, 0.3, 8, dark); B(-10, 0, -8, 10, 0.3, -7.9, dark);
  // выход
  B(-1.7, 0, -8.0, 1.7, 3.0, -7.9, [0.95, 0.95, 0.92]); B(-1.3, 0, -8.0, 1.3, 2.75, -7.78, [0.38, 0.22, 0.12]); B(0.8, 1.2, -7.85, 1.0, 1.4, -7.7, [0.95, 0.8, 0.2]);
  // окна
  GL(-9.97, 1.4, -5.2, -9.92, 2.8, -1.6, [0.72, 0.86, 1]); GL(9.92, 1.4, -2.2, 9.97, 2.8, 2.2, [0.72, 0.86, 1]);
  // прилавок и продавец
  B(-4.5, 0, 1.2, 4.5, 1.1, 2.4, pal.ct, true); B(-4.7, 1.1, 1.0, 4.7, 1.2, 2.6, pal.tp);
  B(-0.7, 1.2, 1.5, 0.7, 1.28, 2.1, dark);
  circles.push({ x: OX, z: OZ + 3.6, r: 0.7 });
  if (kind === 'gun') {
    B(-9.5, 0, 7.0, 9.5, 0.9, 7.9, [0.25, 0.18, 0.12], true);
    for (let k = 0; k < 6; k++) {
      const x = -8 + k * 3.2;
      B(x, 1.9, 7.78, x + 2.4, 2.02, 7.9, dark); B(x - 0.5, 1.75, 7.78, x + 0.4, 2.1, 7.9, wood); B(x + 0.9, 1.6, 7.78, x + 1.1, 1.9, 7.9, dark);
    }
    for (let k = 0; k < 5; k++) { const z = -6 + k * 2.6; B(-9.95, 1.5, z, -9.55, 1.64, z + 1.8, dark); B(-9.95, 1.3, z + 1.4, -9.6, 1.5, z + 1.7, wood); B(9.55, 1.7, z, 9.95, 1.82, z + 0.7, dark); }
    B(-9, 0, -3.2, -5.4, 1.0, -1.2, [0.3, 0.3, 0.34], true); GL(-8.8, 1.0, -3.0, -5.6, 1.03, -1.4, [0.5, 0.65, 0.8]);
    B(-8.5, 1.03, -2.5, -8.0, 1.12, -2.3, dark); B(-7.6, 1.03, -2.5, -7.1, 1.12, -2.3, dark); B(-6.7, 1.03, -2.5, -6.2, 1.12, -2.3, dark);
    B(7, 0, -6.3, 9, 0.9, -4.4, [0.4, 0.45, 0.28], true); B(7.5, 0.9, -6.0, 8.8, 1.5, -4.8, [0.45, 0.5, 0.3]);
    B(4.5, 1.2, -7.98, 6.5, 2.9, -7.9, [0.9, 0.9, 0.9]); B(4.9, 1.6, -7.9, 6.1, 2.5, -7.85, [0.85, 0.1, 0.1]); B(5.3, 1.9, -7.85, 5.7, 2.2, -7.8, [1, 1, 1]);
    GL(-3, 2.5, 7.93, 3, 3.2, 7.98, [0.9, 0.2, 0.15]);
  } else if (kind === 'car') {
    B(-1.5, 0, -8, 1.5, 0.006, 0.9, [0.2, 0.4, 0.7]);
    for (const d of DISPLAY) {
      B(d[1] - 2.8, 0, d[2] - 2.8, d[1] + 2.8, 0.2, d[2] + 2.8, [0.25, 0.28, 0.36]);
      boxes.push({ x0: OX + d[1] - 2.3, x1: OX + d[1] + 2.3, z0: OZ + d[2] - 2.3, z1: OZ + d[2] + 2.3, h: 1.5 });
      GL(d[1] - 2.8, 0.2, d[2] - 2.8, d[1] + 2.8, 0.24, d[2] - 2.7, [0.3, 0.6, 1]);
    }
    GL(-4, 2.4, 7.93, 4, 3.2, 7.98, [0.1, 0.7, 0.35]);
    B(-2.5, 1.4, 7.85, 2.5, 2.2, 7.9, [0.3, 0.3, 0.35]); B(-2.2, 1.6, 7.8, -1.6, 2.0, 7.85, [0.9, 0.8, 0.2]); B(1.6, 1.6, 7.8, 2.2, 2.0, 7.85, [0.9, 0.8, 0.2]);
    B(9, 0, -7.2, 9.6, 0.5, -6.6, [0.62, 0.32, 0.22], true); S1.g().cone(OX + 9.3, 0.5, OZ - 6.9, 0.8, 1.8, 7, [0.2, 0.55, 0.25]);
  } else if (kind === 'hosp') {
    B(-0.3, 0, -8, 0.3, 0.006, 0.9, [0.2, 0.7, 0.4]);
    for (const dz of [0, 4.8]) {
      B(-9.4, 0, -6.2 + dz, -7, 0.45, -3.6 + dz, [0.8, 0.82, 0.86], dz === 0);
      B(-9.3, 0.45, -6.1 + dz, -7.1, 0.7, -3.7 + dz, [1, 1, 1]); B(-9.3, 0.7, -5.2 + dz, -7.1, 0.78, -3.7 + dz, [0.3, 0.6, 0.85]); B(-9.1, 0.7, -6.0 + dz, -7.3, 0.82, -5.4 + dz, [1, 1, 1]);
    }
    boxes.push({ x0: OX - 9.4, x1: OX - 7, z0: OZ - 1.4, z1: OZ + 1.2, h: 0.8 });
    B(-6.6, 0, -4.0, -6.5, 1.9, -3.9, [0.6, 0.6, 0.65]); GL(-6.8, 1.5, -4.0, -6.3, 1.95, -3.95, [0.6, 0.9, 1]);
    for (const z of [-6, -2.5]) { B(6.2, 0, z, 9.6, 0.5, z + 1, [0.2, 0.5, 0.8], true); B(6.2, 0.5, z, 9.6, 1.1, z + 0.2, [0.2, 0.5, 0.8]); }
    GL(-0.4, 1.4, 7.93, 0.4, 3.2, 7.98, [0.9, 0.1, 0.12]); GL(-1.2, 2.0, 7.93, 1.2, 2.6, 7.98, [0.9, 0.1, 0.12]);
    B(5.5, 0, 7.0, 9.5, 2.4, 7.9, [0.9, 0.92, 0.95], true); GL(5.7, 0.4, 6.93, 9.3, 2.2, 7.0, [0.7, 0.9, 1]);
    for (let k = 0; k < 6; k++) B(5.8 + k * 0.6, 1.0, 6.88, 6.1 + k * 0.6, 1.4, 6.93, k % 2 ? [0.9, 0.3, 0.3] : [0.3, 0.7, 0.9]);
    B(-9.6, 0, 6.6, -8.8, 0.6, 7.4, [0.62, 0.32, 0.22], true); S1.g().cone(OX - 9.2, 0.6, OZ + 7.0, 0.8, 1.8, 7, [0.2, 0.55, 0.25]);
  } else if (kind === 'tune') {
    B(3.6, 0, -5.6, 9.4, 0.62, -0.2, [0.3, 0.32, 0.38], true); B(3.4, 0.62, -5.8, 9.6, 0.7, 0.0, [0.9, 0.55, 0.1]);        // подъёмник-платформа
    GL(3.4, 0.0, -5.85, 9.6, 0.05, -5.8, [1, 0.2, 0.8]); GL(3.4, 0.0, -0.05, 9.6, 0.05, 0.0, [0.1, 0.9, 1]);
    B(-9.7, 0, -5.4, -7.6, 1.0, -0.4, [0.16, 0.17, 0.2], true);                                                          // верстак
    B(-9.6, 1.0, -4.6, -7.8, 1.5, -3.2, [0.9, 0.2, 0.15]); B(-9.6, 1.0, -2.0, -8.2, 1.2, -0.8, [0.7, 0.72, 0.78]);
    for (let k = 0; k < 4; k++) B(-9.5, 0 + k * 0.6, 4.8, -7.5, 0.55 + k * 0.6, 6.9, [0.07, 0.07, 0.08], true);          // стопка шин
    B(-6.4, 0, 6.2, -3.4, 2.2, 7.5, [0.2, 0.22, 0.26], true);
    for (let k = 0; k < 3; k++) B(-6.2, 0.4 + k * 0.7, 6.1, -3.6, 0.9 + k * 0.7, 6.2, [0.45, 0.5, 0.6]);
    B(5.5, 0, 6.6, 8.8, 1.0, 7.7, [0.28, 0.3, 0.34], true);
    GL(-5.5, 2.3, 7.93, 5.5, 3.1, 7.98, [1, 0.5, 0.1]); GL(-9.97, 1.4, 1.0, -9.92, 2.8, 4.0, [1, 0.2, 0.8]); GL(9.92, 1.4, 3.0, 9.97, 2.8, 6.0, [0.1, 0.9, 1]);
    GL(-9.6, 3.0, -7.98, -1.9, 3.3, -7.93, [1, 0.2, 0.8]); GL(1.9, 3.0, -7.98, 9.6, 3.3, -7.93, [0.1, 0.9, 1]);
  } else if (kind === 'cloth') {
    buildClothInterior(B, GL, S1, OX, OZ);
  } else if (kind === 'salon') {
    buildSalonInterior(B, GL, S1, OX, OZ);
  } else if (kind === 'club') {
    buildClubInterior(B, GL, kind);
  } else {
    B(-9.5, 0, -4.2, -6.5, 0.9, -1.6, [0.3, 0.2, 0.12], true); B(-8.5, 0.9, -3.0, -7.5, 1.55, -2.9, dark); GL(-8.4, 1.0, -3.04, -7.6, 1.5, -3.0, [0.3, 0.9, 0.6]);
    for (let k = 0; k < 8; k++) B(4.7 + k * 0.62, 0, 3.0, 4.8 + k * 0.62, 2.6, 3.1, [0.18, 0.18, 0.2]);
    for (let k = 0; k < 5; k++) B(4.5, 0, 3.1 + k * 0.9, 4.6, 2.6, 3.2 + k * 0.9, [0.18, 0.18, 0.2]);
    B(4.5, 2.5, 3.0, 9.6, 2.6, 3.1, [0.18, 0.18, 0.2]);
    boxes.push({ x0: OX + 4.5, x1: OX + 9.6, z0: OZ + 2.95, z1: OZ + 3.15, h: 2.6 }); boxes.push({ x0: OX + 4.45, x1: OX + 4.65, z0: OZ + 3, z1: OZ + 7.6, h: 2.6 });
    B(7, 0, 6.4, 9.6, 0.5, 7.8, [0.4, 0.4, 0.43], true);
    B(-8, 1.4, 7.85, -4, 3.0, 7.95, [0.55, 0.4, 0.25]); B(-7.6, 2.0, 7.78, -7.0, 2.6, 7.85, [0.95, 0.95, 0.9]); B(-6.2, 1.8, 7.78, -5.4, 2.7, 7.85, [0.9, 0.85, 0.6]); B(-4.9, 2.1, 7.78, -4.3, 2.7, 7.85, [0.9, 0.5, 0.5]);
    GL(-2.5, 2.4, 7.93, 2.5, 3.1, 7.98, [0.25, 0.4, 0.95]);
    B(6.2, 0, -6, 9.6, 0.5, -5, [0.3, 0.3, 0.34], true); B(9.4, 0, -3.5, 9.9, 2.2, -0.5, [0.35, 0.4, 0.5], true);
    B(-9.6, 0, 5.5, -9.0, 2.4, 5.62, [0.8, 0.8, 0.82]); B(-9.5, 1.4, 5.62, -9.1, 2.3, 5.7, [0.2, 0.3, 0.8]);
  }
  return { lit: S1.done(), glow: S2.done() };
}
function buildCity() {
  const R = rng(20261025);
  const WSETS = {}, ALWAYS = new GeoSet(), GROUND = new GeoSet(), ROADS = new GeoSet(), DECAL = new GeoSet(), LAMPS = new GeoSet(), LGLOW = new GeoSet();
  const WGET = (bi, bj) => {
    const rx = Math.floor(bi / 4), rz = Math.floor(bj / 4), k = rx + ',' + rz;
    if (!WSETS[k]) WSETS[k] = { set: new GeoSet(), x0: -HALF + rx * 4 * PITCH, x1: -HALF + (rx * 4 + 4) * PITCH, z0: -HALF + rz * 4 * PITCH, z1: -HALF + (rz * 4 + 4) * PITCH };
    return WSETS[k].set;
  };
  const e = HALF + ROAD / 2;
  // асфальт плитками разной яркости
  for (let i = 0; i <= GRID; i++) for (let j = 0; j <= GRID; j++) {
    const x0 = Math.max(-e, nodeC(i) - PITCH / 2), x1 = Math.min(e, nodeC(i) + PITCH / 2);
    const z0 = Math.max(-e, nodeC(j) - PITCH / 2), z1 = Math.min(e, nodeC(j) + PITCH / 2);
    const k = 0.2 + (R() - 0.5) * 0.03;
    ROADS.g().flat(x0, z0, x1, z1, 0, [k, k + 0.008, k + 0.03, 1]);
  }
  GROUND.g().flat(-(EDGE + 14), -(EDGE + 14), EDGE + 14, EDGE + 14, -0.08, [0.27, 0.42, 0.25, 1]);
  const palette = [[0.78, 0.74, 0.68], [0.66, 0.70, 0.76], [0.82, 0.62, 0.52], [0.60, 0.64, 0.62], [0.85, 0.83, 0.78], [0.55, 0.60, 0.70], [0.72, 0.55, 0.50], [0.9, 0.85, 0.7], [0.5, 0.56, 0.64]];
  const greens = [[0.2, 0.5, 0.22], [0.16, 0.42, 0.2], [0.26, 0.55, 0.25]];

  for (let bi = 0; bi < GRID; bi++) { blockType[bi] = []; for (let bj = 0; bj < GRID; bj++) {
    const cx = bc(bi), cz = bc(bj), key = bi + ',' + bj;
    const WORLD = WGET(bi, bj);
    if (METRO_AT[key]) buildMetroEntrance(WORLD, cx, cz, METRO_AT[key]);
    const park = PARKS.has(key);
    blockType[bi][bj] = park ? 'park' : 'city';
    // тротуар
    WORLD.g().box(cx - 32, 0, cz - 32, cx + 32, 0.16, cz + 32, [0.66, 0.66, 0.63, 1], false, true);
    if (park) {
      WORLD.g().box(cx - 29, 0.16, cz - 29, cx + 29, 0.2, cz + 29, [0.22, 0.5, 0.24, 1], false, true);
      // дорожки
      WORLD.g().box(cx - 1.5, 0.2, cz - 29, cx + 1.5, 0.22, cz + 29, [0.7, 0.62, 0.48, 1], false, true);
      WORLD.g().box(cx - 29, 0.2, cz - 1.5, cx + 29, 0.22, cz + 1.5, [0.7, 0.62, 0.48, 1], false, true);
      // фонтан
      WORLD.g().box(cx - 4, 0.2, cz - 4, cx + 4, 0.9, cz + 4, [0.6, 0.6, 0.62, 1], false, true);
      WORLD.g().box(cx - 3.2, 0.9, cz - 3.2, cx + 3.2, 1.0, cz + 3.2, [0.25, 0.55, 0.8, 1], false, true);
      boxes.push({ x0: cx - 4, x1: cx + 4, z0: cz - 4, z1: cz + 4, h: 1 });
      if (BIZ_BLK[key]) buildKiosk(WORLD, cx, cz, BIZ_BLK[key]);
      for (let t = 0; t < 22; t++) {
        const tx = cx + (R() - 0.5) * 54, tz = cz + (R() - 0.5) * 54;
        if (Math.abs(tx - cx) < 4.5 || Math.abs(tz - cz) < 4.5) continue;
        if (BIZ_BLK[key] && (BIZ_BLK[key].id === 'port' || BIZ_BLK[key].id === 'casino')) continue;
        if (BIZ_BLK[key] && tx > cx + 4 && tx < cx + 24 && tz > cz + 4 && tz < cz + 24) continue;
        const g = greens[Math.floor(R() * 3)], h = 3 + R() * 3, w = 1.6 + R() * 1.0;
        const G = WORLD.g();
        G.box(tx - 0.22, 0.2, tz - 0.22, tx + 0.22, 1.8, tz + 0.22, [0.4, 0.27, 0.16, 1], false, true);
        G.cone(tx, 1.4, tz, w, h * 0.65, 7, g);
        G.cone(tx, 1.4 + h * 0.4, tz, w * 0.72, h * 0.6, 7, [g[0] * 1.1, g[1] * 1.1, g[2] * 1.1]);
        circles.push({ x: tx, z: tz, r: 0.7 });
      }
      continue;
    }
    // застройка
    const dist = Math.hypot(bi - (GRID - 1) / 2, bj - (GRID - 1) / 2) / (GRID * 0.69);
    const hMax = lerp(90, 16, clamp(dist, 0, 1));
    let lots = [];
    if (bi === HOME_B && bj === HOME_B) { buildHomeExterior(WORLD, cx, cz, R, greens); }
    else if (bi === HOSP_BLK[0] && bj === HOSP_BLK[1]) buildCivic(WORLD, cx, cz, 'hosp');
    else if (bi === POL_BLK[0] && bj === POL_BLK[1]) buildCivic(WORLD, cx, cz, 'pol');
    else if (SHOP_BLKS.some(q => q.b[0] === bi && q.b[1] === bj)) buildShopBuilding(WORLD, cx, cz, SHOP_BLKS.find(q => q.b[0] === bi && q.b[1] === bj).k);
    else if (STORE_AT[key]) buildStoreBuilding(WORLD, cx, cz, STORE_AT[key]);
    else if (key === TUNE_KEY) buildTuneShop(WORLD, cx, cz);
    else if (key === ESTATE_KEY) buildEstateAgency(WORLD, cx, cz);
    else if (key === CLUB_KEY) buildClubHouse(WORLD, cx, cz);
    else if (CLOTH_AT[key]) buildClothStore(WORLD, cx, cz, CLOTH_AT[key].v);
    else if (SALON_AT[key]) buildSalon(WORLD, cx, cz, SALON_AT[key].v);
    else if (PROP_AT[key]) buildPropertyBuilding(WORLD, cx, cz, PROP_AT[key]);
    else if (indKind(key)) buildIndustrial(WORLD, cx, cz, indKind(key));
    else if (bi === GRID / 2 - 1 && bj === GRID / 2 - 1) lots = [{ x: cx, z: cz, w: 50, d: 50, tower: true }];
    else {
      const r = R();
      if (r < 0.15) lots = [{ x: cx, z: cz, w: 50, d: 50 }];
      else if (r < 0.45) {
        if (R() < 0.5) lots = [{ x: cx - 15, z: cz, w: 26, d: 52 }, { x: cx + 15, z: cz, w: 26, d: 52 }];
        else lots = [{ x: cx, z: cz - 15, w: 52, d: 26 }, { x: cx, z: cz + 15, w: 52, d: 26 }];
      } else lots = [{ x: cx - 15, z: cz - 15, w: 26, d: 26 }, { x: cx + 15, z: cz - 15, w: 26, d: 26 }, { x: cx - 15, z: cz + 15, w: 26, d: 26 }, { x: cx + 15, z: cz + 15, w: 26, d: 26 }];
    }
    for (const lot of lots) {
      const iw = lot.w - R() * 4, id = lot.d - R() * 4;
      const x0 = lot.x - iw / 2, x1 = lot.x + iw / 2, z0 = lot.z - id / 2, z1 = lot.z + id / 2;
      let h = 8 + R() * hMax; if (lot.tower) h = 150;
      const col = lot.tower ? [0.28, 0.42, 0.58, 1] : palette[Math.floor(R() * palette.length)].concat([1]);
      const G = lot.tower ? ALWAYS.g() : WORLD.g();
      G.box(x0, 0.16, z0, x1, h, z1, col, true, true);
      const hl = h; let up = null;
      if (h > 40 && !lot.tower) { // верхний ярус
        const m = 0.18; G.box(x0 + iw * m, h, z0 + id * m, x1 - iw * m, h * 1.22, z1 - id * m, col, true, true);
        h = h * 1.22; up = { x0: x0 + iw * m, x1: x1 - iw * m, z0: z0 + id * m, z1: z1 - id * m, h };
      }
      // крыша: тех. надстройка
      G.box(lot.x - 2, h, lot.z - 2, lot.x + 2, h + 1.8, lot.z + 2, [0.45, 0.45, 0.47, 1], false, true);
      if (lot.tower) { G.box(lot.x - 0.4, h, lot.z - 0.4, lot.x + 0.4, h + 18, lot.z + 0.4, [0.7, 0.7, 0.72, 1], false, true); CITY_TOWER.y = h + 18; CITY_TOWER.x = lot.x; CITY_TOWER.z = lot.z; }
      boxes.push({ x0, x1, z0, z1, h, hl, up });
    }
    // уличные фонари
    const LP = (x, z) => {
      LGLOW.g().discAt(x, 0.25, z, 9, 14, [1, 0.82, 0.5, 0.75], [1, 0.82, 0.5, 0]);
      circles.push({ x, z, r: 0.3 });   // столб — препятствие
      WORLD.g().box(x - 0.09, 0.16, z - 0.09, x + 0.09, 6.2, z + 0.09, [0.62, 0.64, 0.7, 1], false, true);
      for (let b = 0; b < 9; b++) WORLD.g().box(x - 0.125, 0.9 + b * 0.6, z - 0.125, x + 0.125, 1.1 + b * 0.6, z + 0.125, [0.12, 0.13, 0.16, 1], false, true);   // тёмные полосы
      for (const [rx, rz] of [[0.11, 0], [-0.11, 0], [0, 0.11], [0, -0.11]]) WORLD.g().box(x + rx - 0.03, 0.8, z + rz - 0.03, x + rx + 0.03, 6.0, z + rz + 0.03, [0.82, 0.84, 0.9, 1], false, true);   // рёбра
      WORLD.g().box(x - 0.24, 0.16, z - 0.24, x + 0.24, 0.6, z + 0.24, [0.22, 0.23, 0.27, 1], false, true);   // основание
      WORLD.g().box(x - 0.15, 0.6, z - 0.15, x + 0.15, 0.78, z + 0.15, [0.5, 0.5, 0.55, 1], false, true);
      for (const ry of [1.6, 3.2, 4.8]) WORLD.g().box(x - 0.13, ry, z - 0.13, x + 0.13, ry + 0.14, z + 0.13, [0.55, 0.56, 0.6, 1], false, true);   // кольца
      WORLD.g().box(x - 0.3, 6.0, z - 0.3, x + 0.3, 6.2, z + 0.3, [0.2, 0.2, 0.24, 1], false, true);          // оголовок
      WORLD.g().box(x - 0.5, 6.4, z - 0.3, x + 0.5, 6.52, z + 0.3, [0.2, 0.2, 0.24, 1], false, true);         // колпак лампы
      LAMPS.g().box(x - 0.35, 6.2, z - 0.2, x + 0.35, 6.4, z + 0.2, [1, 0.95, 0.75, 1], false, true);
    };
    LP(cx - 10, cz - 30.5); LP(cx + 10, cz + 30.5); LP(cx - 30.5, cz + 10); LP(cx + 30.5, cz - 10);
  } }

  // дорожная разметка
  const Y = 0.02, YEL = [0.9, 0.75, 0.2, 1], WHT = [0.85, 0.85, 0.85, 1];
  for (let k = 0; k <= GRID; k++) {
    const rc = nodeC(k);
    for (let s = 0; s < GRID; s++) {
      const a = nodeC(s) + 12, b = nodeC(s + 1) - 12;
      for (let p = a; p < b - 3; p += 8) {
        DECAL.g().flat(rc - 0.15, p, rc + 0.15, p + 4, Y, YEL);   // вертикальная дорога (вдоль z)
        DECAL.g().flat(p, rc - 0.15, p + 4, rc + 0.15, Y, YEL);   // горизонтальная (вдоль x)
      }
      // краевые линии
      for (const sd of [-7.4, 7.4]) {
        DECAL.g().flat(rc + sd - 0.08, a - 3, rc + sd + 0.08, b + 3, Y, WHT);
        DECAL.g().flat(a - 3, rc + sd - 0.08, b + 3, rc + sd + 0.08, Y, WHT);
      }
    }
  }
  // пешеходные переходы
  for (let i = 0; i <= GRID; i++) for (let j = 0; j <= GRID; j++) {
    const nx = nodeC(i), nz = nodeC(j);
    for (const sgn of [-1, 1]) {
      const ofs = sgn * 10.5;
      if (Math.abs(nz + ofs) <= HALF + 6) for (let s = -6; s <= 6; s += 2.4) DECAL.g().flat(nx + s - 0.5, nz + ofs - 1.6, nx + s + 0.5, nz + ofs + 1.6, Y, WHT);
      if (Math.abs(nx + ofs) <= HALF + 6) for (let s = -6; s <= 6; s += 2.4) DECAL.g().flat(nx + ofs - 1.6, nz + s - 0.5, nx + ofs + 1.6, nz + s + 0.5, Y, WHT);
    }
  }
  // ограждение по периметру
  const E2 = HALF + ROAD / 2 + 1.5, rail = [0.5, 0.5, 0.55, 1];
  for (let t = -E2; t < -E2; t += 30) {      // ограждение убрано: туман считается по вершинам
    const t2 = Math.min(t + 30, E2);
    ALWAYS.g().box(-E2 - 0.5, 0, t, -E2, 1.1, t2, rail, false, true);
    ALWAYS.g().box(E2, 0, t, E2 + 0.5, 1.1, t2, rail, false, true);
    ALWAYS.g().box(t, 0, -E2 - 0.5, t2, 1.1, -E2, rail, false, true);
    ALWAYS.g().box(t, 0, E2, t2, 1.1, E2 + 0.5, rail, false, true);
  }

  buildSignalPoles(ALWAYS);
  const worldRegs = Object.keys(WSETS).map(k => { const w = WSETS[k]; return { meshes: w.set.done(), x0: w.x0, x1: w.x1, z0: w.z0, z1: w.z1 }; });
  worldRegs.push({ meshes: ALWAYS.done(), always: true });
  const SNOWM = buildSnow();
  CITY = { snow: SNOWM, roads: ROADS.done(), world: worldRegs, interior: buildInterior(), ints: { gun: buildShopInterior('gun', INT.gun.x, INT.gun.z), car: buildShopInterior('car', INT.car.x, INT.car.z), hosp: buildShopInterior('hosp', INT.hosp.x, INT.hosp.z), pol: buildShopInterior('pol', INT.pol.x, INT.pol.z), tune: buildShopInterior('tune', INT.tune.x, INT.tune.z), club: buildShopInterior('club', INT.club.x, INT.club.z), cloth: buildShopInterior('cloth', INT.cloth.x, INT.cloth.z), salon: buildShopInterior('salon', INT.salon.x, INT.salon.z), garage: buildGarageInterior(INT.garage.x, INT.garage.z), ...buildPropInteriors() }, ground: GROUND.done(), decal: DECAL.done(), lamps: LAMPS.done(), lglow: LGLOW.done() };
}
const CITY_TOWER = { x: 0, y: 0, z: 0 };

/* высота поверхности (тротуар чуть выше дороги) */
function terrainY(x, z) {
  const u = (x + HALF) / PITCH, v = (z + HALF) / PITCH;
  if (u < 0 || v < 0 || u >= GRID || v >= GRID) return 0;
  const fu = u - Math.floor(u), fv = v - Math.floor(v);
  return (fu > 0.1 && fu < 0.9 && fv > 0.1 && fv < 0.9) ? 0.16 : 0;
}
/* выталкивание круга из зданий/деревьев; возвращает нормаль последнего контакта */
const HIT = { nx: 0, nz: 0, hit: false };
function pushCircle(p, r, alt) {
  HIT.hit = false;
  for (let k = 0; k < boxes.length; k++) {
    let b = boxes[k];
    if (alt > 0) { if (b.up && alt > b.hl - 0.6) { if (alt > b.h - 0.6) continue; b = b.up; } else if (alt > (b.h || 999) - 0.6) continue; }
    if (p.x + r < b.x0 || p.x - r > b.x1 || p.z + r < b.z0 || p.z - r > b.z1) continue;
    const cx = clamp(p.x, b.x0, b.x1), cz = clamp(p.z, b.z0, b.z1);
    const dx = p.x - cx, dz = p.z - cz, d2 = dx * dx + dz * dz;
    if (d2 >= r * r) continue;
    let nx, nz, pen;
    if (d2 > 1e-6) { const d = Math.sqrt(d2); nx = dx / d; nz = dz / d; pen = r - d; }
    else {
      const l = p.x - b.x0, rr = b.x1 - p.x, t = p.z - b.z0, bt = b.z1 - p.z, m = Math.min(l, rr, t, bt);
      if (m === l) { nx = -1; nz = 0; pen = l + r; } else if (m === rr) { nx = 1; nz = 0; pen = rr + r; }
      else if (m === t) { nx = 0; nz = -1; pen = t + r; } else { nx = 0; nz = 1; pen = bt + r; }
    }
    p.x += nx * pen; p.z += nz * pen; HIT.nx = nx; HIT.nz = nz; HIT.hit = true;
  }
  for (let k = 0; k < circles.length && !(alt > 7); k++) {
    const c = circles[k], dx = p.x - c.x, dz = p.z - c.z, rr = r + c.r;
    if (Math.abs(dx) > rr || Math.abs(dz) > rr) continue;
    const d2 = dx * dx + dz * dz;
    if (d2 >= rr * rr) continue;
    const d = Math.sqrt(d2) || 0.001, nx = dx / d, nz = dz / d, pen = rr - d;
    p.x += nx * pen; p.z += nz * pen; HIT.nx = nx; HIT.nz = nz; HIT.hit = true;
  }
  return HIT.hit;
}
/* ближайшая точка дороги + направление */
function nearestRoad(x, z, hx, hz) {
  const ix = clamp(Math.round((x + HALF) / PITCH), 0, GRID), iz = clamp(Math.round((z + HALF) / PITCH), 0, GRID);
  const rx = nodeC(ix), rz = nodeC(iz), dx = Math.abs(x - rx), dz = Math.abs(z - rz);
  let d, px, pz;
  if (dx <= dz) { // вертикальная дорога, едем вдоль z
    const sg = (hz === undefined ? 1 : (hz >= 0 ? 1 : -1)); d = sg > 0 ? 1 : 3;
    px = rx; pz = clamp(z, -HALF + 14, HALF - 14);
  } else {
    const sg = (hx === undefined ? 1 : (hx >= 0 ? 1 : -1)); d = sg > 0 ? 0 : 2;
    px = clamp(x, -HALF + 14, HALF - 14); pz = rz;
  }
  const rt = rightOf(d), f = DIRS[d];
  return { x: px + rt[0] * LANE, z: pz + rt[1] * LANE, h: Math.atan2(f[0], f[1]), d };
}

