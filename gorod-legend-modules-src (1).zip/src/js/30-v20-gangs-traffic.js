/* ===================== v20: банды и районы, аварии и пробки ===================== */
const GANGS = {
  wolves: { n: 'Волки', ico: '🐺', col: '#e63946', rgb: [0.9, 0.22, 0.27] },
  vipers: { n: 'Гадюки', ico: '🐍', col: '#3dd16f', rgb: [0.24, 0.82, 0.44] },
  kings: { n: 'Короли', ico: '👑', col: '#b06cff', rgb: [0.69, 0.42, 1] },
  ghosts: { n: 'Призраки', ico: '👻', col: '#25d0ff', rgb: [0.15, 0.82, 1] }
};
const DNAMES = ['Старый порт', 'Рынок', 'Заводы', 'Склады', 'Холмы', 'Деловой центр', 'Университет', 'Набережная',
  'Трущобы', 'Арена', 'Парк-сити', 'Аэродром', 'Тихая гавань', 'Оптовая', 'Стройка', 'Пригород'];
const DIST = [];
for (let dz = 0; dz < 4; dz++) for (let dx = 0; dx < 4; dx++) {
  const center = dx >= 1 && dx <= 2 && dz >= 1 && dz <= 2;
  const g = center ? null : (dz < 2 ? (dx < 2 ? 'wolves' : 'vipers') : (dx < 2 ? 'kings' : 'ghosts'));
  DIST.push({ idx: dz * 4 + dx, dx, dz, n: DNAMES[dz * 4 + dx], g });
}
const GANG_NEED = 8;
const GANG = { units: [], spT: 3, last: -1, incT: 0 };
function distAt(x, z) {
  const bi = clamp(Math.floor((x + HALF) / PITCH), 0, GRID - 1), bj = clamp(Math.floor((z + HALF) / PITCH), 0, GRID - 1);
  return Math.floor(bj / 4) * 4 + Math.floor(bi / 4);
}
function gdState() {
  if (!S.flags.gd || typeof S.flags.gd !== 'object') S.flags.gd = { own: {}, prog: {} };
  return S.flags.gd;
}
const distOwned = i => !!gdState().own[i];
const distHostile = i => !!DIST[i].g && !distOwned(i);
const ownedCount = () => DIST.filter(d => d.g && distOwned(d.idx)).length;

function gangLook(g) {
  const c = GANGS[g].rgb;
  return { pants: [0.13, 0.13, 0.16], shirt: c, skin: hexRGB('#d9a07a'), hair: [0.06, 0.05, 0.05], dark: [0.04, 0.04, 0.06] };
}
function spawnGang(g) {
  const ang = Math.random() * TAU, r = rand(36, 56);
  const e = { x: clamp(P.x + Math.cos(ang) * r, -EDGE, EDGE), z: clamp(P.z + Math.sin(ang) * r, -EDGE, EDGE), h: 0, hp: 46, maxhp: 46, cd: rand(1.2, 2.4), ph: Math.random() * 6, amp: 0,
    sp: rand(3.8, 5), pref: rand(9, 16), sdir: Math.random() < 0.5 ? 1 : -1, sflip: rand(1, 3), hit: 0, boss: false, sc: 1, cop: false, gang: g, look: gangLook(g),
    gun: { id: Math.random() < 0.3 ? 'smg' : 'pistol', aim: 0, kick: 0, reload: 0 }, dmg: rand(3, 5), rate: rand(1.2, 1.9) };
  pushCircle(e, 0.6);
  GANG.units.push(e);
}
function damageGang(e, dmg) {
  e.hp -= dmg; e.hit = 0.1; SFX.hit(); sparks(e.x, 1.2, e.z, [1, 0.4, 0.3]);
  if (e.hp > 0) return;
  const i = GANG.units.indexOf(e); if (i >= 0) GANG.units.splice(i, 1);
  for (let k = 0; k < 7; k++) emit(e.x, 1 + Math.random(), e.z, rand(-2, 2), rand(0.5, 2.5), rand(-2, 2), 0.7, 0.3, 1.2, 0.85, 0.85, 0.9, 0.6, false);
  addMoney(40);
  const idx = distAt(e.x, e.z);
  if (distHostile(idx) && DIST[idx].g === e.gang) {
    const st = gdState(); st.prog[idx] = (st.prog[idx] || 0) + 1;
    if (st.prog[idx] >= GANG_NEED) captureDist(idx);
    else toast(GANGS[e.gang].ico + ' ' + GANGS[e.gang].n + ': ' + st.prog[idx] + ' / ' + GANG_NEED + ' — район «' + DIST[idx].n + '»');
  }
}
function captureDist(idx) {
  const st = gdState(); st.own[idx] = 1; delete st.prog[idx];
  const g = GANGS[DIST[idx].g];
  addMoney(1500); SFX.buy();
  toast('🏴 Район «' + DIST[idx].n + '» захвачен у банды ' + g.n + '! +$1500 · доход +$150/мин');
  for (let k = GANG.units.length - 1; k >= 0; k--) if (distAt(GANG.units[k].x, GANG.units[k].z) === idx) GANG.units.splice(k, 1);
  persist();
}
function gangTick(dt, play) {
  const c = P.car, air = !!c && c.def.heli && (c.alt - (c.fl || 0)) > 4;
  const idx = distAt(P.x, P.z), hostile = distHostile(idx);
  if (idx !== GANG.last) {
    GANG.last = idx;
    if (play && DIST[idx].g) {
      const g = GANGS[DIST[idx].g];
      if (hostile) toast('⚠ Территория банды ' + g.ico + ' ' + g.n + ' — район «' + DIST[idx].n + '». Убейте ' + GANG_NEED + ' бойцов, чтобы захватить');
      else toast('🏴 Ваш район «' + DIST[idx].n + '»');
    }
  }
  if (!play || air || P.hp <= 0) { GANG.units.length = 0; }
  for (let k = GANG.units.length - 1; k >= 0; k--) {
    const u = GANG.units[k], d = Math.hypot(u.x - P.x, u.z - P.z);
    if (d > 115 || (!hostile && d > 55)) GANG.units.splice(k, 1);
  }
  if (play && hostile && !air && P.hp > 0 && !(M && M.state === 'countdown')) {
    GANG.spT -= dt;
    if (GANG.spT <= 0 && GANG.units.length < 4) { spawnGang(DIST[idx].g); GANG.spT = 4 + Math.random() * 3; }
  }
  if (play && GANG.units.length) updateEnemyList(GANG.units, dt);
  if (play) {
    GANG.incT += dt;
    if (GANG.incT >= 60) { GANG.incT = 0; const n = ownedCount(); if (n) { addMoney(n * 150); toast('🏴 Доход с районов: +' + fmtMoney(n * 150)); } }
  }
}
/* плашка района */
function distPillEl() {
  let e = document.getElementById('distPill');
  if (!e) {
    e = document.createElement('div'); e.id = 'distPill';
    e.style.cssText = 'position:fixed;left:50%;top:10px;transform:translateX(-50%);padding:4px 12px;border-radius:16px;background:rgba(10,12,20,.72);color:#fff;font:600 12px system-ui,sans-serif;z-index:24;display:none;border:1px solid rgba(255,255,255,.2);white-space:nowrap;pointer-events:none';
    document.body.appendChild(e);
  }
  return e;
}
function distPill(play) {
  const e = distPillEl();
  const show = play && !G.inHome && UI.cur === null;
  if (show) {
    const d = DIST[distAt(P.x, P.z)], st = gdState();
    let tx, bc = 'rgba(255,255,255,.2)';
    if (!d.g) tx = '📍 ' + d.n + ' · нейтральная зона';
    else if (distOwned(d.idx)) { tx = '🏴 ' + d.n + ' · ваш район'; bc = '#ffd23f'; }
    else { const g = GANGS[d.g]; tx = g.ico + ' ' + d.n + ' · ' + g.n + ' · захват ' + (st.prog[d.idx] || 0) + '/' + GANG_NEED; bc = g.col; }
    if (e._t !== tx) { e._t = tx; e.textContent = tx; }
    e.style.borderColor = bc;
  }
  e.style.display = show ? 'block' : 'none';
}
/* районы на карте */
function drawDistricts(ctx, full) {
  const W = 4 * PITCH;
  for (const d of DIST) {
    if (!d.g) continue;
    const own = distOwned(d.idx), col = own ? '#ffd23f' : GANGS[d.g].col;
    ctx.globalAlpha = own ? 0.16 : 0.2; ctx.fillStyle = col;
    ctx.fillRect(-HALF + d.dx * W + 4, -HALF + d.dz * W + 4, W - 8, W - 8);
    ctx.globalAlpha = 1;
  }
}
function drawDistLabels(ctx, sc) {
  ctx.font = '700 12px system-ui,sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (const d of DIST) {
    const p = sc(-HALF + (d.dx + 0.5) * 4 * PITCH, -HALF + (d.dz + 0.5) * 4 * PITCH);
    const own = d.g && distOwned(d.idx);
    ctx.fillStyle = 'rgba(0,0,0,.55)'; const w = ctx.measureText(d.n).width + 10; ctx.fillRect(p[0] - w / 2, p[1] - 22, w, 17);
    ctx.fillStyle = !d.g ? '#cfd6e8' : own ? '#ffd23f' : GANGS[d.g].col; ctx.fillText(d.n, p[0], p[1] - 13);
    if (d.g) { ctx.fillStyle = '#fff'; ctx.font = '600 11px system-ui,sans-serif'; ctx.fillText(own ? '🏴 ваш' : GANGS[d.g].ico + ' ' + GANGS[d.g].n, p[0], p[1] + 3); ctx.font = '700 12px system-ui,sans-serif'; }
  }
  ctx.textAlign = 'start'; ctx.textBaseline = 'alphabetic';
}

/* --- аварии и пробки --- */
const ACC = { list: [], t: 30 };
function accSpawn() {
  let i, j, d, t, f, rt, x = 0, z = 0, ok = false;
  for (let tries = 0; tries < 60 && !ok; tries++) {
    const ci = Math.round((P.x + HALF) / PITCH), cj = Math.round((P.z + HALF) / PITCH);
    i = clamp(ci + Math.floor(rand(-4, 5)), 1, GRID - 1); j = clamp(cj + Math.floor(rand(-4, 5)), 1, GRID - 1);
    d = Math.floor(Math.random() * 4); f = DIRS[d]; rt = rightOf(d); t = 22 + Math.random() * 24;
    x = nodeC(i) + f[0] * t + rt[0] * LANE; z = nodeC(j) + f[1] * t + rt[1] * LANE;
    const dp = Math.hypot(x - P.x, z - P.z);
    ok = dp > 70 && dp < 300;
  }
  if (!ok) return;
  const a = { x, z, life: 85, sm: 0, jam: false, cars: [] };
  const defs = [CAR_BY_ID.hatch, CAR_BY_ID.sedan, CAR_BY_ID.van, CAR_BY_ID.suv, CAR_BY_ID.taxi];
  const h0 = Math.atan2(f[0], f[1]);
  const mk = (tt, lat, dh) => {
    const def = pick(defs), c = makeCar(def, 'wreck', def.taxi ? '#ffd60a' : pick(COLORS));
    c.x = nodeC(i) + f[0] * tt + rt[0] * (LANE + lat); c.z = nodeC(j) + f[1] * tt + rt[1] * (LANE + lat);
    c.h = h0 + dh; c.vx = c.vz = c.vf = c.vl = 0; c.spd = 0; a.cars.push(c);
  };
  mk(t, 0.2, 0.6); mk(t + 5.2, -1.1, -0.9);
  ACC.list.push(a);
  const dp = Math.hypot(x - P.x, z - P.z);
  if (dp < 320) toast('🚨 Авария на дороге — ' + Math.round(dp / 10) * 10 + ' м от вас. Скоро будет пробка');
}
function accTick(dt, play) {
  if (G.mode !== 'play') return;
  ACC.t -= dt;
  if (ACC.t <= 0 && play && ACC.list.length < 2 && !(M && M.state === 'countdown')) { ACC.t = 55 + Math.random() * 60; accSpawn(); }
  for (let k = ACC.list.length - 1; k >= 0; k--) {
    const a = ACC.list[k];
    a.life -= dt; a.sm -= dt;
    const dc = Math.hypot(a.x - CAM.x, a.z - CAM.z);
    if (a.sm <= 0 && dc < 170) {
      a.sm = 0.14;
      for (const c of a.cars) emit(c.x + rand(-0.6, 0.6), 1.1, c.z + rand(-0.6, 0.6), rand(-0.3, 0.3), rand(1.2, 2.2), rand(-0.3, 0.3), 1.8, 0.4, 1.7, 0.3, 0.3, 0.33, 0.55, false);
      if (Math.random() < 0.5) { const c = a.cars[0]; emit(c.x, 0.9, c.z, rand(-0.4, 0.4), rand(0.5, 1.2), rand(-0.4, 0.4), 0.4, 0.3, 0.1, 1, 0.5, 0.12, 0.9, true); }
    }
    if (!a.jam && a.life < 70) {
      let n = 0; for (const c of cars) if (c.kind === 'traffic' && c.spd < 1 && Math.hypot(c.x - a.x, c.z - a.z) < 45) n++;
      if (n >= 3) { a.jam = true; if (dc < 450) toast('🚗 Пробка у места аварии — ' + n + ' машин стоят'); }
    }
    if (a.life <= 0 || !play && dc > 700) {
      for (const c of a.cars) removeCar(c);
      ACC.list.splice(k, 1);
      if (dc < 300) toast('✅ Дорогу расчистили — пробка рассасывается');
    }
  }
}
function accClear() { for (const a of ACC.list) for (const c of a.cars) removeCar(c); ACC.list.length = 0; }
function drawAccidents(ctx, full, sc) {
  for (const a of ACC.list) {
    ctx.fillStyle = 'rgba(255,122,0,0.22)'; ctx.strokeStyle = 'rgba(255,150,40,0.9)'; ctx.lineWidth = (full ? 2.5 : 2) / sc;
    ctx.beginPath(); ctx.arc(a.x, a.z, 38, 0, TAU); ctx.fill(); ctx.stroke();
  }
}

function v20Tick(dt) {
  if (G.mode !== 'play') { GANG.units.length = 0; if (ACC.list.length) accClear(); return; }
  const play = G.mode === 'play' && !G.paused && !G.inHome;
  gangTick(dt, play);
  accTick(dt, play);
  distPill(play);
}

