/* ===================== v36: КАРТА+ (боковая панель, значки, фильтры) И КОМПАКТНАЯ ПАУЗА ===================== */
{
  const CATS = [['shop', '🛒', 'Магазины', '#3dff8a'], ['garage', '🔧', 'Гаражи', '#ffb703'], ['home', '🏠', 'Жильё', '#8ecae6'],
    ['casino', '🎰', 'Казино', '#ff2fa0'], ['biz', '💼', 'Бизнес', '#c77dff'], ['task', '🎯', 'Задания', '#ffd60a']];
  const CAT = {}; for (const c of CATS) CAT[c[0]] = c;
  const MX = { sel: null, hide: {} };
  try { const j = JSON.parse(localStorage.getItem('gl_mapf_v1') || '{}'); if (j && typeof j === 'object') MX.hide = j; } catch (e) { }
  const saveF = () => { try { localStorage.setItem('gl_mapf_v1', JSON.stringify(MX.hide)); } catch (e) { } };

  const catOf = m => { const id = m.id || ''; if (id === 'casino_in') return 'casino'; if (id === 'club' || id === 'tune' || id === 'homegar') return 'garage'; if (id === 'estate' || id.indexOf('prop_') === 0) return 'home'; if (id.indexOf('rob_') === 0 || id.indexOf('cl_') === 0) return 'shop'; return 'biz'; };
  const distName = (x, z) => { const dx = clamp(Math.floor((x + HALF) / (4 * PITCH)), 0, 3), dz = clamp(Math.floor((z + HALF) / (4 * PITCH)), 0, 3); return DIST[dz * 4 + dx].n; };
  const fmtD = d => d < 1000 ? Math.round(d / 10) * 10 + ' м' : (d / 1000).toFixed(1) + ' км';
  const pretty = l => { l = String(l || '').replace(/^\S+\s+/, ''); return l ? l.charAt(0) + l.slice(1).toLowerCase() : ''; };

  const nice = t => t === t.toUpperCase() && /[А-ЯA-Z]/.test(t) ? t.charAt(0) + t.slice(1).toLowerCase() : t;
  function places() {
    const out = [];
    for (const m of WORLD_MARKS) {
      if (m.int || !m.short) continue;
      const mt = /^(\S+)\s+(.*)$/.exec(m.short), cat = catOf(m);
      out.push({ id: m.id, cat, ico: mt ? mt[1] : '📍', name: nice(mt ? mt[2] : m.short), x: m.x, z: m.z, desc: pretty(m.label) });
    }
    if (typeof missionTargets === 'function') {
      missionTargets().forEach((t, i) => out.push({ id: 'task' + i, cat: 'task', ico: '🎯', name: i === 0 ? ('Задание' + (M && M.def ? ': ' + M.def.name : '')) : 'Дополнительная цель', x: t.x, z: t.z, desc: 'Цель текущего задания' }));
    }
    for (const p of out) p.d = Math.hypot(P.x - p.x, P.z - p.z);
    return out;
  }
  const vis = p => !MX.hide[p.cat];

  /* ---------- разметка ---------- */
  const scr = $('mapScreen'), pan = scr.querySelector('.panel'), cv = $('bigMap');
  pan.classList.remove('center'); pan.classList.add('mapp');
  const oldHint = pan.querySelector('p.muted'); if (oldHint) oldHint.remove();
  const head = pan.querySelector('.ps-head'); head.insertAdjacentHTML('beforeend', '<span id="mpWhere" class="mp-me"></span>');
  const body = document.createElement('div'); body.className = 'mp-body';
  const cvw = document.createElement('div'); cvw.className = 'mp-cv';
  const side = document.createElement('div'); side.className = 'mp-side';
  side.innerHTML = '<div id="mpFilt" class="mp-chips"></div><div id="mpPick"></div><div id="mpPlaces" class="mp-list"></div><div class="mp-hint">Тап по значку — подробности. Тап по пустому месту — маршрут туда. 🧭 у места — проложить маршрут.</div>';
  cvw.appendChild(cv); body.appendChild(cvw); body.appendChild(side); pan.appendChild(body);

  function selPlace(list) { return MX.sel ? list.find(p => p.id === MX.sel) : null; }
  function routeTo(p) { navSet(p.x, p.z); sideRefresh(); drawFullMap(); }

  function sideRefresh() {
    const list = places(), me = $('mpWhere');
    me.textContent = '📍 ' + distName(P.x, P.z) + (NAV.on ? ' · 🧭 ' + Math.round(NAV.dist || 0) + ' м' : '');
    // фильтры
    const cnt = {}; for (const p of list) cnt[p.cat] = (cnt[p.cat] || 0) + 1;
    $('mpFilt').innerHTML = CATS.filter(c => cnt[c[0]]).map(c => '<button class="chip' + (MX.hide[c[0]] ? '' : ' on') + '" data-cat="' + c[0] + '">' + c[1] + ' ' + c[2] + ' <small>' + cnt[c[0]] + '</small></button>').join('')
      + (NAV.on ? '<button class="chip" data-act2="clr">✖ Убрать маршрут</button>' : '');
    // выбранное место
    const sp = selPlace(list), se = $('mpPick');
    if (sp) {
      const rt = NAV.on && Math.hypot(NAV.x - sp.x, NAV.z - sp.z) < 20;
      se.innerHTML = '<div class="mp-card"><span class="e">' + sp.ico + '</span><div class="n"><b>' + sp.name + '</b><small>' + CAT[sp.cat][2] + ' · ' + distName(sp.x, sp.z) + ' · ' + fmtD(sp.d) + '</small>' + (sp.desc ? '<small>' + sp.desc + '</small>' : '') + '</div>'
        + '<button class="btn small' + (rt ? '' : ' primary') + '" data-go="' + sp.id + '">' + (rt ? '✖ Убрать' : '🧭 Маршрут') + '</button></div>';
    } else se.innerHTML = '';
    // список
    const ls = $('mpPlaces'), keep = ls.scrollTop; let h = '';
    for (const c of CATS) {
      if (MX.hide[c[0]]) continue;
      const g = list.filter(p => p.cat === c[0]).sort((a, b) => a.d - b.d); if (!g.length) continue;
      h += '<div class="mp-gh" style="--c:' + c[3] + '">' + c[1] + ' ' + c[2] + '</div>';
      for (const p of g) h += '<div class="mp-row' + (p.id === MX.sel ? ' sel' : '') + '" data-pid="' + p.id + '"><span class="e">' + p.ico + '</span><span class="n"><b>' + p.name + '</b><small>' + distName(p.x, p.z) + '</small></span><span class="d">' + fmtD(p.d) + '</span><button class="mp-go" data-go="' + p.id + '" aria-label="Маршрут">🧭</button></div>';
    }
    ls.innerHTML = h || '<div class="mp-empty">Все слои скрыты — включите фильтр выше.</div>'; ls.scrollTop = keep;
  }

  side.addEventListener('click', ev => {
    const t = ev.target, go = t.closest('[data-go]'), ch = t.closest('[data-cat]'), cl = t.closest('[data-act2]'), row = t.closest('[data-pid]');
    if (cl) { if (navClear()) { SFX.click(); toast('🧭 Маршрут убран'); } }
    else if (ch) { MX.hide[ch.dataset.cat] = !MX.hide[ch.dataset.cat]; saveF(); SFX.click(); }
    else if (go) {
      const p = places().find(q => q.id === go.dataset.go); if (!p) return;
      MX.sel = p.id;
      if (NAV.on && Math.hypot(NAV.x - p.x, NAV.z - p.z) < 20) { if (navClear()) { SFX.click(); toast('🧭 Маршрут убран'); } } else { navSet(p.x, p.z); }
    }
    else if (row) { MX.sel = MX.sel === row.dataset.pid ? null : row.dataset.pid; SFX.click(); }
    else return;
    sideRefresh(); drawFullMap();
  });

  /* ---------- тап по значку на карте ---------- */
  function badgeAt(ev) {
    const r = cv.getBoundingClientRect(), k = cv.width / r.width, px = (ev.clientX - r.left) * k, py = (ev.clientY - r.top) * k;
    const T = xf(), hit = 17 * K();
    let best = null, bd = 1e9;
    for (const p of places()) { if (!vis(p) || p.cat === 'task') continue; const q = sc(T, p.x, p.z), d = Math.hypot(q[0] - px, q[1] - py); if (d < hit && d < bd) { bd = d; best = p; } }
    return best;
  }
  cv.addEventListener('click', ev => {
    if (G.mode !== 'play') return;
    const p = badgeAt(ev); if (!p) return;
    ev.stopImmediatePropagation(); ev.preventDefault();
    MX.sel = MX.sel === p.id ? null : p.id; SFX.click(); sideRefresh(); drawFullMap();
    const row = $('mpPlaces').querySelector('[data-pid="' + p.id + '"]'); if (row && row.scrollIntoView) row.scrollIntoView({ block: 'nearest' });
  }, true);

  /* ---------- рисование ---------- */
  const K = () => Math.max(1, cv.width / Math.max(1, cv.clientWidth || cv.width));
  const xf = () => { const s = cv.width / (2 * HALF + 60), T = mapXform(bigc, cv.width, cv.height, 0, 0, 0, -1, s); bigc.setTransform(1, 0, 0, 1, 0, 0); return T; };
  const sc = (T, x, z) => [T.a * x + T.c * z + T.e, T.b * x + T.d * z + T.f];

  drawDistLabels = function (ctx, sc2) {
    const k = ctx.canvas === cv ? K() * (cv.clientWidth < 420 ? 0.8 : 1) : 1;
    ctx.font = '700 ' + Math.round(11 * k) + 'px system-ui,sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (const d of DIST) {
      const p = sc2(-HALF + (d.dx + 0.5) * 4 * PITCH, -HALF + (d.dz + 0.5) * 4 * PITCH);
      const own = d.g && distOwned(d.idx);
      const w = ctx.measureText(d.n).width + 8 * k; ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(p[0] - w / 2, p[1] - 21 * k, w, 15 * k);
      ctx.fillStyle = !d.g ? '#cfd6e8' : own ? '#ffd23f' : GANGS[d.g].col; ctx.fillText(d.n, p[0], p[1] - 13.5 * k);
      if (d.g && !(ctx.canvas === cv && cv.clientWidth < 420)) { ctx.fillStyle = '#fff'; ctx.font = '600 ' + Math.round(10 * k) + 'px system-ui,sans-serif'; ctx.fillText(own ? '🏴 ваш' : GANGS[d.g].ico + ' ' + GANGS[d.g].n, p[0], p[1] + 2 * k); ctx.font = '700 ' + Math.round(11 * k) + 'px system-ui,sans-serif'; }
    }
    ctx.textAlign = 'start'; ctx.textBaseline = 'alphabetic';
  };

  const df0 = drawFullMap;
  drawFullMap = function () {
    const cw = cv.clientWidth;
    if (cw > 0) { const t = Math.min(1100, Math.round(cw * Math.min(2, window.devicePixelRatio || 1))); if (cv.width !== t) { cv.width = t; cv.height = t; } }
    const list = places(), hid = [];
    for (const m of WORLD_MARKS) if (!m.int && m.short && MX.hide[catOf(m)]) { m.int = true; hid.push(m); }
    try { df0(); } finally { for (const m of hid) m.int = false; }
    const k = K(), T = xf(), ctx = bigc, r = (cw < 420 ? 7.5 : 10) * k, tm = performance.now() / 1000;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const labelAll = cw >= 560;
    for (const p of list) {
      if (p.cat === 'task' || !vis(p)) continue;
      const q = sc(T, p.x, p.z), on = p.id === MX.sel, col = CAT[p.cat][3];
      if (q[0] < -r || q[1] < -r || q[0] > cv.width + r || q[1] > cv.height + r) continue;
      const rr = on ? r * 1.3 : r;
      if (on) { ctx.strokeStyle = 'rgba(255,255,255,' + (0.35 + 0.35 * Math.sin(tm * 5)) + ')'; ctx.lineWidth = 2 * k; ctx.beginPath(); ctx.arc(q[0], q[1], rr + (4 + 2 * Math.sin(tm * 5)) * k, 0, TAU); ctx.stroke(); }
      ctx.fillStyle = '#0b1020'; ctx.strokeStyle = on ? '#fff' : col; ctx.lineWidth = (on ? 2.5 : 2) * k;
      ctx.beginPath(); ctx.arc(q[0], q[1], rr, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.font = Math.round(rr * 1.15) + 'px system-ui,"Apple Color Emoji","Segoe UI Emoji",sans-serif'; ctx.fillText(p.ico, q[0], q[1] + k * 0.5);
    }
    ctx.font = '700 ' + Math.round(10.5 * k) + 'px system-ui,sans-serif';
    const lab = (p, strong) => {
      const q = sc(T, p.x, p.z), w = ctx.measureText(p.name).width + 8 * k, y = q[1] + r * (strong ? 1.3 : 1) + 8 * k;
      ctx.fillStyle = strong ? 'rgba(255,183,3,.95)' : 'rgba(0,0,0,.7)'; ctx.fillRect(q[0] - w / 2, y - 7.5 * k, w, 15 * k);
      ctx.fillStyle = strong ? '#1a0f00' : '#fff'; ctx.fillText(p.name, q[0], y);
    };
    if (labelAll) for (const p of list) if (p.cat !== 'task' && vis(p) && p.id !== MX.sel) lab(p, false);
    const sp = selPlace(list); if (sp && vis(sp)) lab(sp, true);
    ctx.textAlign = 'start'; ctx.textBaseline = 'alphabetic';
    if (UI.cur === 'mapScreen') sideRefresh();
  };
  addEventListener('resize', () => { if (UI.cur === 'mapScreen') drawFullMap(); });
  const ss0 = showScreen;
  showScreen = function (name) { if (name === 'mapScreen' && UI.cur !== 'mapScreen') MX.sel = null; return ss0(name); };

  /* ---------- стили ---------- */
  const st = document.createElement('style');
  st.textContent = `
#mapScreen .panel.mapp{width:min(98vw,1120px);max-height:96vh;height:auto;align-items:stretch;text-align:left;padding:10px 12px}
#mapScreen .ps-head{margin-bottom:8px;flex:none}.mp-me{color:var(--mut);font-size:13px;font-weight:700;white-space:nowrap}
.mp-body{display:flex;gap:12px;flex:none;height:min(calc(96vh - 64px),56vw);min-height:0}
.mp-cv{flex:none;display:flex;align-items:flex-start}
#mapScreen #bigMap{width:min(calc(96vh - 64px),56vw);height:min(calc(96vh - 64px),56vw);max-width:none;display:block}
.mp-side{flex:1;min-width:0;display:flex;flex-direction:column;gap:8px;min-height:0}
.mp-chips{display:flex;flex-wrap:wrap;gap:6px;flex:none}.mp-chips .chip{padding:6px 10px;font-size:13px}.mp-chips .chip small{opacity:.65;margin-left:2px}
.mp-card{display:flex;align-items:center;gap:10px;padding:10px;border:1px solid var(--acc);background:rgba(255,183,3,.09);border-radius:14px;flex:none}
.mp-card .e,.mp-row .e{font-size:26px;width:34px;text-align:center;flex:none}.mp-card .n{flex:1;min-width:0}.mp-card b{font-size:15px}.mp-card small{display:block;color:var(--mut);font-size:12px;margin-top:1px}
.mp-list{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;display:flex;flex-direction:column;gap:5px;padding-right:3px;touch-action:pan-y;-webkit-overflow-scrolling:touch}
.mp-gh{position:sticky;top:0;z-index:1;font-size:12px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;color:var(--c);background:var(--panel);padding:6px 2px 3px;border-bottom:1px solid var(--line)}
.mp-row{display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:12px;border:1px solid var(--line);background:rgba(255,255,255,.04);cursor:pointer;min-height:46px}
.mp-row.sel{border-color:var(--acc);background:rgba(255,183,3,.1)}.mp-row .n{flex:1;min-width:0}.mp-row b{font-size:14px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.mp-row small{color:var(--mut);font-size:11.5px}
.mp-row .d{font-size:12.5px;font-weight:700;color:var(--gold);flex:none}
.mp-go{flex:none;width:40px;height:36px;border-radius:10px;border:1px solid var(--line);background:rgba(255,255,255,.08);font-size:18px;cursor:pointer;color:inherit}
.mp-hint,.mp-empty{color:var(--mut);font-size:11.5px;flex:none}.mp-empty{padding:12px 4px}
@media (orientation:portrait),(max-width:700px){
 #mapScreen .panel.mapp{overflow-y:auto}
 .mp-body{flex-direction:column;overflow:visible;flex:none;height:auto}
 .mp-cv{justify-content:center}
 #mapScreen #bigMap{width:min(94vw,70vh);height:min(94vw,70vh)}
 .mp-list{overflow:visible;flex:none}
}
@media (max-height:480px){.mp-chips .chip{padding:4px 8px;font-size:12px}.mp-card{padding:6px 8px}.mp-card .e{font-size:22px}.mp-hint{display:none}.mp-row{min-height:40px}}
#pause .panel{width:min(96vw,660px);max-height:96vh;overflow-y:auto;padding:12px 14px}
#pause .panel h2{margin-bottom:8px;font-size:20px}
#pause .menu-btns{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;width:100%}
#pause .menu-btns .btn{padding:10px 8px;font-size:15px;min-height:46px;margin:0}
#pause .menu-btns .btn.primary{grid-column:1/-1}
@media (min-width:560px) and (max-height:560px){
 #pause .panel{width:min(96vw,760px);padding:10px 12px}
 #pause .menu-btns{grid-template-columns:repeat(3,1fr);gap:6px}
 #pause .menu-btns .btn{padding:6px 6px;font-size:13.5px;min-height:40px}
}
`;
  document.head.appendChild(st);
}

