/* ===================== v45: РЫБАЛКА — пирс, лодки, удочки, наживка, лавка и продажа улова ===================== */
{
  const V = window.__v42, PXE = V.SW + 84, PZ = V.PZ, PX0 = V.PX0;
  const RODS = [
    { n: 'Бамбуковая удочка', p: 0, bite: [3.5, 8], luck: 1, ico: '🎋' },
    { n: 'Карбоновый спиннинг', p: 4500, bite: [2.2, 5.5], luck: 1.5, ico: '🎣' },
    { n: 'Удилище «Нептун»', p: 22000, bite: [1.4, 3.8], luck: 2.2, ico: '🔱' }
  ];
  const FISH = [
    { id: 'boot', n: 'Старый ботинок', ico: '🥾', p: 5, w: 7, tier: 0, r: 0 },
    { id: 'roach', n: 'Плотва', ico: '🐟', p: 40, w: 50, tier: 0, r: 1 },
    { id: 'perch', n: 'Окунь', ico: '🐟', p: 90, w: 30, tier: 0, r: 1 },
    { id: 'carp', n: 'Карп', ico: '🐠', p: 180, w: 16, tier: 1, r: 1 },
    { id: 'pike', n: 'Щука', ico: '🐊', p: 340, w: 9, tier: 1, r: 2 },
    { id: 'salmon', n: 'Лосось', ico: '🍣', p: 650, w: 5, tier: 2, r: 2 },
    { id: 'tuna', n: 'Тунец', ico: '🐋', p: 1500, w: 3, tier: 3, r: 2, deep: 55 },
    { id: 'marlin', n: 'Меч-рыба', ico: '🗡', p: 4200, w: 1.2, tier: 4, r: 3, deep: 70 },
    { id: 'golden', n: 'Золотая рыбка', ico: '🏅', p: 14000, w: 0.25, tier: 5, r: 3, deep: 40 }
  ];
  const BYID = {}; FISH.forEach(f => BYID[f.id] = f);
  const FD = () => S.fish || (S.fish = { bag: {}, rod: 0, own: { 0: 1 }, bait: 0, n: 0, best: 0, sold: 0 });
  const F = { st: '', t: 0, x: 0, z: 0, bt: 0, deep: 0, fish: null, premium: false, ox: 0, oz: 0, mode: '' };
  const css = document.createElement('style');
  css.textContent = `
#fishBtn{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(var(--safe-b,0px) + 214px);z-index:24;padding:8px 18px;border-radius:18px;border:1px solid #5ad1ff;background:rgba(8,16,30,.85);color:#fff;font:800 14px system-ui,sans-serif;display:none;cursor:pointer}
#fishBtn.bite{background:#e5484d;border-color:#ffb4b4;animation:fpulse .35s infinite alternate}@keyframes fpulse{to{transform:translateX(-50%) scale(1.12)}}
#fishHud{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(var(--safe-b,0px) + 256px);z-index:24;padding:4px 12px;border-radius:12px;background:rgba(8,16,30,.78);color:#cfe9ff;font:700 12px system-ui,sans-serif;display:none;pointer-events:none}
#fishShop{position:fixed;inset:0;z-index:58;background:rgba(5,10,20,.82);display:none;align-items:center;justify-content:center}
#fishShop .in{width:min(560px,94vw);max-height:86vh;overflow:auto;background:#0f1a30;border:1px solid #2b4a7a;border-radius:18px;padding:14px 16px;color:#fff;font:500 13px/1.4 system-ui,sans-serif}
#fishShop h2{margin:0 0 6px;font-size:19px}#fishShop h3{margin:12px 0 4px;font-size:14px;color:#7fdcff}
#fishShop .r{display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid #1b2c4d}#fishShop .r span{flex:1}
#fishShop button{border:0;border-radius:9px;padding:6px 11px;font:700 12px system-ui;background:#2b6cff;color:#fff;cursor:pointer}#fishShop button:disabled{opacity:.4}#fishShop button.g{background:#2fb86a}#fishShop button.x{background:#2b3350}
`;
  document.head.appendChild(css);
  const btn = document.createElement('button'); btn.id = 'fishBtn'; document.body.appendChild(btn);
  const hud = document.createElement('div'); hud.id = 'fishHud'; document.body.appendChild(hud);
  const shop = document.createElement('div'); shop.id = 'fishShop'; document.body.appendChild(shop);

  const onPier = () => P.x > PX0 + 22 && P.x < PXE + 1 && Math.abs(P.z - PZ) < 9 && !P.car && !P.boat && !G.inHome;
  const spot = () => {
    if (G.mode !== 'play' || G.inHome || P.hp <= 0) return null;
    if (P.boat) { const b = P.boat; if (V.dst(b.x, b.z) > 30) return { mode: 'boat', x: b.x + Math.sin(b.h) * 8, z: b.z + Math.cos(b.h) * 8, deep: V.dst(b.x, b.z) }; return null; }
    if (onPier()) return { mode: 'pier', x: P.x + 8, z: P.z, deep: V.dst(P.x, P.z) };
    return null;
  };
  function pickFish(deep) {
    const D = FD(), rod = RODS[D.rod], lk = rod.luck * (F.premium ? 1.6 : 1) * (1 + clamp(deep, 0, 120) / 140);
    let tot = 0; const ws = FISH.map(f => { let w = (f.deep && deep < f.deep) ? 0 : f.w * Math.pow(lk, f.tier * 0.8); if (f.r === 0) w = f.w; tot += w; return w; });
    let x = Math.random() * tot; for (let i = 0; i < FISH.length; i++) { x -= ws[i]; if (x <= 0) return FISH[i]; } return FISH[1];
  }
  function stop(msg) { F.st = ''; if (msg) toast(msg); hud.style.display = 'none'; }
  function cast() {
    const sp = spot(); if (!sp) { toast('🎣 Рыбачить можно на конце пирса или с лодки далеко от берега (L / кнопка)'); SFX.err(); return; }
    const D = FD(); if (D.bait > 0) { D.bait--; F.premium = true; } else F.premium = false;
    Object.assign(F, { st: 'wait', mode: sp.mode, x: sp.x, z: sp.z, deep: sp.deep, ox: P.x, oz: P.z, fish: null });
    const r = RODS[D.rod]; F.t = rand(r.bite[0], r.bite[1]) * (F.premium ? 0.75 : 1); F.bt = 0;
    SFX.click(); for (let i = 0; i < 8; i++) emit(F.x + rand(-0.3, 0.3), 0.05, F.z + rand(-0.3, 0.3), rand(-1, 1), rand(1.5, 3), rand(-1, 1), 0.6, 0.15, 0.4, 0.9, 0.97, 1, 0.8, false);
    toast('🎣 Заброс' + (F.premium ? ' с премиум-наживкой' : '') + '. Ждите поклёвку…');
  }
  function hook() {
    const f = F.fish = pickFish(F.deep); F.st = 'fight';
    if (f.r === 0) return land(f);
    const ok = window.__skillCheck(f.r, f.ico + ' ' + f.n + ' на крючке!', fails => { if (fails > (f.r >= 3 ? 1 : 0)) { F.st = ''; toast('💨 Сорвалась! ' + f.n + ' ушла'); SFX.err(); } else land(f); }, 'Пробел / E / тап — вываживайте рыбу, стрелка в зелёной зоне');
    if (!ok) F.st = '';
  }
  function land(f) {
    const D = FD(); D.bag[f.id] = (D.bag[f.id] || 0) + 1; D.n++;
    if (f.r > 0) S.flags.fishN = (S.flags.fishN || 0) + 1;
    const first = !D['s_' + f.id]; D['s_' + f.id] = 1;
    if (f.p > D.best) D.best = f.p;
    SFX.buy(); F.st = '';
    toast(f.ico + ' Поймана: ' + f.n + ' (≈' + fmtMoney(f.p) + ')' + (first && f.r > 0 ? ' — новый вид!' : ''));
    for (let i = 0; i < 10; i++) emit(F.x + rand(-0.4, 0.4), 0.1, F.z + rand(-0.4, 0.4), rand(-2, 2), rand(2, 5), rand(-2, 2), 0.7, 0.2, 0.5, 0.9, 0.97, 1, 0.8, false);
    persist();
  }
  const press = () => { if (F.st === '') cast(); else if (F.st === 'wait') { stop('🎣 Леска смотана'); } else if (F.st === 'bite') hook(); };
  btn.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); press(); });
  document.addEventListener('keydown', e => { if (e.code === 'KeyL' && !e.repeat && G.mode === 'play' && UI.cur === null && shop.style.display !== 'flex') press(); });
  HOME_FN.fishSpot = function () { press(); };

  /* --- лавка --- */
  function sellAll() {
    const D = FD(); let sum = 0, n = 0; for (const id in D.bag) { const f = BYID[id]; if (f) { sum += f.p * D.bag[id]; n += D.bag[id]; } }
    if (!n) { toast('🎣 Улова нет'); SFX.err(); return; }
    D.bag = {}; D.sold += sum; addMoney(sum); SFX.cash(); toast('🎣 Продано рыбы: ' + n + ' шт. на ' + fmtMoney(sum)); persist();
  }
  function renderShop() {
    const D = FD(); let h = '<div class="in"><h2>🎣 Рыбацкая лавка</h2><div style="color:#9fb0d8">Улов: ' + D.n + ' · лучший трофей: ' + fmtMoney(D.best) + ' · продано на ' + fmtMoney(D.sold) + '</div><h3>Ваш улов</h3>';
    let sum = 0, any = false;
    for (const f of FISH) { const n = D.bag[f.id] || 0; if (!n) continue; any = true; sum += n * f.p; h += '<div class="r"><b>' + f.ico + '</b><span>' + f.n + ' ×' + n + '</span><b>' + fmtMoney(n * f.p) + '</b></div>'; }
    h += any ? '<div class="r"><span></span><button class="g" data-a="sell">Продать всё за ' + fmtMoney(sum) + '</button></div>' : '<div style="color:#9fb0d8;padding:4px 0">Пусто. Закиньте удочку с конца пирса (L)!</div>';
    h += '<h3>Снасти</h3>';
    RODS.forEach((r, i) => {
      const own = !!D.own[i], cur = D.rod === i;
      h += '<div class="r"><b>' + r.ico + '</b><span>' + r.n + '<br><small style="color:#9fb0d8">клёв быстрее, редкая рыба чаще ×' + r.luck + '</small></span>' + (cur ? '<b style="color:#6df09a">В руках</b>' : own ? '<button data-a="eq' + i + '">Взять</button>' : '<button data-a="buy' + i + '"' + (S.money < r.p ? ' disabled' : '') + '>' + fmtMoney(r.p) + '</button>') + '</div>';
    });
    h += '<div class="r"><b>🪱</b><span>Премиум-наживка ×5 (у вас: ' + D.bait + ')<br><small style="color:#9fb0d8">+60% к редкой рыбе, клёв на 25% быстрее</small></span><button data-a="bait"' + (S.money < 150 ? ' disabled' : '') + '>$150</button></div>';
    h += '<div style="text-align:right;margin-top:10px"><button class="x" data-a="close">Закрыть</button></div></div>';
    shop.innerHTML = h;
  }
  shop.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) { if (e.target === shop) shop.style.display = 'none'; return; }
    const a = b.dataset.a, D = FD();
    if (a === 'close') shop.style.display = 'none';
    else if (a === 'sell') sellAll();
    else if (a === 'bait') { if (S.money < 150) { SFX.err(); return; } S.money -= 150; D.bait += 5; refreshMoney(true); SFX.buy(); persist(); }
    else if (a && a.startsWith('eq')) { D.rod = +a.slice(2); SFX.click(); persist(); }
    else if (a && a.startsWith('buy')) { const i = +a.slice(3), r = RODS[i]; if (S.money < r.p) { SFX.err(); return; } S.money -= r.p; D.own[i] = 1; D.rod = i; refreshMoney(true); SFX.buy(); toast(r.ico + ' ' + r.n + ' куплена!'); persist(); }
    renderShop();
  });
  document.addEventListener('keydown', e => { if (e.code === 'Escape' && shop.style.display === 'flex') shop.style.display = 'none'; });
  HOME_FN.fishShop = function () { renderShop(); shop.style.display = 'flex'; };
  WORLD_MARKS.push({ id: 'fish_shop', x: PX0 + 16, z: PZ, r: 4, c: [0.3, 0.9, 0.6], br: 2.5, label: '🎣 РЫБАЦКАЯ ЛАВКА: УДОЧКИ, НАЖИВКА, ПРОДАЖА', short: '🎣 ЛАВКА', dot: '#2fd0ff', fn: 'fishShop' });
  WORLD_MARKS.push({ id: 'fish_spot', x: PXE - 4, z: PZ, r: 5, c: [0.3, 0.7, 1], br: 2.5, label: '🎣 РЫБАЛКА: ЗАБРОСИТЬ / ПОДСЕЧЬ', short: '🎣 КЛЁВ', dot: '#2fd0ff', fn: 'fishSpot' });

  /* --- поплавок --- */
  let BOB = null;
  function bobMesh() {
    if (BOB) return BOB; const g = new Geo();
    g.box(-0.14, 0, -0.14, 0.14, 0.2, 0.14, [1, 0.15, 0.12, 1], false, true); g.box(-0.1, 0.2, -0.1, 0.1, 0.36, 0.1, [1, 1, 1, 1], false, true); g.box(-0.02, 0.36, -0.02, 0.02, 0.6, 0.02, [0.1, 0.1, 0.12, 1], false, true);
    return BOB = makeMesh(g);
  }
  const sd0 = seaDraw;
  seaDraw = function () {
    sd0.apply(this, arguments);
    if (F.st === 'wait' || F.st === 'bite' || F.st === 'fight') {
      const t = G.time, dip = F.st === 'bite' ? -0.18 + Math.sin(t * 40) * 0.06 : Math.sin(t * 1.7) * 0.04;
      setPass('opaque');
      mTRS(DM, F.x, -0.04 + dip, F.z, 0, 0, 0, 1, 1, 1); drawMesh(bobMesh(), DM, 1, 1, 1, 1, 0, false);
    }
  };
  const v0 = v18Tick;
  v18Tick = function (dt) {
    v0(dt);
    const sp = spot(), act = F.st !== '';
    if (act && (P.hp <= 0 || G.mode !== 'play' || G.inHome || (F.mode === 'pier' && (!onPier() || Math.hypot(P.x - F.ox, P.z - F.oz) > 5)) || (F.mode === 'boat' && (!P.boat || Math.abs(P.boat.v) > 3)))) stop('🎣 Леска смотана');
    if (F.st === 'wait') { F.t -= dt; if (F.t <= 0) { F.st = 'bite'; F.bt = 1.35; SFX.hit(); toast('🐟 КЛЮЁТ! Жмите L / кнопку'); for (let i = 0; i < 6; i++) emit(F.x, 0.1, F.z, rand(-1, 1), rand(2, 4), rand(-1, 1), 0.5, 0.2, 0.5, 1, 1, 1, 0.9, false); } }
    else if (F.st === 'bite') { F.bt -= dt; if (F.bt <= 0) { stop('💨 Рыба сорвалась — вы зевнули поклёвку'); SFX.err(); } }
    const quiet = UI.cur !== null || G.paused || shop.style.display === 'flex';
    const show = (sp || act) && !quiet && G.mode === 'play';
    btn.style.display = show ? 'block' : 'none';
    btn.className = F.st === 'bite' ? 'bite' : '';
    btn.textContent = F.st === '' ? '🎣 Закинуть удочку (L)' : F.st === 'wait' ? '🎣 Смотать (L)' : F.st === 'bite' ? '❗ ПОДСЕКАЙ! (L)' : '🎣 Вываживание…';
    hud.style.display = show && FD().bait >= 0 ? 'block' : 'none';
    if (show) hud.textContent = RODS[FD().rod].ico + ' ' + RODS[FD().rod].n + ' · 🪱 ' + FD().bait + ' · рыбы в садке: ' + Object.values(FD().bag).reduce((a, b) => a + b, 0);
  };
  window.__fish = { F, FISH, RODS, cast, FD };
}
