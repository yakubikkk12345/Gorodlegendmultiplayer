/* ===================== v42: ПЛАВАНИЕ, УТОПЛЕНИЕ, ТОНУЩИЕ МАШИНЫ, КАТЕРА, HUD РОЗЫСКА И РАДИО ===================== */
{
  const SW = EDGE + 14;                       // конец песка — дальше море
  const PZ = 120, PX0 = EDGE + 5, PX1 = SW + 72, PXE = SW + 84, PHW = 4.2;
  function onPier(x, z) { return (x > PX0 && x < PX1 && Math.abs(z - PZ) < PHW) || (x >= PX1 && x < PXE && Math.abs(z - PZ) < 8.2); }
  const wet = (x, z) => (Math.abs(x) > SW || Math.abs(z) > SW) && !onPier(x, z);
  const css = document.createElement('style');
  css.textContent = `
#stars { left: auto !important; transform: none !important; right: calc(var(--safe-r, 0px) + 12px + 162px) !important; top: calc(var(--safe-t, 0px) + 48px) !important; padding: 3px 9px !important; gap: 2px !important; flex-wrap: wrap; max-width: 46vw; justify-content: flex-end; }
#stars small { font-size: 10px !important; }
#radioPill { left: auto !important; transform: none !important; right: calc(var(--safe-r, 0px) + 12px + 162px) !important; top: calc(var(--safe-t, 0px) + 12px) !important; max-width: 40vw; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; padding: 4px 10px !important; }
#onBtn { right: auto !important; left: calc(var(--safe-l, 0px) + 232px) !important; top: calc(var(--safe-t, 0px) + 12px) !important; }
@media (max-height: 560px) {
  #menu { overflow-y: auto; }
  #menu .btn { padding: 8px 10px !important; font-size: 15px !important; border-radius: 11px !important; }
  #menu .btn.primary { font-size: 16px !important; }
  #menu .menu-btns { gap: 6px !important; }
  #menu .menu-foot { text-align: left !important; left: 14px !important; right: auto !important; bottom: 4px !important; font-size: 13px; }
  #menu .vtag { position: absolute; left: 14px; bottom: 24px; font-size: 10px; max-width: 28vw; opacity: .7; }
}
.vtag { color: var(--mut, #9aa4b8); font-size: 11px; text-align: center; }
#diveBtn { position: fixed; left: 50%; transform: translateX(-50%); bottom: calc(var(--safe-b, 0px) + 178px); z-index: 24; padding: 6px 14px; border-radius: 16px; background: rgba(8,16,30,.78); border: 1px solid rgba(120,200,255,.6); color: #fff; font: 700 13px system-ui, sans-serif; display: none; }
#airBox { position: fixed; left: 50%; transform: translateX(-50%); bottom: calc(var(--safe-b, 0px) + 150px); z-index: 24; width: 190px; height: 20px; border-radius: 10px; background: rgba(8,16,30,.72); border: 1px solid rgba(120,200,255,.5); overflow: hidden; display: none; pointer-events: none; }
#airBox i { position: absolute; left: 0; top: 0; bottom: 0; width: 100%; background: linear-gradient(90deg, #2aa7ff, #7fdcff); }
#airBox span { position: absolute; inset: 0; text-align: center; font: 700 11px/20px system-ui, sans-serif; color: #fff; text-shadow: 0 1px 2px #000; }
#airBox.low i { background: linear-gradient(90deg, #e5484d, #ff9a5a); }
`;
  document.head.appendChild(css);
  const airBox = document.createElement('div'); airBox.id = 'airBox';
  airBox.innerHTML = '<i></i><span>🫧 ВОЗДУХ</span>';
  document.body.appendChild(airBox);
  const diveBtn = document.createElement('button'); diveBtn.id = 'diveBtn'; document.body.appendChild(diveBtn);
  diveBtn.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); toggleDive(); });
  const airFill = airBox.firstChild;
  P.air = 100; P.swim = false; P.dep = 0; P.dive = false;
  let splT = 0, hitT = 0, jPrev = false, shallowT = 0;
  const dst = (x, z) => Math.max(Math.abs(x), Math.abs(z)) - SW;
  const bedD = d => d <= 0 ? 0 : Math.min(5, 0.06 + 0.1 * (Math.floor(d / 2) * 2 + 1));   // глубина дна: ступени по 2 м, пологий спуск
  const floorAt = (x, z) => bedD(dst(x, z));
  const toggleDive = () => {
    if (!P.swim) return;
    if (!P.dive && floorAt(P.x, P.z) < 1.5) { toast('🏖 Слишком мелко, отплывите дальше от берега'); return; }
    P.dive = !P.dive; SFX.click();
    if (P.dive) for (let i = 0; i < 10; i++) emit(P.x + rand(-0.4, 0.4), 0.05, P.z + rand(-0.4, 0.4), rand(-1.5, 1.5), rand(2, 4), rand(-1.5, 1.5), 0.7, 0.2, 0.5, 0.95, 0.98, 1, 0.8, false);
  };
  document.addEventListener('keydown', e => { if (e.code === 'KeyV' && UI.cur === null && G.mode === 'play') toggleDive(); });

  /* --- игрок: плавание и ныряние --- */
  const uw0 = updateWalk;
  updateWalk = function (dt, inp) {
    const ox = P.x, oz = P.z;
    uw0(dt, inp);
    if (G.inHome || P.roof || P.car) { P.swim = false; P.dive = false; P.dep = 0; return; }
    const jn = !!(inp && inp.jump);
    if (P.swim && jn && !jPrev) toggleDive();
    jPrev = jn;
    const flr = floorAt(P.x, P.z);
    if (wet(P.x, P.z) && !P.swim && flr < 1.1) {                 // мелководье: идём по дну, вода по колено/пояс
      P.dive = false; P.dep = 0; P.jh = 0;
      const k = 1 - 0.45 * clamp(flr / 1.1, 0, 1);
      P.x = ox + (P.x - ox) * k; P.z = oz + (P.z - oz) * k; P.speed *= k;
      P.y += (-flr - P.y) * Math.min(1, dt * 9);
      P.air = Math.min(100, P.air + dt * 70);
      splT -= dt;
      if (splT <= 0 && P.speed > 0.6) { splT = 0.16; emit(P.x + rand(-0.3, 0.3), 0.04, P.z + rand(-0.3, 0.3), rand(-0.8, 0.8), 1.2, rand(-0.8, 0.8), 0.6, 0.2, 0.7, 0.95, 0.98, 1, 0.55, false); }
      if (!P.wade) { P.wade = true; for (let i = 0; i < 6; i++) emit(P.x, 0.05, P.z, rand(-1.5, 1.5), rand(1, 3), rand(-1.5, 1.5), 0.6, 0.2, 0.5, 0.9, 0.95, 1, 0.7, false); }
    } else if (wet(P.x, P.z) && !(P.swim && flr < 0.85)) {
      P.wade = false;
      if (!P.swim) {
        P.swim = true; P.jh = 0; P.dive = false; P.dep = 0;
        for (let i = 0; i < 14; i++) emit(P.x + rand(-0.4, 0.4), 0.05, P.z + rand(-0.4, 0.4), rand(-2.5, 2.5), rand(2, 5), rand(-2.5, 2.5), 0.8, 0.2, 0.5, 0.9, 0.95, 1, 0.8, false);
        toast('🌊 Вы плывёте. Нырнуть/всплыть — «Прыжок» или V');
      }
      const fl = floorAt(P.x, P.z), tgt = P.dive ? Math.min(2.6, fl - 0.7) : 0;
      if (P.dive && tgt < 0.4) P.dive = false;
      P.dep += clamp(tgt - P.dep, -2.2 * dt, 2 * dt);
      P.x = ox + (P.x - ox) * 0.5; P.z = oz + (P.z - oz) * 0.5; P.speed *= 0.5;
      P.y = -0.12 - P.dep + (P.dep < 0.3 ? Math.sin(G.time * 3) * 0.04 : 0); P.jh = 0;
      const under = P.dep > 0.7;
      if (under) P.air = Math.max(0, P.air - dt * 100 / 20); else P.air = Math.min(100, P.air + dt * 60);
      splT -= dt;
      if (splT <= 0 && P.speed > 0.4) { splT = 0.14; if (!under) emit(P.x, 0.04, P.z, rand(-0.6, 0.6), 0.9, rand(-0.6, 0.6), 0.7, 0.25, 0.9, 0.95, 0.98, 1, 0.55, false); }
      if (under && Math.random() < dt * 4) emit(P.x + rand(-0.3, 0.3), -P.dep + 0.5, P.z + rand(-0.3, 0.3), 0, 1.3, 0, 1.2, 0.1, 0.3, 1, 1, 1, 0.6, false);
      if (under && P.air <= 0 && P.hp > 0) {
        P.hp -= 20 * dt; P.lastSrc = 'drown'; HITFX.lastHit = G.time; HITFX.flash = Math.max(HITFX.flash, 0.4);
      }
    } else {
      if (P.swim) { P.swim = false; P.dive = false; P.dep = 0; }
      if (P.wade || P.swim === false && P.y < terrainY(P.x, P.z) - 0.02) { P.y += (terrainY(P.x, P.z) - P.y) * Math.min(1, dt * 9); if (!wet(P.x, P.z) && Math.abs(P.y - terrainY(P.x, P.z)) < 0.03) { P.y = terrainY(P.x, P.z); P.wade = false; } }
      P.air = Math.min(100, P.air + dt * 70);
    }
  };
  const pd0 = playerDown;
  playerDown = function () {
    const dr = P.lastSrc === 'drown';
    pd0();
    P.air = 100; P.swim = false; P.dive = false; P.dep = 0; P.wade = false;
    if (dr) toast('🌊 Вы утонули. Вас откачали в больнице');
  };
  const dh0 = drawHuman;
  drawHuman = function (x, y, z, yaw, phase, amp, look, lod, sc, gun, fall) {
    if (P.swim && x === P.x && z === P.z && !P.car) return dh0(x, -0.3 - P.dep + (P.dep < 0.3 ? Math.sin(G.time * 3) * 0.04 : 0), z, yaw, G.time * (P.dep > 0.3 ? 3 : 5), 1, look, lod, sc, null, 1);
    return dh0(x, y, z, yaw, phase, amp, look, lod, sc, gun, fall);
  };

  /* --- машины: тонут --- */
  const sp0 = stepPhys;
  stepPhys = function (c, inp, dt) {
    if (c.def.heli) return sp0(c, inp, dt);
    const w = wet(c.x, c.z) && floorAt(c.x, c.z) > 0.45;
    if (!w) {
      if (c.sunk) c.sunk = 0;
      if (wet(c.x, c.z)) { sp0(c, inp, dt); const k = Math.exp(-0.9 * dt); c.vx *= k; c.vz *= k; if (Math.abs(c.vf) > 3 && Math.random() < dt * 12) emit(c.x + rand(-1, 1), 0.05, c.z + rand(-1.5, 1.5), rand(-1, 1), rand(1, 2), rand(-1, 1), 0.7, 0.2, 0.6, 0.95, 0.98, 1, 0.55, false); return; }
      return sp0(c, inp, dt);
    }
    c.sunk = (c.sunk || 0) + dt * 0.42;
    sp0(c, c.sunk > 0.35 ? null : inp, dt);
    const k = Math.exp(-1.7 * dt); c.vx *= k; c.vz *= k;
    if (Math.random() < dt * 14) emit(c.x + rand(-1, 1), 0.05, c.z + rand(-1.6, 1.6), rand(-1, 1), rand(1, 3), rand(-1, 1), 0.9, 0.2, 0.7, 0.95, 0.98, 1, 0.6, false);
    if (c.sunk > 0.6 && Math.random() < dt * 8) emit(c.x + rand(-0.8, 0.8), 0.1, c.z + rand(-1.2, 1.2), 0, 1.6, 0, 1, 0.12, 0.4, 1, 1, 1, 0.5, false);
    if (P.car === c && c.sunk > 0.8) { exitCar(true); toast('🌊 Машина тонет! Плывите к берегу'); }
    if (c.sunk > 1.7) {
      if (c === OWN) toast('🚗 Ваша машина утонула. Её можно вызвать снова');
      removeCar(c);
    }
  };
  const dc0 = drawCar;
  drawCar = function (c, dist) {
    const s = c.sunk || 0;
    if (!s || !(wet(c.x, c.z) && floorAt(c.x, c.z) > 0.3)) return dc0(c, dist);
    if (s > 1.6) return;
    const y0 = c.y, p0 = c.pitch, l0 = c.lean;
    c.y = y0 - s * 0.95; c.pitch = (p0 || 0) - s * 0.12; c.lean = (l0 || 0) + Math.sin(G.time * 2.3) * 0.04 * Math.min(1, s * 2);
    dc0(c, dist);
    c.y = y0; c.pitch = p0; c.lean = l0;
  };

  /* --- тротуар-набережная и гуляющие --- */
  let PAVE = null;
  const PR = EDGE + 2.5;     // середина тротуара
  const buildPave = () => {
    const gs = new GeoSet(), y = -0.04, T = 30, A = [0.62, 0.62, 0.66, 1], B = [0.57, 0.57, 0.62, 1], CB = [0.8, 0.8, 0.82, 1];
    const a0 = EDGE - 1.9, a1 = EDGE + 6;
    let q = 0;
    for (let t = -a1; t < a1; t += T, q++) {
      const t2 = Math.min(t + T, a1), c = (q & 1) ? A : B;
      gs.g().flat(t, a0, t2, a1, y, c); gs.g().flat(t, -a1, t2, -a0, y, c);
      if (t >= -a0 && t2 <= a0) { gs.g().flat(a0, t, a1, t2, y, c); gs.g().flat(-a1, t, -a0, t2, y, c); }
    }
    for (let t = -a1; t < a1; t += T) {          // бордюр у кромки моря
      const t2 = Math.min(t + T, a1);
      gs.g().flat(t, a1 - 0.35, t2, a1, y + 0.002, CB); gs.g().flat(t, -a1, t2, -a1 + 0.35, y + 0.002, CB);
      if (t >= -a0 && t2 <= a0) { gs.g().flat(a1 - 0.35, t, a1, t2, y + 0.002, CB); gs.g().flat(-a1, t, -a1 + 0.35, t2, y + 0.002, CB); }
    }
    PAVE = gs.done();
  };
  const RL = 8 * PR;
  const ringPos = (s, lat) => {
    const L = 2 * PR; s = ((s % RL) + RL) % RL; const k = Math.floor(s / L), u = s - k * L - PR;
    if (k === 0) return [u, -PR + lat, Math.PI / 2];
    if (k === 1) return [PR - lat, u, 0];
    if (k === 2) return [-u, PR - lat, -Math.PI / 2];
    return [-PR + lat, -u, Math.PI];
  };
  const ringS = (x, z) => {
    const L = 2 * PR;
    if (Math.abs(x) > Math.abs(z)) return x > 0 ? L + z + PR : 3 * L - z + PR;
    return z < 0 ? x + PR : 2 * L - x + PR;
  };
  const PROM_N = 16; let promT = 0;
  const shirts = ['#3a86ff', '#2ecc71', '#ffd60a', '#ff4fa3', '#9b5de5', '#f1f1f1', '#ff7b00', '#00b4d8'];
  const up0 = updatePeds;
  updatePeds = function (dt) {
    up0(dt);
    if (G.inHome) return;
    let n = 0;
    for (const p of peds) if (p.prom) n++;
    while (n < PROM_N && peds.length < 400) {
      peds.push({ bi: 8, bj: 8, s: 0, dir: Math.random() < 0.5 ? 1 : -1, sp: rand(0.8, 1.3), x: 0, z: 0, h: 0, ph: Math.random() * 6, look: genPedLook(shirts), prom: true, ps: Math.random() * RL, lat: rand(-2.2, 2.6) });
      n++;
    }
    promT -= dt; let relo = 0; if (promT <= 0) { promT = 0.7; relo = 2; }
    const near = Math.abs(Math.max(Math.abs(P.x), Math.abs(P.z)) - PR) < 200, sp = near ? ringS(P.x, P.z) : 0;
    for (const p of peds) {
      if (!p.prom || p.drv || p.thief) continue;
      p.bi = 8; p.bj = 8;
      if (p.dead) continue;
      if (near && relo > 0 && Math.hypot(p.x - P.x, p.z - P.z) > 170 && Math.hypot(p.x - CAM.x, p.z - CAM.z) > 130) { p.ps = sp + rand(-120, 120); relo--; }
      if (p.talk > 0) continue;
      const pm = p.panic > 0 ? 2.4 : 1; if (p.panic > 0) p.panic -= dt;
      p.ps += p.dir * p.sp * pm * dt; p.ph += p.sp * pm * dt * 3.2;
      const r = ringPos(p.ps, p.lat);
      p.x = r[0]; p.z = r[1]; p.h = p.dir > 0 ? r[2] : r[2] + Math.PI;
    }
  };
  /* вызов машины после утопления: машина не должна оставаться «под землёй» */
  const cc0 = callCar;
  callCar = function () {
    cc0();
    if (OWN) { OWN.sunk = 0; if (!OWN.def.heli) OWN.y = terrainY(OWN.x, OWN.z); }
  };

  /* --- катера и качка --- */
  const sm0 = shipMesh;
  shipMesh = function (kind) {
    if (kind !== 'speed') return sm0(kind);
    const g = new Geo(), box = (a, b, c, d, e, f, col) => g.box(a, b, c, d, e, f, col, false, true);
    const W = [0.96, 0.96, 0.98, 1];
    box(-1.1, 0, -3.2, 1.1, 0.75, 2.2, W); box(-0.6, 0, 2.2, 0.6, 0.65, 3.7, W); box(-0.3, 0.2, 3.7, 0.3, 0.55, 4.1, W);
    box(-1.12, 0.38, -3.2, 1.12, 0.55, 2.2, [0.85, 0.15, 0.18, 1]);
    box(-0.8, 0.75, -0.7, 0.8, 1.35, -0.5, [0.2, 0.45, 0.7, 1]); box(-0.7, 0.75, -2.3, 0.7, 1.05, -1.2, [0.12, 0.12, 0.16, 1]);
    box(-0.3, 0.25, -3.6, 0.3, 1, -3.2, [0.2, 0.2, 0.24, 1]);
    return makeMesh(g);
  };
  const BOATS = [];
  const mkBoats = () => {
    const E = EDGE;
    [[-420, E + 70, 60, 0, 0.2], [380, E + 110, 90, 2, -0.15], [140, -(E + 80), 70, 1, 0.19], [-250, -(E + 120), 100, 4, -0.13], [E + 90, -150, 65, 3, 0.2], [-(E + 100), 220, 80, 5, -0.16]]
      .forEach((b, i) => BOATS.push({ m: shipMesh('speed'), cx: b[0], cz: b[1], r: b[2], a: b[3], sp: b[4], ph: i * 1.7 }));
  };
  /* --- дно, рыбы, пловцы, акула --- */
  const hex = h => hexRGB(h);
  const SWIM = [], FISH = [];
  let BED = null, FM = null, SHM = null;
  const buildLife = () => {
    const E2 = SW, N = EDGE + 600, g = new Geo();
    const lerpc = (t) => [0.6 - 0.48 * t, 0.56 - 0.34 * t, 0.4 - 0.1 * t, 1];
    const NL = 26;
    for (let k = 0; k < NL; k++) {
      const d0 = 2 * k, dp = bedD(d0 + 0.01), h0 = E2 + d0, h1 = k < NL - 1 ? E2 + d0 + 2 : N, y1 = -dp, y0 = y1 - 3, c = lerpc(dp / 5);
      g.box(-h1, y0, h0, h1, y1, h1, c, false, true); g.box(-h1, y0, -h1, h1, y1, -h0, c, false, true);
      g.box(-h1, y0, -h0, -h0, y1, h0, c, false, true); g.box(h0, y0, -h0, h1, y1, h0, c, false, true);
    }
    BED = makeMesh(g);
    const f = new Geo(), fb = (a, b, c, d, e, h, col) => f.box(a, b, c, d, e, h, col, false, true);
    fb(-0.09, -0.1, -0.3, 0.09, 0.12, 0.28, [1, 0.62, 0.22, 1]); fb(-0.02, -0.08, -0.5, 0.02, 0.1, -0.3, [1, 0.8, 0.3, 1]); fb(-0.02, 0.12, -0.1, 0.02, 0.2, 0.12, [1, 0.5, 0.2, 1]);
    FM = makeMesh(f);
    const sh = new Geo(), sb = (a, b, c, d, e, h, col) => sh.box(a, b, c, d, e, h, col, false, true);
    sb(-0.45, -0.35, -1.8, 0.45, 0.35, 1.6, [0.45, 0.5, 0.55, 1]); sb(-0.3, -0.25, 1.6, 0.3, 0.25, 2.2, [0.45, 0.5, 0.55, 1]); sb(-0.05, 0.35, -0.3, 0.05, 1.05, 0.5, [0.38, 0.42, 0.47, 1]);
    sb(-0.05, -0.3, -2.4, 0.05, 0.6, -1.8, [0.38, 0.42, 0.47, 1]); sb(-0.9, -0.1, 0.2, 0.9, 0.05, 0.7, [0.4, 0.45, 0.5, 1]);
    SHM = makeMesh(sh);
    const R = rng(77), side = [[0, 1], [0, -1], [1, 0], [-1, 0]];
    for (let k = 0; k < 14; k++) {
      const sd = side[k % 4], u = (R() - 0.5) * 1000, d = SW + 40 + R() * 60;
      const cx = sd[0] ? sd[0] * d : u, cz = sd[1] ? sd[1] * d : u;
      for (let i = 0; i < 7; i++) FISH.push({ cx, cz, r: 6 + R() * 8, a: R() * 6.28, sp: (0.25 + R() * 0.25) * (R() < 0.5 ? 1 : -1), dep: 1 + R() * 1.4, ph: R() * 6.28, sc: 0.8 + R() * 0.9 });
    }
    const looks = [['#1a6fb0', '#f2c230', '#e0ac86', '#2a1a10'], ['#c0392b', '#ffffff', '#c68e6b', '#16110d'], ['#2e8b57', '#f5f5f5', '#f1c7a5', '#5a3825'], ['#222222', '#e67e22', '#8d5a3b', '#111111'], ['#7a1f3d', '#3b6ea8', '#e0ac86', '#3a2415']];
    [[-200, SW + 36, 18, 0.18, 0], [130, SW + 44, 22, -0.14, 0], [450, SW + 34, 16, 0.2, 1.7], [-420, -(SW + 38), 20, -0.16, 0], [SW + 42, 250, 18, 0.17, 1.9], [-(SW + 40), -300, 20, -0.15, 0], [60, -(SW + 46), 14, 0.2, 1.6], [SW + 50, -380, 16, -0.18, 0]]
      .forEach((w, i) => { const L = looks[i % 5]; SWIM.push({ cx: w[0], cz: w[1], r: w[2], sp: w[3], dep: w[4], ph: i * 1.3, look: { pants: hex(L[0]), shirt: hex(L[1]), skin: hex(L[2]), hair: hex(L[3]), dark: [0.05, 0.05, 0.05] } }); });
  };


  let lastT42 = 0;
  const WCOL = [0.08, 0.40, 0.66, 1];
  seaDraw = function () {
    if (G.mode !== 'play' || G.inHome) return;
    if (!SEA.sides) seaInit();
    if (!BED) buildLife();
    if (!BOATS.length) mkBoats();
    const t = G.time, dt = Math.min(0.1, Math.max(0, t - lastT42)); lastT42 = t;
    const k = 0.97 + 0.04 * Math.sin(t * 0.7), far = ENV.fogFar + 80;
    setPass('opaque');
    drawMesh(BED, IDENT, 1, 1, 1, 1, 0, false);
    const near = (x, z, r) => Math.hypot(x - CAM.x, z - CAM.z) < r;
    for (const f of FISH) {
      const a = f.a + f.sp * t, x = f.cx + Math.cos(a) * f.r, z = f.cz + Math.sin(a) * f.r;
      if (!near(x, z, 140)) continue;
      const yaw = Math.atan2(-Math.sin(a) * f.sp, Math.cos(a) * f.sp) + Math.sin(t * 6 + f.ph) * 0.25;
      mTRS(DM, x, -f.dep + Math.sin(t * 1.3 + f.ph) * 0.2, z, yaw, 0, 0, f.sc, f.sc, f.sc); drawMesh(FM, DM, 1, 1, 1, 1, 0, false);
    }
    { const a = 0.5 + 0.09 * t, x = 0 + Math.cos(a) * 260, z = (SW + 90) + Math.sin(a) * 40;
      if (near(x, z, 220)) { mTRS(DM, x, -0.45, z, Math.atan2(-Math.sin(a) * 0.09 * 40, Math.cos(a) * 0.09 * 260), 0, Math.sin(t * 2) * 0.05, 1.3, 1.3, 1.3); drawMesh(SHM, DM, 1, 1, 1, 1, 0, false); } }
    for (const w of SWIM) {
      const a = w.ph + w.sp * t, x = w.cx + Math.cos(a) * w.r, z = w.cz + Math.sin(a) * w.r;
      if (!near(x, z, 120)) continue;
      const yaw = Math.atan2(-Math.sin(a) * w.sp, Math.cos(a) * w.sp);
      dh0(x, -0.3 - w.dep + (w.dep ? 0 : Math.sin(t * 2.5 + w.ph) * 0.04), z, yaw, t * 4 + w.ph, 1, w.look, 0, 1, null, 1);
      if (w.dep) { if (Math.random() < dt * 2) emit(x, -w.dep + 0.4, z, 0, 1.2, 0, 1.4, 0.1, 0.3, 1, 1, 1, 0.6, false); }
      else if (Math.random() < dt * 4) emit(x, 0.04, z, rand(-0.4, 0.4), 0.8, rand(-0.4, 0.4), 0.6, 0.2, 0.7, 0.95, 0.98, 1, 0.5, false);
    }
    window.__pierDraw(t, dt);
    for (const s of SEA.ships) {
      let x, z, yaw;
      if (s.r) { const a = s.a + s.sp * t; x = s.cx + Math.cos(a) * s.r; z = s.cz + Math.sin(a) * s.r; yaw = Math.atan2(-Math.sin(a) * s.sp, Math.cos(a) * s.sp); }
      else { const span = s.x1 - s.x0, u = ((s.x - s.x0 + s.v * t) % (span * 2) + span * 2) % (span * 2); x = s.x0 + (u < span ? u : span * 2 - u); z = s.z; yaw = (u < span) === (s.v > 0) ? Math.PI / 2 : -Math.PI / 2; }
      if (Math.hypot(x - CAM.x, z - CAM.z) > far) continue;
      mTRS(DM, x, -0.1 + Math.sin(t * 0.9 + s.ph) * 0.18, z, yaw, Math.sin(t * 0.7 + s.ph) * 0.02, Math.sin(t * 0.8 + s.ph) * 0.03, 1, 1, 1); drawMesh(s.m, DM, 1, 1, 1, 1, 0, false);
    }
    const wake = (x, z, yaw, len, n, big) => {
      if (Math.hypot(x - CAM.x, z - CAM.z) > 170) return;
      const sx = Math.sin(yaw), cz = Math.cos(yaw);
      for (let i = 0; i < n; i++) {
        const s = (Math.random() - 0.5) * 2;
        emit(x - sx * len + cz * s * 0.9, 0.05, z - cz * len - sx * s * 0.9, -sx * 1.5 + cz * s * 1.6, 0.8 + Math.random() * 1.2, -cz * 1.5 - sx * s * 1.6, 1.1, 0.4 * big, 1.9 * big, 0.95, 0.98, 1, 0.5, false);
      }
    };
    for (const b of BOATS) {
      const a = b.a + b.sp * t, x = b.cx + Math.cos(a) * b.r, z = b.cz + Math.sin(a) * b.r;
      const yaw = Math.atan2(-Math.sin(a) * b.sp, Math.cos(a) * b.sp);
      if (Math.hypot(x - CAM.x, z - CAM.z) > 420) continue;
      const bounce = Math.sin(t * 5 + b.ph);
      mTRS(DM, x, -0.12 + bounce * 0.12, z, yaw, -0.07 + Math.sin(t * 3 + b.ph) * 0.03, (b.sp > 0 ? -0.16 : 0.16) + Math.sin(t * 2 + b.ph) * 0.03, 1, 1, 1);
      drawMesh(b.m, DM, 1, 1, 1, 1, 0, false);
      wake(x, z, yaw, 3.4, 2, 1);
      if (P.swim && Math.hypot(x - P.x, z - P.z) < 3.2 && G.time > hitT && P.dep < 0.5) { hitT = G.time + 1.5; hurtPlayer(25, 'boat'); toast('🚤 Вас сбил катер!'); }
    }
    for (const s of SEA.ships) {
      if (!s.r) continue;
      const a = s.a + s.sp * t, x = s.cx + Math.cos(a) * s.r, z = s.cz + Math.sin(a) * s.r;
      if (Math.random() < 0.6) wake(x, z, Math.atan2(-Math.sin(a) * s.sp, Math.cos(a) * s.sp), 6, 1, 1.3);
    }
    /* вода — полупрозрачная, поверх дна, рыб и пловцов */
    setPass('alpha');
    for (const s of SEA.sides) {
      const dx = Math.max(s.x0 - CAM.x, 0, CAM.x - s.x1), dz = Math.max(s.z0 - CAM.z, 0, CAM.z - s.z1);
      if (dx * dx + dz * dz > far * far) continue;
      for (const m of s.ms) drawMesh(m, IDENT, k * 0.98, k, k * 1.02, 0.45, 0, false);
    }
    setPass('decal');
    for (const m of SEA.beach) drawMesh(m, IDENT, k * 0.98, k, k * 1.02, 1, 0, false);
    if (!PAVE) buildPave();
    for (const m of PAVE) drawMesh(m, IDENT, 1, 1, 1, 1, 0, false);
    setPass('opaque');
    if (P.swim) {
      airBox.style.display = 'block'; airFill.style.width = P.air + '%'; airBox.classList.toggle('low', P.air < 30);
      diveBtn.style.display = 'block'; diveBtn.textContent = P.dive ? '⬆ Всплыть' : '🤿 Нырнуть';
      if (P.dive && P.air < 25 && G.time > shallowT) { shallowT = G.time + 4; toast('⚠ Кончается воздух — всплывайте!'); }
    } else { airBox.style.display = 'none'; diveBtn.style.display = 'none'; }
  };

  /* --- мультиплеер: зайти к другу в магазин, видеть его, видеть как его ранят --- */
  {
    const css2 = document.createElement('style');
    css2.textContent = `#joinBtn { position: fixed; left: 50%; transform: translateX(-50%); top: calc(var(--safe-t, 0px) + 150px); z-index: 26; padding: 8px 16px; border-radius: 18px; background: linear-gradient(180deg, #ffc233, #ff8c1a); color: #1a0f00; font: 800 14px system-ui, sans-serif; border: 0; box-shadow: 0 6px 20px rgba(255,140,26,.45); display: none; }`;
    document.head.appendChild(css2);
    const jb = document.createElement('button'); jb.id = 'joinBtn'; document.body.appendChild(jb);
    const okKind = k => !!(k && k !== 'home' && INT[k] && NPC[k]);
    const ms0 = mpSend;
    mpSend = function (m) {
      if (m && m.t === 's') m.ik = (G.inHome && G.int && okKind(G.int.kind)) ? G.int.kind : '';
      return ms0(m);
    };
    const ma0 = mpApply;
    mpApply = function (p, st) {
      const old = p.hp;
      ma0(p, st);
      p.ik = typeof st.ik === 'string' ? st.ik : '';
      p.shT = st.sh ? G.time : (p.shT || 0);
      if (old != null && p.hp != null && p.hp < old - 0.5 && p.got) {
        const seen = (p.v && !G.inHome) || sameInt(p);
        if (seen) {
          for (let i = 0; i < 8; i++) emit(p.x + rand(-0.2, 0.2), p.y + 0.9 + Math.random() * 0.5, p.z + rand(-0.2, 0.2), rand(-2, 2), rand(0.5, 2.5), rand(-2, 2), 0.6, 0.2, 0.9, 0.85, 0.12, 0.12, 0.8, false);
          if (G.time - (p.hurtToast || 0) > 3) { p.hurtToast = G.time; toast('💥 ' + p.name + ' ранен! ❤ ' + Math.round(p.hp)); }
        }
      }
    };
    const sameInt = p => !!(G.inHome && G.int && p.got && p.ik && p.ik === G.int.kind && !p.v);
    const mv0 = mpVisible;
    mpVisible = function (p) { return mv0(p) || sameInt(p); };
    const dhs0 = drawHomeScene;
    drawHomeScene = function () {
      dhs0();
      if (MP.state !== 'on') return;
      for (const p of MP.peers.values()) {
        if (!sameInt(p)) continue;
        let gun = null;
        if (p.wp && GUNMODEL[p.wp]) { gun = p.gun || (p.gun = { id: '', aim: 0, kick: 0, reload: 0, ap: 0 }); gun.id = p.wp; gun.aim += ((p.sh ? 1 : 0.25) - gun.aim) * 0.2; gun.ap = p.ar || 0; }
        drawHuman(p.x, p.y, p.z, p.h, p.ph, p.am, p.look, false, 1, gun);
        setPass('alpha'); mTRS(DM, p.x, p.y + 0.04, p.z, 0, 0, 0, 0.55, 1, 0.55); drawMesh(M_DISC, DM, 1, 1, 1, 1, 1, false); setPass('opaque');
        if (p.sh && G.time - (p.shT || 0) < 0.3 && Math.random() < 0.5) emit(p.x + Math.sin(p.h) * 0.9, p.y + 1.1, p.z + Math.cos(p.h) * 0.9, 0, 0, 0, 0.08, 0.3, 0.1, 1, 0.85, 0.4, 1, true);
      }
    };
    let joining = false;
    setInterval(() => {
      let f = null;
      if (MP.state === 'on' && G.mode === 'play' && !G.inHome && !G.paused && UI.cur === null && !joining) {
        for (const p of MP.peers.values()) if (p.got && !p.v && okKind(p.ik)) { f = p; break; }
      }
      if (!f) { jb.style.display = 'none'; jb._p = null; return; }
      jb._p = f; jb.style.display = 'block';
      const tx = '🚪 ' + f.name + ' в магазине — зайти к нему';
      if (jb.textContent !== tx) jb.textContent = tx;
    }, 400);
    jb.addEventListener('pointerdown', e => {
      e.preventDefault(); e.stopPropagation();
      const f = jb._p; if (!f || joining || G.inHome) return;
      const kind = f.ik; joining = true; jb.style.display = 'none';
      HOME_FN.enterShop({ kind, x: P.x, z: P.z });
      let n = 0;
      const t = setInterval(() => {
        if (G.inHome && G.int && G.int.kind === kind) {
          clearInterval(t); joining = false;
          const q = MP.peers.get(f.id) || f; P.x = q.x + 1.3; P.z = q.z - 1.3; P.y = 0;
          toast('👥 Вы зашли к ' + f.name);
        } else if (++n > 40) { clearInterval(t); joining = false; }
      }, 100);
    });
  }

  /* ===================== ПИРС, КУПАЛЬЩИКИ, ПРИСТАНЬ С ЛОДКАМИ, ЯХТЫ ===================== */
  {
    const css3 = document.createElement('style');
    css3.textContent = `
#boatUi { position: fixed; left: 50%; transform: translateX(-50%); top: 40%; z-index: 26; display: none; flex-direction: column; gap: 8px; align-items: center; }
#boatUi button { padding: 10px 20px; border-radius: 22px; border: 0; font: 800 15px system-ui, sans-serif; color: #10202a; background: linear-gradient(180deg, #7fe3ff, #2aa7ff); box-shadow: 0 6px 20px rgba(42,167,255,.45); }
#boatShop { position: fixed; inset: 0; z-index: 60; display: none; background: rgba(4,10,20,.78); backdrop-filter: blur(5px); overflow-y: auto; padding: calc(var(--safe-t, 0px) + 12px) 14px 16px; color: #fff; font-family: system-ui, sans-serif; }
#boatShop h2 { margin: 0 0 4px; font-size: 20px; } #boatShop .sub { opacity: .7; font-size: 12px; margin-bottom: 10px; }
#boatShop .x { position: absolute; right: calc(var(--safe-r, 0px) + 14px); top: calc(var(--safe-t, 0px) + 10px); width: 40px; height: 40px; border-radius: 20px; border: 0; background: rgba(255,255,255,.14); color: #fff; font-size: 20px; }
#boatShop .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 10px; }
#boatShop .card { background: linear-gradient(180deg, rgba(30,52,80,.9), rgba(14,26,44,.95)); border: 1px solid rgba(120,200,255,.3); border-radius: 16px; padding: 12px; display: flex; flex-direction: column; gap: 5px; }
#boatShop .card .ic { font-size: 34px; } #boatShop .card b { font-size: 16px; } #boatShop .card small { opacity: .75; line-height: 1.25; }
#boatShop .card .pr { color: #ffd23f; font-weight: 800; font-size: 17px; }
#boatShop .card button { padding: 9px 10px; border-radius: 12px; border: 0; font-weight: 800; font-size: 14px; color: #10202a; background: linear-gradient(180deg, #ffc233, #ff8c1a); }
#boatShop .card button.b2 { background: linear-gradient(180deg, #7fe3ff, #2aa7ff); }
#boatShop .card button[disabled] { opacity: .45; }`;
    document.head.appendChild(css3);
    const ui = document.createElement('div'); ui.id = 'boatUi'; document.body.appendChild(ui);
    const shop = document.createElement('div'); shop.id = 'boatShop'; document.body.appendChild(shop);

    const BD = {
      row: { name: 'Лодка', ico: '🛶', price: 6000, hw: 0.9, len: 4.2, vmax: 6, acc: 2.4, turn: 1.7, deck: 0.45, helm: -0.6, berth: [PX1 - 56, PZ - 6.5], desc: 'Простая моторная лодка: покататься вдоль берега.' },
      speed: { name: 'Катер', ico: '🚤', price: 42000, hw: 1.15, len: 7.5, vmax: 27, acc: 7, turn: 1.35, deck: 0.8, helm: -0.8, berth: [PX1 - 56, PZ + 6.7], desc: 'Быстрый катер: лови волну и прыгай на брызгах.' },
      yacht: { name: 'Яхта', ico: '🛥', price: 480000, hw: 3.2, len: 19, vmax: 11, acc: 2.2, turn: 0.6, deck: 1.4, helm: 4.6, cabin: 'yacht', berth: [PX1 - 26, PZ - 8.7], desc: 'Яхта с каютой: кровать, бар, диван и телевизор.' },
      mega: { name: 'Мега-яхта', ico: '🚢', price: 2400000, hw: 4.4, len: 30, vmax: 9, acc: 1.6, turn: 0.42, deck: 2.0, helm: 8.5, cabin: 'mega', berth: [PX1 - 18, PZ + 10.3], desc: 'Огромная яхта: две кровати, бар, бассейн и джакузи.' }
    };
    const BT = {};
    const owned = t => !!(S.boatsOwn && S.boatsOwn[t]);
    const getBT = t => owned(t) ? (BT[t] || (BT[t] = { type: t, x: BD[t].berth[0], z: BD[t].berth[1], h: Math.PI / 2, v: 0, ph: Math.random() * 6 })) : null;
    let BM = null;
    const buildBoatMeshes = () => {
      BM = {};
      const W = [0.96, 0.96, 0.98, 1], NV = [0.1, 0.18, 0.36, 1], WD = [0.56, 0.38, 0.2, 1], GLS = [0.1, 0.24, 0.34, 1], DK = [0.14, 0.14, 0.17, 1], RD = [0.85, 0.15, 0.18, 1];
      const mk = fn => { const g = new Geo(), b = (a, b2, c, d, e, f, col) => g.box(a, b2, c, d, e, f, col, false, true); fn(b); return makeMesh(g); };
      BM.row = mk(b => { b(-0.8, 0, -2.1, 0.8, 0.45, 1.5, [0.85, 0.82, 0.74, 1]); b(-0.5, 0, 1.5, 0.5, 0.45, 2.2, [0.85, 0.82, 0.74, 1]); b(-0.82, 0.28, -2.1, 0.82, 0.4, 1.5, [0.2, 0.45, 0.75, 1]); b(-0.7, 0.45, -1.2, 0.7, 0.62, -0.7, WD); b(-0.7, 0.45, 0.2, 0.7, 0.62, 0.7, WD); b(-0.15, 0.2, -2.4, 0.15, 0.95, -2.1, DK); });
      BM.speed = shipMesh('speed');
      BM.yacht = mk(b => {
        b(-3, 0, -9, 3, 1.3, 6.5, W); b(-2.2, 0, 6.5, 2.2, 1.3, 8.2, W); b(-1.2, 0, 8.2, 1.2, 1.3, 9.6, W); b(-3.02, 0.55, -9, 3.02, 0.8, 6.5, NV); b(-2.8, 1.3, -8.8, 2.8, 1.38, 6.3, WD);
        b(-2.4, 1.38, -6.2, 2.4, 3.1, 2.4, W); b(-2.43, 1.9, -5.6, 2.43, 2.6, 1.8, GLS); b(-2.5, 3.1, -6.6, 2.5, 3.28, 3, NV); b(-1.7, 3.28, -5, 1.7, 4.2, -0.4, W); b(-1.72, 3.5, -4.6, 1.72, 4.0, -0.8, GLS);
        b(-1.3, 1.38, -8.5, 1.3, 1.8, -7.2, [0.9, 0.85, 0.75, 1]); b(-0.08, 4.2, -2.8, 0.08, 6.6, -2.65, DK); b(-2.5, 1.38, 3.4, 2.5, 1.9, 3.6, W);
      });
      BM.mega = mk(b => {
        b(-4.2, 0, -14.5, 4.2, 2, 10.5, W); b(-3.2, 0, 10.5, 3.2, 2, 13.4, W); b(-1.6, 0, 13.4, 1.6, 2, 15, W); b(-4.22, 0.8, -14.5, 4.22, 1.2, 10.5, NV); b(-4, 2, -14.3, 4, 2.08, 10.3, WD);
        b(-3.4, 2.08, -7, 3.4, 4.6, 6, W); b(-3.43, 2.8, -6.4, 3.43, 3.9, 5.4, GLS); b(-3.5, 4.6, -7.5, 3.5, 4.8, 6.5, NV);
        b(-2.6, 4.8, -5.5, 2.6, 6.8, 2.5, W); b(-2.63, 5.4, -5, 2.63, 6.4, 2, GLS); b(-2.7, 6.8, -6, 2.7, 6.95, 3, NV); b(-0.1, 6.95, -1.5, 0.1, 10, -1.3, DK);
        b(-2.2, 2.08, -13.6, 2.2, 2.3, -8.2, [0.4, 0.8, 0.95, 1]); b(-2.3, 2.08, -13.7, -2.2, 2.45, -8.1, W); b(2.2, 2.08, -13.7, 2.3, 2.45, -8.1, W);
      });
    };
    /* пирс: настил, сваи, фонари, киоск */
    let PIER = null, PIERG = null;
    const buildPier = () => {
      const g = new Geo(), l = new Geo(), b = (a, b2, c, d, e, f, col) => g.box(a, b2, c, d, e, f, col, false, true), gl = (a, b2, c, d, e, f, col) => l.box(a, b2, c, d, e, f, col, false, true);
      const WA = [0.62, 0.45, 0.27, 1], WB = [0.55, 0.39, 0.22, 1], PL = [0.3, 0.2, 0.12, 1];
      let q = 0;
      for (let x = PX0; x < PX1; x += 2, q++) b(x, 0.2, PZ - PHW, Math.min(x + 2, PX1), 0.28, PZ + PHW, q & 1 ? WA : WB);
      b(PX1, 0.2, PZ - 8.2, PXE, 0.28, PZ + 8.2, WA);
      for (let x = SW - 2; x <= PX1; x += 6) for (const s of [-1, 1]) b(x - 0.28, -5.2, PZ + s * (PHW - 0.35) - 0.28, x + 0.28, 0.2, PZ + s * (PHW - 0.35) + 0.28, PL);
      for (const sx of [PX1 + 0.5, PXE - 0.5]) for (const s of [-1, 1]) b(sx - 0.3, -5.2, PZ + s * 7.9 - 0.3, sx + 0.3, 0.2, PZ + s * 7.9 + 0.3, PL);
      for (let x = PX0 + 6; x < PX1; x += 12) for (const s of [-1, 1]) { b(x - 0.08, 0.28, PZ + s * (PHW - 0.2) - 0.08, x + 0.08, 2.6, PZ + s * (PHW - 0.2) + 0.08, DKc); gl(x - 0.22, 2.6, PZ + s * (PHW - 0.2) - 0.22, x + 0.22, 3.0, PZ + s * (PHW - 0.2) + 0.22, [1, 0.9, 0.6, 1]); }
      // киоск продавца лодок
      const kx = EDGE + 8, kz = PZ + 5.6;
      b(kx, 0, kz + 3.6, kx + 5.5, 2.5, kz + 3.8, [0.2, 0.5, 0.75, 1]); b(kx, 0, kz, kx + 0.2, 2.5, kz + 3.8, [0.2, 0.5, 0.75, 1]); b(kx + 5.3, 0, kz, kx + 5.5, 2.5, kz + 3.8, [0.2, 0.5, 0.75, 1]);
      b(kx - 0.3, 2.5, kz - 0.3, kx + 5.8, 2.75, kz + 4.1, [0.95, 0.95, 0.97, 1]); b(kx - 0.3, 2.75, kz - 0.3, kx + 5.8, 2.9, kz + 0.2, RD);
      b(kx, 0, kz, kx + 5.5, 1.05, kz + 0.9, [0.9, 0.9, 0.92, 1]); b(kx - 0.1, 1.05, kz - 0.1, kx + 5.6, 1.15, kz + 1.0, WB);
      gl(kx + 0.6, 2.95, kz - 0.2, kx + 4.9, 3.35, kz + 0.1, [0.3, 0.8, 1, 1]); gl(kx + 1.2, 3.05, kz - 0.25, kx + 2.2, 3.25, kz - 0.2, [1, 1, 1, 1]);
      // шезлонги и полотенца
      for (let i = 0; i < 4; i++) { const z = PZ - 14 - i * 5, x = EDGE + 8.5; b(x, 0.0, z, x + 2.0, 0.06, z + 0.9, [[1, 0.4, 0.5, 1], [0.3, 0.8, 1, 1], [1, 0.85, 0.3, 1], [0.5, 0.9, 0.5, 1]][i]); }
      PIER = makeMesh(g); PIERG = makeMesh(l);
    };
    const DKc = [0.25, 0.18, 0.12, 1], RD = [0.85, 0.15, 0.18, 1];
    const tY0 = terrainY;
    terrainY = function (x, z) { return onPier(x, z) ? 0.28 : tY0(x, z); };
    const inPierBox = (x, z, m) => (x > PX0 - m && x < PX1 + m && Math.abs(z - PZ) < PHW + m) || (x > PX1 - m && x < PXE + m && Math.abs(z - PZ) < 8.2 + m);

    /* купальщики и загорающие */
    const SW2 = [];
    {
      const R = rng(311), sk = ['#e0ac86', '#c68e6b', '#f1c7a5', '#8d5a3b', '#d8a07a'], tr = ['#e63946', '#ffd60a', '#2ec4b6', '#ff7b00', '#9b5de5', '#3a86ff', '#ff4fa3', '#06d6a0'], hr = ['#16110d', '#5a3825', '#d9b36c', '#b5451b', '#3a2415'];
      const lk = () => { const s = hex(sk[Math.floor(R() * sk.length)]); return { pants: hex(tr[Math.floor(R() * tr.length)]), shirt: s, skin: s, hair: hex(hr[Math.floor(R() * hr.length)]), dark: [0.05, 0.05, 0.05] }; };
      for (let i = 0; i < 6; i++) SW2.push({ k: 'wade', x: SW + 2 + R() * 6, z: PZ + (i % 2 ? 1 : -1) * (14 + R() * 26), r: 1.2 + R() * 1.6, sp: 0.3 + R() * 0.3, ph: R() * 6, look: lk() });
      for (let i = 0; i < 5; i++) SW2.push({ k: 'swim', x: SW + 18 + R() * 28, z: PZ + (i % 2 ? 1 : -1) * (14 + R() * 18), r: 5 + R() * 5, sp: (0.18 + R() * 0.16) * (i % 2 ? 1 : -1), ph: R() * 6, look: lk() });
      for (let i = 0; i < 4; i++) SW2.push({ k: 'sun', x: EDGE + 9.5, z: PZ - 14 - i * 5 + 0.4, ph: 1.57, look: lk() });
      for (let i = 0; i < 4; i++) SW2.push({ k: 'stand', x: PX0 + 18 + i * 9 + R() * 3, z: PZ + (R() < 0.5 ? -1 : 1) * 2.6, ph: R() * 6, look: lk() });
    }
    const drawBathers = (t) => {
      for (const w of SW2) {
        if (Math.hypot(w.x - CAM.x, w.z - CAM.z) > 150) continue;
        if (w.k === 'wade') { const a = w.ph + w.sp * t, x = w.x + Math.cos(a) * w.r, z = w.z + Math.sin(a) * w.r; dh0(x, -floorAt(x, z), z, Math.atan2(-Math.sin(a) * w.sp, Math.cos(a) * w.sp), t * 2 + w.ph, 0.5, w.look, 0, 1, null, 0); }
        else if (w.k === 'swim') { const a = w.ph + w.sp * t, x = w.x + Math.cos(a) * w.r, z = w.z + Math.sin(a) * w.r; dh0(x, -0.3 + Math.sin(t * 2.5 + w.ph) * 0.04, z, Math.atan2(-Math.sin(a) * w.sp, Math.cos(a) * w.sp), t * 4 + w.ph, 1, w.look, 0, 1, null, 1); if (Math.random() < 0.03) emit(x, 0.04, z, rand(-0.4, 0.4), 0.8, rand(-0.4, 0.4), 0.6, 0.2, 0.7, 0.95, 0.98, 1, 0.5, false); }
        else if (w.k === 'sun') dh0(w.x, 0.08, w.z, w.ph, 0, 0, w.look, 0, 1, null, 1);
        else dh0(w.x, 0.28, w.z, w.ph * 0.5, 0, 0, w.look, 0, 1, null, 0);
      }
      const sx = EDGE + 10.7, sz = PZ + 7.4;      // продавец за стойкой киоска
      if (Math.hypot(sx - CAM.x, sz - CAM.z) < 150) dh0(sx, 0, sz, Math.PI, 0, 0, SELLER_LOOK, 0, 1, null, 0);
    };
    const SELLER_LOOK = { pants: hex('#1c3a5c'), shirt: hex('#f5f5f5'), skin: hex('#c68e6b'), hair: hex('#222222'), dark: [0.05, 0.05, 0.05] };

    /* лодки: движение и управление */
    const bedAtD = (x, z) => floorAt(x, z);
    const stepBoat = (b, dt, thr, st) => {
      const D = BD[b.type];
      const target = thr > 0 ? thr * D.vmax : thr * D.vmax * 0.35;
      b.v += (target - b.v) * Math.min(1, dt * (thr ? D.acc / Math.max(3, D.vmax) * 1.8 : 0.5));
      b.h -= st * D.turn * dt * clamp(Math.abs(b.v) / (D.vmax * 0.3), 0, 1) * (b.v >= 0 ? 1 : -1);
      const sx = Math.sin(b.h), cz = Math.cos(b.h), nx = b.x + sx * b.v * dt, nz = b.z + cz * b.v * dt;
      const bx = nx + sx * D.len * 0.45, bz = nz + cz * D.len * 0.45, sx2 = nx - sx * D.len * 0.45, sz2 = nz - cz * D.len * 0.45;
      const lim = WLIM() - 5, hwm = 0.6;
      const bad = p => dst(p[0], p[1]) < 1.5 + 0.2 * D.hw || inPierBox(p[0], p[1], hwm) || Math.abs(p[0]) > lim || Math.abs(p[1]) > lim;
      const side = [[nx - cz * D.hw, nz + sx * D.hw], [nx + cz * D.hw, nz - sx * D.hw]];
      const berthed = Math.hypot(b.x - D.berth[0], b.z - D.berth[1]) < 5 && !b.out;
      if (!berthed && (bad([bx, bz]) || bad([nx, nz]) || bad(side[0]) || bad(side[1]) || bad([sx2, sz2]))) { b.v *= -0.35; if (Math.abs(b.v) > 1.5) emit(b.x, 0.3, b.z, 0, 2, 0, 0.5, 0.3, 1, 1, 1, 1, 0.6, false); }
      else { b.x = nx; b.z = nz; if (Math.hypot(b.x - D.berth[0], b.z - D.berth[1]) > 5) b.out = true; }
      if (b.out && Math.hypot(b.x - D.berth[0], b.z - D.berth[1]) < 1.5) b.out = false;
      if (Math.abs(b.v) < 0.05) b.v = 0;
    };
    const wakeBoat = (b, dt) => {
      const D = BD[b.type]; if (Math.abs(b.v) < 1.5) return;
      const n = Math.min(4, 1 + Math.abs(b.v) / 8);
      for (let i = 0; i < n; i++) {
        const s = (Math.random() - 0.5) * 2 * D.hw, sx = Math.sin(b.h), cz = Math.cos(b.h);
        emit(b.x - sx * D.len * 0.5 + cz * s, 0.05, b.z - cz * D.len * 0.5 - sx * s, -sx * 1.5 + cz * s, 0.9 + Math.random(), -cz * 1.5 - sx * s, 1.1, 0.4, 1.6 + D.hw * 0.4, 0.95, 0.98, 1, 0.55, false);
      }
    };
    const boardBoat = (b) => {
      P.boat = b; P.swim = false; P.dive = false; P.dep = 0; P.wade = false; P.vis = true; P.speed = 0; if (P.car) exitCar(true);
      const D = BD[b.type]; P.x = b.x + Math.sin(b.h) * D.helm; P.z = b.z + Math.cos(b.h) * D.helm; P.y = D.deck; P.h = b.h;
      toast(D.ico + ' ' + D.name + ': ведите джойстиком / WASD. Кнопка «Сойти» — выйти');
    };
    const leaveBoat = () => {
      const b = P.boat; if (!b) return; const D = BD[b.type];
      P.boat = null; b.v = 0;
      const d = Math.hypot(b.x - (PX0 + PX1) / 2, b.z - PZ);
      const side = b.z < PZ ? -1 : 1;
      if (b.x > PX0 && b.x < PXE + 4 && Math.abs(b.z - PZ) < D.hw + 10) { P.x = clamp(b.x, PX0 + 2, PX1 - 1); P.z = PZ + side * 2.8; P.y = 0.28; }
      else { P.x = b.x + Math.cos(b.h) * (D.hw + 1.4); P.z = b.z - Math.sin(b.h) * (D.hw + 1.4); P.y = -0.1; }
      P.vis = true; P.speed = 0; CAM.pitch = 0.3;
    };
    const boatNear = () => {
      if (P.boat || G.inHome || P.car || G.mode !== 'play') return null;
      for (const t in BD) {
        const b = getBT(t); if (!b) continue; const D = BD[t];
        const dx = P.x - b.x, dz = P.z - b.z, lf = dx * Math.sin(b.h) + dz * Math.cos(b.h), ll = dx * Math.cos(b.h) - dz * Math.sin(b.h);
        if (Math.abs(ll) < D.hw + 3.4 && Math.abs(lf) < D.len / 2 + 3.4 && Math.abs((P.y || 0) - D.deck) < 6) return b;
      }
      return null;
    };
    /* ввод */
    const uw1 = updateWalk;
    updateWalk = function (dt, inp) {
      if (P.boat && !G.inHome) {
        const b = P.boat, D = BD[b.type]; CB.inp = inp;
        const thr = clamp(inp.y, -1, 1), st = clamp(inp.x, -1, 1);
        stepBoat(b, dt, thr, st); wakeBoat(b, dt);
        if (Math.abs(b.v) > 2 && (Math.abs(st) > 0.1 || Math.abs(thr) > 0.1)) CAM.yaw += wrapA(b.h - CAM.yaw) * Math.min(1, dt * 1.4);
        const bob = Math.sin(G.time * 1.3 + b.ph) * 0.03 * (D.hw + 1);
        P.x = b.x + Math.sin(b.h) * D.helm; P.z = b.z + Math.cos(b.h) * D.helm; P.y = D.deck + bob; P.h = b.h; P.speed = 0; P.jh = 0; P.swim = false; P.air = 100;
        return;
      }
      return uw1(dt, inp);
    };
    const pd1 = playerDown; playerDown = function () { P.boat = null; pd1(); };
    /* кнопки */
    const CAB = { bt: null };
    const ensureInt = kind => { if (CITY && CITY.ints && !CITY.ints[kind]) CITY.ints[kind] = buildYachtInterior(kind); };
    const enterCabin = () => {
      const bt = P.boat; if (!bt || !BD[bt.type].cabin || G.inHome) return;
      if (Math.abs(bt.v) > 1.5) { toast('⚓ Сначала остановитесь'); return; }
      const kind = BD[bt.type].cabin; CAB.bt = bt;
      fadeThen(() => {
        ensureInt(kind); const o = INT[kind]; P.boat = null; bt.v = 0;
        setHomeState(true, kind, { x: bt.x, z: bt.z, h: bt.h });
        P.x = o.x; P.z = o.z - 4.6; P.y = 0; P.h = 0; P.speed = 0; P.vis = true; CAM.yaw = 0; CAM.pitch = 0.82; CAM.off = 0;
        toast('🛥 Добро пожаловать на борт!');
      });
    };
    HOME_FN.leaveYacht = function () {
      fadeThen(() => { const bt = CAB.bt; setHomeState(false); if (bt) boardBoat(bt); else { P.x = INX; P.z = INZ; } CAM.yaw = Math.PI; CAM.pitch = 0.3; });
    };
    let boatKey = '';
    setInterval(() => {
      const near = boatNear(); let key = '', html = '';
      if (G.mode === 'play' && !G.inHome && !G.paused && UI.cur === null && !shopOpen) {
        if (P.boat) { key = 'on' + (BD[P.boat.type].cabin && Math.abs(P.boat.v) < 1.5 ? 'c' : ''); }
        else if (near) key = 'near' + near.type;
      }
      if (key === boatKey) return; boatKey = key;
      if (!key) { ui.style.display = 'none'; return; }
      ui.style.display = 'flex'; ui.innerHTML = '';
      const add = (txt, fn) => { const b = document.createElement('button'); b.textContent = txt; b.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); fn(); }); ui.appendChild(b); };
      if (key.startsWith('near')) add(BD[near.type].ico + ' Сесть: ' + BD[near.type].name, () => { const n = boatNear(); if (n) boardBoat(n); });
      else { if (key === 'onc') add('🛏 В каюту', enterCabin); add('⚓ Сойти', leaveBoat); }
    }, 300);
    window.addEventListener('keydown', e => {
      if (e.code !== 'KeyF' || G.mode !== 'play' || G.inHome || UI.cur !== null) return;
      if (P.boat) { e.stopImmediatePropagation(); leaveBoat(); } else { const n = boatNear(); if (n) { e.stopImmediatePropagation(); boardBoat(n); } }
    }, true);

    /* магазин */
    let shopOpen = false;
    const closeShop = () => { shopOpen = false; shop.style.display = 'none'; };
    const renderShop = () => {
      let h = '<button class="x">✕</button><h2>⚓ Пристань «Морской бриз»</h2><div class="sub">Купленные лодки ждут у причала на пирсе. «Вызвать» вернёт лодку к причалу, откуда бы вы её ни оставили.</div><div class="grid">';
      for (const t in BD) {
        const D = BD[t], o = owned(t);
        h += '<div class="card"><div class="ic">' + D.ico + '</div><b>' + D.name + '</b><small>' + D.desc + '<br>Скорость до ' + Math.round(D.vmax * 3.6) + ' км/ч' + (D.cabin ? ' · есть каюта' : '') + '</small>';
        if (o) h += '<div class="pr">✔ Ваша</div><button class="b2" data-bcall="' + t + '"' + (P.boat && P.boat.type === t ? ' disabled' : '') + '>📍 Вызвать к причалу</button>';
        else h += '<div class="pr">' + fmtMoney(D.price) + '</div><button data-bbuy="' + t + '"' + (S.money < D.price ? ' disabled' : '') + '>Купить</button>';
        h += '</div>';
      }
      shop.innerHTML = h + '</div>';
    };
    shop.addEventListener('click', e => {
      const t = e.target.closest('button'); if (!t) return;
      if (t.classList.contains('x')) { closeShop(); return; }
      if (t.dataset.bbuy) {
        const d = t.dataset.bbuy, D = BD[d];
        if (S.money < D.price) { SFX.err(); toast('Не хватает денег'); return; }
        S.money -= D.price; (S.boatsOwn || (S.boatsOwn = {}))[d] = true; getBT(d); persist(); SFX.buy(); refreshMoney(true);
        toast(D.ico + ' ' + D.name + ' куплена! Она ждёт у причала на пирсе'); renderShop();
      } else if (t.dataset.bcall) {
        const b = getBT(t.dataset.bcall), D = BD[t.dataset.bcall]; if (!b || (P.boat === b)) return;
        b.x = D.berth[0]; b.z = D.berth[1]; b.h = Math.PI / 2; b.v = 0; b.out = false; SFX.click(); toast(D.ico + ' ' + D.name + ' пришвартована у причала'); renderShop();
      }
    });
    document.addEventListener('keydown', e => { if (e.code === 'Escape' && shopOpen) closeShop(); });
    HOME_FN.boatShop = function () { shopOpen = true; renderShop(); shop.style.display = 'block'; toast('⚓ Продавец: добро пожаловать на пристань!'); };
    WORLD_MARKS.push({ id: 'boat_shop', x: EDGE + 10.6, z: PZ + 4.2, c: [0.3, 0.85, 1], label: '⚓ ПРОДАВЕЦ ЛОДОК: КУПИТЬ / ВЫЗВАТЬ', short: '⚓ ПРИСТАНЬ', dot: '#2fd0ff', fn: 'boatShop', r: 4.5, br: 3 });
    NPC.yacht = { ico: '🛥', name: 'Яхта', role: 'Каюта', greet: [''], tips: [] }; NPC.mega = { ico: '🚢', name: 'Мега-яхта', role: 'Каюта', greet: [''], tips: [] };

    /* интерьеры яхт */
    INT.yacht = { kind: 'yacht', x: INX + 5900, z: INZ }; INT.mega = { kind: 'mega', x: INX + 6200, z: INZ };
    for (const k of ['yacht', 'mega']) {
      const O = INT[k];
      const mk = o => WORLD_MARKS.push(Object.assign({ int: true, r: 2.2 }, o));
      mk({ id: 'door_' + k, x: O.x, z: O.z - 6.3, r: 2.6, label: '🚪 ВЫЙТИ НА ПАЛУБУ', fn: 'leaveYacht' });
      mk({ id: 'bed_' + k, x: O.x - 6.6, z: O.z + 4.6, r: 2.6, label: '🛏 ЛЕЧЬ СПАТЬ', fn: 'yachtSleep' });
      mk({ id: 'bar_' + k, x: O.x + 4.2, z: O.z + 0.2, r: 2.6, label: '🍸 БАР: ВЫПИТЬ КОКТЕЙЛЬ ($30)', fn: 'yachtBar' });
      mk({ id: 'tv_' + k, x: O.x - 7.6, z: O.z + 0.2, r: 2.2, label: '📺 СМОТРЕТЬ ТВ', fn: 'watchTV' });
      if (k === 'mega') mk({ id: 'pool_' + k, x: O.x + 0.7, z: O.z + 3.6, r: 3.0, label: '🏊 БАССЕЙН: ИСКУПАТЬСЯ', fn: 'yachtPool' });
    }
    HOME_FN.yachtSleep = function () { fadeThen(() => { dayT = DAY_LEN * 0.05; P.hp = 100; toast('😴 Вы выспались на яхте. Наступило утро.'); persist(); }); };
    HOME_FN.yachtBar = function () {
      if (S.money < 30) { SFX.err(); toast('Нужно $30'); return; }
      S.money -= 30; P.hp = Math.min(100, P.hp + 25); SFX.buy(); refreshMoney(true); toast('🍸 Бармен: за ваше здоровье! +25 ❤');
    };
    HOME_FN.yachtPool = function () {
      SFX.click(); P.hp = 100; toast('🏊 Вы искупались в бассейне. Силы восстановлены!');
      const O = INT.mega; for (let i = 0; i < 16; i++) emit(O.x + rand(-1.5, 2.8), 0.3, O.z + rand(2, 5.5), rand(-2, 2), rand(2, 5), rand(-2, 2), 0.9, 0.2, 0.6, 0.8, 0.95, 1, 0.8, false);
    };
    function buildYachtInterior(kind) {
      const O = INT[kind], S1 = new GeoSet(), S2 = new GeoSet(), bg = mkBG(S1, S2, O.x, O.z), B = bg[0], GL = bg[1];
      const wood = [0.5, 0.34, 0.2], wh = [0.93, 0.93, 0.95], navy = [0.1, 0.2, 0.38], dark = [0.1, 0.1, 0.13];
      B(-9.6, -0.4, -7.6, 9.6, -0.02, 7.6, wood);
      for (let i = -9; i < 9; i += 2) B(i, -0.02, -7.5, i + 0.06, 0.004, 7.5, [0.42, 0.28, 0.16]);
      B(-9.7, -0.3, 7.5, 9.7, 3.4, 8.1, wh, true); B(-9.7, -0.3, -8.1, 9.7, 3.4, -7.5, wh, true); B(-9.7, -0.3, -7.5, -9.1, 3.4, 7.5, wh, true); B(9.1, -0.3, -7.5, 9.7, 3.4, 7.5, wh, true);
      B(-9.1, 0, -7.5, 9.1, 0.35, -7.4, navy); B(-9.1, 0, 7.4, 9.1, 0.35, 7.5, navy);
      for (const x of [-7, -3.5, 0, 3.5, 7]) { GL(x - 0.7, 1.4, 7.42, x + 0.7, 2.4, 7.46, [0.5, 0.82, 1]); }
      GL(-9.06, 2.9, -7, -9.02, 3.0, 7, [1, 0.85, 0.5]); GL(9.02, 2.9, -7, 9.06, 3.0, 7, [1, 0.85, 0.5]);
      B(-1.7, 0, -7.55, 1.7, 3.0, -7.45, wh); B(-1.3, 0, -7.6, 1.3, 2.75, -7.4, [0.36, 0.22, 0.12]); B(0.8, 1.2, -7.4, 1.0, 1.4, -7.3, [0.95, 0.8, 0.2]);
      // кровать
      B(-8.6, 0, 2.8, -4.7, 0.4, 7.0, wood, true); B(-8.5, 0.4, 2.9, -4.8, 0.78, 6.9, wh); B(-8.5, 0.78, 2.9, -4.8, 0.9, 5.3, [0.2, 0.45, 0.78]);
      B(-8.4, 0.78, 5.9, -6.9, 1.0, 6.8, wh); B(-6.4, 0.78, 5.9, -4.9, 1.0, 6.8, wh); B(-8.7, 0, 6.9, -4.6, 1.6, 7.2, wood, true);
      B(-9.0, 0, 6.2, -8.7, 0.7, 7.0, wood, true); B(-4.6, 0, 6.2, -4.3, 0.7, 7.0, wood, true); GL(-8.95, 0.7, 6.4, -8.75, 0.95, 6.8, [1, 0.9, 0.6]);
      // бар
      B(5.1, 0, -3.6, 6.5, 1.1, 3.6, [0.22, 0.13, 0.08], true); B(5.0, 1.1, -3.7, 6.6, 1.2, 3.7, [0.85, 0.85, 0.88]);
      for (const z of [-2.4, 0, 2.4]) { B(3.8, 0, z - 0.3, 4.4, 0.7, z + 0.3, [0.6, 0.1, 0.16], true); }
      B(8.3, 0.9, -3.4, 9.0, 2.7, 3.4, [0.18, 0.1, 0.07], true);
      const bc2 = [[1, 0.3, 0.3], [0.3, 0.9, 0.5], [1, 0.8, 0.2], [0.3, 0.7, 1], [1, 0.5, 0.8]];
      for (let i = 0; i < 9; i++) { GL(8.25, 1.3 + (i % 3) * 0.55, -3.0 + i * 0.7, 8.3, 1.65 + (i % 3) * 0.55, -2.8 + i * 0.7, bc2[i % 5]); }
      // диван и ТВ
      B(-8.6, 0, -5.8, -3.2, 0.5, -4.0, [0.86, 0.8, 0.7], true); B(-8.6, 0.5, -6.2, -3.2, 1.2, -5.8, [0.8, 0.74, 0.64], true); B(-6.6, 0, -3.2, -5.0, 0.4, -2.2, wood, true);
      B(-9.1, 1.2, -1.5, -8.95, 2.5, 1.9, dark, true); GL(-8.95, 1.3, -1.4, -8.9, 2.4, 1.8, [0.3, 0.62, 0.92]);
      if (kind === 'mega') {
        B(-2.4, 0, 0.8, 3.9, 0.28, 6.4, [0.92, 0.92, 0.94], true); GL(-2.1, 0.24, 1.1, 3.6, 0.27, 6.1, [0.2, 0.75, 1]);
        B(3.2, 0, -5.6, 5.6, 0.5, -3.8, [0.92, 0.92, 0.94], true); GL(3.35, 0.45, -5.45, 5.45, 0.52, -3.95, [0.4, 0.85, 1]);
        B(-2.2, 0, -5.9, -0.2, 0.45, -4.4, [0.95, 0.9, 0.7], true); B(0.4, 0, -5.9, 2.4, 0.45, -4.4, [0.95, 0.9, 0.7], true);
        B(-2.9, 0, 0.8, -2.5, 0.3, 6.4, wood, true);
      }
      return { lit: S1.done(), glow: S2.done() };
    }
    const bc3 = buildCity;
    buildCity = function () { bc3(); CITY.ints.yacht = buildYachtInterior('yacht'); CITY.ints.mega = buildYachtInterior('mega'); };
    if (CITY && CITY.ints && CITY.ints.casino) { CITY.ints.yacht = buildYachtInterior('yacht'); CITY.ints.mega = buildYachtInterior('mega'); }

    /* отрисовка (вызывается из seaDraw) */
    window.__pierDraw = function (t, dt) {
      if (!PIER) buildPier();
      if (!BM) buildBoatMeshes();
      drawMesh(PIER, IDENT, 1, 1, 1, 1, 0, false); drawMesh(PIERG, IDENT, 1, 1, 1, 1, 1, false);
      drawBathers(t);
      for (const ty in BD) {
        const b = getBT(ty); if (!b) { delete BT[ty]; continue; }
        if (Math.hypot(b.x - CAM.x, b.z - CAM.z) > 420) continue;
        if (!P.boat || P.boat !== b) { b.v *= Math.exp(-0.6 * dt); if (Math.abs(b.v) > 0.05) { b.x += Math.sin(b.h) * b.v * dt; b.z += Math.cos(b.h) * b.v * dt; } else b.v = 0; }
        const D = BD[ty], k = D.hw;
        mTRS(DM, b.x, -0.05 + Math.sin(t * 1.2 + b.ph) * 0.06 * (0.5 + k * 0.2), b.z, b.h, Math.sin(t * 0.9 + b.ph) * 0.012 * (1 + k * 0.3) - clamp(b.v * 0.004, 0, 0.06), Math.sin(t * 1.1 + b.ph) * 0.02 * (1 + k * 0.3), 1, 1, 1);
        drawMesh(BM[ty], DM, 1, 1, 1, 1, 0, false);
      }
    };
  }
  window.__v42 = { wet, BOATS, dst, WLIM, PZ, SW, PX0, PX1 };
}

window.__game = { v31: () => ({ SEA, shipMesh, PJ, PORT, portOptions, pjStart, portMakeOffers, openTalk, BIZ_BY, blkAudit, PARKS,  CAS, casAct, casRender, bjVal, GRD, XM, firework, tankFire, TK, openScreen, selectCar, seatPlayer, ensureOwn, buyCar, cars, parts, CAR_BY_ID, playerDown, P, S, UI }), v30: () => ({ RC, ARENA, TR, RACES, v30Can, tradeAdd, tradeRemove, carRec, tradeStart, rcJoin, arenaJoin, ARENA_C, evHide }), v28: () => ({ cars, MP, WS, aimManual, aimToggle, zoomToggle, spawnDriver, carjack, peds, CAM, playerShoot, mpVisible, HOSP, nodeC, selectWeapon }), v25: () => ({ pushCircle, circles, nodeC, GRID, CAM, v25Tick, CB, GRN, BOMBS, BURN, EXP, boom, throwGrenade, c4Action, cbZ, cbMelee, carInit, v25Car, carHurt, fuelOpts, buyExp, getOwn: () => OWN, S, G, P, hasOffice, safeCap, safeIn, APT_FLOORS, HOME_FN, WORLD_MARKS, INT, bizTick, BIZ_BY, PROPS, incomeSummary, officeOptions }), v24: () => ({ INC, incSpawn, incClear, METRO, MS, metroOptions, WINTER, incomeSummary, officeOptions, officeGreet, emPatrol, AMB_DEF, FIRE_DEF, FLAKES }), v23: () => ({ ST, chState, fillLook, openStyle, styleClick, styleItems, TOPS, BOTS, DRESSES, SHOES, HAIR_STYLES, CAT, CLOTHES, SALONS, PLAYER_LOOK, applyLook, setGender, describeLook, genPedLook, buildHuman, hairParts }), v22: () => ({ INT, TOWER_FLOORS, towerPad, roofInfo, HOME_FN, WORLD_MARKS, APT_IDS, buyProp, selectCar, setHomeState }), v21: () => ({ clubState, clubRank, clubOptions, STORY2, epiIdx, epiOptions, epiGreet, walkJump, carShowPay, CLUB_BLK, TALK, openTalk, INT, WORLD_MARKS, blkAudit }), v20: () => ({ DIST, GANG, GANGS, ACC, distAt, gdState, spawnGang, damageGang, captureDist, accSpawn, ownedCount, killPed, peds }), v19: () => ({ roofInfo, roofY, roofDown, WET, reflOn, shadowAlpha, SHD, interactCar, exitCar, enterCar }), v18: () => ({ slotKey, slotInfo, switchSlot, exportSave, importSave, renderSlots, HINTS, HN, hintTick, get SLOT() { return SLOT; } }), v17: () => ({ WX, sigState, lightStop, RADIO, radioNext, radioIdx, GENRES, lightning }), blkAudit, v16: () => ({ STORES, PROPS, STORE_BY, PROP_BY, ROB, robStart, buyProp, garageCap, carCount, applyMod, markOf, WORLD_MARKS, INT, CITY, ownedIds, refreshGarageMarks, GFAKE, modKey, boxes }), WANT, peds, G, HOSP, POLST, hurt: (n,s)=>hurtPlayer(n,s), S: () => S, P, cars, CAM, startMission, enterGame, act, openScreen, closeScreens, MISSIONS, M: () => M, UI, keys, touch, endMission, addMoney, toMenu, drawScene: () => 0, HOME_FN, setDay: t => { dayT = t; }, CARS, makeCar, enterCar, exitCar, CAR_BY_ID, BIZ, STORY, openTalk, TALK, stepPhys, WX, ACH, NAV, navSet, buyGun, selectWeapon, playerShoot, PGUN, JOB, EV, taxiStart, thiefStart, walletStart, talkPed, lifeTick };
try { if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('/sw.js').catch(() => { }); } catch (e) { }
