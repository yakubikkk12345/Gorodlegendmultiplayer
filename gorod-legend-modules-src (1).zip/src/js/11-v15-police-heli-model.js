/* ===================== v15: ПОЛИЦЕЙСКИЙ ВЕРТОЛЁТ (модель и отрисовка) ===================== */
function buildPoliceHeli() {
  const wh = [0.95, 0.96, 0.98, 1], bl = [0.1, 0.22, 0.6, 1], gl = [0.08, 0.14, 0.22, 1], dk = [0.1, 0.1, 0.12, 1];
  const b = new Geo(), r = new Geo(), lr = new Geo(), lb = new Geo();
  b.box(-1.0, -0.7, -1.7, 1.0, 0.8, 2.1, wh, false, true);
  b.box(-1.02, -0.72, -1.7, 1.02, -0.15, 2.1, bl, false, true);
  b.box(-0.85, -0.05, 1.5, 0.85, 0.7, 2.45, gl, false, true);
  b.box(-0.22, 0.0, -6.6, 0.22, 0.55, -1.7, wh, false, true);
  b.box(-0.07, 0.55, -6.7, 0.07, 2.0, -5.9, bl, false, true);
  b.box(-0.9, -0.05, -6.1, 0.9, 0.05, -5.6, wh, false, true);
  b.box(-0.12, 0.8, -0.12, 0.12, 1.3, 0.12, dk, false, true);
  for (const sx of [-1.15, 1.15]) {
    b.box(sx - 0.05, -1.35, -2.0, sx + 0.05, -1.25, 2.2, dk, false, true);
    b.box(sx - 0.05, -1.3, -1.0, sx + 0.05, -0.7, -0.8, dk, false, true);
    b.box(sx - 0.05, -1.3, 1.0, sx + 0.05, -0.7, 1.2, dk, false, true);
  }
  r.box(-5.2, 0, -0.14, 5.2, 0.06, 0.14, dk, false, true);
  r.box(-0.14, 0, -5.2, 0.14, 0.06, 5.2, dk, false, true);
  lr.box(-0.8, -0.85, 0.8, -0.1, -0.7, 1.3, [1, 1, 1, 1], false, true);
  lb.box(0.1, -0.85, 0.8, 0.8, -0.7, 1.3, [1, 1, 1, 1], false, true);
  return { body: makeMesh(b), rotor: makeMesh(r), lampR: makeMesh(lr), lampB: makeMesh(lb) };
}
const PHM = newM(), PHR = newM(), PHW = newM();
function drawPoliceHeli() {
  const h = WANT.heli; if (!h || !M_PH) return;
  if (!visible(h.x, h.z, 10, 520)) return;
  mTRS(PHM, h.x, h.y + Math.sin(G.time * 2) * 0.4, h.z, h.h, 0.07, Math.sin(G.time * 1.3) * 0.04, 1, 1, 1);
  drawMesh(M_PH.body, PHM, 1, 1, 1, 1, 0, false);
  mTRS(PHR, 0, 1.3, 0, G.time * 34, 0, 0, 1, 1, 1); mMul(PHW, PHM, PHR);
  drawMesh(M_PH.rotor, PHW, 1, 1, 1, 1, 0, false);
  const ph = Math.floor(G.time * 5) % 2;
  drawMesh(M_PH.lampR, PHM, ph ? 1 : 0.15, 0.05, 0.05, 1, 1, false);
  drawMesh(M_PH.lampB, PHM, 0.05, 0.12 + (ph ? 0.1 : 0.7), ph ? 0.3 : 1, 1, 1, false);
}
/* прожектор вертолёта: аддитивный столб света + пятно на земле (вызывается в проходе 'add') */
function drawHeliLight() {
  const h = WANT.heli; if (!h) return;
  const dx = h.x - h.lx, dy = h.y - 0.2, dz = h.z - h.lz, len = Math.hypot(dx, dy, dz) || 1;
  const rx = Math.acos(clamp(dy / len, -1, 1)), ry = Math.atan2(dx, dz);
  const cd = Math.hypot(CAM.x - h.lx, CAM.z - h.lz), f = clamp((cd - 5) / 14, 0.12, 1);
  const a = (0.55 + ENV.night * 0.45) * f;
  mTRS(DM, h.lx, 0.2, h.lz, ry, rx, 0, 5.2, len, 5.2);
  drawMesh(M_SPOT, DM, 1, 0.97, 0.82, a, 2, false);
  mTRS(DM, h.lx, 0.3, h.lz, 0, 0, 0, 6.5, 1, 6.5);
  drawMesh(M_GLOW, DM, 1, 0.97, 0.82, (0.18 + ENV.night * 0.4) * f, 2, false);
}

