/* ===================== v46: ДАЙВИНГ — клады на дне, жемчуг, затонувшие корабли, баллоны и сонар ===================== */
{
  const V = window.__v42, SW = V.SW, PZ = V.PZ, PX0 = V.PX0;
  const bedD = d => d <= 0 ? 0 : Math.min(5, 0.06 + 0.1 * (Math.floor(d / 2) * 2 + 1));
  const floorAt = (x, z) => bedD(V.dst(x, z));
  const TYPES = {
    pearl: { ico: '🦪', n: 'Жемчужина', pay: 300, re: 15 * 60e3 },
    chest: { ico: '🧰', n: 'Сундук с монетами', pay: 1800, re: 25 * 60e3 },
    relic: { ico: '🏺', n: 'Древняя реликвия', pay: 7500, re: 40 * 60e3 },
    wreck: { ico: '💎', n: 'Сокровище затонувшего корабля', pay: 25000, re: 60 * 60e3 }
  };
  const TANKS = [{ n: 'Баллон 1 л (стандарт)', p: 0, k: 0 }, { n: 'Баллон 6 л', p: 9000, k: 0.35 }, { n: 'Баллон 12 л + регулятор', p: 35000, k: 0.65 }];
  const DD = () => S.dive || (S.dive = { got: {}, n: 0, total: 0, tank: 0, own: { 0: 1 }, sonar: 0, best: 0 });
  /* --- размещение кладов (одинаково при каждом запуске) --- */
  const ITEMS = [];
  {
    const R = rng(4242), sides = [[0, 1], [0, -1], [1, 0], [-1, 0]];
    for (let i = 0; i < 110; i++) {
      const sd = sides[i % 4], u = (R() - 0.5) * 1100, d = SW + 16 + R() * 105, x = sd[0] ? sd[0] * d : u, z = sd[1] ? sd[1] * d : u, q = R();
      ITEMS.push({ id: 'i' + i, t: q < 0.58 ? 'pearl' : q < 0.88 ? 'chest' : 'relic', x, z, ph: R() * 6 });
    }
    // затонувшие корабли — рядом с пирсом, чтобы их легко найти
    [[SW + 70, PZ + 44, 0.4], [SW + 95, PZ - 60, 1.2], [SW + 48, -180, 2.1], [-(SW + 80), 90, 0.9]].forEach((w, i) => ITEMS.push({ id: 'w' + i, t: 'wreck', x: w[0], z: w[1], ph: w[2], big: 1 }));
  }
  const avail = it => !((DD().got[it.id] || 0) > Date.now());
  /* --- меши --- */
  const MS = {};
  function meshes() {
    if (MS.pearl) return MS;
    const mk = fn => { const g = new Geo(); fn((a, b, c, d, e, f, col) => g.box(a, b, c, d, e, f, col, false, true)); return makeMesh(g); };
    MS.pearl = mk(b => { b(-0.3, 0, -0.3, 0.3, 0.14, 0.3, [0.35, 0.3, 0.4, 1]); b(-0.14, 0.14, -0.14, 0.14, 0.42, 0.14, [1, 0.95, 0.98, 1]); });
    MS.chest = mk(b => { b(-0.5, 0, -0.34, 0.5, 0.34, 0.34, [0.5, 0.3, 0.14, 1]); b(-0.5, 0.34, -0.34, 0.5, 0.56, 0.34, [0.42, 0.24, 0.1, 1]); b(-0.08, 0.2, 0.33, 0.08, 0.44, 0.38, [1, 0.85, 0.2, 1]); b(-0.52, 0, -0.1, -0.44, 0.56, 0.1, [1, 0.8, 0.2, 1]); b(0.44, 0, -0.1, 0.52, 0.56, 0.1, [1, 0.8, 0.2, 1]); });
    MS.relic = mk(b => { b(-0.26, 0, -0.26, 0.26, 0.12, 0.26, [0.9, 0.7, 0.15, 1]); b(-0.2, 0.12, -0.2, 0.2, 0.5, 0.2, [1, 0.82, 0.25, 1]); b(-0.3, 0.5, -0.3, 0.3, 0.8, 0.3, [1, 0.88, 0.3, 1]); b(-0.14, 0.8, -0.14, 0.14, 0.95, 0.14, [0.9, 0.7, 0.15, 1]); b(-0.38, 0.55, -0.06, -0.3, 0.7, 0.06, [0.9, 0.7, 0.15, 1]); b(0.3, 0.55, -0.06, 0.38, 0.7, 0.06, [0.9, 0.7, 0.15, 1]); });
    MS.wreck = mk(b => {
      const w = [0.3, 0.2, 0.12, 1], w2 = [0.22, 0.15, 0.09, 1];
      b(-2.6, 0, -7, 2.6, 1.6, 7, w); b(-2.2, 1.6, -6, 2.2, 2.2, 5.5, w2); b(-0.15, 2.2, -1.5, 0.15, 9, -1.2, w2); b(-2, 3, -1.4, 2, 3.2, -1.3, w2); b(-0.2, 1.6, 6.6, 0.2, 3.6, 8.8, w2);
      b(-2.6, 0.3, -2, -2.3, 1.2, 2, [0.1, 0.07, 0.04, 1]); b(2.3, 0.3, -2, 2.6, 1.2, 2, [0.1, 0.07, 0.04, 1]);
      b(-0.5, 1.6, 1.5, 0.5, 2.1, 2.4, [1, 0.82, 0.2, 1]); b(-0.35, 2.1, 1.6, 0.35, 2.3, 2.3, [1, 0.9, 0.35, 1]);
    });
    return MS;
  }
  /* --- лавка дайвера --- */
  const css = document.createElement('style');
  css.textContent = `#diveShop{position:fixed;inset:0;z-index:58;background:rgba(3,10,22,.84);display:none;align-items:center;justify-content:center}
#diveShop .in{width:min(540px,94vw);max-height:86vh;overflow:auto;background:#0b1a2e;border:1px solid #1f5a8a;border-radius:18px;padding:14px 16px;color:#fff;font:500 13px/1.4 system-ui,sans-serif}
#diveShop h2{margin:0 0 6px;font-size:19px}#diveShop .r{display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #16355a}#diveShop .r span{flex:1}
#diveShop button{border:0;border-radius:9px;padding:6px 11px;font:700 12px system-ui;background:#1f8fff;color:#fff;cursor:pointer}#diveShop button:disabled{opacity:.4}#diveShop button.x{background:#2b3350}
#sonar{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(var(--safe-b,0px) + 128px);z-index:24;padding:4px 12px;border-radius:12px;background:rgba(8,26,40,.85);color:#9ff0ff;font:700 12px system-ui,sans-serif;display:none;pointer-events:none}`;
  document.head.appendChild(css);
  const shop = document.createElement('div'); shop.id = 'diveShop'; document.body.appendChild(shop);
  const son = document.createElement('div'); son.id = 'sonar'; document.body.appendChild(son);
  function renderShop() {
    const D = DD(); let h = '<div class="in"><h2>🤿 Дайв-центр «Глубина»</h2><div style="color:#9fb0d8">Найдено кладов: ' + D.n + ' на ' + fmtMoney(D.total) + '. Клады появляются снова через 15–60 минут. Ныряйте: плывите от берега → V.</div>';
    TANKS.forEach((T, i) => {
      const own = !!D.own[i], cur = D.tank === i;
      h += '<div class="r"><b>🤿</b><span>' + T.n + '<br><small style="color:#9fb0d8">расход воздуха ' + (i ? '−' + Math.round(T.k * 100) + '%' : 'обычный') + '</small></span>' + (cur ? '<b style="color:#6df09a">Надет</b>' : own ? '<button data-a="eq' + i + '">Надеть</button>' : '<button data-a="buy' + i + '"' + (S.money < T.p ? ' disabled' : '') + '>' + fmtMoney(T.p) + '</button>') + '</div>';
    });
    h += '<div class="r"><b>📡</b><span>Гидролокатор<br><small style="color:#9fb0d8">показывает расстояние и направление до ближайшего клада</small></span>' + (D.sonar ? '<b style="color:#6df09a">Куплен</b>' : '<button data-a="sonar"' + (S.money < 6000 ? ' disabled' : '') + '>$6 000</button>') + '</div>';
    h += '<div style="text-align:right;margin-top:10px"><button class="x" data-a="close">Закрыть</button></div></div>';
    shop.innerHTML = h;
  }
  shop.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) { if (e.target === shop) shop.style.display = 'none'; return; }
    const a = b.dataset.a, D = DD();
    if (a === 'close') shop.style.display = 'none';
    else if (a === 'sonar') { if (S.money < 6000) { SFX.err(); return; } S.money -= 6000; D.sonar = 1; refreshMoney(true); SFX.buy(); toast('📡 Гидролокатор установлен'); persist(); }
    else if (a && a.startsWith('eq')) { D.tank = +a.slice(2); SFX.click(); persist(); }
    else if (a && a.startsWith('buy')) { const i = +a.slice(3), T = TANKS[i]; if (S.money < T.p) { SFX.err(); return; } S.money -= T.p; D.own[i] = 1; D.tank = i; refreshMoney(true); SFX.buy(); toast('🤿 ' + T.n + ' — куплено!'); persist(); }
    renderShop();
  });
  document.addEventListener('keydown', e => { if (e.code === 'Escape' && shop.style.display === 'flex') shop.style.display = 'none'; });
  HOME_FN.diveShop = function () { renderShop(); shop.style.display = 'flex'; };
  WORLD_MARKS.push({ id: 'dive_shop', x: PX0 + 28, z: PZ, r: 4, c: [0.2, 0.8, 1], br: 2.5, label: '🤿 ДАЙВ-ЦЕНТР: БАЛЛОНЫ И ГИДРОЛОКАТОР', short: '🤿 ДАЙВ', dot: '#2fd0ff', fn: 'diveShop' });

  /* --- отрисовка и сбор --- */
  const sd1 = seaDraw;
  seaDraw = function () {
    sd1.apply(this, arguments);
    if (G.mode !== 'play' || G.inHome) return;
    const M2 = meshes(), t = G.time; setPass('opaque');
    for (const it of ITEMS) {
      if (Math.abs(it.x - CAM.x) > 90 || Math.abs(it.z - CAM.z) > 90 || !avail(it)) continue;
      const fl = floorAt(it.x, it.z), big = it.big;
      mTRS(DM, it.x, -fl + 0.02 + (big ? 0 : Math.sin(t * 1.6 + it.ph) * 0.04), it.z, big ? it.ph : t * 0.6 + it.ph, 0, big ? 0.05 : 0, 1, 1, 1);
      drawMesh(M2[it.t], DM, 1, 1, 1, 1, it.t === 'wreck' ? 0 : 1, false);
    }
  };
  const air0 = { v: 100 };
  let lastN = 0, bubT = 0;
  const v0 = v18Tick;
  v18Tick = function (dt) {
    v0(dt);
    const D = DD();
    if (P.dive && P.swim) {                      // баллоны: тратим воздух медленнее
      const k = TANKS[D.tank].k;
      if (k > 0 && P.air < air0.v) P.air = air0.v - (air0.v - P.air) * (1 - k);
      if (!(S.flags.dvHint)) { S.flags.dvHint = 1; toast('🤿 Под водой: ищите сундуки и жемчуг на дне. Подплывите вплотную — клад подберётся сам'); }
      let best = null, bd = 1e9;
      for (const it of ITEMS) {
        if (!avail(it)) continue;
        const d = Math.hypot(it.x - P.x, it.z - P.z);
        if (d < bd) { bd = d; best = it; }
        if (d < (it.big ? 4.2 : 2.5)) { collect(it); }
      }
      if (D.sonar && best) {
        const ang = Math.atan2(best.x - P.x, best.z - P.z) - P.h, a = wrapA(ang), arrow = ['⬆', '↗', '➡', '↘', '⬇', '↙', '⬅', '↖'][Math.round(((a + TAU) % TAU) / (TAU / 8)) % 8];
        son.style.display = 'block'; son.textContent = '📡 ' + TYPES[best.t].ico + ' ' + Math.round(bd) + ' м ' + arrow;
      } else son.style.display = 'none';
      if (best && bd < 10 && (bubT -= dt) <= 0) { bubT = 0.4; emit(best.x + rand(-0.3, 0.3), -floorAt(best.x, best.z) + 0.3, best.z + rand(-0.3, 0.3), 0, 1.4, 0, 1.2, 0.08, 0.2, 1, 1, 1, 0.7, false); }
    } else son.style.display = 'none';
    air0.v = P.air;
  };
  function collect(it) {
    const T = TYPES[it.t], D = DD();
    D.got[it.id] = Date.now() + T.re; D.n++; D.total += T.pay; if (T.pay > D.best) D.best = T.pay;
    S.flags.dvN = (S.flags.dvN || 0) + 1;
    const bonus = D.n % 10 === 0 ? 1000 : 0;
    addMoney(T.pay + bonus); SFX.cash(); P.air = Math.min(100, P.air + 12);
    toast(T.ico + ' ' + T.n + ': +' + fmtMoney(T.pay) + (bonus ? ' · бонус коллекционера +$1 000' : ''));
    for (let i = 0; i < 12; i++) emit(P.x + rand(-0.5, 0.5), -P.dep + 0.2, P.z + rand(-0.5, 0.5), rand(-1, 1), rand(1, 3), rand(-1, 1), 0.9, 0.1, 0.35, 1, 0.95, 0.6, 0.9, true);
    persist();
  }
  window.__dive = { ITEMS, TYPES, DD, collect, floorAt };
}
