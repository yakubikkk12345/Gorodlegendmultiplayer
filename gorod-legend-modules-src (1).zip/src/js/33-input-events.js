/* ===================== 20. СОБЫТИЯ ВВОДА ===================== */
function bindInput() {
  window.addEventListener('keydown', e => {
    if (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
    keys[e.code] = true;
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'Tab'].includes(e.code)) e.preventDefault();
    if (e.repeat) return;
    auInit();
    switch (e.code) {
      case 'KeyF': case 'Enter': if (UI.cur === null) interactCar(); break;
      case 'KeyE': if (UI.cur === null) interactMark(); break;
      case 'KeyC': if (UI.cur === null) callCar(); break;
      case 'KeyR': if (UI.cur === null) { if (P.car) resetCar(); else reloadWeapon(); } break;
      case 'Digit1': case 'Digit2': case 'Digit3': case 'Digit4': case 'Digit5': case 'Digit6': case 'Digit7': case 'Digit8': case 'Digit9': if (UI.cur === null && G.mode === 'play') selectWeaponIdx(+e.code.slice(5) - 1); break;
      case 'KeyN': if (UI.cur === null && G.mode === 'play') { auInit(); radioNext(); } break;
      case 'KeyH': if (UI.cur === null) horn(); break;
      case 'KeyY': if (UI.cur === null && G.mode === 'play') aimToggle(); break;
      case 'KeyU': if (UI.cur === null && G.mode === 'play') zoomToggle(); break;
      case 'KeyZ': if (UI.cur === null && G.mode === 'play') cbZ(); break;
      case 'KeyQ': if (UI.cur === null && G.mode === 'play') throwGrenade(); break;
      case 'KeyB': if (UI.cur === null && G.mode === 'play') c4Action(); break;
      case 'Escape': case 'KeyP': if (G.mode === 'play') togglePause(); else if (UI.cur && UI.cur !== 'menu') backScreen(); break;
      case 'KeyM': if (G.mode === 'play') { if (UI.cur === 'mapScreen') backScreen(); else if (UI.cur === null) openScreen('mapScreen'); } break;
      case 'KeyJ': if (G.mode === 'play') { if (UI.cur === 'missions') backScreen(); else if (UI.cur === null) openScreen('missions'); } break;
    }
  });
  window.addEventListener('keyup', e => { keys[e.code] = false; });
  window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; });
  document.addEventListener('visibilitychange', () => { if (document.hidden && G.mode === 'play' && UI.cur === null) openScreen('pause'); });

  // клики по интерфейсу
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-act],[data-start],[data-gsel],[data-use],[data-upg],[data-paint],[data-mod],[data-shopsel],[data-buy],[data-gbuy],[data-gammo],[data-gequip],[data-talk],[data-st]');
    if (!t) return;
    auInit();
    const d = t.dataset;
    if (d.talk !== undefined) { const op = TALK.opts[+d.talk]; if (op && !op.dis) { SFX.click(); op.fn(); } return; }
    if (d.st !== undefined) { styleClick(d.st); return; }
    if (d.gbuy) { buyGun(d.gbuy); return; }
    if (d.gammo) { buyAmmo(d.gammo); return; }
    if (d.gequip) { selectWeapon(d.gequip); renderGunshop(); return; }
    if (d.buy) { e.stopPropagation(); buyCar(d.buy); if (UI.cur === 'shop') renderShop(); return; }
    if (d.act) act(d.act, t);
    else if (d.start) { SFX.click(); startMission(d.start); }
    else if (d.gsel) { UI.garSel = d.gsel; SFX.click(); renderGarage(); }
    else if (d.use) { selectCar(d.use); renderGarage(); }
    else if (d.upg) upgradeCar(d.upg);
    else if (d.paint) paintCar(d.paint);
    else if (d.mod !== undefined) applyMod(d.mod);
    else if (d.shopsel) { UI.shopSel = d.shopsel; SFX.click(); renderShop(); }
  });

  // камера: перетаскивание по сцене
  let drag = null;
  const lockOK = () => G.mode === 'play' && !G.paused && UI.cur === null;
  const locked = () => document.pointerLockElement === canvas;
  let wasLocked = false;
  canvas.addEventListener('pointerdown', e => {
    if (G.mode !== 'play' || G.paused) return;
    if (e.pointerType === 'mouse' && e.button === 0 && !locked() && lockOK() && canvas.requestPointerLock) {
      try { const r = canvas.requestPointerLock(); if (r && r.catch) r.catch(() => { }); } catch (_) { }
    }
    drag = { id: e.pointerId, x: e.clientX, y: e.clientY };
    try { canvas.setPointerCapture(e.pointerId); } catch (_) { }
  });
  canvas.addEventListener('pointermove', e => {
    if (!drag || drag.id !== e.pointerId || document.pointerLockElement === canvas) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY;
    const k = 0.0055 * S.set.sens * Math.max(0.16, CAM.fov / 1.05);
    if (P.car) { CAM.off -= dx * k; CAM.lastDrag = performance.now(); } else CAM.yaw -= dx * k;
    CAM.pitch = clamp(CAM.pitch + dy * k * 0.7, -0.9, 0.95);
  });
  document.addEventListener('mousemove', e => {
    if (!locked() || !lockOK()) return;
    const k = 0.0055 * S.set.sens * Math.max(0.16, CAM.fov / 1.05);
    if (P.car) { CAM.off -= e.movementX * k; CAM.lastDrag = performance.now(); } else CAM.yaw -= e.movementX * k;
    CAM.pitch = clamp(CAM.pitch + e.movementY * k * 0.7, -0.9, 0.95);
  });
  document.addEventListener('pointerlockchange', () => {
    const l = locked();
    if (wasLocked && !l && lockOK()) openScreen('pause');
    wasLocked = l;
  });
  setInterval(() => { if (locked() && !lockOK()) { try { document.exitPointerLock(); } catch (_) { } } }, 150);
  const up = e => { if (drag && drag.id === e.pointerId) drag = null; };
  canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
  canvas.addEventListener('contextmenu', e => e.preventDefault());
  canvas.addEventListener('pointerdown', e => { if (G.mode !== 'play') return; if (e.button === 2) zoomToggle(); else if (e.button === 0 && e.pointerType === 'mouse' && locked()) WS.mf = true; });
  canvas.addEventListener('pointerup', e => { if (e.button === 2) WS.zoomHold = false; if (e.button === 0) WS.mf = false; });
  canvas.addEventListener('pointercancel', () => { WS.zoomHold = false; WS.mf = false; });

  // джойстик
  const stick = $('stick'), knob = $('knob'); let sid = null;
  const mvStick = e => {
    const r = stick.getBoundingClientRect(), R = r.width / 2;
    let dx = e.clientX - (r.left + R), dy = e.clientY - (r.top + R); const l = Math.hypot(dx, dy);
    if (l > R) { dx = dx / l * R; dy = dy / l * R; }
    touch.jx = dx / R; touch.jy = -dy / R; if (Math.hypot(touch.jx, touch.jy) < 0.12) { touch.jx = 0; touch.jy = 0; }
    knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
  };
  stick.addEventListener('pointerdown', e => { sid = e.pointerId; stick.setPointerCapture(sid); mvStick(e); e.preventDefault(); });
  stick.addEventListener('pointermove', e => { if (e.pointerId === sid) mvStick(e); });
  const endStick = e => { if (e.pointerId !== sid) return; sid = null; touch.jx = touch.jy = 0; knob.style.transform = 'translate(0,0)'; };
  stick.addEventListener('pointerup', endStick); stick.addEventListener('pointercancel', endStick);

  // кнопки (удержание)
  document.querySelectorAll('[data-hold]').forEach(b => {
    const k = b.dataset.hold;
    const on = e => { touch[k] = 1; b.classList.add('down'); try { b.setPointerCapture(e.pointerId); } catch (_) { } e.preventDefault(); auInit(); };
    const off = () => { touch[k] = 0; b.classList.remove('down'); };
    b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off); b.addEventListener('lostpointercapture', off);
  });
  document.querySelectorAll('[data-tap]').forEach(b => {
    b.addEventListener('pointerdown', e => {
      e.preventDefault(); auInit();
      const t = b.dataset.tap;
      if (t === 'enter') interactCar(); else if (t === 'marker') interactMark(); else if (t === 'call') callCar(); else if (t === 'horn') horn(); else if (t === 'reset') resetCar(); else if (t === 'reload') reloadWeapon(); else if (t === 'weapon') cycleWeapon();
    });
  });
  document.addEventListener('gesturestart', e => e.preventDefault());
  window.addEventListener('resize', () => { resize(); });
  window.addEventListener('orientationchange', () => setTimeout(resize, 300));
}

