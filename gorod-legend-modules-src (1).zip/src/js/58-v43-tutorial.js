/* ===================== v43: ОБУЧЕНИЕ «АКАДЕМИЯ УЛИЦ» — пошаговый туториал для новичков ===================== */
const TUT = {
  steps: [
    { id: 'walk', ico: '🚶', t: 'Пройдите пешком 100 м', h: 'W A S D или левый джойстик. Shift — бег. Мышь: кликните по игре, чтобы управлять камерой.', ok: () => TUT.walked > 100, r: 100 },
    { id: 'car', ico: '🚗', t: 'Сядьте в свою машину', h: 'Она припаркована рядом с домом. Подойдите и нажмите F (на телефоне — кнопка «Сесть»).', ok: () => !!S.flags.hCar, r: 150 },
    { id: 'drive', ico: '🏎', t: 'Проедьте 300 м на машине', h: 'W / S — газ и тормоз, A / D — руль, Пробел — ручник, Shift — нитро, H — сигнал, N — радио.', ok: () => TUT.driven > 300, r: 200 },
    { id: 'map', ico: '🗺', t: 'Откройте карту (M)', h: 'На карте видны задания, магазины, порт и аэродром. Тап по карте строит маршрут.', ok: () => !!S.flags.hMap, r: 100 },
    { id: 'mis', ico: '📋', t: 'Откройте задания (J)', h: 'Начните с «Пицца на вынос»: оранжевая метка возле дома.', ok: () => !!S.flags.hMis, r: 100 },
    { id: 'shop', ico: '🛒', t: 'Зайдите в любой магазин', h: 'Автосалон, оружейный, тюнинг — подойдите к метке и нажмите E.', ok: () => !!S.flags.hShop, r: 200 },
    { id: 'm1', ico: '✅', t: 'Выполните первое задание', h: 'За задания платят деньги и открывают сюжет. Следуйте за лучом на карте.', ok: () => doneCount() > 0, r: 500 },
    { id: 'gun', ico: '🔫', t: 'Купите оружие', h: 'Оружейный магазин: пистолет нужен для ограблений. Патроны покупаются там же.', ok: () => hasAnyGun(), r: 300 },
    { id: 'rob', ico: '🏪', t: 'Ограбьте мини-маркет', h: 'Метка 🏪 на карте. Стойте у кассы, пока идёт полоска. Охрана и полиция уже в пути! Ограбления теперь сложнее — но и прибыльнее.', ok: () => (S.stats.robs || 0) > 0, r: 800 },
    { id: 'fish', ico: '🎣', t: 'Поймайте рыбу', h: 'Пирс на востоке пляжа: подойдите к метке 🎣 и забросьте удочку. Клёв — жмите E/тап в момент поклёвки. Рыбу продают на пристани.', ok: () => (S.flags.fishN || 0) > 0, r: 600 },
    { id: 'dive', ico: '🤿', t: 'Найдите сокровище под водой', h: 'Заплывите дальше от берега, нажмите V — нырнуть. Следите за воздухом! На дне — сундуки и жемчужины.', ok: () => (S.flags.dvN || 0) > 0, r: 800 },
    { id: 'plane', ico: '✈', t: 'Поднимитесь в небо на самолёте', h: 'Купите самолёт в автосалоне, возьмите его в ангаре аэродрома. W — газ, на скорости 30+ тяните Shift, чтобы взлететь. Садитесь на полосу плавно.', ok: () => !!S.flags.planeFly, r: 1500 },
    { id: 'coop', ico: '🕶', t: 'Участвуйте в кооп-ограблении', h: 'Мультиплеер → создайте комнату с друзьями → метка 🕶 у бара «Крот». Роли: хакер, стрелок, взломщик, водитель.', ok: () => (S.flags.coopN || 0) > 0, r: 3000 }
  ],
  walked: 0, driven: 0, lx: undefined, lz: 0, hide: false, okT: 0, ready: false, openList: false
};
{
  const css = document.createElement('style');
  css.textContent = `
#tutBox{position:fixed;left:calc(var(--safe-l,0px) + 10px);top:calc(var(--safe-t,0px) + 96px);z-index:21;max-width:min(300px,62vw);padding:9px 12px;border-radius:14px;background:rgba(10,16,34,.84);color:#fff;font:600 12.5px/1.38 system-ui,sans-serif;border:1px solid rgba(255,214,10,.45);box-shadow:0 4px 16px rgba(0,0,0,.4);display:none}
#tutBox b.h{display:block;font-size:13.5px;color:#ffd60a;margin-bottom:2px}
#tutBox .bar{height:5px;border-radius:4px;background:#2b3350;margin:6px 0;overflow:hidden}#tutBox .bar i{display:block;height:100%;background:linear-gradient(90deg,#ffd60a,#ff9f1c);width:0}
#tutBox .row{display:flex;gap:6px;justify-content:flex-end;margin-top:4px}
#tutBox button,#tutBtn{pointer-events:auto;border:0;border-radius:9px;padding:4px 9px;font:700 11px system-ui,sans-serif;background:#2b3350;color:#dfe6ff;cursor:pointer}
#tutBtn{position:fixed;left:calc(var(--safe-l,0px) + 10px);top:calc(var(--safe-t,0px) + 58px);z-index:21;display:none;font-size:13px;padding:5px 9px;background:rgba(10,16,34,.8);border:1px solid rgba(255,214,10,.4)}
#tutList{position:fixed;inset:0;z-index:60;background:rgba(5,8,18,.82);display:none;align-items:center;justify-content:center}
#tutList .in{width:min(520px,92vw);max-height:84vh;overflow:auto;background:#101830;border:1px solid #2b3a66;border-radius:18px;padding:16px 18px;color:#fff;font:500 13.5px/1.4 system-ui,sans-serif}
#tutList h2{margin:0 0 4px;font-size:19px}#tutList .st{display:flex;gap:10px;padding:7px 0;border-bottom:1px solid #1e2850}#tutList .st.ok{opacity:.55}#tutList .st small{display:block;color:#9fb0d8;font-size:11.5px}
#tutList .ft{display:flex;gap:8px;justify-content:flex-end;margin-top:12px}#tutList .ft button{border:0;border-radius:10px;padding:8px 14px;font:700 13px system-ui;background:#2b3350;color:#fff;cursor:pointer}#tutList .ft button.p{background:#ffd60a;color:#1a1a1a}
body.tutOn #hintBox{display:none!important}
`;
  document.head.appendChild(css);
  const box = document.createElement('div'); box.id = 'tutBox';
  const btn = document.createElement('button'); btn.id = 'tutBtn'; btn.textContent = '🎓 Обучение';
  const list = document.createElement('div'); list.id = 'tutList';
  document.body.appendChild(box); document.body.appendChild(btn); document.body.appendChild(list);
  const st = () => (S.flags.tut && typeof S.flags.tut === 'object') ? S.flags.tut : (S.flags.tut = { done: {}, skip: false, fin: false });
  const doneN = () => TUT.steps.filter(s => st().done[s.id]).length;
  const cur = () => TUT.steps.find(s => !st().done[s.id]);
  function complete(s, silent) {
    st().done[s.id] = 1;
    if (!silent) { addMoney(s.r); SFX.buy(); toast('🎓 Обучение: «' + s.t + '» — +' + fmtMoney(s.r)); TUT.okT = 2.2; }
    if (!cur() && !st().fin) { st().fin = 1; addMoney(5000); toast('🏆 Академия окончена! Бонус +$5 000'); }
    persist(); render();
  }
  function render() {
    const s = cur(), n = doneN(), tot = TUT.steps.length;
    if (!s) { box.style.display = 'none'; return; }
    box.innerHTML = '<b class="h">🎓 Шаг ' + (n + 1) + '/' + tot + ': ' + s.ico + ' ' + s.t + '</b>' + s.h + '<div class="bar"><i style="width:' + (n / tot * 100) + '%"></i></div><div class="row"><button data-a="list">Все шаги</button><button data-a="skip">Пропустить обучение</button></div>';
  }
  function renderList() {
    const t = st(); let h = '<div class="in"><h2>🎓 Академия улиц</h2><div style="color:#9fb0d8;margin-bottom:8px">За каждый шаг — деньги. Выполнено ' + doneN() + ' из ' + TUT.steps.length + '. Итоговый бонус — $5 000.</div>';
    for (const s of TUT.steps) h += '<div class="st' + (t.done[s.id] ? ' ok' : '') + '"><span style="font-size:20px">' + (t.done[s.id] ? '✅' : s.ico) + '</span><div><b>' + s.t + '</b> <span style="color:#ffd60a">+' + fmtMoney(s.r) + '</span><small>' + s.h + '</small></div></div>';
    h += '<div class="ft">' + (t.skip ? '<button class="p" data-a="resume">▶ Продолжить обучение</button>' : '') + '<button data-a="close">Закрыть</button></div></div>';
    list.innerHTML = h;
  }
  const act = a => {
    if (a === 'list') { renderList(); list.style.display = 'flex'; }
    else if (a === 'close') list.style.display = 'none';
    else if (a === 'skip') { st().skip = true; persist(); toast('🎓 Обучение скрыто. Вернуться: кнопка «🎓 Обучение»'); }
    else if (a === 'resume') { st().skip = false; persist(); list.style.display = 'none'; }
    SFX.click();
  };
  for (const el of [box, list]) el.addEventListener('click', e => { const b = e.target.closest('button[data-a]'); if (b) { e.stopPropagation(); act(b.dataset.a); if (el === list && b.dataset.a === 'resume') render(); } });
  btn.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); act('list'); });
  window.__tutShow = () => act('list');
  const v0 = v18Tick;
  v18Tick = function (dt) {
    v0(dt);
    if (G.mode !== 'play') { box.style.display = 'none'; btn.style.display = 'none'; document.body.classList.remove('tutOn'); return; }
    const t = st();
    if (!TUT.ready) {            // старые сохранения: уже сделанное засчитываем молча
      TUT.ready = true;
      for (const s of TUT.steps) if (s.id !== 'walk' && s.id !== 'drive' && s.ok()) t.done[s.id] = 1;
      if (doneCount() >= 3) { t.done.walk = 1; t.done.drive = 1; }
      if (!cur()) t.fin = 1;
      render();
    }
    const px = P.car ? P.car.x : P.x, pz = P.car ? P.car.z : P.z;
    if (TUT.lx !== undefined) { const d = Math.hypot(px - TUT.lx, pz - TUT.lz); if (d < 40) { if (P.car) TUT.driven += d; else TUT.walked += d; } }
    TUT.lx = px; TUT.lz = pz;
    const s = cur();
    if (s && s.ok()) complete(s, false);
    const quiet = G.paused || G.inHome || M || UI.cur !== null;
    const show = !!cur() && !t.skip && !quiet;
    box.style.display = show ? 'block' : 'none';
    btn.style.display = (!quiet && (t.skip || !cur())) ? 'block' : 'none';
    if (!cur()) btn.textContent = '🎓 Достижения';
    document.body.classList.toggle('tutOn', show);
    if (show) { const bar = box.querySelector('.bar i'); if (bar) bar.style.width = (doneN() / TUT.steps.length * 100) + '%'; }
  };
}
