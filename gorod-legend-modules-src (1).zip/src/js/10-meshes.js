/* ===================== 8. МЕШИ ===================== */
let M_UCOL, M_ULIMB, M_BEAM, M_RING, M_DISC, M_OCTA, M_CONE, M_GLOW, M_PH, M_SPOT;
function initMeshes() {
  let g;
  g = new Geo(); g.box(-0.5, 0, -0.5, 0.5, 1, 0.5, [1, 1, 1, 1], false, true); M_UCOL = makeMesh(g);
  g = new Geo(); g.box(-0.5, -1, -0.5, 0.5, 0, 0.5, [1, 1, 1, 1], false, true); M_ULIMB = makeMesh(g);
  g = new Geo(); g.beam(20, 0.55, 0.0, [1, 1, 1]); M_BEAM = makeMesh(g);
  g = new Geo(); g.ring(40, 0.82, 1.0, [1, 1, 1, 0.9]); M_RING = makeMesh(g);
  g = new Geo(); g.disc(16, [0, 0, 0, 0.5], [0, 0, 0, 0]); M_DISC = makeMesh(g);
  g = new Geo(); g.disc(20, [1, 1, 1, 0.8], [1, 1, 1, 0]); M_GLOW = makeMesh(g);
  g = new Geo(); g.octa(0.7, [1, 1, 1, 1]); M_OCTA = makeMesh(g);
  g = new Geo(); g.cone(0, 0, 0, 0.22, 1.5, 8, [1, 1, 1, 0.9]); M_CONE = makeMesh(g);
  M_PH = buildPoliceHeli();
  g = new Geo();   // конус прожектора: узкий у вертолёта (y=1), широкий и ярче на земле (y=0)
  { const lo = [], hi = [], N = 20;
    for (let i = 0; i <= N; i++) { const a = i / N * TAU, x = Math.cos(a), z = Math.sin(a);
      lo.push(g.p(x, 0, z, 0, 1, 0, [1, 1, 1, 0.34])); hi.push(g.p(x * 0.04, 1, z * 0.04, 0, 1, 0, [1, 1, 1, 0.03])); }
    for (let i = 0; i < N; i++) { g.i.push(lo[i], lo[i + 1], hi[i + 1], lo[i], hi[i + 1], hi[i]); g.i.push(lo[i], hi[i], hi[i + 1], lo[i], hi[i + 1], lo[i + 1]); } }
  M_SPOT = makeMesh(g);
}

