/* ===================== 22. ЗАПУСК ===================== */
function boot() {
  const bar = $('loadBar'), txt = $('loadTxt');
  const steps = [
    ['Строим улицы…', () => buildCity()],
    ['Собираем модели…', () => initMeshes()],
    ['Паркуем машины…', () => { spawnParked(40); }],
    ['Выпускаем трафик…', () => { applyQuality(); }],
    ['Настраиваем управление…', () => { bindInput(); bindSettings(); applyTouchMode(); tgInit(); mpInit(); v28Init(); v30Init(); $('fps').style.display = S.set.fps ? 'block' : 'none'; }]
  ];
  let i = 0;
  const next = () => {
    if (i >= steps.length) {
      G.mode = 'menu'; $('loading').classList.remove('show');
      showScreen('menu'); refreshMoney(false);
      requestAnimationFrame(t => { lastT = t; requestAnimationFrame(frame); });
      return;
    }
    txt.textContent = steps[i][0]; bar.style.width = ((i + 1) / steps.length * 100) + '%';
    try { steps[i][1](); } catch (e) { fatal('Ошибка загрузки: ' + e.message); console.error(e); return; }
    i++; setTimeout(next, 30);
  };
  next();
}

