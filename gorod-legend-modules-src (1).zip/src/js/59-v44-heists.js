/* ===================== v44: ОГРАБЛЕНИЯ ПОСЛОЖНЕЕ И ВЫГОДНЕЕ + КООПЕРАТИВНЫЕ ОГРАБЛЕНИЯ ===================== */
const HXS = { guards: [], mult: 1, fails: 0, chk: 0, chkN: 0, gT: 0 };
const HXC = { lobby: null, run: null, stage: null, kills: 0, sent: -1, down: false, hudT: 0, gT: 0, wait: 0 };
{
  const hxBc = i => -HALF + (i + 0.5) * PITCH;
  const HX_KINDS = {
    jewel: { ico: '💎', name: 'Ювелирный «Бриллиант»', min: 2, pay: '$24–34 тыс.', b: [1, 6], d: 'Взлом → охрана → витрины → уход' },
    bank: { ico: '🏦', name: 'Банк «Столичный»', min: 2, pay: '$80–110 тыс.', b: [7, 5], d: '5 этапов, две волны охраны' },
    vault: { ico: '💰', name: 'Хранилище «Народный»', min: 3, pay: '$190–260 тыс.', b: [12, 12], d: '6 этапов, три замка, 3 игрока' }
  };
  const css = document.createElement('style');
  css.textContent = `
#skOv{position:fixed;left:50%;top:34%;transform:translateX(-50%);z-index:55;width:min(340px,86vw);padding:12px 14px;border-radius:16px;background:rgba(8,12,26,.93);border:1px solid #ffb703;color:#fff;font:700 14px system-ui,sans-serif;text-align:center;display:none;touch-action:manipulation;user-select:none}
#skOv .bar{position:relative;height:26px;margin:10px 0 6px;border-radius:13px;background:#222a45;overflow:hidden}
#skOv .zone{position:absolute;top:0;bottom:0;background:linear-gradient(#35e07a,#1faa56)}
#skOv .ndl{position:absolute;top:-2px;bottom:-2px;width:5px;margin-left:-2px;border-radius:3px;background:#fff;box-shadow:0 0 8px #fff}
#skOv small{display:block;color:#9fb0d8;font-weight:500}
#hxHud{position:fixed;left:50%;top:calc(var(--safe-t,0px) + 8px);transform:translateX(-50%);z-index:22;padding:6px 14px;border-radius:14px;background:rgba(40,10,14,.86);border:1px solid #ff4d4d;color:#fff;font:700 13px/1.35 system-ui,sans-serif;text-align:center;display:none;pointer-events:none;max-width:90vw}
`;
  document.head.appendChild(css);

  /* ---------- мини-игра «взлом»: остановите стрелку в зелёной зоне ---------- */
  const SK = { on: false, rounds: 0, round: 0, fails: 0, cb: null, t0: 0, zc: 0.5, zw: 0.16, speed: 1.6, tmr: 0 };
  const sk = document.createElement('div'); sk.id = 'skOv'; document.body.appendChild(sk);
  function skDraw() {
    const t = (performance.now() - SK.t0) / 1000, pos = 0.5 + 0.5 * Math.sin(t * SK.speed * 3.2 - Math.PI / 2);
    const n = sk.querySelector('.ndl'); if (n) n.style.left = (pos * 100) + '%';
    SK.pos = pos;
    if (t > 7) skStop(true);
  }
  function skRound() {
    SK.zw = Math.max(0.075, 0.17 - SK.round * 0.018); SK.zc = rand(0.2, 0.8); SK.speed = 1.0 + SK.round * 0.22; SK.t0 = performance.now();
    let dots = ''; for (let i = 0; i < SK.rounds; i++) dots += i < SK.round ? '●' : '○';
    sk.innerHTML = '<div>' + SK.title + ' <span style="color:#ffb703">' + dots + '</span></div><div class="bar"><div class="zone" style="left:' + ((SK.zc - SK.zw / 2) * 100) + '%;width:' + (SK.zw * 100) + '%"></div><div class="ndl"></div></div><small>' + (SK.hint || 'Пробел / E / тап — остановить стрелку в зелёной зоне. Промах = тревога!') + '</small>';
  }
  function skStop(timeout) {
    if (!SK.on) return;
    const ok = !timeout && Math.abs(SK.pos - SK.zc) <= SK.zw / 2;
    if (!ok) { SK.fails++; SFX.err(); CAM.shake = Math.max(CAM.shake, 0.3); } else SFX.click();
    SK.round++;
    if (SK.round >= SK.rounds) { clearInterval(SK.tmr); SK.on = false; sk.style.display = 'none'; const cb = SK.cb; SK.cb = null; cb && cb(SK.fails); return; }
    skRound();
  }
  function skillCheck(rounds, title, cb, hint) {
    if (SK.on) return false;
    SK.on = true; SK.hint = hint || ''; SK.rounds = rounds; SK.round = 0; SK.fails = 0; SK.cb = cb; SK.title = title;
    skRound(); sk.style.display = 'block'; clearInterval(SK.tmr); SK.tmr = setInterval(skDraw, 16);
    return true;
  }
  const skAbort = () => { if (!SK.on) return; clearInterval(SK.tmr); SK.on = false; SK.cb = null; sk.style.display = 'none'; };
  window.addEventListener('keydown', e => { if (SK.on && (e.code === 'Space' || e.code === 'KeyE')) { e.preventDefault(); e.stopImmediatePropagation(); if (!e.repeat) skStop(false); } }, true);
  sk.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); skStop(false); });
  window.__skillCheck = skillCheck;

  /* ---------- охрана (использует общий список банд — бьётся, стреляет, видна на радаре) ---------- */
  const GK = { patrol: { gun: 'smg', hp: 55, dmg: [4, 7] }, elite: { gun: 'rifle', hp: 85, dmg: [6, 10] } };
  function spawnGuard(cx, cz, elite) {
    const T = elite ? GK.elite : GK.patrol, a = Math.random() * TAU, r = rand(10, 24);
    const e = { x: cx + Math.cos(a) * r, z: cz + Math.sin(a) * r, h: 0, hp: T.hp, maxhp: T.hp, cd: rand(0.8, 1.6), ph: Math.random() * 6, amp: 0, sp: rand(4.1, 5.2), pref: rand(9, 15), sdir: Math.random() < 0.5 ? 1 : -1, sflip: rand(1, 3), hit: 0, boss: false, sc: elite ? 1.08 : 1, cop: false, gang: 'wolves', hx: 1,
      look: elite ? BOSS_LOOK : pick(GANG_LOOKS), gun: { id: T.gun, aim: 0, kick: 0, reload: 0 }, dmg: rand(T.dmg[0], T.dmg[1]), rate: rand(0.9, 1.4) };
    pushCircle(e, 0.6); GANG.units.push(e); HXS.guards.push(e); return e;
  }
  const guardsAlive = () => HXS.guards.filter(e => GANG.units.includes(e)).length;
  const clearGuards = () => { for (const e of HXS.guards) { const i = GANG.units.indexOf(e); if (i >= 0) GANG.units.splice(i, 1); } HXS.guards.length = 0; };
  const dg0 = damageGang;
  damageGang = function (e, dmg) {
    const was = GANG.units.includes(e); dg0(e, dmg);
    if (e.hx && was && !GANG.units.includes(e)) { HXC.kills++; HXS.kills = (HXS.kills || 0) + 1; }
  };

  /* ---------- одиночные ограбления: сложнее и выгоднее ---------- */
  Object.assign(STORE_TYPES.mini, { lo: 700, hi: 1600, stars: 2, dur: 10, guards: 2, checks: 1 });
  Object.assign(STORE_TYPES.jewel, { lo: 3500, hi: 7500, stars: 3, dur: 14, guards: 3, checks: 2 });
  Object.assign(STORE_TYPES.bank, { lo: 12000, hi: 24000, stars: 4, dur: 20, guards: 5, checks: 3 });
  const rs0 = robStart;
  robStart = function (s) {
    const was = ROB.st; rs0(s);
    if (!was && ROB.st === s) {
      const T = STORE_TYPES[s.t], m = markOf('rob_' + s.id);
      HXS.fails = 0; HXS.chk = 0; HXS.chkN = T.checks; HXS.mult = 1; HXS.gT = 0; HXS.kills = 0; HXS.guardsN = T.guards;
      for (let i = 0; i < T.guards; i++) spawnGuard(m.x, m.z, s.t === 'bank' && i === 0);
      toast('🛡 Охрана вызвана: ' + T.guards + ' бойцов. Впереди ' + T.checks + ' взлом(а) замка — не промахнитесь!');
    }
  };
  robEnd = function (ok) {
    const s = ROB.st; if (!s) return;
    const T = STORE_TYPES[s.t]; ROB.st = null; robBarEl().style.display = 'none'; skAbort();
    clearGuards();
    if (ok) {
      const perfect = HXS.fails === 0, killB = Math.min(0.25, (HXS.kills || 0) * 0.05);
      const mult = (perfect ? 1.25 : Math.max(0.55, 1 - 0.18 * HXS.fails)) + killB;
      const pay = Math.round((T.lo + Math.random() * (T.hi - T.lo)) * mult / 10) * 10;
      addMoney(pay); SFX.cash(); S.rob[s.id] = Date.now() + 10 * 60 * 1000;
      S.stats.robs = (S.stats.robs || 0) + 1; if (s.t === 'bank') S.flags.bank = 1;
      toast(T.ico + ' Касса вскрыта: ' + fmtMoney(pay) + (perfect ? ' (чистая работа ×1.25)' : '') + '. Уходите от полиции!'); persist();
    } else { S.rob[s.id] = Date.now() + 90 * 1000; toast('❌ Ограбление сорвано'); SFX.err(); }
  };
  const v16t0 = v16Tick;
  v16Tick = function (dt) {
    const robbing = !!ROB.st;
    v16t0(dt);
    if (!robbing || !ROB.st) return;
    const s = ROB.st, T = STORE_TYPES[s.t];
    if (SK.on) ROB.t = Math.max(0, ROB.t - dt);                 // пока идёт взлом, таймер ограбления стоит
    else if (HXS.chk < HXS.chkN && ROB.t >= T.dur * (0.2 + 0.55 * HXS.chk / Math.max(1, HXS.chkN))) {
      const n = ++HXS.chk;
      skillCheck(2 + (s.t === 'bank' ? 1 : 0), '🔐 Замок ' + n + '/' + HXS.chkN, f => {
        HXS.fails += f;
        if (f) { crimeWanted(Math.min(5, WANT.stars + 1), 'сработала тревога'); toast('🔔 Промах! Тревога усилилась'); } else toast('🔓 Замок вскрыт чисто');
      });
    }
    if ((HXS.gT -= dt) <= 0) {                                  // охрана подтягивается волнами
      HXS.gT = 9; const m = markOf('rob_' + s.id);
      if (guardsAlive() < Math.ceil(T.guards / 2) && ROB.t > T.dur * 0.35 && HXS.guards.length < T.guards * 2) spawnGuard(m.x, m.z, false);
    }
  };

  /* ---------- кооперативные ограбления ---------- */
  const hxTarget = k => { const K = HX_KINDS[k]; return { x: hxBc(K.b[0]), z: hxBc(K.b[1]) - 12 }; };
  WORLD_MARKS.push({ id: 'coop', x: bc(8 + BO) + 14, z: bc(5 + BO) + 16, c: [1, 0.2, 0.25], label: '🕶 КООП-ОГРАБЛЕНИЕ: СОБРАТЬ КОМАНДУ', short: '🕶 КООП', dot: '#ff4d4d', fn: 'coopHeist' });
  HOME_FN.coopHeist = function () { hxMenu(); };
  const mpIn = () => typeof mpConnected === 'function' && mpConnected();
  function hxMenu() {
    if (!mpIn()) { toast('🕶 Для кооп-ограблений нужна комната: Меню → Мультиплеер. Позовите до 3 друзей!'); SFX.err(); return; }
    if (HXC.lobby || HXC.run) { hxLobbyUI(); return; }
    const btns = Object.keys(HX_KINDS).map(k => ({ t: HX_KINDS[k].ico + ' ' + HX_KINDS[k].name.split(' ')[0] + ' · ' + HX_KINDS[k].pay, fn: () => { evHide('hxm'); mpSend({ t: 'heist-open', kind: k }); } }));
    btns.push({ t: 'Закрыть', fn: () => evHide('hxm') });
    evBanner('hxm', '<b>🕶 Кооп-ограбление</b><br><small>Роли: 🖥 хакер (взлом), 🔫 стрелок (охрана), 🔐 взломщик (сейф), 🚗 водитель (побег). Деньги делятся между выжившими. Тревога растёт каждые 40 с.<br>' +
      Object.keys(HX_KINDS).map(k => HX_KINDS[k].ico + ' ' + HX_KINDS[k].name + ' — от ' + HX_KINDS[k].min + ' игроков: ' + HX_KINDS[k].d).join('<br>') + '</small>', btns, 60000);
  }
  function hxLobbyUI() {
    const L = HXC.lobby; if (!L) { evHide('hx'); return; }
    const K = HX_KINDS[L.kind], host = L.host === MP.id, inn = L.players.some(p => p.id === MP.id);
    const names = L.players.map(p => mpEsc(p.name) + (p.id === L.host ? ' 👑' : '')).join(', ');
    const btns = [];
    if (host) { btns.push({ t: '▶ Начать', pri: 1, fn: () => mpSend({ t: 'heist-start' }) }); btns.push({ t: 'Отмена', fn: () => mpSend({ t: 'heist-cancel' }) }); }
    else if (inn) btns.push({ t: 'Выйти', fn: () => mpSend({ t: 'heist-leave' }) });
    else btns.push({ t: '🕶 Присоединиться', pri: 1, fn: () => mpSend({ t: 'heist-join' }) });
    evBanner('hx', '<b>' + K.ico + ' ' + K.name + '</b> · ' + K.pay + '<br>Команда (' + L.players.length + '/4, нужно ' + K.min + '+): ' + names + '<br><small>' + K.d + '. Езжайте к цели, оружие обязательно.</small>', btns);
  }
  const ROLE_TXT = { hack: '🖥 Хакер взламывает сигнализацию', guards: '🔫 Перебейте охрану', vault: '🔐 Взломщик вскрывает сейф', escape: '🚗 Сядьте в машину и уезжайте' };
  const tgtDist = () => { const r = HXC.run; return r ? Math.hypot((P.car ? P.car.x : P.x) - r.x, (P.car ? P.car.z : P.z) - r.z) : 9e9; };
  function hxReset() { HXC.run = null; HXC.stage = null; HXC.lobby = null; HXC.kills = 0; HXC.sent = -1; HXC.down = false; clearGuards(); skAbort(); hud.style.display = 'none'; evHide('hx'); evHide('hxm'); }
  const hud = document.createElement('div'); hud.id = 'hxHud'; document.body.appendChild(hud);
  const mm1 = mpMsg;
  mpMsg = function (m) {
    mm1(m);
    const t = m.t; if (typeof t !== 'string' || !t.startsWith('heist-')) return;
    if (t === 'heist-open') { HXC.lobby = { kind: m.kind, host: m.host, players: [] }; toast('🕶 ' + m.hname + ' собирает команду: ' + m.name); SFX.click(); }
    else if (t === 'heist-lobby') { HXC.lobby = { kind: m.kind, host: m.host, players: m.players }; hxLobbyUI(); }
    else if (t === 'heist-cancel') { hxReset(); toast('🕶 Сбор команды отменён'); }
    else if (t === 'heist-go') {
      const ids = m.players.map(p => p.id);
      if (!ids.includes(MP.id)) { HXC.lobby = null; evHide('hx'); return; }
      evHide('hx'); HXC.lobby = null; clearGuards(); HXC.kills = 0; HXC.sent = -1; HXC.down = false;
      HXC.run = { kind: m.kind, name: m.name, ico: m.ico, x: m.x, z: m.z, total: m.total, endAt: performance.now() + m.time, i: -1 };
      toast(m.ico + ' ' + m.name + ': операция началась! Езжайте к цели — луч на карте и в мире');
      if (!hasAnyGun()) toast('⚠ У вас нет оружия — купите хотя бы пистолет');
    } else if (t === 'heist-stage') {
      if (!HXC.run) return; clearGuards(); skAbort(); HXC.kills = 0; HXC.sent = -1;
      HXC.stage = { i: m.i, k: m.k, ch: m.ch, n: m.n, actor: m.actor, aname: m.aname, at: performance.now(), busy: false, ms: 0, spawned: 0 };
      HXC.run.i = m.i; HXC.run.endAt = performance.now() + m.left;
      SFX.click(); toast('🕶 Этап ' + (m.i + 1) + '/' + m.of + ': ' + (m.k === 'hack' || m.k === 'vault' ? m.role + ' — ' + mpEsc(m.aname) : ROLE_TXT[m.k]));
    } else if (t === 'heist-alarm') { crimeWanted(clamp(m.stars, 1, 5), 'тревога на ограблении'); }
    else if (t === 'heist-note') { toast(m.msg); }
    else if (t === 'heist-end') {
      const r = HXC.run; hxReset();
      if (!r) return;
      if (m.ok) {
        if (m.pay > 0) { addMoney(m.pay); SFX.cash(); }
        S.flags.coopN = (S.flags.coopN || 0) + 1; S.stats.coopHeists = (S.stats.coopHeists || 0) + 1; persist();
        evBanner('hxr', '<b>' + r.ico + ' Дело сделано!</b><br>Общая добыча: ' + fmtMoney(m.total) + (m.pay ? '<br>💰 Ваша доля: <b>' + fmtMoney(m.pay) + '</b>' : '<br>Вы были выведены из строя — доли нет') + '<br><small>Время: ' + m.secs + ' с · ошибок: ' + m.fails + '</small>', [{ t: 'ОК', fn: () => evHide('hxr') }], 20000);
      } else { evBanner('hxr', '<b>' + r.ico + ' Провал</b><br>' + mpEsc(m.why || ''), [{ t: 'ОК', fn: () => evHide('hxr') }], 12000); SFX.err(); }
    } else if (t === 'leave' || t === 'welcome') { /* комнатные события обрабатывает основной обработчик */ }
  };
  const mpd = mpDisconnect;
  mpDisconnect = function () { hxReset(); return mpd.apply(this, arguments); };

  const bm0 = drawMarkers;
  drawMarkers = function () {
    bm0();
    const r = HXC.run; if (!r || G.mode !== 'play') return;
    const pulse = 0.75 + 0.25 * Math.sin(G.time * 6), s = HXC.stage;
    const esc = s && s.k === 'escape';
    drawBeamAt(r.x, r.z, esc ? 2 : 4, 60, esc ? [0.3, 1, 0.5] : [1, 0.25, 0.25], 0.9 * pulse);
  };

  function hxTick(dt) {
    const r = HXC.run; if (!r) return;
    if (G.mode !== 'play') return;
    const s = HXC.stage, now = performance.now();
    if (P.hp <= 0 && !HXC.down) { HXC.down = true; mpSend({ t: 'heist-down' }); skAbort(); clearGuards(); }
    if (HXC.down) { hud.style.display = 'block'; hud.textContent = '🚑 Вы выведены из строя — ждите исхода дела'; return; }
    const left = Math.max(0, Math.ceil((r.endAt - now) / 1000)), d = tgtDist();
    let line = r.ico + ' ' + r.name + ' · ⏱ ' + Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0');
    if (s) {
      const need = s.k === 'guards';
      line += ' · этап ' + (s.i + 1) + '/' + r.total + '<br>' + (s.k === 'hack' || s.k === 'vault' ? (s.actor === MP.id ? '👉 ВАША задача: ' : 'Работает ' + mpEsc(s.aname) + ': ') : '') + ROLE_TXT[s.k] + (need ? ' ' + Math.min(HXC.kills, s.n) + '/' + s.n : '') + (d > 45 && s.k !== 'escape' ? ' · до цели ' + Math.round(d) + ' м' : '');
      const since = now - s.at;
      if (s.k === 'guards' && d < 70) {
        if ((HXC.gT -= dt) <= 0) { HXC.gT = 2.2; const alive = guardsAlive(), left2 = s.n - HXC.kills; if (alive < Math.min(4, left2)) { spawnGuard(r.x, r.z, s.spawned % 5 === 4); s.spawned++; } }
        if (HXC.kills >= s.n && HXC.sent !== s.i) { HXC.sent = s.i; HXC.wait = 0.5; }
      } else if ((s.k === 'hack' || s.k === 'vault') && s.actor === MP.id && d < 40 && !s.busy && SK.on === false && HXC.sent !== s.i) {
        s.busy = true; skillCheck(s.ch, s.k === 'hack' ? '🖥 Взлом системы' : '🔐 Сейф', f => { HXC.sent = s.i; HXC.fails = f; HXC.wait = 0.5; toast(f ? '🔔 Ошибок: ' + f + ' — тревога!' : '✔ Чисто!'); });
      } else if (s.k === 'escape' && P.car && d > 130 && HXC.sent !== s.i) { HXC.sent = s.i; HXC.wait = 0.2; }
      if (HXC.sent === s.i && (HXC.wait -= dt) <= 0 && !s.sentAt) { s.sentAt = now; mpSend({ t: 'heist-done', i: s.i, fails: HXC.fails | 0 }); HXC.fails = 0; }
      if (s.sentAt && now - s.sentAt > 4000) { s.sentAt = 0; HXC.sent = -1; HXC.wait = 3; }   // сервер отказал (слишком рано) — повтор
    } else line += '<br>Ждём первый этап…';
    hud.innerHTML = line; hud.style.display = 'block';
  }
  const v18h = v18Tick;
  v18Tick = function (dt) { v18h(dt); try { hxTick(dt); } catch (e) { } if (!HXC.run) hud.style.display = 'none'; };
  window.__hx = { HXC, HXS, skillCheck, HX_KINDS };
}
