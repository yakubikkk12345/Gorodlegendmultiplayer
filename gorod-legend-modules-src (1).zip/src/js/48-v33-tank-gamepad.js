/* ===================== v33: ПРИЦЕЛ ТАНКА, ГЕЙМПАД, SG 556, ОТДАЧА ===================== */
{
  /* ---------- SG 556 ---------- */
  const sg = { id: 'sigsg', name: 'SG 556', icon: '🔫', price: 21000, dmg: 20, pellets: 1, rate: 0.082, mag: 30, reload: 1.6, spread: 0.034, range: 130, ammoPack: 60, packPrice: 480, minAmmo: 120 };
  WEAPONS.push(sg); WBY[sg.id] = sg;
  GUNMODEL.sigsg = { two: true, m: 0.82, b: [
    [0, 0.03, 0.30, 0.06, 0.09, 0.80, 0.11, 0.11, 0.12],   // ствольная коробка и цевьё
    [0, -0.13, 0.20, 0.04, 0.16, 0.07, 0.09, 0.09, 0.10],  // магазин
    [0, -0.03, -0.15, 0.05, 0.11, 0.32, 0.13, 0.13, 0.15], // приклад
    [0, 0.105, 0.28, 0.04, 0.05, 0.26, 0.07, 0.07, 0.08],  // планка с прицелом
    [0, -0.07, 0.04, 0.04, 0.10, 0.05, 0.09, 0.09, 0.10],  // рукоять
    [0, 0.03, 0.76, 0.028, 0.028, 0.12, 0.06, 0.06, 0.07]  // дульный тормоз
  ] };
  const g1 = SFX.gun;
  SFX.gun = function (id, v) {
    if (id === 'sigsg') { v = v === undefined ? 1 : v; noiseBurst(0.1, 0.3 * v, 2900); tone(190, 0.08, 'sawtooth', 0.17 * v, 60); return; }
    g1(id, v);
  };

  /* ---------- ОТДАЧА ---------- */
  // p — подброс ствола (рад), y — рыскание, b — рост разброса, s — тряска камеры
  const RECOIL = window.__RECOIL = {
    pistol: { p: 0.016, y: 0.004, b: 0.22, s: 0.10 },
    smg: { p: 0.008, y: 0.006, b: 0.15, s: 0.07 },
    shotgun: { p: 0.055, y: 0.010, b: 0.30, s: 0.32 },
    rifle: { p: 0.070, y: 0.008, b: 0.20, s: 0.24 },
    kalash: { p: 0.019, y: 0.012, b: 0.20, s: 0.11 },
    sigsg: { p: 0.012, y: 0.007, b: 0.14, s: 0.08 }
  };
  const REC = { bloom: 0, climb: 0, back: 0 };


  /* ---------- НАСТРОЙКИ УПРАВЛЕНИЯ (раскладка клавиш и геймпада) ---------- */
  const CTL = window.__CTL = {
    keys: {}, pad: { jump: 0, act: 1, reload: 2, enter: 3, wnext: 4, nade: 5, aim: 6, fire: 7, map: 8, pause: 9, run: 10, aimmode: 11, radio: 12, call: 13, wprev: 14, wnext2: 15, fmode: 16 },
    padSens: 1, dz: 0.17, invX: false, invY: false, listen: null, padActive: () => false
  };
  try {
    const j = JSON.parse(localStorage.getItem('gl_ctl_v1') || '{}');
    if (j.keys && typeof j.keys === 'object') CTL.keys = j.keys;
    if (j.pad && typeof j.pad === 'object') for (const k in CTL.pad) if (Number.isInteger(j.pad[k]) && j.pad[k] >= 0 && j.pad[k] < 17) CTL.pad[k] = j.pad[k];
    if (typeof j.padSens === 'number') CTL.padSens = Math.max(0.3, Math.min(3, j.padSens));
    if (typeof j.dz === 'number') CTL.dz = Math.max(0.05, Math.min(0.45, j.dz));
    CTL.invX = !!j.invX; CTL.invY = !!j.invY;
  } catch (_) { }
  CTL.save = () => { try { localStorage.setItem('gl_ctl_v1', JSON.stringify({ keys: CTL.keys, pad: CTL.pad, padSens: CTL.padSens, dz: CTL.dz, invX: CTL.invX, invY: CTL.invY })); } catch (_) { } };

  const GP = { st: null, pb: [], act: 0, t: performance.now(), run: false, focus: null, nav: { dir: '', t: 0, rep: 0 }, hint: false };
  const gpPad = () => { const l = navigator.getGamepads ? navigator.getGamepads() : []; for (const p of l) if (p && p.connected) return p; return null; };
  function rumble(s, w, ms) {
    try { const p = gpPad(), a = p && p.vibrationActuator; if (a && a.playEffect) a.playEffect('dual-rumble', { startDelay: 0, duration: ms, weakMagnitude: w, strongMagnitude: s }); } catch (_) { }
  }

  const ps0 = playerShoot;
  playerShoot = function () {
    if (P.car && P.car.def.tank) return ps0();
    const d = wDef(), r = d && RECOIL[d.id];
    if (!r || d.melee) return ps0();
    const before = wMag(d.id), base = d.spread;
    d.spread = base * (1 + REC.bloom);
    try { ps0(); } finally { d.spread = base; }
    if (wMag(d.id) < before) {
      REC.bloom = Math.min(1.2, REC.bloom + r.b);
      CAM.shake = Math.max(CAM.shake, r.s * 0.5);
      if (aimManual()) {
        CAM.pitch = clamp(CAM.pitch - r.p, -0.95, 0.95); REC.climb += r.p;
        CAM.yaw += (Math.random() - 0.5) * 2 * r.y;
      } else { CAM.pitch += r.p * 0.8; REC.back += r.p * 0.8; }
      rumble(Math.min(1, r.s * 2.2), Math.min(1, r.s * 1.4), 70);
    }
  };

  /* ---------- ТАНК: башня и прицел ---------- */
  TK.yaw = 0; TK.on = null; TK.lastOff = 0; TK.rec = 0;
  function tkImpact(c) {
    const fx = Math.sin(TK.yaw), fz = Math.cos(TK.yaw);
    const range = clamp(14.5 / Math.tan(Math.max(CAM.pitch, 0.06)), 12, 120);
    const us = WANT.units.concat(GANG.units, (M && M.enemies) || []);
    let d = range, hit = false;
    for (let t = 10; t <= range && !hit; t += 3) {
      const x = c.x + fx * t, z = c.z + fz * t;
      for (const o of cars) if (o !== c && !o.def.heli && Math.hypot(o.x - x, o.z - z) < 4) { d = t; hit = true; break; }
      if (!hit) for (const e of us) if (Math.hypot(e.x - x, e.z - z) < 3) { d = t; hit = true; break; }
    }
    return { x: c.x + fx * d, z: c.z + fz * d, d, hit };
  }
  tankFire = function (c) {
    if (TK.cd > 0) return; TK.cd = 1.5;
    if (TK.on !== c) TK.yaw = c.h;
    const t = tkImpact(c), fx = Math.sin(TK.yaw), fz = Math.cos(TK.yaw), ox = c.x + Math.sin(c.h) * 0.1, oz = c.z + Math.cos(c.h) * 0.1;
    SFX.crash(30); CAM.shake = Math.max(CAM.shake, 0.55);
    for (let i = 0; i < 10; i++) emit(ox + fx * 4.8, 1.8, oz + fz * 4.8, fx * rand(4, 12) + rand(-1, 1), rand(0, 2), fz * rand(4, 12) + rand(-1, 1), 0.5, 0.5, 2.2, 1, 0.7, 0.2, 1, true);
    setTimeout(() => { if (G.mode === 'play') boom(t.x, t.z, 13, 160, 'tank'); }, Math.round(t.d * 6));
    if (t.hit) crimeWanted(2, 'танк');
    TK.rec = 1; c.vf -= 1.6; rumble(1, 0.8, 260);
  };

  // башня — отдельный меш (см. carMeshes)
  const dc0 = drawCar, TM1 = newM(), TM2 = newM(), TM3 = newM();
  drawCar = function (c, dist) {
    dc0(c, dist);
    const m = c.meshes; if (!m || !m.turret) return;
    const mine = c === P.car && TK.on === c;
    mTRS(TM1, 0, 0, 0.1, mine ? wrapA(TK.yaw - c.h) : 0, 0, 0, 1, 1, 1);
    mTRS(TM2, 0, 0, -0.1 - (mine ? TK.rec * 0.55 : 0), 0, 0, 0, 1, 1, 1);
    mMul(TM3, TM1, TM2); mMul(TM1, CMX, TM3);
    const dk = 1 - 0.0045 * (c.dmg || 0);
    drawMesh(m.turret, TM1, dk, dk, dk, 1, 0, false);
  };

  // прицельная метка
  const st = document.createElement('style');
  st.textContent = '#tkAim{position:fixed;left:0;top:0;width:46px;height:46px;margin:-23px 0 0 -23px;border:2px solid rgba(255,255,255,.9);border-radius:50%;pointer-events:none;display:none;z-index:9;box-shadow:0 0 8px rgba(0,0,0,.6)}'
    + '#tkAim::before,#tkAim::after{content:"";position:absolute;background:rgba(255,255,255,.9)}'
    + '#tkAim::before{left:50%;top:-9px;bottom:-9px;width:2px;margin-left:-1px}#tkAim::after{top:50%;left:-9px;right:-9px;height:2px;margin-top:-1px}'
    + '#tkAim.hit{border-color:#ff3b3b}#tkAim.hit::before,#tkAim.hit::after{background:#ff3b3b}'
    + '#tkAim span{position:absolute;left:50%;top:100%;transform:translateX(-50%);margin-top:12px;font:700 12px/1 system-ui,sans-serif;color:#fff;text-shadow:0 1px 3px #000;white-space:nowrap}'
    + '.gpf{outline:3px solid #ffd23f !important;outline-offset:2px;box-shadow:0 0 14px rgba(255,210,63,.7) !important}';
  document.head.appendChild(st);
  const aimEl = document.createElement('div'); aimEl.id = 'tkAim'; aimEl.innerHTML = '<span></span>'; document.body.appendChild(aimEl);
  const aimTxt = aimEl.firstChild;
  const hideAim = () => { aimEl.style.display = 'none'; };

  const uc0 = updateCombat;
  updateCombat = function (dt, inp) {
    uc0(dt, inp);
    REC.bloom = Math.max(0, REC.bloom - dt * 1.6);
    if (REC.back > 0) { const a = REC.back * Math.min(1, dt * 7); REC.back -= a; if (!aimManual()) CAM.pitch = Math.max(0.06, CAM.pitch - a); }
    if (REC.climb > 0) {
      if (!aimManual()) REC.climb = 0;
      else { const a = REC.climb * Math.min(1, dt * 2.2); REC.climb -= a; CAM.pitch = clamp(CAM.pitch + a * 0.6, -0.95, 0.95); }
    }
    if (TK.rec > 0) TK.rec = Math.max(0, TK.rec - dt * 4);
    const c = P.car;
    if (c && c.def.tank && G.mode === 'play') {
      if (TK.on !== c) { TK.on = c; TK.yaw = c.h; CAM.off = 0; TK.lastOff = 0; }
      TK.yaw += CAM.off - TK.lastOff;                 // мышь, касание и Q/E поворачивают башню
      CAM.off = wrapA(TK.yaw - c.h); TK.yaw = c.h + CAM.off; TK.lastOff = CAM.off;
      CAM.lastDrag = performance.now();               // камера не возвращается за корпусом
      CAM.yaw += wrapA(TK.yaw - CAM.yaw) * (1 - Math.exp(-dt * 14));
      const t = tkImpact(c), pr = project(t.x, terrainY(t.x, t.z) + 0.3, t.z);
      if (pr && UI.cur === null) {
        aimEl.style.display = 'block'; aimEl.style.transform = 'translate(' + pr.x.toFixed(1) + 'px,' + pr.y.toFixed(1) + 'px)';
        aimEl.classList.toggle('hit', t.hit); aimTxt.textContent = Math.round(t.d) + ' м' + (TK.cd > 0 ? ' · заряжается' : '');
      } else hideAim();
    } else { TK.on = null; hideAim(); }
  };
  setInterval(() => { if (!(P.car && P.car.def.tank && G.mode === 'play' && UI.cur === null)) hideAim(); }, 300);

  /* ---------- ГЕЙМПАД ---------- */
  const dz = v => { const z = CTL.dz; return Math.abs(v) < z ? 0 : Math.sign(v) * (Math.abs(v) - z) / (1 - z); };
  const ri0 = readInput;
  readInput = function () {
    const r = ri0(), g = GP.st; if (!g) return r;
    r.x = clamp(r.x + g.x, -1, 1); r.y = clamp(r.y + g.y, -1, 1); r.steer = clamp(r.steer + g.steer, -1, 1);
    r.gas = Math.max(r.gas, g.gas); r.brake = Math.max(r.brake, g.brake);
    r.hand = r.hand || g.hand; r.nitro = r.nitro || g.nitro; r.run = r.run || g.run; r.fire = r.fire || g.fire; r.jump = r.jump || g.jump;
    return r;
  };
  const hp0 = hurtPlayer;
  hurtPlayer = function () { rumble(0.6, 0.4, 140); return hp0.apply(this, arguments); };

  const NAVSEL = 'button,[data-act],[data-start],[data-gsel],[data-use],[data-upg],[data-paint],[data-mod],[data-shopsel],[data-buy],[data-gbuy],[data-gammo],[data-gequip],[data-talk],[data-st],input,select';
  function navList() {
    const root = UI.cur ? $(UI.cur) : null; if (!root) return [];
    return Array.from(root.querySelectorAll(NAVSEL)).filter(e => { if (e.disabled || e.type === 'hidden') return false; const b = e.getBoundingClientRect(); return b.width > 4 && b.height > 4 && e.offsetParent !== null; });
  }
  function navMove(dir) {
    const l = navList(); if (!l.length) return;
    let cur = GP.focus && l.includes(GP.focus) ? GP.focus : null;
    if (!cur) { cur = l.slice().sort((a, b) => { const A = a.getBoundingClientRect(), B = b.getBoundingClientRect(); return (A.top - B.top) || (A.left - B.left); })[0]; setFocus(cur); return; }
    if (cur.type === 'range' && (dir === 'l' || dir === 'r')) {
      const stp = +cur.step || 1, mn = +cur.min || 0, mx = cur.max === '' ? 100 : +cur.max || 100;
      cur.value = clamp(+cur.value + (dir === 'r' ? 1 : -1) * Math.max(stp, (mx - mn) / 20), mn, mx);
      cur.dispatchEvent(new Event('input', { bubbles: true })); cur.dispatchEvent(new Event('change', { bubbles: true })); return;
    }
    const cb = cur.getBoundingClientRect(), cx = cb.left + cb.width / 2, cy = cb.top + cb.height / 2;
    let best = null, bs = 1e9;
    for (const e of l) {
      if (e === cur) continue;
      const b = e.getBoundingClientRect(), dx = b.left + b.width / 2 - cx, dy = b.top + b.height / 2 - cy;
      let main, off;
      if (dir === 'u') { main = -dy; off = Math.abs(dx); } else if (dir === 'd') { main = dy; off = Math.abs(dx); }
      else if (dir === 'l') { main = -dx; off = Math.abs(dy); } else { main = dx; off = Math.abs(dy); }
      if (main < 6) continue;
      const s = main + off * 2.2; if (s < bs) { bs = s; best = e; }
    }
    if (best) setFocus(best);
  }
  function setFocus(e) {
    if (GP.focus) GP.focus.classList.remove('gpf');
    GP.focus = e; if (e) { e.classList.add('gpf'); try { e.scrollIntoView({ block: 'nearest', inline: 'nearest' }); if (e.focus && /INPUT|SELECT/.test(e.tagName)) e.focus({ preventScroll: true }); } catch (_) { } }
    SFX.tick && SFX.tick();
  }
  function prevWeapon() {
    const o = WEAPONS.filter(w => S.guns.own[w.id]); if (o.length < 2) return;
    const i = o.findIndex(w => w.id === S.guns.sel); selectWeapon(o[(i + o.length - 1) % o.length].id);
  }

  function gpLoop(now) {
    requestAnimationFrame(gpLoop);
    const dt = Math.min(0.05, (now - GP.t) / 1000); GP.t = now;
    const p = gpPad();
    if (!p) { GP.st = null; if (GP.focus) { GP.focus.classList.remove('gpf'); GP.focus = null; } return; }
    const V = i => p.buttons[i] ? p.buttons[i].value : 0, B = i => !!(p.buttons[i] && (p.buttons[i].pressed || p.buttons[i].value > 0.5));
    const cur = []; for (let i = 0; i < 17; i++) cur[i] = B(i);
    const prs = i => cur[i] && !GP.pb[i], rel = i => !cur[i] && GP.pb[i];
    const lx = dz(p.axes[0] || 0), ly = dz(p.axes[1] || 0), rx = dz(p.axes[2] || 0), ry = dz(p.axes[3] || 0);
    if (cur.some(Boolean) || lx || ly || rx || ry) { if (now - GP.act > 3000) auInit(); GP.act = now; }
    const D = CTL.pad;
    if (CTL.listen && CTL.listen.t === 'p') { const j = cur.findIndex((v, n) => v && !GP.pb[n]); if (j >= 0) { const cb = CTL.listen.cb; CTL.listen = null; cb(j); } GP.pb = cur; GP.st = null; return; }
    const inPlay = G.mode === 'play' && UI.cur === null && !G.paused;

    // меню: навигация и кнопки
    if (UI.cur !== null && UI.cur !== 'loading') {
      let dir = cur[12] || ly < -0.6 ? 'u' : cur[13] || ly > 0.6 ? 'd' : cur[14] || lx < -0.6 ? 'l' : cur[15] || lx > 0.6 ? 'r' : '';
      const N = GP.nav;
      if (dir !== N.dir) { N.dir = dir; N.t = now; N.rep = 0; if (dir) navMove(dir); }
      else if (dir && now - N.t > (N.rep ? 140 : 420)) { N.t = now; N.rep = 1; navMove(dir); }
      if (prs(0)) { const l = navList(); if (GP.focus && l.includes(GP.focus)) { auInit(); GP.focus.click(); } else navMove('d'); }
      if (prs(1) || prs(9)) { if (G.mode === 'play') togglePause(); else if (UI.cur && UI.cur !== 'menu') backScreen(); }
      GP.st = null;
    } else {
      if (GP.focus) { GP.focus.classList.remove('gpf'); GP.focus = null; }
      GP.nav.dir = '';
      if (G.mode === 'play' && prs(D.pause)) togglePause();
      if (inPlay) {
        const c = P.car, tank = c && c.def.tank, heli = c && c.def.heli;
        // камера / башня правым стиком
        const WHL = window.__wheel && window.__wheel.isOpen();
        if (WHL) { window.__wheel.stick(rx, ry); if (prs(D.jump)) window.__wheel.fm(); }
        else if (rx || ry) {
          const k = 3.0 * CTL.padSens * S.set.sens * Math.max(0.3, CAM.fov / 1.05) * dt, cx = rx * Math.abs(rx) * (CTL.invX ? -1 : 1), cy = ry * Math.abs(ry) * (CTL.invY ? -1 : 1);
          if (tank) TK.yaw -= cx * k; else if (c) { CAM.off -= cx * k; CAM.lastDrag = performance.now(); } else CAM.yaw -= cx * k;
          CAM.pitch = clamp(CAM.pitch + cy * k * 0.7, -0.9, 0.95);
        }
        // кнопки-события
        if (prs(D.enter)) interactCar();
        if (prs(D.wnext)) { GP.lbT = now; GP.lbW = false; }
        if (cur[D.wnext] && GP.lbT && !GP.lbW && now - GP.lbT > 260 && window.__wheel && !c) { GP.lbW = true; window.__wheel.open(); }
        if (rel(D.wnext)) { if (GP.lbW) window.__wheel.close(true); else cycleWeapon(); GP.lbT = 0; GP.lbW = false; }
        if (prs(D.fmode) && window.__fmToggle) window.__fmToggle();
        if (prs(D.wprev)) prevWeapon();
        if (prs(D.wnext2)) cycleWeapon();
        if (prs(D.radio)) { auInit(); radioNext(); }
        if (prs(D.call)) callCar();
        if (prs(D.map)) openScreen('mapScreen');
        if (prs(D.aimmode)) aimToggle();
        if (!c) {
          if (prs(D.act)) interactMark();
          if (prs(D.reload)) reloadWeapon();
          if (prs(D.nade)) throwGrenade();
          if (prs(D.run)) GP.run = !GP.run;
          if (prs(D.aim)) zoomToggle();
          if (rel(D.aim)) WS.zoomHold = false;
        } else if (prs(D.reload)) horn();
        // непрерывные оси
        const s = { x: 0, y: 0, steer: 0, gas: 0, brake: 0, hand: false, nitro: false, run: false, fire: false, jump: false };
        if (!c) {
          s.x = lx; s.y = -ly; s.run = GP.run && (lx || ly) ? true : false; if (!(lx || ly)) GP.run = false;
          s.fire = V(D.fire) > 0.3; s.jump = B(D.jump);
        } else {
          s.x = lx; s.y = -ly; s.steer = lx;
          if (tank) { s.gas = Math.max(0, -ly); s.brake = Math.max(0, ly); s.fire = V(D.fire) > 0.3 || B(D.nade); s.hand = B(D.jump); }
          else if (heli) { s.gas = Math.max(0, -ly); s.brake = Math.max(0, ly); s.nitro = V(D.fire) > 0.3; s.hand = V(D.aim) > 0.3; s.fire = B(D.nade); }
          else { s.gas = Math.max(V(D.fire), -ly); s.brake = Math.max(V(D.aim), ly); s.hand = B(D.jump); s.nitro = B(D.act); s.fire = B(D.nade); }
        }
        GP.st = s;
      } else { GP.st = null; if (rel(D.aim)) WS.zoomHold = false; }
    }
    GP.pb = cur;
  }
  CTL.padActive = () => performance.now() - GP.act < 5000 && !!gpPad();
  requestAnimationFrame(gpLoop);
  window.addEventListener('gamepadconnected', () => { if (G.mode === 'play') toast('🎮 Геймпад подключён'); });
}


