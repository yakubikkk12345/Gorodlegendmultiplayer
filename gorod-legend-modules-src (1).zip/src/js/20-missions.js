/* ===================== 16. МИССИИ ===================== */
function expandRoute(start, keys) {
  const r = [start.slice()], keyIdx = []; let cur = start.slice();
  for (const k of keys) {
    while (cur[0] !== k[0]) { cur = [cur[0] + Math.sign(k[0] - cur[0]), cur[1]]; r.push(cur); }
    while (cur[1] !== k[1]) { cur = [cur[0], cur[1] + Math.sign(k[1] - cur[1])]; r.push(cur); }
    keyIdx.push(r.length - 1);
  }
  return { route: r, keyIdx };
}
function dirToward(a, b) { if (!b) return 0; if (b[0] !== a[0]) return b[0] > a[0] ? 0 : 2; if (b[1] !== a[1]) return b[1] > a[1] ? 1 : 3; return 0; }
function nodeOK(i, j) { return i >= 0 && j >= 0 && i <= GRID && j <= GRID; }
function ensureOwn() { return OWN || spawnOwn(0, 0, 0); }
function seatPlayer(car) {
  if (P.car && P.car !== car) { P.car.driver = null; P.car = null; }
  P.car = car; car.driver = 'player'; P.vis = false;
  car.vx = car.vz = car.vf = car.vl = 0; car.nitro = 1;
}
function initNavAI(c, mode, i, j, d, lane, maxSp, acc) {
  const f = DIRS[d], rt = rightOf(d);
  c.x = nodeC(i) + f[0] * 22 + rt[0] * lane; c.z = nodeC(j) + f[1] * 22 + rt[1] * lane; c.h = Math.atan2(f[0], f[1]);
  c.ai = { mode, wps: [], i: i + f[0], j: j + f[1], d, maxSp, base: maxSp, acc, blocked: 0, ignoreT: 0, hold: true };
  const bx = nodeC(c.ai.i), bz = nodeC(c.ai.j);
  c.ai.wps.push({ x: bx - f[0] * 14 + rt[0] * lane, z: bz - f[1] * 14 + rt[1] * lane });
}
function genOrbs(def) {
  let seed = 0; for (const ch of def.id) seed = seed * 31 + ch.charCodeAt(0);
  const R = rng(seed), s = def.start, out = [];
  let guard = 0;
  while (out.length < def.count && guard++ < 500) {
    const vertical = R() < 0.5;
    const a = clamp(s[vertical ? 0 : 1] + Math.round((R() - 0.5) * 2 * def.spread), 0, GRID);
    const along = clamp((vertical ? nodeC(s[1]) : nodeC(s[0])) + (R() - 0.5) * 2 * def.spread * PITCH * 0.9, -HALF + 12, HALF - 12);
    const x = vertical ? nodeC(a) : along, z = vertical ? along : nodeC(a);
    if (Math.hypot(x - nodeC(s[0]), z - nodeC(s[1])) < 35) continue;
    if (out.some(o => Math.hypot(o.x - x, o.z - z) < 30)) continue;
    out.push({ x, z, got: false });
  }
  return out;
}
function startMission(id) {
  const def = MISSIONS.find(m => m.id === id); if (!def) return;
  if (RC.state || ARENA.on) { toast('Сначала завершите событие'); return; }
  auInit();
  if (G.mode !== 'play') enterGame(false);
  closeScreens();
  cleanupMission();
  fadeThen(() => setupMission(def));
}
function setupMission(def) {
  if (G.inHome) setHomeState(false);
  M = { def, state: 'countdown', cd: 3.4, lastN: 4, t: 0, left: def.time || 0, idx: 0, stage: 0, pts: [], got: 0, racers: [], cops: [], holdT: 0, contact: 0, contactTotal: 0, flash: 0, rivalFin: 0, route: null, cumKey: [], drBase: DR.total };
  lastMissionId = def.id; clearWanted();
  P.hp = 100; HITFX.flash = 0; TRACERS.length = 0; WS.reload = 0;
  if (def.type === 'shootout') topUpAmmo();
  const s = def.start, nx = nodeC(s[0]), nz = nodeC(s[1]);
  let d = 0;
  const refTop = statsFor(CAR_BY_ID[S.sel], S.cars[S.sel].u).maxSpeed;
  if (def.type === 'checkpoints') { M.pts = def.pts.map(p => ({ x: nodeC(p[0]), z: nodeC(p[1]) })); d = dirToward(s, def.pts[0]); }
  else if (def.type === 'delivery') { M.pts = def.stages.map(p => ({ x: nodeC(p.p[0]), z: nodeC(p.p[1]) })); d = dirToward(s, def.stages[0].p); }
  else if (def.type === 'collect') { M.orbs = genOrbs(def); MARK.orbs = M.orbs; }
  else if (def.type === 'race') {
    const ex = expandRoute(s, def.route);
    M.route = ex.route; M.cumKey = ex.keyIdx.map(i => i * PITCH);
    M.pts = def.route.map(p => ({ x: nodeC(p[0]), z: nodeC(p[1]) }));
    d = dirBetween(ex.route[0], ex.route[1]);
  }
  const f = DIRS[d], rt = rightOf(d);
  const back = nodeOK(s[0] - f[0], s[1] - f[1]) ? 14 : 5;
  const useCar = def.needCar || def.type === 'race';
  if (useCar) {
    const car = ensureOwn();
    if (def.type === 'race') {
      const slot = n => { const row = Math.floor(n / 2), side = n % 2, lat = side ? 5.2 : 1.9, bk = 7 + row * 9; return [nx - f[0] * bk + rt[0] * lat, nz - f[1] * bk + rt[1] * lat]; };
      const p0 = slot(0); car.x = p0[0]; car.z = p0[1];
      const rivalDefs = def.diff > 1.0 ? [CAR_BY_ID.super, CAR_BY_ID.sport, CAR_BY_ID.gt, CAR_BY_ID.rally] : def.diff > 0.95 ? [CAR_BY_ID.sport, CAR_BY_ID.gt, CAR_BY_ID.muscle, CAR_BY_ID.rally] : [CAR_BY_ID.coupe, CAR_BY_ID.muscle, CAR_BY_ID.sport, CAR_BY_ID.sedan];
      for (let k = 0; k < def.rivals; k++) {
        const rd = rivalDefs[k % rivalDefs.length], rc = makeCar(rd, 'racer', COLORS[(k * 3 + 1) % COLORS.length]);
        const p = slot(k + 1); rc.x = p[0]; rc.z = p[1]; rc.h = Math.atan2(f[0], f[1]);
        const base = clamp(refTop * 0.8 * def.diff * (0.96 + k * 0.03), 24, 64);
        rc.ai = { mode: 'race', route: M.route, k: 0, d, wps: [], maxSp: base, base, acc: 12, hold: true, finished: false };
        M.racers.push(rc);
      }
    } else { car.x = nx + rt[0] * LANE - f[0] * back; car.z = nz + rt[1] * LANE - f[1] * back; }
    car.h = Math.atan2(f[0], f[1]);
    seatPlayer(car);
    CAM.yaw = car.h; CAM.off = 0;
  } else {
    if (P.car) exitCar(true);
    { const sg = (s[0] === HOME_B && s[1] === HOME_B) ? -1 : 1; P.x = nx + 10.5 * sg; P.z = nz + 10.5 * sg; }
    P.y = terrainY(P.x, P.z); P.speed = 0;
    CAM.yaw = Math.atan2(-1, -1);
  }
  if (def.type === 'chase') {
    for (let k = 0; k < def.cops; k++) {
      let i, j, g = 0;
      do { i = Math.floor(Math.random() * (GRID + 1)); j = Math.floor(Math.random() * (GRID + 1)); } while (Math.abs(i - s[0]) + Math.abs(j - s[1]) < 3 && g++ < 50);
      const opts = validDirs(i, j, Math.floor(Math.random() * 4));
      const cp = makeCar(POLICE_DEF, 'police', '#f5f5f5');
      initNavAI(cp, 'police', i, j, opts[0], 2, clamp(refTop * 0.9, 34, 60), 14);
      M.cops.push(cp);
    }
  }
  DR.cur = 0; DR.mult = 1; DR.idle = 0;
  if (def.type === 'shootout') initShootout(def);
  refreshMarkers();
  toast(def.icon + ' ' + def.name);
}
function setHold(h) { if (!M) return; for (const c of M.racers.concat(M.cops)) c.ai.hold = h; }
function missionTargets() {
  const out = MARK.list.map(m => ({ x: m.x, z: m.z, c: m.c }));
  for (const o of MARK.orbs) if (!o.got) out.push({ x: o.x, z: o.z, c: [1, 0.8, 0.1] });
  return out;
}
function refreshMarkers() {
  MARK.list = [];
  if (!M) return;
  const def = M.def;
  if (def.type === 'checkpoints' || def.type === 'race') {
    const c = def.type === 'race' ? [0.2, 0.9, 1] : [1, 0.85, 0.15];
    if (M.pts[M.idx]) MARK.list.push({ x: M.pts[M.idx].x, z: M.pts[M.idx].z, r: 8, c });
    if (M.pts[M.idx + 1]) MARK.list.push({ x: M.pts[M.idx + 1].x, z: M.pts[M.idx + 1].z, r: 8, c: [1, 1, 1] });
  } else if (def.type === 'delivery') {
    const t = M.pts[M.stage];
    if (t) MARK.list.push({ x: t.x, z: t.z, r: 7, c: M.stage === 0 ? [0.2, 1, 0.4] : [0.3, 0.6, 1] });
  }
}
function cleanupMission() {
  if (M) { for (const c of M.racers.concat(M.cops)) removeCar(c); }
  M = null; MARK.list = []; MARK.orbs = [];
  showCountdown('');
}
function updateMission(dt) {
  if (!M) return;
  const def = M.def;
  if (M.state === 'countdown') {
    M.cd -= dt;
    const n = Math.ceil(M.cd);
    if (n !== M.lastN) { M.lastN = n; if (n > 0) { showCountdown(String(n)); SFX.tick(); } else { showCountdown('GO!'); SFX.go(); } }
    if (M.cd <= 0) { M.state = 'run'; setHold(false); setTimeout(() => showCountdown(''), 700); }
    return;
  }
  if (M.state !== 'run') return;
  M.t += dt; M.flash -= dt;
  if (def.time) M.left -= dt;
  const car = P.car, px = car ? car.x : P.x, pz = car ? car.z : P.z, kmh = car ? Math.abs(car.vf) * 3.6 : 0;
  const canAct = !def.needCar || !!car;
  if (def.type === 'checkpoints' || def.type === 'race') {
    const t = M.pts[M.idx];
    if (t && canAct && Math.hypot(px - t.x, pz - t.z) < (def.type === 'race' ? 12 : 10)) {
      if (def.minSpeed && kmh < def.minSpeed) {
        if (M.flash <= 0) { toast('🐢 Слишком медленно! Нужно ' + def.minSpeed + ' км/ч'); SFX.err(); M.flash = 1.5; }
      } else {
        M.idx++; SFX.cp(); refreshMarkers();
        if (M.idx >= M.pts.length) { endMission(true); return; }
        toast('✔ Чекпоинт ' + M.idx + '/' + M.pts.length);
      }
    }
    if (def.type === 'race') {
      const pr = M.idx < M.pts.length ? M.cumKey[M.idx] - Math.hypot(px - M.pts[M.idx].x, pz - M.pts[M.idx].z) : 1e9;
      let ahead = 0;
      for (const r of M.racers) {
        const ai = r.ai, last = M.route.length - 1;
        if (!ai.finished) {
          const nd = M.route[Math.min(ai.k, last)], dd = Math.hypot(r.x - nodeC(nd[0]), r.z - nodeC(nd[1]));
          ai.prog = ai.k * PITCH - dd;
          if (ai.k >= last && dd < 9) { ai.finished = true; ai.maxSp = 0; M.rivalFin++; }
          const lead = ai.prog - pr;
          ai.maxSp = ai.base * (lead > 90 ? 0.86 : lead < -90 ? 1.08 : 1);
        } else ai.prog = 1e8;
        if (ai.prog > pr) ahead++;
      }
      M.pos = ahead + 1;
      if (M.rivalFin > 0) { endMission(false, 'Соперник пришёл первым!'); return; }
    }
  } else if (def.type === 'delivery') {
    const st = def.stages[M.stage], t = M.pts[M.stage], dist = Math.hypot(px - t.x, pz - t.z);
    if (canAct && dist < (st.stop ? 8 : (car ? 8 : 5))) {
      let ok = true;
      if (st.stop) { if (kmh < 8) { M.holdT += dt; ok = M.holdT >= 1; } else { M.holdT = 0; ok = false; } }
      if (ok) {
        M.stage++; M.holdT = 0; SFX.cp(); refreshMarkers();
        if (M.stage >= def.stages.length) { endMission(true); return; }
        toast('✔ ' + def.stages[M.stage].t);
      }
    } else M.holdT = 0;
  } else if (def.type === 'collect') {
    for (const o of M.orbs) {
      if (o.got || !canAct) continue;
      if (Math.hypot(px - o.x, pz - o.z) < 5.5) {
        o.got = true; M.got++; M.left += def.bonus; SFX.coin();
        for (let i = 0; i < 10; i++) emit(o.x, 1.8, o.z, rand(-4, 4), rand(1, 6), rand(-4, 4), 0.6, 0.25, 0.05, 1, 0.8, 0.1, 1, true);
        toast('💰 ' + M.got + '/' + def.count + '  +' + def.bonus + ' c');
        if (M.got >= def.count) { endMission(true); return; }
      }
    }
  } else if (def.type === 'drift') {
    if (DR.total - M.drBase + DR.cur >= def.target) { DR.total += Math.round(DR.cur); DR.cur = 0; endMission(true); return; }
  } else if (def.type === 'shootout') {
    shootStep(dt);
    if (M.state === 'done') return;
  } else if (def.type === 'chase') {
    let near = 1e9;
    for (const c of M.cops) {
      const d = Math.hypot(c.x - px, c.z - pz); near = Math.min(near, d);
      c.ai.maxSp = c.ai.base * (d > 130 ? 1.25 : 1);
    }
    if (near < 6) { M.contact += dt / 4; M.contactTotal += dt; } else M.contact = Math.max(0, M.contact - dt * 0.25);
    auSiren(clamp(1 - near / 130, 0, 1));
    if (M.contact >= 1) { endMission(false, 'Вас задержала полиция!'); return; }
    if (M.left <= 0) { endMission(true); return; }
    return;
  }
  if (def.time && M.left <= 0) endMission(false, 'Время вышло!');
}
function endMission(ok, msg) {
  if (!M || M.state === 'done') return;
  M.state = 'done';
  const def = M.def, t = M.t;
  const rec = S.missions[def.id] || (S.missions[def.id] = { done: false, best: 0, medal: 0, plays: 0 });
  rec.plays++;
  let medal = 0, reward = 0, bonus = 0, first = false;
  if (ok) {
    const ratio = def.type === 'chase' ? 1 - clamp(M.contactTotal / 3, 0, 1) : (def.time ? clamp(M.left / def.time, 0, 1) : 0.5);
    medal = ratio > 0.5 ? 3 : ratio > 0.25 ? 2 : 1;
    first = !rec.done;
    reward = first ? def.reward : Math.round(def.reward * 0.5);
    bonus = medal === 3 ? Math.round(reward * 0.25) : medal === 2 ? Math.round(reward * 0.1) : 0;
    if (first) S.stats.missions++;
    rec.done = true; rec.medal = Math.max(rec.medal || 0, medal);
    if (!rec.best || t < rec.best) rec.best = t;
    S.money += reward + bonus; SFX.win();
  } else SFX.lose();
  persist(); refreshMoney(true);
  const pos = M.pos;
  cleanupMission();
  showResult({ ok, msg, def, medal, reward, bonus, first, t, pos });
}
function cancelMission() { if (M) { cleanupMission(); toast('Задание отменено'); } }

