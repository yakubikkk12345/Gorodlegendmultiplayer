/* ===================== 2. ДАННЫЕ ИГРЫ ===================== */
const GRID = 16, PITCH = 80, ROAD = 16, BLOCK = 64;
const BO = (GRID - 12) / 2;   // сдвиг блоков старого города (12×12) к центру новой карты: мировые координаты прежние
const HALF = GRID * PITCH / 2;           // 320
const EDGE = HALF + ROAD / 2 + 2;        // граница мира
const LANE = 3.6;
const nodeC = i => -HALF + i * PITCH;    // координата узла (перекрёстка)
const DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]];
const rightOf = d => { const f = DIRS[d]; return [-f[1], f[0]]; };
const OFS = (GRID - 8) / 2;               // сдвиг заданий к центру большой карты
const HOME_B = 6 + BO;                          // блок, где стоит дом игрока
const INX = 1500, INZ = 1500;              // координаты интерьера дома (далеко от города)
const DAY_LEN = 720;                      // секунд на полные сутки

const BIZ = [
  { id: 'gas', blk: [5, 0], ico: '⛽', name: 'АЗС «Магистраль»', short: 'АЗС', price: 6000, rate: 200, col: [0.9, 0.45, 0.1, 1], mc: [1, 0.6, 0.1], dot: '#ff9f1c' },
  { id: 'wash', blk: [6, 11], ico: '🚿', name: 'Автомойка «Блеск»', short: 'АВТОМОЙКА', price: 15000, rate: 600, col: [0.2, 0.6, 0.85, 1], mc: [0.3, 0.8, 1], dot: '#4cc9f0' },
  { id: 'club', blk: [9, 2], ico: '🎵', name: 'Ночной клуб «Неон»', short: 'КЛУБ', price: 40000, rate: 1800, col: [0.55, 0.2, 0.75, 1], mc: [0.8, 0.4, 1], dot: '#c77dff' },
  { id: 'port', blk: [6, 13], ico: '⚓', name: 'Морской порт «Гавань»', short: 'ПОРТ', price: 150000, rate: 3200, col: [0.22, 0.32, 0.48, 1], mc: [0.3, 0.7, 1], dot: '#2a9df4' },
  { id: 'casino', blk: [8, 8], ico: '🎰', name: 'Казино «Золотой дракон»', short: 'КАЗИНО', price: 500000, rate: 15000, col: [0.35, 0.1, 0.45, 1], mc: [1, 0.8, 0.2], dot: '#ff2fa0' }
];
BIZ.forEach(b => { b.blk = [b.blk[0] + BO, b.blk[1] + BO]; });
const BIZ_BY = {}; BIZ.forEach(b => BIZ_BY[b.id] = b);
const BIZ_BLK = {}; BIZ.forEach(b => BIZ_BLK[b.blk.join(',')] = b);
BIZ_BLK[(8 + BO) + ',' + (5 + BO)] = { id: 'boss', ico: '📞', name: 'Бар «Крот»', short: 'БАР КРОТА', col: [0.16, 0.16, 0.22, 1], mc: [1, 0.85, 0.2], dot: '#ffd23f', blk: [8 + BO, 5 + BO] };
BIZ_BLK[(3 + BO) + ',' + (3 + BO)] = { id: 'taxi', ico: '🚕', name: 'Таксопарк', short: 'ТАКСОПАРК', col: [0.95, 0.8, 0.15, 1], mc: [1, 0.85, 0.1], dot: '#ffd60a', blk: [3 + BO, 3 + BO] };
BIZ_BLK[(8 + BO) + ',' + (3 + BO)] = { id: 'food', ico: '🌭', name: 'Кафе «Вкусно»', short: 'КАФЕ', col: [0.85, 0.3, 0.25, 1], mc: [1, 0.5, 0.4], dot: '#ff7a5c', blk: [8 + BO, 3 + BO] };
const bizMult = r => 1 + 0.5 * ((r.lvl || 1) - 1);
const bizCap = (r, b) => b.rate * bizMult(r) * 15;
const hasOffice = () => !!(S.props && S.props.tower && S.props.tower.own);
function safeCap() { let c = 0; for (const k in S.biz) { const r = S.biz[k], b = BIZ_BY[k]; if (b && r && r.own) c += bizCap(r, b); } for (const p of PROPS) if (propOwn(p.id)) c += propCap(p); return c; }
function safeIn(v) { if (v > 0) S.safe = Math.min(safeCap(), (S.safe || 0) + v); }
function bizAdd(r, b, sec) {
  if (hasOffice()) { if (r.acc > 0) { S.safe = (S.safe || 0) + r.acc; r.acc = 0; } safeIn(b.rate * bizMult(r) / 60 * sec); return; }
  r.acc = Math.min(bizCap(r, b), (r.acc || 0) + b.rate * bizMult(r) / 60 * sec);
}
const STORY = [
  { req: 'm1', t: 'Новичок', intro: 'Новенький? Меня зовут Крот, и этот город — мой. Докажи, что на что-то годишься: развези пиццу на время.', outro: 'Неплохо для новичка. Держи аванс.', reward: 500 },
  { req: 'm2', t: 'Проверка за рулём', intro: 'Теперь покажи, как ты водишь. Пройди утренний заезд по чекпоинтам.', outro: 'Руки растут откуда надо. Продолжаем.', reward: 800 },
  { req: 'm4', t: 'Свои люди', intro: 'Мне нужны люди, которые знают каждую улицу. Поработай ночным таксистом.', outro: 'Город тебя запомнил. Держи.', reward: 1200 },
  { req: 'm5', t: 'Соперник', intro: 'Лис, главарь соседней банды, зазнался. Обгони его людей на уличных гонках.', outro: 'Лис в бешенстве, а я доволен. Твоя доля.', reward: 2000 },
  { req: 'm8', t: 'Хвост', intro: 'Лис натравил на нас полицию. Оторвись от погони и не подставь меня.', outro: 'Ушёл чисто. Уважаю.', reward: 2500 },
  { req: 'm10', t: 'Гонка чемпионов', intro: 'Весь город смотрит на большую гонку. Выиграй её — и все узнают, чей ты человек.', outro: 'Чемпион! Теперь ты настоящая фигура.', reward: 4000 },
  { req: 'm21', t: 'Парк', intro: 'Бойцы Лиса заняли парк. Купи ствол в оружейном магазине и очисти его.', outro: 'Парк снова наш. Но Лис ещё жив.', reward: 5000 },
  { req: 'm23', t: 'Охота на банду', intro: 'Хватит игр. Выследи основные силы банды Лиса. Бери дробовик или винтовку.', outro: 'Банда разбита. Остался только он сам.', reward: 8000 },
  { req: 'm24', t: 'Король перестрелок', intro: 'Финал. Лис ждёт тебя со всей своей охраной. Сделай это, и город твой.', outro: 'Лис повержен. Ты — легенда города! Держи главный приз.', reward: 25000, final: true }
];

const INT = {
  home: { kind: 'home', x: INX, z: INZ }, gun: { kind: 'gun', x: INX + 300, z: INZ }, car: { kind: 'car', x: INX + 600, z: INZ },
  hosp: { kind: 'hosp', x: INX + 900, z: INZ }, pol: { kind: 'pol', x: INX + 1200, z: INZ },
  tune: { kind: 'tune', x: INX + 1500, z: INZ }, garage: { kind: 'garage', x: INX + 1800, z: INZ }, club: { kind: 'club', x: INX + 2100, z: INZ },
  cloth: { kind: 'cloth', x: INX + 5000, z: INZ }, salon: { kind: 'salon', x: INX + 5300, z: INZ }
};
const SELLERS = {};
{
  const L = (p, s, k, h) => ({ pants: hexRGB(p), shirt: hexRGB(s), skin: hexRGB(k), hair: hexRGB(h), dark: [0.05, 0.05, 0.05] });
  SELLERS.gun = { x: INT.gun.x, z: INT.gun.z + 3.6, name: 'Борис', look: L('#2a2a2a', '#8a4b14', '#c68e6b', '#222222') };
  SELLERS.car = { x: INT.car.x, z: INT.car.z + 3.6, name: 'Виктор', look: L('#1c2540', '#e8eef8', '#f1c7a5', '#5a3825') };
  SELLERS.hosp = { x: INT.hosp.x, z: INT.hosp.z + 3.6, name: 'Доктор Анна', look: L('#e6eef5', '#ffffff', '#e0ac86', '#3a2415') };
  SELLERS.pol = { x: INT.pol.x, z: INT.pol.z + 3.6, name: 'Офицер Петров', look: L('#1b2438', '#2f5fd0', '#e0ac86', '#10182b') };
  SELLERS.club = { x: INT.club.x, z: INT.club.z + 3.6, name: 'Гена', look: L('#2a2a30', '#b8561a', '#d8a07a', '#2a1a10') };
  SELLERS.tune = { x: INT.tune.x, z: INT.tune.z + 3.6, name: 'Макс', look: L('#2b3140', '#e8742c', '#d8a07a', '#1a1a1a') };
  {
    const FL = (shirt, bot, skin, hair, bt, ty, hs) => setLook({ pants: hexRGB(bot), shirt: hexRGB(shirt), skin: hexRGB(skin), hair: hexRGB(hair), dark: [0.05, 0.05, 0.05], shoe: hexRGB('#2a2a2e'), lips: hexRGB('#c43a62') }, { f: true, hs, bt, ty, sh: 0.1 });
    SELLERS.cloth = { x: INT.cloth.x, z: INT.cloth.z + 3.6, name: 'Алиса', look: FL('#ff7eb6', '#1a1a1f', '#f1c7a5', '#5a3825', 'skirt', 'crop', 'f0') };
    SELLERS.salon = { x: INT.salon.x, z: INT.salon.z + 3.6, name: 'Карина', look: FL('#2b2b33', '#2b2b33', '#e0ac86', '#e3c07a', 'pants', 'tank', 'f3') };
  }
}
const CARS = [
  { id: 'hatch', name: 'Городской Хэтч', price: 0, speed: 34, accel: 9, handling: 1.0, grip: 7.5, color: '#e63946', desc: 'Надёжный старт для любого гангстера.', shape: { L: 3.9, W: 1.72, H: 0.62, cL: 2.0, cH: 0.6, cZ: -0.15, wr: 0.31 } },
  { id: 'van', name: 'Фургон Курьер', price: 2500, speed: 31, accel: 7, handling: 0.85, grip: 7, color: '#f1faee', desc: 'Медленный, зато вместительный.', shape: { L: 4.8, W: 1.95, H: 1.0, cL: 3.1, cH: 0.8, cZ: -0.35, wr: 0.36 } },
  { id: 'taxi', name: 'Такси Центр', price: 5000, speed: 38, accel: 10, handling: 0.95, grip: 7.5, color: '#ffd60a', taxi: true, desc: 'Знает каждую улицу города.', shape: { L: 4.5, W: 1.8, H: 0.66, cL: 2.3, cH: 0.62, cZ: -0.2, wr: 0.33 } },
  { id: 'sedan', name: 'Седан Комфорт', price: 6000, speed: 41, accel: 11, handling: 1.0, grip: 8, color: '#3a86ff', desc: 'Солидная машина для деловых встреч.', shape: { L: 4.6, W: 1.82, H: 0.66, cL: 2.4, cH: 0.6, cZ: -0.2, wr: 0.33 } },
  { id: 'pickup', name: 'Пикап Ранчо', price: 7500, speed: 39, accel: 10.5, handling: 0.92, grip: 8, color: '#b5651d', desc: 'Рабочая лошадка с мощным мотором.', shape: { L: 5.0, W: 1.95, H: 0.78, cL: 1.7, cH: 0.62, cZ: 0.55, wr: 0.4 } },
  { id: 'suv', name: 'Внедорожник Тайга', price: 10000, speed: 40, accel: 11, handling: 0.9, grip: 8.5, color: '#2d6a4f', desc: 'Тяжёлый и устойчивый на поворотах.', shape: { L: 4.7, W: 1.98, H: 0.85, cL: 2.8, cH: 0.7, cZ: -0.25, wr: 0.4 } },
  { id: 'classic', name: 'Классика 66', price: 12500, speed: 44, accel: 12.5, handling: 1.0, grip: 8, color: '#2a9d8f', desc: 'Ретро-седан с характером.', shape: { L: 4.9, W: 1.85, H: 0.62, cL: 2.1, cH: 0.52, cZ: -0.3, wr: 0.34 } },
  { id: 'coupe', name: 'Купе Вектор', price: 15000, speed: 46, accel: 14, handling: 1.1, grip: 8.5, color: '#8338ec', desc: 'Лёгкое и отзывчивое купе.', shape: { L: 4.3, W: 1.84, H: 0.55, cL: 1.9, cH: 0.5, cZ: -0.3, wr: 0.33 } },
  { id: 'rally', name: 'Ралли Буря', price: 20000, speed: 50, accel: 16, handling: 1.25, grip: 10, color: '#0077b6', spoiler: true, desc: 'Цепляется за дорогу, как кошка.', shape: { L: 4.2, W: 1.84, H: 0.6, cL: 1.9, cH: 0.54, cZ: -0.15, wr: 0.34 } },
  { id: 'muscle', name: 'Мускул Торнадо', price: 24000, speed: 52, accel: 17, handling: 0.95, grip: 7.5, color: '#ff7b00', desc: 'Рёв мотора и дымящиеся шины.', shape: { L: 4.9, W: 1.95, H: 0.6, cL: 2.0, cH: 0.5, cZ: -0.4, wr: 0.36 } },
  { id: 'gt', name: 'Гран Туризмо Ураган', price: 32000, speed: 56, accel: 18, handling: 1.15, grip: 9, color: '#6a040f', desc: 'Быстрое и комфортное купе дальних дорог.', shape: { L: 4.7, W: 1.9, H: 0.5, cL: 1.8, cH: 0.44, cZ: -0.25, wr: 0.35 } },
  { id: 'sport', name: 'Спорт Молния', price: 38000, speed: 58, accel: 19, handling: 1.2, grip: 9, color: '#00b4d8', spoiler: true, desc: 'Настоящий гоночный болид для улиц.', shape: { L: 4.4, W: 1.9, H: 0.5, cL: 1.7, cH: 0.44, cZ: -0.2, wr: 0.34 } },
  { id: 'super', name: 'Суперкар Феникс', price: 60000, speed: 66, accel: 22, handling: 1.3, grip: 9.5, color: '#e63946', spoiler: true, desc: 'Скорость, от которой захватывает дух.', shape: { L: 4.5, W: 2.0, H: 0.46, cL: 1.6, cH: 0.4, cZ: -0.1, wr: 0.35 } },
  { id: 'electro', name: 'Электро Импульс', price: 78000, speed: 72, accel: 30, handling: 1.3, grip: 9.5, color: '#4cc9f0', spoiler: true, desc: 'Бесшумный разгон до небес.', shape: { L: 4.5, W: 1.98, H: 0.46, cL: 1.7, cH: 0.4, cZ: -0.1, wr: 0.35 } },
  { id: 'hyper', name: 'Гиперкар Легенда', price: 95000, speed: 76, accel: 25, handling: 1.4, grip: 10, color: '#ffd60a', spoiler: true, desc: 'Вершина автопрома. Король города.', shape: { L: 4.6, W: 2.02, H: 0.44, cL: 1.55, cH: 0.38, cZ: -0.05, wr: 0.36 } },
  { id: 'scooter', name: 'Скутер Шмель', price: 1800, speed: 26, accel: 8, handling: 1.35, grip: 6.5, color: '#ffd60a', bike: true, desc: 'Юркий и дешёвый скутер: проскочит в любую щель.', shape: { L: 2.0, W: 0.7, H: 0.45, cL: 0.5, cH: 0.3, cZ: -0.1, wr: 0.26 } },
  { id: 'moto', name: 'Мотоцикл Байкер', price: 9000, speed: 50, accel: 20, handling: 1.5, grip: 8, color: '#d00000', bike: true, desc: 'Настоящий мотоцикл: быстрый разгон и наклоны в поворотах.', shape: { L: 2.2, W: 0.7, H: 0.5, cL: 0.5, cH: 0.3, cZ: -0.1, wr: 0.3 } },
  { id: 'superbike', name: 'Спортбайк Кобра', price: 42000, speed: 70, accel: 28, handling: 1.6, grip: 9.5, color: '#00b4d8', bike: true, desc: 'Скорость почти как у суперкара, только без крыши.', shape: { L: 2.2, W: 0.7, H: 0.5, cL: 0.5, cH: 0.3, cZ: -0.1, wr: 0.31 } },
  { id: 'raptor', name: 'Вездеход Раптор', price: 28000, speed: 50, accel: 15, handling: 1.05, grip: 10, color: '#c2630a', massK: 1.5, desc: 'Внедорожник на высокой подвеске: цепкий, прочный, не боится бордюров.', shape: { L: 4.8, W: 2.05, H: 0.95, cL: 2.6, cH: 0.75, cZ: -0.3, wr: 0.5 } },
  { id: 'armored', name: 'Броневик Страж', price: 120000, speed: 46, accel: 11, handling: 0.85, grip: 9, color: '#3d4a3a', massK: 2.2, armorK: 0.35, dmgK: 0.3, desc: 'Бронированный: пули и удары почти не страшны. Тяжёлый, сносит всё на пути.', shape: { L: 5.4, W: 2.15, H: 1.0, cL: 3.0, cH: 0.8, cZ: -0.2, wr: 0.5 } },
  { id: 'tank', name: 'Танк Мамонт', price: 450000, speed: 30, accel: 8, handling: 0.7, grip: 10, color: '#4b5320', tank: true, massK: 6, armorK: 0.12, dmgK: 0.08, desc: 'Гусеничный монстр. Давит машины, почти неуязвим. Огонь (G / кнопка) — снаряд с взрывом, перезарядка 1,5 с.', shape: { L: 6.6, W: 3.1, H: 1.1, cL: 2.6, cH: 0.75, cZ: -0.3, wr: 0.6 } },
  { id: 'heli', name: 'Вертолёт Стриж', price: 70000, speed: 55, accel: 14, handling: 1.2, grip: 2, color: '#e63946', heli: true, desc: 'Летает над городом! Shift — вверх, Пробел — вниз, W/S — вперёд/назад.', shape: { L: 6.2, W: 2.0, H: 1.2, cL: 1.4, cH: 0.9, cZ: 0.9, wr: 0.3 } }
];
CARS.sort((a, b) => a.price - b.price);
const CAR_BY_ID = {}; CARS.forEach(c => CAR_BY_ID[c.id] = c);
const POLICE_DEF = Object.assign({}, CAR_BY_ID.sedan, { id: 'police', name: 'Полиция', color: '#f5f5f5', police: true });
const COLORS = ['#e63946', '#ff7b00', '#ffd60a', '#2ecc71', '#00b4d8', '#3a86ff', '#8338ec', '#ff4fa3', '#f1f1f1', '#222222', '#9aa0a6', '#7b3f00'];
const UPGRADES = [
  { key: 'eng', name: 'Двигатель', icon: '⚙️', desc: '+5% макс. скорости за уровень' },
  { key: 'acc', name: 'Трансмиссия', icon: '🔩', desc: '+7% ускорения за уровень' },
  { key: 'tir', name: 'Шины и подвеска', icon: '🛞', desc: 'Лучше управляемость и сцепление' },
  { key: 'nit', name: 'Нитро', icon: '🔥', desc: 'Больше запас и мощность нитро' }
];
const MAX_UPG = 5;
const upgCost = (def, lvl) => Math.round((300 + def.price * 0.03) * (lvl + 1));
function statsFor(def, u) {
  u = u || { eng: 0, acc: 0, tir: 0, nit: 0 };
  return {
    maxSpeed: def.speed * (1 + 0.05 * u.eng),
    accel: def.accel * (1 + 0.07 * u.acc),
    handling: def.handling * (1 + 0.04 * u.tir),
    grip: def.grip + 0.5 * u.tir,
    nitro: 1 + 0.15 * u.nit,
    brake: 24
  };
}

/* ---- Миссии (20 штук) ----
   Координаты задаются узлами сетки [i,j] (0..8). Центр города — [4,4]. */
const MISSIONS = [
  { id: 'm1', icon: '🍕', name: 'Пицца на вынос', type: 'delivery', needCar: false, reward: 300, time: 150, start: [4, 4],
    desc: 'Заберите заказы и доставьте клиентам. Можно бегом, а можно на машине.',
    stages: [{ p: [5, 4], t: 'Заберите пиццу в пиццерии' }, { p: [3, 5], t: 'Доставьте клиенту №1' }, { p: [3, 3], t: 'Доставьте клиенту №2' }] },
  { id: 'm2', icon: '⏱️', name: 'Утренняя разминка', type: 'checkpoints', needCar: true, reward: 500, time: 75, start: [4, 4],
    desc: 'Проедьте все чекпоинты на время.', pts: [[5, 4], [6, 4], [6, 5], [6, 6], [5, 6]] },
  { id: 'm3', icon: '💰', name: 'Охота за монетами', type: 'collect', needCar: false, reward: 600, time: 90, start: [4, 4], count: 8, spread: 3, bonus: 3,
    desc: 'Соберите 8 золотых сфер по улицам. Каждая даёт +3 секунды.' },
  { id: 'm4', icon: '🚕', name: 'Ночное такси', type: 'delivery', needCar: true, reward: 800, time: 130, start: [4, 4],
    desc: 'Подберите пассажиров, остановившись у метки, и отвезите их по адресам.',
    stages: [{ p: [3, 3], t: 'Остановитесь: заберите пассажира', stop: true }, { p: [6, 3], t: 'Высадите пассажира (остановитесь)', stop: true }, { p: [6, 6], t: 'Заберите второго пассажира', stop: true }, { p: [2, 6], t: 'Высадите его у отеля', stop: true }] },
  { id: 'm5', icon: '🏁', name: 'Уличные гонки', type: 'race', needCar: true, reward: 1200, time: 140, start: [1, 1], rivals: 2, diff: 0.8,
    desc: 'Обгоните двоих соперников и придите первым.', route: [[7, 1], [7, 4], [4, 4], [4, 7]] },
  { id: 'm6', icon: '🌀', name: 'Король дрифта', type: 'drift', needCar: true, reward: 1000, time: 90, start: [4, 4], target: 2500,
    desc: 'Наберите 2500 очков, скользя в заносе. Используйте ручник (Пробел).' },
  { id: 'm7', icon: '📡', name: 'Скоростной радар', type: 'checkpoints', needCar: true, reward: 1500, time: 60, start: [0, 4], minSpeed: 100,
    desc: 'Пролетайте радары на скорости не менее 100 км/ч. Нитро — ваш друг.', pts: [[2, 4], [4, 4], [6, 4], [8, 4]] },
  { id: 'm8', icon: '🚓', name: 'Побег от полиции', type: 'chase', needCar: true, reward: 1800, time: 60, start: [4, 4], cops: 3,
    desc: 'Продержитесь 60 секунд и не дайте копам зажать вас.' },
  { id: 'm9', icon: '📦', name: 'Ночной курьер', type: 'delivery', needCar: true, reward: 2200, time: 140, start: [4, 4],
    desc: 'Развезите четыре посылки по всему городу.',
    stages: [{ p: [1, 3], t: 'Склад №1' }, { p: [3, 6], t: 'Магазин на Северной' }, { p: [7, 6], t: 'Офис на Восточной' }, { p: [6, 1], t: 'Клиент на Южной' }] },
  { id: 'm10', icon: '🏆', name: 'Гонка чемпионов', type: 'race', needCar: true, reward: 3000, time: 170, start: [1, 0], rivals: 3, diff: 0.92,
    desc: 'Большой круг по городу против трёх сильных соперников.', route: [[8, 0], [8, 8], [0, 8], [0, 2], [4, 2]] },
  { id: 'm11', icon: '💎', name: 'Большая охота', type: 'collect', needCar: true, reward: 2500, time: 100, start: [4, 4], count: 12, spread: 4, bonus: 4,
    desc: 'Соберите 12 сфер по всему городу на машине.' },
  { id: 'm12', icon: '👑', name: 'Легенда города', type: 'race', needCar: true, reward: 8000, time: 150, start: [2, 6], rivals: 3, diff: 1.0,
    desc: 'Финальная гонка. Только победитель станет легендой.', route: [[2, 2], [6, 2], [6, 6], [3, 6], [3, 3]] },
  { id: 'm13', icon: '🚑', name: 'Срочная доставка', type: 'delivery', needCar: true, reward: 2800, time: 120, start: [4, 4],
    desc: 'Доставьте груз через весь город: четыре адреса, ни секунды лишней.',
    stages: [{ p: [1, 1], t: 'Заберите груз на юго-западе' }, { p: [7, 2], t: 'Первый адрес на востоке' }, { p: [7, 7], t: 'Второй адрес на севере' }, { p: [1, 7], t: 'Финиш в западном районе' }] },
  { id: 'm14', icon: '🌀', name: 'Слалом по городу', type: 'checkpoints', needCar: true, reward: 3000, time: 85, start: [1, 4],
    desc: 'Восемь чекпоинтов зигзагом. Тормозите вовремя!', pts: [[2, 4], [2, 3], [3, 3], [3, 5], [4, 5], [4, 2], [5, 2], [5, 6]] },
  { id: 'm15', icon: '🔥', name: 'Ночной дрифт', type: 'drift', needCar: true, reward: 3200, time: 110, start: [4, 4], target: 6000,
    desc: 'Набейте 6000 очков в заносе. Не врезайтесь — серия сбросится.' },
  { id: 'm16', icon: '🚨', name: 'Большая погоня', type: 'chase', needCar: true, reward: 4200, time: 90, start: [4, 4], cops: 5,
    desc: 'Пять патрульных машин на хвосте. Продержитесь 90 секунд.' },
  { id: 'm17', icon: '💎', name: 'Золотая лихорадка', type: 'collect', needCar: true, reward: 3600, time: 120, start: [4, 4], count: 16, spread: 5, bonus: 4,
    desc: 'Шестнадцать сфер по всему городу. Каждая даёт +4 секунды.' },
  { id: 'm18', icon: '📡', name: 'Сверхзвук', type: 'checkpoints', needCar: true, reward: 4800, time: 55, start: [0, 2], minSpeed: 130,
    desc: 'Радары на скорости от 130 км/ч. Нужна быстрая машина и нитро.', pts: [[2, 2], [4, 2], [6, 2], [8, 2]] },
  { id: 'm19', icon: '🏁', name: 'Кольцо ярости', type: 'race', needCar: true, reward: 6000, time: 180, start: [0, 0], rivals: 3, diff: 0.97,
    desc: 'Большой круг по окраинам против трёх опытных гонщиков.', route: [[8, 0], [8, 8], [0, 8], [0, 0], [4, 0]] },
  { id: 'm20', icon: '🏆', name: 'Король улиц', type: 'race', needCar: true, reward: 12000, time: 160, start: [4, 8], rivals: 3, diff: 1.06,
    desc: 'Финал для настоящих чемпионов. Соперники не прощают ошибок.', route: [[0, 8], [0, 4], [8, 4], [8, 0], [4, 0], [4, 4]] },
  { id: 'm21', icon: '🔫', name: 'Разборка в парке', type: 'shootout', needCar: false, reward: 3500, time: 150, start: [2, 4], arena: [4, 6], count: 8, hp: 40,
    desc: 'Банда заняла парк. Нужно оружие: купите его в оружейном магазине. Обезвредьте 8 бойцов. Огонь: Пробел или кнопка 🔫, авто-прицел включён. За каждого вы получаете +8 здоровья.' },
  { id: 'm22', icon: '🏚️', name: 'Налёт на склад', type: 'shootout', needCar: false, reward: 5200, time: 170, start: [5, 3], arena: [7, 5], waves: [6, 8], hp: 50,
    desc: 'Две волны бандитов у склада. Не стойте на месте: бегите и стреляйте.' },
  { id: 'm23', icon: '💥', name: 'Охота на банду', type: 'shootout', needCar: false, reward: 7500, time: 190, start: [1, 6], arena: [3, 8], waves: [8, 10], hp: 55,
    desc: 'Две больших волны. Купите дробовик или винтовку в оружейном магазине.' },
  { id: 'm24', icon: '☠️', name: 'Король перестрелок', type: 'shootout', needCar: false, reward: 14000, time: 260, start: [6, 6], arena: [8, 8], waves: [8, 10, 12], hp: 60, boss: true,
    desc: 'Три волны и главарь банды в конце. Только для настоящих легенд.' }
];

