/* ===================== TELEGRAM MINI APP ===================== */
const TG = window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.initData !== undefined && window.Telegram.WebApp.platform !== 'unknown' ? window.Telegram.WebApp : null;
const CHUNK = 3500;
let cloudT = 0, cloudLast = '';
function cloudSave(now) {
  if (!TG || !TG.CloudStorage) return;
  if (!now) { if (cloudT) return; cloudT = setTimeout(() => { cloudT = 0; cloudSave(true); }, 6000); return; }
  try {
    const json = JSON.stringify(S), key = 'sv' + SLOT;
    if (json === cloudLast) return; cloudLast = json;
    const n = Math.ceil(json.length / CHUNK), o = {};
    for (let i = 0; i < n; i++) o[key + '_' + i] = json.substr(i * CHUNK, CHUNK);
    o[key + '_n'] = String(n);
    const keys = Object.keys(o);
    let k = 0; const nextKey = () => { if (k >= keys.length) return; const kk = keys[k++]; TG.CloudStorage.setItem(kk, o[kk], nextKey); };
    // сначала части, потом счётчик (он последний в списке)
    nextKey();
  } catch (e) { console.warn('cloud save', e); }
}
function cloudLoad() {
  if (!TG || !TG.CloudStorage) return;
  const cs = TG.CloudStorage;
  [1, 2, 3].forEach(slot => {
    const key = 'sv' + slot;
    cs.getItem(key + '_n', (err, nv) => {
      const n = +nv; if (err || !n || n > 40) return;
      const ks = []; for (let i = 0; i < n; i++) ks.push(key + '_' + i);
      cs.getItems(ks, (e2, vals) => {
        if (e2 || !vals) return;
        let json = ''; for (const kk of ks) { if (!vals[kk]) return; json += vals[kk]; }
        let c; try { c = JSON.parse(json); } catch (e) { return; }
        if (!c || c.v !== 1 || typeof c.money !== 'number') return;
        let loc = null; try { const r = localStorage.getItem(slotKey(slot)); if (r) loc = JSON.parse(r); } catch (e) { }
        const locT = slot === SLOT && G.mode === 'play' ? Infinity : (loc && loc.bizT) || 0;
        if ((c.bizT || 0) > locT) {
          try { localStorage.setItem(slotKey(slot), json); } catch (e) { }
          if (slot === SLOT && G.mode === 'menu') { reloadSlot(); if (UI.cur === 'slots') renderSlots(); toast('☁️ Сохранение загружено из Telegram'); }
        }
        if (slot === SLOT) cloudLast = json;
      });
    });
  });
}
function tgInit() {
  if (!TG) return;
  try {
    TG.ready(); TG.expand();
    try { TG.disableVerticalSwipes && TG.disableVerticalSwipes(); } catch (e) { }
    try { TG.setHeaderColor && TG.setHeaderColor('#0b0f1a'); TG.setBackgroundColor && TG.setBackgroundColor('#0b0f1a'); } catch (e) { }
    try { if (TG.requestFullscreen && /android|ios/.test(TG.platform)) TG.requestFullscreen(); } catch (e) { }
    try { TG.enableClosingConfirmation && TG.enableClosingConfirmation(); } catch (e) { }
    const sa = () => {
      const r = document.documentElement.style, c = TG.contentSafeAreaInset || {}, d = TG.safeAreaInset || {};
      r.setProperty('--safe-t', ((c.top || 0) + (d.top || 0)) + 'px');
    };
    sa(); TG.onEvent && TG.onEvent('safeAreaChanged', sa); TG.onEvent && TG.onEvent('contentSafeAreaChanged', sa); TG.onEvent && TG.onEvent('fullscreenChanged', sa);
    document.addEventListener('visibilitychange', () => { if (document.hidden) { persist(); cloudSave(true); } });
    window.addEventListener('pagehide', () => { persist(); cloudSave(true); });
    cloudLoad();
  } catch (e) { console.warn('tg init', e); }
}

