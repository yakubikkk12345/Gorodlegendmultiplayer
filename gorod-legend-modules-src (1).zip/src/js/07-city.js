/* ===================== 6. ГОРОД ===================== */
const boxes = [];    // коллайдеры зданий {x0,x1,z0,z1}
const circles = [];  // деревья и т.п. {x,z,r}
const blockType = []; // blockType[bi][bj]
const PARKS = new Set(['3,3', '8,3', '3,8', '8,8', '4,6', '7,5', '5,8', '8,5', '0,0', '11,0', '0,11', '11,11', '0,5', '11,6', '5,0', '6,11', '2,9', '9,2'].map(k => { const a = k.split(',').map(Number); return (a[0] + BO) + ',' + (a[1] + BO); }).concat(['0,0', (GRID - 1) + ',0', '0,' + (GRID - 1), (GRID - 1) + ',' + (GRID - 1), '7,0', '8,' + (GRID - 1), '0,7', (GRID - 1) + ',8']));
const bc = i => -HALF + (i + 0.5) * PITCH;   // центр блока
const HOSP_BLK = [11 + BO, 5 + BO], POL_BLK = [0 + BO, 6 + BO];          // больница — на востоке, участок — на западе
const SHOP_BLKS = [{ b: [3 + BO, 1 + BO], k: 'gun', id: 'gunA' }, { b: [8 + BO, 10 + BO], k: 'gun', id: 'gunB' }, { b: [2 + BO, 7 + BO], k: 'car', id: 'carA' }, { b: [10 + BO, 2 + BO], k: 'car', id: 'carB' }];
const HOSP = { x: bc(HOSP_BLK[0]), z: bc(HOSP_BLK[1]) }, POLST = { x: bc(POL_BLK[0]), z: bc(POL_BLK[1]) };
let CITY = null;

