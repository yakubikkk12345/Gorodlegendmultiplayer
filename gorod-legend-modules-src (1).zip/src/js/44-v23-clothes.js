/* ===================== v23: ОДЕЖДА, ПРИЧЁСКИ, ПЕРСОНАЖ ===================== */
const TOPS = [
  { id: 'tm0', n: 'Красная куртка', c: '#c0392b', ty: 'jacket', p: 0, g: 'u', lg: 0 },
  { id: 'tm1', n: 'Синяя футболка', c: '#2c7be5', ty: 'tee', p: 0, g: 'u', lg: 1 },
  { id: 'tf0', n: 'Розовый топ', c: '#ff6fb5', ty: 'crop', p: 0, g: 'f' },
  { id: 'tf1', n: 'Белая майка', c: '#f4f4f4', ty: 'tank', p: 0, g: 'f' },
  { id: 'tm2', n: 'Зелёная толстовка', c: '#2ecc71', ty: 'hoodie', p: 120, g: 'u', lg: 2 },
  { id: 'tm3', n: 'Жёлтая худи', c: '#f1c40f', ty: 'hoodie', p: 140, g: 'u', lg: 3 },
  { id: 'tm4', n: 'Фиолетовая рубашка', c: '#8e44ad', ty: 'long', p: 200, g: 'u', lg: 4 },
  { id: 'tm5', n: 'Белая рубашка', c: '#ecf0f1', ty: 'long', p: 180, g: 'u', lg: 5 },
  { id: 'tm6', n: 'Оранжевая куртка', c: '#e67e22', ty: 'jacket', p: 260, g: 'u', lg: 6 },
  { id: 'tm7', n: 'Чёрный пиджак', c: '#161616', ty: 'jacket', p: 700, g: 'u', lg: 7 },
  { id: 'tu1', n: 'Чёрная футболка', c: '#1a1a1a', ty: 'tee', p: 60, g: 'u' },
  { id: 'tu2', n: 'Белая футболка', c: '#f5f5f5', ty: 'tee', p: 70, g: 'u' },
  { id: 'tu3', n: 'Кожаная куртка', c: '#2a2220', ty: 'jacket', p: 450, g: 'u' },
  { id: 'tu4', n: 'Джинсовая куртка', c: '#3b6ea8', ty: 'jacket', p: 320, g: 'u' },
  { id: 'tu5', n: 'Золотой пиджак', c: '#d4af37', ty: 'jacket', p: 1200, g: 'u' },
  { id: 'tf2', n: 'Красная блуза', c: '#d7263d', ty: 'long', p: 240, g: 'f' },
  { id: 'tf3', n: 'Бирюзовый кроп-топ', c: '#20c9c0', ty: 'crop', p: 150, g: 'f' },
  { id: 'tf4', n: 'Лавандовый свитер', c: '#b79cf2', ty: 'long', p: 280, g: 'f' },
  { id: 'tf5', n: 'Чёрный топ', c: '#151515', ty: 'tank', p: 110, g: 'f' },
  { id: 'tf6', n: 'Жёлтая футболка', c: '#ffd23f', ty: 'tee', p: 90, g: 'f' }
];
const BOTS = [
  { id: 'b0', n: 'Чёрные брюки', c: '#23262e', bt: 'pants', p: 0, g: 'u' },
  { id: 'b1', n: 'Тёмные джинсы', c: '#1c2a4a', bt: 'pants', p: 0, g: 'u' },
  { id: 'bf0', n: 'Чёрная юбка', c: '#1a1a1f', bt: 'skirt', p: 0, g: 'f' },
  { id: 'b2', n: 'Серые брюки', c: '#555a63', bt: 'pants', p: 80, g: 'u' },
  { id: 'b3', n: 'Хаки карго', c: '#5b6247', bt: 'pants', p: 120, g: 'u' },
  { id: 'b4', n: 'Белые джинсы', c: '#e9e9e9', bt: 'pants', p: 160, g: 'u' },
  { id: 'b5', n: 'Джинсовые шорты', c: '#3b6ea8', bt: 'shorts', p: 90, g: 'u' },
  { id: 'b6', n: 'Красные шорты', c: '#e63946', bt: 'shorts', p: 70, g: 'u' },
  { id: 'b7', n: 'Кожаные брюки', c: '#1b1514', bt: 'pants', p: 400, g: 'u' },
  { id: 'bf1', n: 'Джинсовая юбка', c: '#3b6ea8', bt: 'skirt', p: 90, g: 'f' },
  { id: 'bf2', n: 'Красная юбка', c: '#c0392b', bt: 'skirt', p: 130, g: 'f' },
  { id: 'bf3', n: 'Розовая мини-юбка', c: '#ff8fc2', bt: 'skirt', p: 120, g: 'f' },
  { id: 'bf4', n: 'Клетчатая юбка', c: '#7a1f3d', bt: 'skirt', p: 150, g: 'f' },
  { id: 'bf5', n: 'Белая юбка', c: '#f2f2f2', bt: 'skirt', p: 140, g: 'f' },
  { id: 'bf6', n: 'Леггинсы', c: '#0f0f12', bt: 'pants', p: 100, g: 'f' },
  { id: 'bf7', n: 'Золотые шорты', c: '#d4af37', bt: 'shorts', p: 260, g: 'f' }
];
const DRESSES = [
  { id: 'dr0', n: 'Красное платье', c: '#d7263d', p: 600, g: 'f' },
  { id: 'dr1', n: 'Чёрное платье', c: '#121212', p: 700, g: 'f' },
  { id: 'dr2', n: 'Голубое платье', c: '#5ab0f0', p: 500, g: 'f' },
  { id: 'dr3', n: 'Розовое платье', c: '#ff7eb6', p: 450, g: 'f' },
  { id: 'dr4', n: 'Белое платье', c: '#f6f6f6', p: 550, g: 'f' },
  { id: 'dr5', n: 'Изумрудное платье', c: '#1fa971', p: 650, g: 'f' },
  { id: 'dr6', n: 'Золотое вечернее', c: '#d4af37', p: 1500, g: 'f' }
];
const SHOES = [
  { id: 'sh0', n: 'Чёрные кроссовки', c: '#111111', sh: 0.1, p: 0, g: 'u' },
  { id: 'sh1', n: 'Белые кроссовки', c: '#f2f2f2', sh: 0.1, p: 80, g: 'u' },
  { id: 'sh2', n: 'Красные кеды', c: '#d7263d', sh: 0.1, p: 90, g: 'u' },
  { id: 'sh3', n: 'Коричневые ботинки', c: '#4b2e1e', sh: 0.2, p: 160, g: 'u' },
  { id: 'sh4', n: 'Чёрные сапоги', c: '#0c0c0c', sh: 0.34, p: 300, g: 'u' },
  { id: 'sh5', n: 'Розовые кеды', c: '#ff7eb6', sh: 0.1, p: 90, g: 'f' },
  { id: 'sh6', n: 'Белые сапоги', c: '#f2f2f2', sh: 0.34, p: 340, g: 'f' },
  { id: 'sh7', n: 'Золотые туфли', c: '#d4af37', sh: 0.1, p: 400, g: 'u' }
];
const CAT = {}; [TOPS, BOTS, DRESSES, SHOES].forEach(a => a.forEach(i => CAT[i.id] = i));
const HAIR_STYLES = [
  { id: 'm0', g: 'm', n: 'Короткая', p: 0 }, { id: 'm1', g: 'm', n: 'Бокс', p: 50 }, { id: 'm2', g: 'm', n: 'Шипы', p: 90 }, { id: 'm3', g: 'm', n: 'Длинные', p: 120 },
  { id: 'm4', g: 'm', n: 'Ирокез', p: 150 }, { id: 'm5', g: 'm', n: 'Под ноль', p: 40 }, { id: 'm6', g: 'm', n: 'Пучок', p: 100 },
  { id: 'f0', g: 'f', n: 'Длинные волосы', p: 0 }, { id: 'f1', g: 'f', n: 'Хвост', p: 70 }, { id: 'f2', g: 'f', n: 'Каре', p: 110 }, { id: 'f3', g: 'f', n: 'Пучок', p: 90 },
  { id: 'f4', g: 'f', n: 'Два хвостика', p: 90 }, { id: 'f5', g: 'f', n: 'Пикси', p: 130 }, { id: 'f6', g: 'f', n: 'Коса', p: 120 }, { id: 'f7', g: 'f', n: 'Крупные локоны', p: 200 }
];
const HAIR_BY = {}; HAIR_STYLES.forEach(h => HAIR_BY[h.id] = h);
const HAIR_COLS = [['#16110d', 'Чёрный', 0], ['#3a2415', 'Тёмно-каштановый', 0], ['#5a3825', 'Каштановый', 0], ['#b98b5a', 'Русый', 0], ['#e3c07a', 'Блонд', 40], ['#f0e6c8', 'Платина', 60],
  ['#b5451b', 'Рыжий', 40], ['#c0262d', 'Красный', 70], ['#ff6fb5', 'Розовый', 70], ['#2c6bed', 'Синий', 70], ['#8e44ad', 'Фиолетовый', 70], ['#1fc8c0', 'Бирюзовый', 70], ['#e9e9e9', 'Серебристый', 60]];
const SKINS = [['#fbe0cf', 'Очень светлая'], ['#f1c7a5', 'Светлая'], ['#e0ac86', 'Бежевая'], ['#c68e6b', 'Смуглая'], ['#8d5a3b', 'Тёмная'], ['#5e3a24', 'Очень тёмная']];
const TY_N = { tee: 'Футболка', long: 'Рубашка / свитер', jacket: 'Куртка', hoodie: 'Худи', tank: 'Майка', crop: 'Топ' };
const BT_N = { pants: 'Брюки', shorts: 'Шорты', skirt: 'Юбка' };
const DEF_OF = { m: { top: 'tm0', bot: 'b0', hair: 'm0' }, f: { top: 'tf0', bot: 'bf0', hair: 'f0' } };

function chState() {
  if (!S.wd) S.wd = {};
  if (!S.ch) {
    const lg = TOPS.find(t => t.lg === (S.look || 0));
    S.ch = { g: 'm', top: lg ? lg.id : 'tm0', bot: 'b0', dr: null, sh: 'sh0', hair: 'm0', hc: '#16110d', sk: '#e0ac86' };
    if (lg) S.wd[lg.id] = 1;
  }
  return S.ch;
}
function ownsItem(id) { const it = CAT[id]; return !!it && (it.p === 0 || !!(S.wd && S.wd[id])); }
function fillLook(L, c) {
  const f = c.g === 'f', dr = c.dr && f ? CAT[c.dr] : null;
  const top = CAT[c.top] || CAT.tm0, bot = CAT[c.bot] || CAT.b0, sh = CAT[c.sh] || CAT.sh0;
  L.shirt = hexRGB(dr ? dr.c : top.c); L.pants = hexRGB(bot.c); L.skin = hexRGB(c.sk); L.hair = hexRGB(c.hc);
  L.shoe = hexRGB(sh.c); L.lips = hexRGB(f ? '#c43a62' : c.sk); L.dark = [0.04, 0.04, 0.04];
  const hs = HAIR_BY[c.hair] && HAIR_BY[c.hair].g === c.g ? c.hair : DEF_OF[c.g].hair;
  setLook(L, { f, hs, bt: dr ? 'dress' : bot.bt, ty: dr ? 'tank' : top.ty, sh: sh.sh });
  return L;
}
function setGender(c, g) {
  c.g = g;
  if (g === 'm') c.dr = null;
  const okG = id => { const it = CAT[id]; return it && (it.g === 'u' || it.g === g); };
  if (g === 'f' && c.top === 'tm0') c.top = 'tf0';
  if (g === 'f' && c.bot === 'b0') c.bot = 'bf0';
  if (!okG(c.top)) c.top = DEF_OF[g].top;
  if (!okG(c.bot)) c.bot = DEF_OF[g].bot;
  if (!okG(c.sh)) c.sh = 'sh0';
  if (c.dr && !okG(c.dr)) c.dr = null;
  if (!HAIR_BY[c.hair] || HAIR_BY[c.hair].g !== g) c.hair = DEF_OF[g].hair;
}
function describeLook() {
  const c = chState(), top = CAT[c.top], bot = CAT[c.bot], sh = CAT[c.sh], dr = c.dr ? CAT[c.dr] : null, hs = HAIR_BY[c.hair];
  return 'Сейчас на вас: ' + (dr ? dr.n.toLowerCase() : top.n.toLowerCase() + ' и ' + bot.n.toLowerCase()) + ', ' + sh.n.toLowerCase() + '. Причёска: ' + (hs ? hs.n.toLowerCase() : '—') + '.';
}

/* --- экран --- */
function styleTabs() {
  const f = ST.pv.g === 'f';
  if (ST.mode === 'salon') return [['hair', '✂ Причёска'], ['hc', '🎨 Цвет волос'], ['sk', '🌞 Тон кожи'], ['g', '👤 Образ']];
  const t = [['top', '👕 Верх'], ['bot', '👖 Низ']];
  if (f) t.push(['dr', '👗 Платья']);
  t.push(['sh', '👟 Обувь']);
  if (ST.mode === 'wd') t.push(['g', '👤 Образ']);
  return t;
}
function styleItems() {
  const pv = ST.pv, c = chState(), g = pv.g, tab = ST.tab, wd = ST.mode === 'wd', out = [];
  const gOk = it => it.g === 'u' || it.g === g;
  const fromCat = (arr, field, sub) => arr.filter(gOk).forEach(it => {
    const owned = ownsItem(it.id);
    if (wd && !owned) return;
    out.push({ id: it.id, n: it.n, sub: sub(it), p: it.p, owned, sw: it.c, sel: pv[field] === it.id && (field === 'dr' || !pv.dr || field === 'sh'), worn: c[field] === it.id && (field === 'dr' || !c.dr || field === 'sh') });
  });
  if (tab === 'top') fromCat(TOPS, 'top', it => TY_N[it.ty]);
  else if (tab === 'bot') fromCat(BOTS, 'bot', it => BT_N[it.bt]);
  else if (tab === 'dr') fromCat(DRESSES, 'dr', () => 'Платье');
  else if (tab === 'sh') fromCat(SHOES, 'sh', it => it.sh >= 0.3 ? 'Сапоги' : it.sh >= 0.18 ? 'Ботинки' : 'Обувь');
  else if (tab === 'hair') HAIR_STYLES.filter(h => h.g === g).forEach(h => out.push({ id: h.id, n: h.n, sub: g === 'f' ? 'Женская причёска' : 'Мужская причёска', p: h.p, owned: h.p === 0 || c.hair === h.id, ico: '✂', sw: '#3a3f4b', sel: pv.hair === h.id, worn: c.hair === h.id, svc: true }));
  else if (tab === 'hc') HAIR_COLS.forEach(h => out.push({ id: h[0], n: h[1], sub: 'Окрашивание', p: h[2], owned: h[2] === 0 || c.hc === h[0], sw: h[0], sel: pv.hc === h[0], worn: c.hc === h[0], svc: true }));
  else if (tab === 'sk') SKINS.forEach(h => out.push({ id: h[0], n: h[1], sub: 'Бесплатно', p: 0, owned: true, sw: h[0], sel: pv.sk === h[0], worn: c.sk === h[0] }));
  else if (tab === 'g') [['f', 'Девушка', '👩'], ['m', 'Парень', '👨']].forEach(h => out.push({ id: h[0], n: h[1], sub: 'Сменить модель персонажа. Бесплатно', p: 0, owned: true, ico: h[2], sw: '#3a3f4b', sel: pv.g === h[0], worn: c.g === h[0] }));
  return out;
}
function renderStyle() {
  if (!ST.pv) return;
  const tabs = styleTabs(); if (!tabs.some(t => t[0] === ST.tab)) ST.tab = tabs[0][0];
  $('stTitle').textContent = ST.mode === 'salon' ? '💇 Салон красоты' : ST.mode === 'cloth' ? '👗 Примерочная' : '👔 Гардероб';
  $('stTabs').innerHTML = tabs.map(t => '<button class="chip' + (t[0] === ST.tab ? ' on' : '') + '" data-st="tab:' + t[0] + '">' + t[1] + '</button>').join('');
  const items = styleItems();
  $('stList').innerHTML = items.length ? items.map(it => {
    const btn = it.worn ? '<span class="tag">Надето</span>' :
      '<button class="btn small" data-st="do:' + it.id + '"' + (!it.owned && S.money < it.p ? ' disabled' : '') + '>' + (it.owned ? (ST.mode === 'salon' && it.svc ? 'Сделать' : 'Надеть') : fmtMoney(it.p)) + '</button>';
    return '<div class="card stcard' + (it.sel ? ' sel' : '') + '" data-st="pv:' + it.id + '"><span class="sw" style="background:' + it.sw + '">' + (it.ico || '') + '</span><div class="c-body"><b>' + it.n + '</b><small>' + it.sub + (it.p && !it.owned ? ' · ' + fmtMoney(it.p) : '') + '</small></div><div class="gbtns">' + btn + '</div></div>';
  }).join('') : '<div class="muted" style="padding:12px">Здесь пока ничего нет. Загляните в магазин одежды 👗</div>';
  refreshMoney(false);
}
function openStyle(mode, tab) {
  chState(); ST.open = true; ST.mode = mode; ST.pv = Object.assign({}, S.ch); ST.zoom = 0;
  ST.tab = tab || (mode === 'salon' ? 'hair' : 'top');
  P.h = Math.PI + 0.5; CAM.yaw = 0;
  if (G.int && (G.int.kind === 'cloth' || G.int.kind === 'salon')) { P.x = G.int.x; P.z = G.int.z - 1.0; }
  fillLook(PLAYER_LOOK, ST.pv);
  openScreen('style');
}
function leaveStyle() { ST.open = false; ST.pv = null; ST.zoom = 0; applyLook(); }
function stylePreview(tab, id) {
  const pv = ST.pv;
  if (tab === 'top') { pv.top = id; pv.dr = null; }
  else if (tab === 'bot') { pv.bot = id; pv.dr = null; }
  else if (tab === 'dr') pv.dr = id;
  else if (tab === 'sh') pv.sh = id;
  else if (tab === 'hair') pv.hair = id;
  else if (tab === 'hc') pv.hc = id;
  else if (tab === 'sk') pv.sk = id;
  else if (tab === 'g') setGender(pv, id);
  fillLook(PLAYER_LOOK, pv);
}
function styleDo(id) {
  const c = chState(), tab = ST.tab, it = styleItems().find(x => x.id === id); if (!it) return;
  if (!it.owned) {
    if (S.money < it.p) { SFX.err(); toast('Не хватает денег'); return; }
    S.money -= it.p; if (CAT[id]) S.wd[id] = 1;
  } else if (it.svc && it.p && !it.worn && ST.mode === 'salon') {
    // услуга салона оплачивается каждый раз; бесплатной считается только текущая
  }
  if (tab === 'top') { c.top = id; c.dr = null; } else if (tab === 'bot') { c.bot = id; c.dr = null; } else if (tab === 'dr') c.dr = id;
  else if (tab === 'sh') c.sh = id; else if (tab === 'hair') c.hair = id; else if (tab === 'hc') c.hc = id; else if (tab === 'sk') c.sk = id;
  else if (tab === 'g') setGender(c, id);
  ST.pv = Object.assign({}, c); fillLook(PLAYER_LOOK, ST.pv);
  SFX.buy(); persist(); refreshMoney(true);
  toast(it.p && !it.owned ? '🛍 ' + it.n + ' — куплено' : '✨ ' + it.n);
  renderStyle();
}
function styleClick(str) {
  const i = str.indexOf(':'), cmd = str.slice(0, i), id = str.slice(i + 1);
  if (cmd === 'tab') { SFX.click(); ST.tab = id; renderStyle(); }
  else if (cmd === 'pv') { SFX.click(); stylePreview(ST.tab, id); renderStyle(); }
  else if (cmd === 'do') styleDo(id);
}

/* --- продавцы --- */
Object.assign(NPC, {
  cloth: { ico: '👩', name: 'Алиса', role: 'Консультант магазина одежды',
    greet: ['Добро пожаловать! Новая коллекция уже на вешалках.', 'Здравствуйте! Подберём что-нибудь на вашу фигуру?', 'Привет! У нас есть и классика, и последние тренды.'],
    tips: ['Тёмный верх и светлый низ смотрятся контрастно. Попробуйте!', 'Платья — для особых случаев, а сапоги подходят почти ко всему.', 'Купленное хранится дома в гардеробе: можно переодеваться в любой момент.'] },
  salon: { ico: '💇‍♀️', name: 'Карина', role: 'Стилист салона красоты',
    greet: ['Здравствуйте! Хотите сменить причёску или цвет?', 'Добро пожаловать в салон! Садитесь, подберём вам образ.', 'Привет! Сегодня в моде яркие цвета.'],
    tips: ['Новый цвет волос меняет образ сильнее, чем кажется.', 'Хвост и пучок — для активных, локоны — для вечеринок.', 'Сменить образ с парня на девушку можно прямо у меня, это бесплатно.'] }
});
function clothOptions() {
  return [
    { t: '👗 Примерочная — выбрать одежду', fn: () => openStyle('cloth') },
    { t: '🧾 Что на мне сейчас?', fn: () => say(describeLook()) },
    { t: '💡 Совет стилиста', fn: () => say(pick(NPC.cloth.tips)) },
    byeOpt()
  ];
}
function salonOptions() {
  return [
    { t: '✂ Причёска и цвет волос', fn: () => openStyle('salon', 'hair') },
    { t: '👤 Сменить образ: парень / девушка', fn: () => openStyle('salon', 'g') },
    { t: '💡 Совет стилиста', fn: () => say(pick(NPC.salon.tips)) },
    byeOpt()
  ];
}
/* --- метки в мире --- */
for (const c of CLOTHES) WORLD_MARKS.push({ id: 'cl_' + c.id, x: bc(c.b[0]), z: bc(c.b[1]) - 12, c: [1, 0.5, 0.75], label: '👗 ВОЙТИ В МАГАЗИН ОДЕЖДЫ', short: '👗 ОДЕЖДА', dot: '#ff7eb6', fn: 'enterShop', kind: 'cloth', r: 6, br: 3 });
for (const c of SALONS) WORLD_MARKS.push({ id: 'sl_' + c.id, x: bc(c.b[0]), z: bc(c.b[1]) - 12, c: [0.4, 0.95, 0.9], label: '💇 ВОЙТИ В САЛОН КРАСОТЫ', short: '💇 САЛОН', dot: '#7ee8d8', fn: 'enterShop', kind: 'salon', r: 6, br: 3 });


