/* ===================== v22: жильё в недвижимости, пентхаус на 11 этажей, вертолётная площадка ===================== */
const APT_IDS = ['flat', 'house', 'villa'];
const APT_THEME = {
  flat: { fl: [0.66, 0.64, 0.6], bd: [0.55, 0.53, 0.5], wl: [0.84, 0.87, 0.92], c1: [0.2, 0.36, 0.6, 1], c2: [0.85, 0.85, 0.88, 1] },
  house: { fl: [0.64, 0.47, 0.32], bd: [0.5, 0.35, 0.22], wl: [0.9, 0.83, 0.7], c1: [0.55, 0.16, 0.2, 1], c2: [0.78, 0.65, 0.3, 1] },
  villa: { fl: [0.92, 0.9, 0.86], bd: [0.8, 0.78, 0.74], wl: [0.97, 0.95, 0.9], c1: [0.14, 0.45, 0.5, 1], c2: [0.9, 0.78, 0.4, 1] },
  tower: { fl: [0.3, 0.3, 0.34], bd: [0.22, 0.22, 0.26], wl: [0.78, 0.8, 0.88], c1: [0.2, 0.22, 0.32, 1], c2: [0.62, 0.55, 0.3, 1] }
};
const TOWER_FLOORS = [
  { n: 'Лобби', pal: { fl: [0.78, 0.76, 0.72], wl: [0.9, 0.88, 0.84], ac: [0.95, 0.8, 0.3] }, mk: [{ act: 'concierge', x: 0, z: 2.4, label: '🛎 КОНСЬЕРЖ: подать машину к выходу' }, { fn: 'aptGarage', x: -7.5, z: 3, label: '🚗 СПУСТИТЬСЯ В ГАРАЖ' }] },
  { n: 'Спортзал', pal: { fl: [0.22, 0.24, 0.28], wl: [0.3, 0.32, 0.38], ac: [1, 0.4, 0.2] }, mk: [{ act: 'gym', x: 0, z: 3, label: '🏋 ТРЕНИРОВКА' }] },
  { n: 'Бассейн и спа', pal: { fl: [0.7, 0.85, 0.9], wl: [0.85, 0.93, 0.96], ac: [0.2, 0.7, 1] }, mk: [{ act: 'spa', x: 0, z: 3.4, label: '💆 СПА: восстановить силы' }] },
  { n: 'Кинозал', pal: { fl: [0.2, 0.08, 0.1], wl: [0.18, 0.07, 0.09], ac: [1, 0.2, 0.3] }, mk: [{ act: 'cinema', x: 0, z: 1.5, label: '🎬 СМОТРЕТЬ ФИЛЬМ' }] },
  { n: 'Игровая', pal: { fl: [0.15, 0.12, 0.22], wl: [0.2, 0.15, 0.3], ac: [0.9, 0.3, 1] }, mk: [{ act: 'slots', x: 6.4, z: 2.4, label: '🎰 КАЗИНО — рулетка, блэкджек, автомат' }] },
  { n: 'Библиотека', pal: { fl: [0.42, 0.3, 0.2], wl: [0.38, 0.27, 0.18], ac: [1, 0.85, 0.4] }, mk: [{ act: 'library', x: 0, z: 3.4, label: '📚 ЧИТАТЬ' }] },
  { n: 'Оружейная', pal: { fl: [0.25, 0.26, 0.24], wl: [0.32, 0.33, 0.3], ac: [1, 0.3, 0.2] }, mk: [{ act: 'armory', x: 0, z: 3.4, label: '🔫 ЗАПАСЫ: пополнить патроны' }] },
  { n: 'Гардеробная', pal: { fl: [0.82, 0.78, 0.74], wl: [0.92, 0.88, 0.84], ac: [1, 0.55, 0.8] }, mk: [{ fn: 'wardrobe', x: 0, z: 3.4, label: '👔 ПЕРЕОДЕТЬСЯ' }] },
  { n: 'Бар-лаунж', pal: { fl: [0.12, 0.12, 0.16], wl: [0.14, 0.14, 0.2], ac: [0.2, 1, 0.8] }, mk: [{ act: 'bar', x: 0, z: 3.4, label: '🍸 КОКТЕЙЛЬ — $200 (броня +30)' }] },
  { n: 'Жилой этаж', room: true },
  { n: 'Кабинет', pal: { fl: [0.35, 0.25, 0.18], wl: [0.5, 0.42, 0.34], ac: [1, 0.85, 0.3] }, mk: [{ act: 'rent', x: 0, z: 3.4, label: '💼 КОНТОРА: СОБРАТЬ ДОХОДЫ СО ВСЕГО' }] }
];
function towerPad() {
  const cx = bc(PROP_BY.tower.b[0]), cz = bc(PROP_BY.tower.b[1]), z0 = cz - 4, z1 = cz + 22;
  return { cx, cz, x: cx, z: cz + 9, rect: { x0: cx - 14, x1: cx + 14, z0: z0 + 3, z1: z1 - 3 }, y: 62 + 5 };
}
const APT_X0 = 2400, TW_X0 = 2850, TW_STEP = 150;
INT.apt_flat = { kind: 'apt_flat', x: INX + APT_X0, z: INZ };
INT.apt_house = { kind: 'apt_house', x: INX + APT_X0 + 150, z: INZ };
INT.apt_villa = { kind: 'apt_villa', x: INX + APT_X0 + 300, z: INZ };
const APT_FLOORS = { house: ['apt_house', 'apt_house2'], villa: ['apt_villa', 'apt_villa2', 'apt_villa3'] };
INT.apt_house2 = { kind: 'apt_house2', x: INX + 4550, z: INZ };
INT.apt_villa2 = { kind: 'apt_villa2', x: INX + 4700, z: INZ };
INT.apt_villa3 = { kind: 'apt_villa3', x: INX + 4850, z: INZ };
for (let i = 1; i <= 11; i++) INT['tw' + i] = { kind: 'tw' + i, x: INX + TW_X0 + (i - 1) * TW_STEP, z: INZ };

function mkBG(S1, S2, OX, OZ) {
  const B = (x0, y0, z0, x1, y1, z1, c, coll) => {
    S1.g().box(OX + x0, y0, OZ + z0, OX + x1, y1, OZ + z1, c.length === 3 ? c.concat([1]) : c, false, true);
    if (coll) boxes.push({ x0: OX + x0, x1: OX + x1, z0: OZ + z0, z1: OZ + z1, h: y1 });
  };
  const GL = (x0, y0, z0, x1, y1, z1, c) => S2.g().box(OX + x0, y0, OZ + z0, OX + x1, y1, OZ + z1, c.concat([1]), false, true);
  return [B, GL];
}
function towerDeco(fi, B, GL, ac) {
  const dark = [0.12, 0.12, 0.14], wood = [0.45, 0.28, 0.14];
  switch (fi) {
    case 1:   // лобби: стойка, диваны, пальмы
      B(-3.4, 0, 3.2, 3.4, 1.1, 4.4, [0.28, 0.2, 0.14], true); B(-3.6, 1.1, 3.1, 3.6, 1.2, 4.5, [0.9, 0.85, 0.75]);
      B(-9.4, 0, -2.6, -6.2, 0.5, 1.4, [0.35, 0.3, 0.28], true); B(6.2, 0, -2.6, 9.4, 0.5, 1.4, [0.35, 0.3, 0.28], true);
      B(-9.4, 0.5, -2.6, -9.0, 1.2, 1.4, [0.3, 0.25, 0.23]); B(9.0, 0.5, -2.6, 9.4, 1.2, 1.4, [0.3, 0.25, 0.23]);
      B(-9.2, 0, 5.8, -8.4, 0.7, 6.6, [0.62, 0.32, 0.22], true); B(8.4, 0, 5.8, 9.2, 0.7, 6.6, [0.62, 0.32, 0.22], true);
      break;
    case 2:   // спортзал: беговые дорожки, штанга
      for (let k = 0; k < 3; k++) { B(-8.6 + k * 2.4, 0, -2.6, -7.2 + k * 2.4, 0.4, 0.8, [0.1, 0.1, 0.12], true); B(-8.6 + k * 2.4, 0.4, 0.2, -7.2 + k * 2.4, 1.5, 0.5, [0.3, 0.3, 0.34]); }
      B(2.2, 0, -2.6, 9, 0.35, 1.2, [0.12, 0.12, 0.14]); B(3.0, 0.35, -0.3, 8.2, 0.55, 0.3, [0.5, 0.5, 0.55]); B(2.8, 0.2, -0.5, 3.3, 1.0, 0.5, [0.15, 0.15, 0.17]); B(7.9, 0.2, -0.5, 8.4, 1.0, 0.5, [0.15, 0.15, 0.17]);
      B(-9.6, 0, 5.4, -4.4, 1.0, 7.8, [0.2, 0.2, 0.24], true);
      break;
    case 3:   // бассейн
      B(-7.8, -0.15, -2.4, 7.8, 0.12, 2.8, [0.9, 0.9, 0.92]); GL(-7.2, 0.1, -1.9, 7.2, 0.13, 2.3, [0.2, 0.65, 0.95]);
      B(-9.4, 0, 4.6, -6.6, 0.45, 6.4, [0.95, 0.95, 0.9], true); B(6.6, 0, 4.6, 9.4, 0.45, 6.4, [0.95, 0.95, 0.9], true);
      B(-3.4, 0, 6.6, 3.4, 0.9, 7.8, [0.8, 0.84, 0.86], true);
      break;
    case 4:   // кинозал: экран и кресла
      GL(-6, 0.9, 7.5, 6, 3.0, 7.58, [0.55, 0.65, 0.95]); B(-6.3, 0.8, 7.7, 6.3, 3.2, 7.95, [0.04, 0.04, 0.05]);
      for (let r = 0; r < 3; r++) for (let k = -3; k <= 3; k++) B(k * 1.5 - 0.5, r * 0.25, 0.4 - r * 1.8, k * 1.5 + 0.5, 0.65 + r * 0.25, 1.0 - r * 1.8, [0.7, 0.12, 0.18], r === 0 && false);
      break;
    case 5:   // игровая: автоматы и бильярд
      for (let k = 0; k < 4; k++) { B(5.2 + k * 1.15, 0, 3.2, 6.1 + k * 1.15, 2.0, 4.1, [0.12, 0.12, 0.2], true); GL(5.35 + k * 1.15, 1.2, 3.12, 5.95 + k * 1.15, 1.8, 3.2, [0.9, 0.3, 1]); }
      B(-7, 0, -3, -2.6, 0.85, -0.6, [0.12, 0.4, 0.2], true); B(-7.3, 0.85, -3.3, -2.3, 1.0, -0.3, [0.35, 0.22, 0.12]);
      B(-9.6, 0, 4.8, -7.2, 0.6, 6.4, [0.6, 0.2, 0.3], true);
      break;
    case 6:   // библиотека: стеллажи и стол
      for (let k = 0; k < 6; k++) { B(-9.6 + k * 3.2, 0, 7.2, -7.2 + k * 3.2, 3.0, 7.9, [0.4, 0.26, 0.14], true); for (let s = 0; s < 4; s++) B(-9.5 + k * 3.2, 0.5 + s * 0.65, 7.1, -7.3 + k * 3.2, 0.9 + s * 0.65, 7.2, [0.2 + (k + s) % 3 * 0.25, 0.3, 0.5 + s * 0.1]); }
      B(-3, 0, 1.0, 3, 0.8, 2.8, [0.35, 0.22, 0.12], true); B(-1, 0.8, 1.3, 1, 0.9, 2.3, [0.9, 0.9, 0.82]);
      break;
    case 7:   // оружейная: стойки
      for (let k = 0; k < 4; k++) { B(-9.2 + k * 2.6, 0, 7.0, -7.2 + k * 2.6, 2.4, 7.9, [0.2, 0.2, 0.22], true); for (let s = 0; s < 3; s++) B(-9.0 + k * 2.6, 0.8 + s * 0.5, 6.9, -7.4 + k * 2.6, 0.95 + s * 0.5, 7.0, [0.08, 0.08, 0.1]); }
      B(3, 0, -2.4, 8.4, 0.9, 0.2, [0.28, 0.3, 0.26], true); B(3.4, 0.9, -2.0, 4.6, 1.2, -0.8, [0.4, 0.45, 0.3]);
      break;
    case 8:   // гардеробная: вешалки и зеркало
      for (let k = 0; k < 4; k++) { B(-9.6, 0, -3.5 + k * 2.6, -8.2, 2.4, -1.6 + k * 2.6, [0.5, 0.32, 0.2], true); B(9.2, 0, -3.5 + k * 2.6, 9.6, 2.4, -1.6 + k * 2.6, [0.5, 0.32, 0.2]); }
      GL(-1.6, 0.6, 7.93, 1.6, 2.8, 7.98, [0.85, 0.92, 1]); B(-0.9, 0, 3.4, 0.9, 0.5, 4.8, [0.8, 0.4, 0.55], true);
      break;
    case 9:   // бар
      B(-6.2, 0, 3.6, 6.2, 1.1, 5.0, [0.12, 0.12, 0.16], true); B(-6.4, 1.1, 3.5, 6.4, 1.2, 5.1, [0.6, 0.45, 0.25]);
      for (let k = -4; k <= 4; k += 2) B(k - 0.35, 0, 2.2, k + 0.35, 0.75, 2.9, [0.7, 0.2, 0.2]);
      B(-7, 1.4, 7.6, 7, 1.55, 7.9, [0.4, 0.28, 0.16]); for (let k = 0; k < 9; k++) B(-6.4 + k * 1.6, 1.55, 7.65, -6.0 + k * 1.6, 2.1 + (k % 3) * 0.12, 7.85, [0.2, 0.7 - k % 3 * 0.15, 0.4 + k % 2 * 0.3]);
      GL(-6.8, 2.6, 7.93, 6.8, 2.8, 7.98, [0.2, 1, 0.8]);
      break;
    case 11:  // кабинет: стол, карта, сейф
      B(-3.4, 0, 2.6, 3.4, 0.85, 4.4, [0.3, 0.2, 0.12], true); B(-0.8, 0.85, 3.2, 0.8, 1.0, 3.9, [0.1, 0.1, 0.12]); B(-0.9, 0, 5.0, 0.9, 1.0, 6.0, [0.12, 0.12, 0.14]);
      B(-9.4, 0, -2.4, -4.6, 0.9, 1.6, [0.35, 0.28, 0.2], true); GL(-9.0, 0.92, -2.0, -5.0, 0.95, 1.2, [0.3, 0.7, 0.4]);
      B(6.6, 0, 5.4, 9.4, 2.0, 7.8, [0.25, 0.26, 0.3], true); B(7.3, 0.6, 5.3, 8.7, 1.4, 5.4, [0.55, 0.55, 0.6]);
      break;
  }
}
function buildTowerFloor(fi, OX, OZ) {
  const T = TOWER_FLOORS[fi - 1];
  if (T.room) return buildAptRoom(OX, OZ, APT_THEME.tower);
  const S1 = new GeoSet(), S2 = new GeoSet(), bg = mkBG(S1, S2, OX, OZ), B = bg[0], GL = bg[1], pal = T.pal;
  B(-70, -0.4, -70, 70, -0.05, 70, [0.04, 0.04, 0.06]);
  B(-10, -0.2, -8, 10, 0, 8, pal.fl);
  const st = [pal.fl[0] * 0.82, pal.fl[1] * 0.82, pal.fl[2] * 0.82];
  for (let i = -9; i <= 9; i += 2) B(i - 0.03, 0, -8, i + 0.03, 0.005, 8, st);
  B(-10.6, -0.2, 8, 10.6, 3.4, 8.6, pal.wl, true); B(-10.6, -0.2, -8.6, 10.6, 3.4, -8, pal.wl, true);
  B(-10.6, -0.2, -8, -10, 3.4, 8, pal.wl, true); B(10, -0.2, -8, 10.6, 3.4, 8, pal.wl, true);
  /* панорамные окна: город ночью */
  if (fi !== 4 && fi !== 6 && fi !== 7) { GL(-9.97, 1.2, -4.0, -9.92, 2.9, 3.6, [0.35, 0.5, 0.8]); GL(9.92, 1.2, -4.0, 9.97, 2.9, 3.6, [0.35, 0.5, 0.8]); }
  if (fi === 1 || fi === 3 || fi === 5 || fi === 9) GL(-8, 1.2, 7.93, 8, 2.9, 7.98, [0.35, 0.5, 0.8]);
  /* лифты у входной стены */
  B(-3.4, 0, -8.0, -0.4, 3.0, -7.9, [0.7, 0.72, 0.78]); B(0.4, 0, -8.0, 3.4, 3.0, -7.9, [0.7, 0.72, 0.78]);
  GL(-3.2, 2.9, -7.92, -0.6, 3.1, -7.86, pal.ac); GL(0.6, 2.9, -7.92, 3.2, 3.1, -7.86, pal.ac);
  GL(-10.1, 3.2, -8, 10.1, 3.35, -7.95, pal.ac);
  towerDeco(fi, B, GL, pal.ac);
  return { lit: S1.done(), glow: S2.done() };
}
function buildPropInteriors() {
  const out = {};
  const tint = (t, k) => Object.assign({}, t, { wl: t.wl.map((v, i) => Math.min(1, v * [0.94, 0.97, 1.0][k % 3] * (i === k % 3 ? 1.04 : 1))), c1: t.c1.map((v, i) => i === 3 ? 1 : Math.min(1, v * (0.7 + 0.2 * k))) });
  for (const id of APT_IDS) {
    const fl = APT_FLOORS[id] || [];
    out['apt_' + id] = buildAptRoom(INT['apt_' + id].x, INT['apt_' + id].z, APT_THEME[id], { fl: 1, n: fl.length || 1 });
    for (let k = 1; k < fl.length; k++) out[fl[k]] = buildAptRoom(INT[fl[k]].x, INT[fl[k]].z, tint(APT_THEME[id], k), { fl: k + 1, n: fl.length });
  }
  for (let i = 1; i <= 11; i++) out['tw' + i] = buildTowerFloor(i, INT['tw' + i].x, INT['tw' + i].z);
  return out;
}

/* --- метки внутри --- */
function aptMarks(kind, withDoor) {
  const o = INT[kind], X = o.x, Z = o.z;
  WORLD_MARKS.push({ id: 'bed_' + kind, int: true, x: X - 7.2, z: Z + 2.9, r: 2.8, label: '🛏 ЛЕЧЬ СПАТЬ', fn: 'aptSleep' });
  WORLD_MARKS.push({ id: 'tv_' + kind, int: true, x: X, z: Z + 6.1, r: 2.2, label: '📺 СМОТРЕТЬ ТВ', fn: 'watchTV' });
  WORLD_MARKS.push({ id: 'ward_' + kind, int: true, x: X + 7.5, z: Z + 5.4, r: 2.6, label: '👔 ГАРДЕРОБ', fn: 'wardrobe' });
  if (withDoor) {
    WORLD_MARKS.push({ id: 'door_' + kind, int: true, x: X, z: Z - 6.3, r: 2.6, label: '🚪 ВЫЙТИ НА УЛИЦУ', fn: 'leaveShop' });
    WORLD_MARKS.push({ id: 'gar_' + kind, int: true, x: X + 8.2, z: Z + 0.6, r: 2.4, label: '🚗 СПУСТИТЬСЯ В ГАРАЖ', fn: 'aptGarage' });
  }
}
for (const id of APT_IDS) aptMarks('apt_' + id, true);
for (const id in APT_FLOORS) {
  const fl = APT_FLOORS[id];
  for (let k = 0; k < fl.length; k++) {
    const kind = fl[k], o = INT[kind];
    if (k > 0) aptMarks(kind, false);
    if (k < fl.length - 1) WORLD_MARKS.push({ id: 'stu_' + kind, int: true, x: o.x - 5.2, z: o.z - 5.0, r: 2.0, to: fl[k + 1], fn: 'aptStairs', label: '🪜 ПОДНЯТЬСЯ НА ' + (k + 2) + '-й ЭТАЖ' });
    if (k > 0) WORLD_MARKS.push({ id: 'std_' + kind, int: true, x: o.x, z: o.z - 5.0, r: 2.0, to: fl[k - 1], down: true, fn: 'aptStairs', label: '🪜 СПУСТИТЬСЯ НА ' + k + '-й ЭТАЖ' });
  }
}
for (let i = 1; i <= 11; i++) {
  const k = 'tw' + i, o = INT[k], T = TOWER_FLOORS[i - 1];
  const nm = j => 'этаж ' + j + ' · ' + TOWER_FLOORS[j - 1].n;
  if (T.room) aptMarks(k, false);
  WORLD_MARKS.push({ id: 'up_' + k, int: true, x: o.x + 1.9, z: o.z - 6.5, r: 1.6, f: i, dir: 1, fn: 'twLift', label: i === 11 ? '⬆ ЛИФТ: НА КРЫШУ (вертолётная площадка)' : '⬆ ЛИФТ: ' + nm(i + 1) });
  WORLD_MARKS.push({ id: 'dn_' + k, int: true, x: o.x - 1.9, z: o.z - 6.5, r: 1.6, f: i, dir: -1, fn: i === 1 ? 'leaveShop' : 'twLift', label: i === 1 ? '🚪 ВЫЙТИ НА УЛИЦУ' : '⬇ ЛИФТ: ' + nm(i - 1) });
  for (const m of (T.mk || [])) WORLD_MARKS.push({ id: 'mk_' + k + '_' + (m.act || m.fn), int: true, x: o.x + m.x, z: o.z + m.z, r: 2.4, fn: m.fn || 'twAct', act: m.act, label: m.label });
}
(function roofMarks() {
  const pd = towerPad(), r = pd.rect;
  WORLD_MARKS.push({ id: 'roof_lift', int: true, roofY: pd.y, x: r.x0 + 3, z: pd.z, r: 2.8, fn: 'roofToFloor', label: '🛗 ЛИФТ В ПЕНТХАУС' });
  WORLD_MARKS.push({ id: 'roof_heli', int: true, roofY: pd.y, x: r.x1 - 3, z: pd.z, r: 2.8, fn: 'heliCall', label: '🚁 ВЫЗВАТЬ ВЕРТОЛЁТ НА ПЛОЩАДКУ' });
})();

/* --- действия --- */
function aptBack(kind) { return G.int && G.int.ret ? G.int.ret : { x: 40, z: 16.5, h: Math.PI }; }
HOME_FN.enterApt = function (m) {
  if (G.inHome) return;
  if (!propOwn(m.kind)) { toast('Сначала купите этот объект'); SFX.err(); return; }
  const kind = m.kind === 'tower' ? 'tw1' : 'apt_' + m.kind;
  fadeThen(() => {
    if (P.car) exitCar(true);
    const o = INT[kind];
    setHomeState(true, kind, { x: m.x, z: m.z - 2, h: Math.PI });
    P.x = o.x; P.z = o.z - 4.6; P.y = 0; P.h = 0; P.speed = 0; P.vis = true;
    CAM.yaw = 0; CAM.pitch = 0.82; CAM.off = 0;
    toast(m.kind === 'tower' ? '🌆 Пентхаус «Небо»: лобби. Лифт — у входной стены' : '🏠 Вы дома: ' + PROP_BY[m.kind].nm);
  });
};
HOME_FN.aptStairs = function (m) {
  if (!G.inHome || !G.int) return;
  const ret = G.int.ret;
  fadeThen(() => {
    const o = INT[m.to];
    setHomeState(true, m.to, ret);
    P.x = m.down ? o.x - 5.2 : o.x; P.z = o.z - 2.6; P.y = 0; P.h = 0; P.speed = 0; P.vis = true;
    CAM.yaw = 0; CAM.pitch = 0.82; CAM.off = 0;
    const id = m.to.replace('apt_', '').replace(/\d$/, ''), n = (APT_FLOORS[id] || []).indexOf(m.to) + 1;
    toast('🪜 ' + n + '-й этаж: ' + PROP_BY[id].nm);
  });
};
HOME_FN.aptSleep = function () {
  const ret = G.int && G.int.ret;
  fadeThen(() => {
    dayT = DAY_LEN * 0.05;
    if (ret) S.pos = { x: ret.x, z: ret.z }; persist();
    P.hp = 100;
    toast('😴 Вы выспались. Наступило утро. Игра сохранена.');
  });
};
HOME_FN.aptGarage = function () {
  if (!G.inHome || !G.int) return;
  const ret = G.int.ret;
  fadeThen(() => {
    const o = INT.garage;
    setHomeState(true, 'garage', ret);
    P.x = o.x; P.z = o.z - 4.6; P.y = 0; P.h = 0; P.speed = 0; P.vis = true;
    CAM.yaw = 0; CAM.pitch = 0.82; CAM.off = 0;
    refreshGarageMarks();
    toast('🅿 Гараж: ' + carCount() + ' из ' + garageCap() + ' мест. Подойдите к машине и нажмите E');
  });
};
HOME_FN.twLift = function (m) {
  if (!G.inHome || !G.int) return;
  const to = m.f + m.dir, ret = G.int.ret, call = G.int.callCar;
  if (to > 11) { HOME_FN.twRoof(); return; }
  fadeThen(() => {
    const o = INT['tw' + to];
    setHomeState(true, 'tw' + to, ret); if (call) G.int.callCar = true;
    P.x = o.x; P.z = o.z - 4.6; P.y = 0; P.h = 0; P.speed = 0; P.vis = true;
    CAM.yaw = 0; CAM.pitch = 0.82; CAM.off = 0;
    const fl = S.flags.twf && typeof S.flags.twf === 'object' ? S.flags.twf : (S.flags.twf = {});
    fl[to] = 1; fl[m.f] = 1;
    toast('🛗 Этаж ' + to + ': ' + TOWER_FLOORS[to - 1].n);
  });
};
HOME_FN.twRoof = function () {
  fadeThen(() => {
    const pd = towerPad(), r = pd.rect;
    setHomeState(false);
    P.x = r.x0 + 6; P.z = pd.z; P.y = pd.y; P.h = Math.PI / 2; P.speed = 0; P.vis = true;
    P.roof = { y: pd.y, base: pd.y, rect: r, cx: 1e6, cz: 1e6, b: -1 };
    CAM.yaw = Math.PI / 2; CAM.pitch = 0.3; CAM.off = 0;
    toast('🚁 Крыша пентхауса — вертолётная площадка. F — лифт вниз');
  });
};
HOME_FN.roofToFloor = function () {
  if (G.inHome) return;
  fadeThen(() => {
    const pd = towerPad(), o = INT.tw11;
    setHomeState(true, 'tw11', { x: pd.cx, z: pd.cz - 4 - 6, h: Math.PI });
    P.roof = null; P.x = o.x; P.z = o.z - 4.6; P.y = 0; P.h = 0; P.speed = 0; P.vis = true;
    CAM.yaw = 0; CAM.pitch = 0.82; CAM.off = 0;
    toast('🛗 Этаж 11: Кабинет');
  });
};
HOME_FN.heliCall = function () {
  if (!S.cars.heli) { toast('🚁 У вас нет вертолёта — его можно купить в автосалоне'); SFX.err(); return; }
  const pd = towerPad();
  if (S.sel !== 'heli') selectCar('heli');
  if (!OWN) spawnOwn(pd.x, pd.z, 0);
  OWN.x = pd.x + 0.01; OWN.z = pd.z; OWN.h = 0; OWN.vx = OWN.vz = OWN.vf = OWN.vl = 0; OWN.alt = pd.y; OWN.y = pd.y;
  SFX.click(); toast('🚁 Вертолёт подан на площадку. F — сесть');
};
HOME_FN.twAct = function (m) {
  const act = m.act;
  if (act === 'concierge') { if (G.int) G.int.callCar = true; toast('🛎 Консьерж: ваша машина будет подана к выходу'); return; }
  if (act === 'gym') {
    if (G.time - (V22.gymT || -99) < 20) { toast('🏋 Отдохните минуту — мышцы гудят'); return; }
    V22.gymT = G.time; S.flags.gym = (S.flags.gym || 0) + 1; P.hp = 100; SFX.buy();
    if (S.flags.gym >= 5 && !S.vit) { S.vit = 1; toast('💪 Закалка! Здоровье теперь восстанавливается быстрее'); } else toast('🏋 Тренировка №' + S.flags.gym + ' окончена (закалка после 5)');
    persist(); return;
  }
  if (act === 'spa') { P.hp = 100; HITFX.flash = 0; SFX.buy(); toast('💆 Вы полностью восстановили силы'); return; }
  if (act === 'cinema') { fadeThen(() => { dayT = (dayT + DAY_LEN * 0.04) % DAY_LEN; toast('🎬 ' + pick(['Фильм про гонщика-легенду: зал аплодирует.', 'Боевик: ваша машина снималась бы лучше.', 'Комедия: два часа смеха пролетели незаметно.', 'Триллер про банду и город — жутко похоже на правду.'])); }); return; }
  if (act === 'slots') { openScreen('casino'); return; }
  if (act === 'library') {
    const ch = S.story.ch;
    toast('📚 ' + (ch < STORY.length ? 'Сюжет: «' + STORY[ch].t + '»' : epiIdx() < STORY2.length ? 'Цель эпилога: ' + STORY2[epiIdx()].goal + ' (' + STORY2[epiIdx()].prog() + ')' : 'Все главы пройдены. Вы — хозяин города.'));
    return;
  }
  if (act === 'armory') {
    const left = ((S.flags.armT || 0) + 10 * 60 * 1000 - Date.now()) / 1000;
    if (left > 0) { toast('🔫 Склад пуст. Новые запасы через ' + Math.ceil(left) + ' с'); SFX.err(); return; }
    let n = 0; for (const w of WEAPONS) if (!w.melee && S.guns.own[w.id]) { S.guns.ammo[w.id] = (S.guns.ammo[w.id] || 0) + w.ammoPack; n++; }
    if (!n) { toast('🔫 У вас нет огнестрельного оружия'); return; }
    S.flags.armT = Date.now(); persist(); SFX.buy(); toast('🔫 Патроны пополнены для оружия: ' + n); return;
  }
  if (act === 'bar') {
    if (S.money < 200) { toast('Нужно $200'); SFX.err(); return; }
    S.money -= 200; S.armor = Math.min(100, (S.armor || 0) + 30); refreshMoney(false); SFX.buy(); toast('🍸 Коктейль «Небо»: броня ' + Math.round(S.armor)); return;
  }
  if (act === 'rent') {
    openTalk('office'); say(officeGreet()); return;
  }
};
const V22 = { gymT: -99 };
function v22Tick() { }

