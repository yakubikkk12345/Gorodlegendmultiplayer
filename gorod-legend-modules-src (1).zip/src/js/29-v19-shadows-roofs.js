/* ===================== v19: тени зданий, мокрая дорога, крыши, стрельба из машины ===================== */

/* --- крыши: высота поверхности под точкой (0 — земля) --- */
function inRect(b, x, z, ins) { return x > b.x0 + ins && x < b.x1 - ins && z > b.z0 + ins && z < b.z1 - ins; }
function roofInfo(x, z, ins) {
  let best = null;
  for (let k = 0; k < boxes.length; k++) {
    const b = boxes[k];
    if (b.h < 6 || b.x0 > 1000) continue;
    if (x < b.x0 || x > b.x1 || z < b.z0 || z > b.z1) continue;
    if ((b.x1 - b.x0) * (b.z1 - b.z0) < 120) continue;
    let y, rc;
    if (b.up) { if (inRect(b.up, x, z, ins)) { y = b.up.h; rc = b.up; } else if (inRect(b, x, z, ins)) { y = b.hl; rc = b; } else continue; }
    else if (inRect(b, x, z, ins)) { y = b.h; rc = b; } else continue;
    const cx = (b.x0 + b.x1) / 2, cz = (b.z0 + b.z1) / 2, base = y;
    if (!b.nt && Math.abs(x - cx) < 2.3 && Math.abs(z - cz) < 2.3) y += 1.8;   // техническая надстройка
    if (!best || y > best.y) best = { y, base, b: k, rect: rc, cx, cz };
  }
  return best;
}
const roofY = (x, z, ins) => { const r = roofInfo(x, z, ins === undefined ? 0.6 : ins); return r ? r.y : 0; };

/* спуск с крыши «на лифте» */
function roofDown() {
  const r = P.roof; if (!r) return;
  SFX.door();
  fadeThen(() => {
    const b = r.rect, dl = P.x - b.x0, dr = b.x1 - P.x, dt = P.z - b.z0, db = b.z1 - P.z, m = Math.min(dl, dr, dt, db);
    const p = { x: P.x, z: P.z };
    if (m === dl) p.x = b.x0 - 3.6; else if (m === dr) p.x = b.x1 + 3.6; else if (m === dt) p.z = b.z0 - 3.6; else p.z = b.z1 + 3.6;
    for (let k = 0; k < 3; k++) pushCircle(p, 0.6);
    P.x = p.x; P.z = p.z; P.roof = null; P.y = terrainY(P.x, P.z);
    toast('🛗 Вы спустились на улицу');
  });
}

/* ходьба по крыше */
function roofWalk() {
  const r = P.roof, b = r.rect;
  P.x = clamp(P.x, b.x0 + 0.7, b.x1 - 0.7); P.z = clamp(P.z, b.z0 + 0.7, b.z1 - 0.7);
  const cx = r.cx, cz = r.cz, hx = 2.7, hz = 2.7;     // надстройка
  if (Math.abs(P.x - cx) < hx && Math.abs(P.z - cz) < hz) {
    const dx = hx - Math.abs(P.x - cx), dz = hz - Math.abs(P.z - cz);
    if (dx < dz) P.x = cx + Math.sign(P.x - cx || 1) * hx; else P.z = cz + Math.sign(P.z - cz || 1) * hz;
  }
}

/* --- тени зданий (динамические, по положению солнца) --- */
const SHD = { vb: null, ib: null, vf: new Float32Array(4200 * 12), xf: new Uint16Array(4200 * 3), a: 0 };
function hull(pts) {
  pts.sort((p, q) => p[0] - q[0] || p[1] - q[1]);
  const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lo = [], up = [];
  for (const p of pts) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); }
  for (let k = pts.length - 1; k >= 0; k--) { const p = pts[k]; while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], p) <= 0) up.pop(); up.push(p); }
  lo.pop(); up.pop(); return lo.concat(up);
}
function shadowAlpha() {
  const sh = ENV.sunVis[1];
  return clamp(sh * 3.2, 0, 1) * 0.46 * (1 - 0.85 * WX.rain) * (1 - 0.5 * WX.fog);
}
function drawBuildingShadows() {
  if (G.inHome || G.mode !== 'play' && G.mode !== 'menu') return;
  const a = shadowAlpha(); if (a < 0.03) return;
  if (!SHD.vb) { SHD.vb = gl.createBuffer(); SHD.ib = gl.createBuffer(); }
  const sv = ENV.sunVis, hz = Math.hypot(sv[0], sv[2]) || 1, k = Math.min(hz / Math.max(sv[1], 0.1), 4.2);
  const ux = -sv[0] / hz, uz = -sv[2] / hz;
  let nv = 0, ni = 0;
  const R = 190;
  for (let n = 0; n < boxes.length; n++) {
    const b = boxes[n];
    if (b.h < 6 || b.x0 > 1000) continue;
    if (b.x1 < CAM.x - R || b.x0 > CAM.x + R || b.z1 < CAM.z - R || b.z0 > CAM.z + R) continue;
    if ((b.x1 - b.x0) * (b.z1 - b.z0) < 120) continue;
    if (nv + 10 > 4200) break;
    const L = Math.min(b.h * k, 110), ox = ux * L, oz = uz * L;
    const pts = [[b.x0, b.z0], [b.x1, b.z0], [b.x1, b.z1], [b.x0, b.z1], [b.x0 + ox, b.z0 + oz], [b.x1 + ox, b.z0 + oz], [b.x1 + ox, b.z1 + oz], [b.x0 + ox, b.z1 + oz]];
    const hp = hull(pts), base = nv;
    for (const p of hp) {
      const o = nv * 12; nv++;
      SHD.vf[o] = p[0]; SHD.vf[o + 1] = 0.2; SHD.vf[o + 2] = p[1];
      SHD.vf[o + 3] = 0; SHD.vf[o + 4] = 1; SHD.vf[o + 5] = 0;
      SHD.vf[o + 6] = 0.02; SHD.vf[o + 7] = 0.02; SHD.vf[o + 8] = 0.06; SHD.vf[o + 9] = 1; SHD.vf[o + 10] = 0; SHD.vf[o + 11] = 0;
    }
    for (let j = 1; j < hp.length - 1; j++) { SHD.xf[ni++] = base; SHD.xf[ni++] = base + j; SHD.xf[ni++] = base + j + 1; }
  }
  if (!ni) return;
  gl.bindBuffer(gl.ARRAY_BUFFER, SHD.vb); gl.bufferData(gl.ARRAY_BUFFER, SHD.vf.subarray(0, nv * 12), gl.DYNAMIC_DRAW);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, SHD.ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, SHD.xf.subarray(0, ni), gl.DYNAMIC_DRAW);
  gl.enable(gl.STENCIL_TEST); gl.stencilMask(0xff); gl.stencilFunc(gl.EQUAL, 0, 0xff); gl.stencilOp(gl.KEEP, gl.KEEP, gl.INCR);
  drawMesh({ vb: SHD.vb, ib: SHD.ib, n: ni }, IDENT, 1, 1, 1, a, 1, false);
  gl.disable(gl.STENCIL_TEST);
}

/* --- мокрая дорога: планарное отражение --- */
const WET = { v: 0, VPM: newM(), S: newM() };
function wetTick(dt) {
  const raining = WX.rain > 0.25 && !WINTER.on;
  WET.v += raining ? dt / 7 : -dt / 110;
  WET.v = clamp(WET.v, 0, 1);
}
function reflOn() {
  return WET.v > 0.08 && !G.inHome && S.set.quality !== 'low' && !!(CITY && CITY.roads);
}
function drawReflection() {
  const wet = WET.v;
  mTRS(WET.S, 0, 0, 0, 0, 0, 0, 1, -1, 1); mMul(WET.VPM, VP, WET.S);
  // 1) разметка стенсила по асфальту
  gl.enable(gl.STENCIL_TEST); gl.stencilMask(0xff); gl.clear(gl.STENCIL_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.stencilFunc(gl.ALWAYS, 1, 0xff); gl.stencilOp(gl.KEEP, gl.KEEP, gl.REPLACE);
  gl.colorMask(false, false, false, false); gl.depthMask(false);
  for (const m of CITY.roads) drawMesh(m, IDENT, 1, 1, 1, 1, 0, false);
  gl.colorMask(true, true, true, true); gl.depthMask(true);
  // 2) зеркальная сцена только там, где асфальт
  gl.stencilFunc(gl.EQUAL, 1, 0xff); gl.stencilOp(gl.KEEP, gl.KEEP, gl.KEEP); gl.stencilMask(0);
  gl.uniformMatrix4fv(U.uVP, false, WET.VPM);
  curBlend = ''; setPass('opaque');
  const far = Math.min(ENV.fogFar + 40, 260), tk = 0.7;
  for (const r of CITY.world) {
    if (!r.always) {
      const dx = Math.max(r.x0 - CAM.x, 0, CAM.x - r.x1), dz = Math.max(r.z0 - CAM.z, 0, CAM.z - r.z1);
      if (dx * dx + dz * dz > far * far) continue;
    }
    for (const m of r.meshes) drawMesh(m, IDENT, tk, tk, tk, 1, 0, true);
  }
  const lk = 0.55 + ENV.night * 0.75;
  for (const m of CITY.lamps) drawMesh(m, IDENT, lk, lk * 0.92, lk * 0.6, 1, 1, false);
  for (const c of cars) {
    if (c.def.heli && (c.alt || 0) > 3) continue;
    const d = visible(c.x, c.z, 6, 150); if (!d) continue;
    drawCar(c, d);
  }
  drawSignals();
  curBlend = ''; setPass('opaque');
  if (ENV.night > 0.06) {
    setPass('add');
    for (const m of CITY.lglow) drawMesh(m, IDENT, 1, 0.86, 0.55, ENV.night * 0.5, 2, false);
    setPass('opaque');
  }
  // 3) вернуть нормальную камеру
  gl.stencilMask(0xff); gl.disable(gl.STENCIL_TEST); gl.clear(gl.STENCIL_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.uniformMatrix4fv(U.uVP, false, VP);
  curBlend = ''; setPass('opaque');
}
function drawRoads() {
  if (!CITY.roads) return;
  if (!reflOn()) { const rt = WINTER.on ? 1.9 : 1; for (const m of CITY.roads) drawMesh(m, IDENT, rt, rt, rt * 1.03, 1, 0, false); return; }
  gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
  const al = 1 - 0.3 * WET.v, dk = 1 - 0.12 * WET.v;
  for (const m of CITY.roads) drawMesh(m, IDENT, dk, dk, dk, al, 0, false);
  gl.disable(gl.BLEND);
}

/* --- тик v19 --- */
const V19 = { carT: 0, hint: 0 };
function v19Tick(dt) {
  wetTick(dt);
  const play = G.mode === 'play' && !G.paused && !G.inHome;
  // игрок на крыше
  if (P.roof) {
    if (P.car || G.inHome || !inRect(P.roof.rect, P.x, P.z, -1.5)) P.roof = null;
  }
  const c = P.car;
  // подсказка про стрельбу из машины
  if (c && play && !S.flags.hDriveBy) {
    V19.carT += dt;
    if (V19.carT > 5 && !c.def.heli) { S.flags.hDriveBy = 1; toast('🔫 Стрельба из машины: клавиша G' + (UI.touchMode ? ' (красная кнопка слева)' : '') + ' — авто-наводка на врагов и полицию'); }
  } else if (!c) V19.carT = 0;
  // посадка вертолёта на крышу
  if (c && c.def.heli && play) {
    const ri = roofInfo(c.x, c.z, 0.6);
    if (ri && c.alt - ri.y < 0.8 && Math.abs(c.vf) < 2) {
      if (typeof S.flags.roofs !== 'object' || !S.flags.roofs) S.flags.roofs = {};
      if (!S.flags.roofs[ri.b]) { S.flags.roofs[ri.b] = 1; const n = Object.keys(S.flags.roofs).length; toast('🏢 Посадка на крышу! Крыш освоено: ' + n + (n === 1 ? ' · F — выйти' : '')); SFX.buy(); persist(); }
    }
  }
}

