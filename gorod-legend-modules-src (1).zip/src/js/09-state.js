/* ===================== 7. СОСТОЯНИЕ ИГРЫ, СРЕДА ===================== */
const G = { mode: 'loading', paused: false, time: 0, saveT: 0, quality: null, scale: 1, inHome: false };
const QUAL = {
  low: { dpr: 1, fogFar: 300, traffic: 20, peds: 30 },
  med: { dpr: 1.5, fogFar: 430, traffic: 38, peds: 58 },
  high: { dpr: 2, fogFar: 560, traffic: 54, peds: 80 }
};
const ENV = { top: [0.4, 0.6, 0.9], bot: [0.8, 0.88, 0.98], sunCol: [0.6, 0.55, 0.45], sky: [0.5, 0.55, 0.65], ground: [0.3, 0.28, 0.26], night: 0, fogNear: 100, fogFar: 520, sunDir: [0.5, 0.8, 0.35], sunVis: [0.5, 0.8, 0.35], sun: 1 };
{ const l = Math.hypot(...ENV.sunDir); ENV.sunDir = ENV.sunDir.map(v => v / l); }
let dayT = DAY_LEN * 0.22;
const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
function updateEnv(dt) {
  dayT = (dayT + dt) % DAY_LEN;
  const sh = Math.sin(dayT / DAY_LEN * TAU);
  const day = clamp((sh + 0.12) / 0.45, 0, 1), ds = day * day * (3 - 2 * day);
  const sunset = clamp(1 - Math.abs(sh) * 4, 0, 1);
  let top = mix3([0.02, 0.03, 0.09], [0.32, 0.58, 0.95], ds); top = mix3(top, [0.42, 0.34, 0.6], sunset * 0.7);
  let bot = mix3([0.07, 0.09, 0.18], [0.78, 0.88, 0.98], ds); bot = mix3(bot, [1.0, 0.64, 0.4], sunset * 0.85);
  let sc = mix3([0.09, 0.11, 0.24], [0.6, 0.56, 0.47], ds); sc = mix3(sc, [0.7, 0.46, 0.26], sunset * 0.6);
  ENV.top = top; ENV.bot = bot; ENV.sunCol = sc;
  ENV.sky = mix3([0.16, 0.2, 0.36], [0.46, 0.52, 0.62], ds);
  ENV.ground = mix3([0.07, 0.08, 0.14], [0.3, 0.28, 0.26], ds);
  ENV.night = 1 - ds;
  {
    const a = dayT / DAY_LEN * TAU, vx = Math.cos(a) * 0.9, vz = 0.4, vl = Math.hypot(vx, sh, vz);
    ENV.sunVis = [vx / vl, sh / vl, vz / vl];
    const ly = Math.max(Math.abs(sh), 0.32), ll = Math.hypot(vx, ly, vz);
    ENV.sunDir = [vx / ll, ly / ll, vz / ll];
  }
  const q = QUAL[S.set.quality] || QUAL.med;
  ENV.fogNear = 90; ENV.fogFar = q.fogFar;
  if (typeof weatherEnv === 'function' && typeof WX !== 'undefined') weatherEnv();
}
function applyQuality() {
  G.quality = QUAL[S.set.quality] || QUAL.med;
  resize();
  applyTraffic(); applyPeds();
}

