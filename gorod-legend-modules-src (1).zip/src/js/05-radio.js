/* ===================== v17: РАДИО (несколько жанров на WebAudio) ===================== */
const RADIO = [
  { n: '🌃 Ночной драйв', bpm: 112 }, { n: '🎤 Улицы FM', bpm: 90 }, { n: '🎧 Клуб 124', bpm: 124 },
  { n: '🎸 Рок-волна', bpm: 138 }, { n: '🎷 Джаз-лаунж', bpm: 96 }, { n: '📻 Радио выключено', bpm: 100 }
];
const RADIO_OFF = RADIO.length - 1;
const MUS_ROOT = [55, 43.65, 65.41, 49];
const MUS_CH = [[0, 3, 7], [0, 4, 7], [0, 4, 7], [0, 4, 7]];
const radioIdx = () => { const i = S.set.radio | 0; return i >= 0 && i < RADIO.length ? i : 0; };
function radioNext() {
  S.set.radio = (radioIdx() + 1) % RADIO.length; AU.step = 0;
  if (AU.ctx) AU.nextT = AU.ctx.currentTime + 0.1;
  S.flags.radioN = (S.flags.radioN || 0) + 1; persist(); SFX.click(); toast('📻 ' + RADIO[radioIdx()].n);
}
const GENRES = [
  /* 0: ночной драйв */
  (s, bar, k, L) => {
    const root = MUS_ROOT[bar], ch = MUS_CH[bar];
    if (s % 4 === 0) k.kick(0.5);
    if (s % 2 === 1) k.hat(0.12);
    if ([0, 3, 6, 10, 12, 14].indexOf(s) >= 0) k.note(root, L * 2.2, 'triangle', 0.5);
    if (s % 2 === 0) k.note(root * 4 * Math.pow(2, ch[(s / 2) % 3] / 12), L * 1.6, 'square', 0.07);
    if (s === 0) ch.forEach(i => k.note(root * 2 * Math.pow(2, i / 12), L * 7, 'sawtooth', 0.035));
  },
  /* 1: хип-хоп */
  (s, bar, k, L) => {
    const root = [55, 49, 43.65, 49][bar], PENT = [0, 3, 5, 7, 10];
    if (s === 0 || s === 7 || s === 10) k.kick(0.55);
    if (s === 4 || s === 12) k.snare(0.32);
    if (s % 2 === 0) k.hat(0.06); if (s === 14) k.hat(0.09, 0.12);
    if (s === 0 || s === 7 || s === 10) k.note(root, L * 3, 'sine', 0.6);
    if (s === 0) [0, 3, 7, 10].forEach(i => k.note(root * 4 * Math.pow(2, i / 12), L * 6, 'triangle', 0.04));
    if (s === 2 || s === 6 || s === 11 || s === 14) k.note(root * 8 * Math.pow(2, PENT[(bar * 3 + s) % 5] / 12), L * 1.5, 'sine', 0.05);
  },
  /* 2: хаус */
  (s, bar, k, L) => {
    const root = [55, 55, 65.41, 49][bar], A = [0, 3, 7, 10];
    if (s % 4 === 0) k.kick(0.55);
    if (s === 4 || s === 12) k.snare(0.2);
    if (s % 4 === 2) k.hat(0.1, 0.09); else if (s % 2 === 1) k.hat(0.035);
    if (s % 4 === 2) k.note(root, L * 1.7, 'sawtooth', 0.2);
    if (s === 0) A.forEach(i => k.note(root * 4 * Math.pow(2, i / 12), L * 15, 'sawtooth', 0.022));
    if (s % 2 === 0) k.note(root * 8 * Math.pow(2, A[(s / 2) % 4] / 12), L * 0.9, 'square', 0.035);
  },
  /* 3: рок */
  (s, bar, k, L) => {
    const root = [82.41, 98, 73.42, 110][bar];
    if (s === 0 || s === 8 || s === 10) k.kick(0.55);
    if (s === 4 || s === 12) k.snare(0.4);
    if (s % 2 === 0) k.hat(0.08);
    if (s % 4 === 0 || s === 6 || s === 14) { const d = L * (s === 6 || s === 14 ? 1.8 : 3.6); k.note(root * 2, d, 'sawtooth', 0.07); k.note(root * 3, d, 'sawtooth', 0.06); k.note(root * 4, d, 'sawtooth', 0.05); }
    if (s % 2 === 0) k.note(root, L * 1.8, 'triangle', 0.35);
  },
  /* 4: джаз */
  (s, bar, k, L) => {
    const root = [73.42, 98, 65.41, 110][bar], WALK = [0, 4, 7, 9];
    if (s % 4 === 0) k.note(root * Math.pow(2, WALK[s / 4] / 12), L * 3.4, 'triangle', 0.45);
    if (s % 4 === 0) k.hat(0.05); else if (s % 4 === 2) k.hat(0.035); else if (s === 6 || s === 14) k.hat(0.05);
    if (s === 4 || s === 12) k.snare(0.05);
    if (s === 2 || s === 10) [0, 4, 7, 10].forEach(i => k.note(root * 4 * Math.pow(2, i / 12), L * 3, 'sine', 0.04));
  }
];
function musicTick() {
  const ri = radioIdx();
  if (!AU.ctx || S.set.music <= 0.01 || ri === RADIO_OFF) { if (AU.ctx) AU.nextT = Math.max(AU.nextT, AU.ctx.currentTime); return; }
  const ctx = AU.ctx, L = 60 / RADIO[ri].bpm / 4;
  while (AU.nextT < ctx.currentTime + 0.25) {
    const st = AU.step++, s = st % 16, bar = Math.floor(st / 16) % 4, t = AU.nextT;
    const note = (f, dur, type, vol) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = type; o.frequency.value = f;
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(AU.mus); o.start(t); o.stop(t + dur + 0.02);
    };
    const hit = (v, dur, hp) => {
      if (!AU.noise) return;
      const src = ctx.createBufferSource(); src.buffer = AU.noise;
      const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = hp;
      const g = ctx.createGain(); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      src.connect(f); f.connect(g); g.connect(AU.mus); src.start(t); src.stop(t + dur + 0.02);
    };
    const kit = {
      note,
      kick: v => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.15); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18); o.connect(g); g.connect(AU.mus); o.start(t); o.stop(t + 0.2); },
      snare: v => { hit(v, 0.14, 1800); note(190, 0.08, 'triangle', v * 0.5); },
      hat: (v, d) => hit(v, d || 0.05, 7000)
    };
    GENRES[ri](s, bar, kit, L);
    AU.nextT += L;
  }
}

