/* ===================== v41: ПРОЧНОСТЬ МАШИНЫ, БРОНЕКУЗОВ, СТЕК УВЕДОМЛЕНИЙ, КАРТА НА ТЕЛЕФОНЕ ===================== */
{
  const css = document.createElement('style');
  css.textContent = `
#toasts { pointer-events: none; }
#toasts .toast { pointer-events: auto; cursor: pointer; }
#toasts.exp { max-height: 62vh; overflow-y: auto; pointer-events: auto; }
#toasts .toast[data-n]::after { content: '+' attr(data-n); margin-left: 8px; background: #ffb703; color: #000; border-radius: 10px; padding: 1px 7px; font-size: 12px; font-weight: 800; }
#toasts.exp .toast::after { content: none !important; }
@media (max-height: 480px) {
  #mapScreen .panel.mapp { padding: 5px 10px; max-height: 98vh; }
  #mapScreen .ps-head { margin-bottom: 3px; }
  #mapScreen .ps-head .btn { padding: 4px 10px; font-size: 13px; }
  #mapScreen .ps-head h2 { font-size: 17px; margin: 0; }
  .mp-body { height: calc(100vh - 78px); }
  #mapScreen #bigMap { width: calc(100vh - 78px); height: calc(100vh - 78px); }
}
`;
  document.head.appendChild(css);

  /* ---- уведомления: стопка, видно последнее; тап раскрывает все ---- */
  const TL = [], LIFE = 4200, box = () => $('toasts');
  const now = () => performance.now();
  function tLayout() {
    const b = box(); if (!b) return;
    const ex = b.classList.contains('exp');
    TL.forEach((it, i) => { it.el.style.display = (ex || i === TL.length - 1) ? '' : 'none'; it.el.removeAttribute('data-n'); });
    if (!ex && TL.length > 1) TL[TL.length - 1].el.setAttribute('data-n', TL.length - 1);
    if (!TL.length) b.classList.remove('exp');
  }
  function tDrop(it) { const i = TL.indexOf(it); if (i >= 0) TL.splice(i, 1); it.el.classList.add('out'); setTimeout(() => it.el.remove(), 400); }
  toast = function (text) {
    const b = box(); if (!b) return;
    const t = now(), last = TL[TL.length - 1];
    if (last && last.text === text && t - last.t < 2500) { last.n++; last.t = t; last.exp = t + LIFE; last.el.textContent = text + ' ×' + last.n; tLayout(); return; }
    const el = document.createElement('div'); el.className = 'toast'; el.textContent = text; b.appendChild(el);
    TL.push({ el, text, t, exp: t + LIFE, n: 1 });
    while (TL.length > 14) { const o = TL.shift(); o.el.remove(); }
    tLayout();
  };
  setInterval(() => {
    const t = now(); let ch = false;
    for (const it of TL.slice()) if (t > it.exp) { tDrop(it); ch = true; }
    if (ch) tLayout();
  }, 250);
  document.addEventListener('click', e => {
    const b = box(); if (!b) return;
    const el = e.target.closest && e.target.closest('#toasts .toast'); if (!el) return;
    const open = !b.classList.contains('exp');
    b.classList.toggle('exp', open);
    const t = now() + (open ? 9000 : LIFE);
    for (const it of TL) it.exp = Math.max(it.exp, t);
    tLayout(); if (open) b.scrollTop = b.scrollHeight;
  }, true);

  /* ---- прокачка прочности машины ---- */
  UPGRADES.push({ key: 'hp', name: 'Бронекузов', icon: '🛡️', desc: '−9% получаемых повреждений за уровень' });
  const norm = () => { for (const id in S.cars) { const r = S.cars[id]; if (!r.u) r.u = { eng: 0, acc: 0, tir: 0, nit: 0 }; if (r.u.hp === undefined) r.u.hp = 0; } };
  const rg0 = renderGarage; renderGarage = function () { norm(); return rg0.apply(this, arguments); };
  const ug0 = upgradeCar; upgradeCar = function () { norm(); return ug0.apply(this, arguments); };
  const hpLv = c => { const r = c === OWN ? S.cars[c.recId || S.sel] : (c === P.car && c.recId ? S.cars[c.recId] : null); return r && r.u && r.u.hp ? r.u.hp : 0; };
  const ch0 = carHurt;
  carHurt = function (c, imp) { return ch0(c, imp * (1 - 0.09 * hpLv(c))); };

  /* метка версии: видно, какая сборка реально загружена */
  for (const id of ['menu', 'pause']) {
    const e = $(id), p = e && (e.querySelector('.panel') || e); if (!p) continue;
    const d = document.createElement('div'); d.className = 'vtag'; d.textContent = 'Версия сборки: v45 (' + 'пирс, лодки, яхты)';
    d.style.cssText = 'margin-top:10px;font:11px system-ui,sans-serif;color:#8da0b8;text-align:center;width:100%';
    p.appendChild(d);
  }
}

function WLIM() { return EDGE + 260; }
