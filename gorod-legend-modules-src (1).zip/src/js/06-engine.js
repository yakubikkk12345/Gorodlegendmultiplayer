/* ===================== 5. ДВИЖОК WebGL ===================== */
const canvas = $('game');
let gl = null;
try {
  gl = canvas.getContext('webgl', { antialias: !isTouch(), alpha: false, depth: true, stencil: true, powerPreference: 'high-performance' }) ||
       canvas.getContext('experimental-webgl');
} catch (e) { }
if (!gl) { fatal('Ваше устройство или браузер не поддерживает WebGL. Попробуйте Chrome.'); return; }

const VS = `
attribute vec3 aPos; attribute vec3 aNor; attribute vec4 aCol; attribute vec2 aUV;
uniform mat4 uVP; uniform mat4 uM; uniform vec3 uCam;
uniform vec3 uSunDir; uniform vec3 uSunCol; uniform vec3 uSky; uniform vec3 uGround;
uniform float uFogNear; uniform float uFogFar;
varying vec4 vCol; varying vec2 vUV; varying vec3 vLight; varying float vFog;
void main(){
  vec4 wp = uM * vec4(aPos,1.0);
  gl_Position = uVP * wp;
  mat3 nm = mat3(normalize(uM[0].xyz), normalize(uM[1].xyz), normalize(uM[2].xyz));
  vec3 n = normalize(nm * aNor);
  float ndl = max(dot(n, uSunDir), 0.0);
  vec3 amb = mix(uGround, uSky, n.y*0.5+0.5);
  vLight = amb + uSunCol * ndl;
  vCol = aCol; vUV = aUV;
  vFog = clamp((length(wp.xyz - uCam) - uFogNear) / (uFogFar - uFogNear), 0.0, 1.0);
}`;
const FS = `
precision mediump float;
varying vec4 vCol; varying vec2 vUV; varying vec3 vLight; varying float vFog;
uniform sampler2D uTex; uniform sampler2D uTexE;
uniform float uUseTex; uniform float uNight; uniform float uUnlit; uniform float uAlpha;
uniform vec3 uFogCol; uniform vec3 uTint;
void main(){
  vec4 base = vCol; vec3 em = vec3(0.0);
  if (uUseTex > 0.5) {
    vec4 t = texture2D(uTex, vUV);
    base.rgb *= t.rgb;
    em = texture2D(uTexE, vUV).rgb * uNight;
  }
  base.rgb *= uTint;
  vec3 c; float a = base.a * uAlpha;
  if (uUnlit < 0.5) { c = base.rgb * vLight + em; c = mix(c, uFogCol, vFog); }
  else if (uUnlit < 1.5) { c = mix(base.rgb, uFogCol, vFog); }
  else { c = base.rgb; a *= (1.0 - vFog); }
  gl_FragColor = vec4(c, a);
}`;
const SKY_VS = `attribute vec2 aP; uniform vec3 uR; uniform vec3 uU; uniform vec3 uF; uniform vec2 uT; varying vec3 vD;
void main(){ vD = uF + uR*aP.x*uT.x + uU*aP.y*uT.y; gl_Position = vec4(aP,0.9999,1.0); }`;
const SKY_FS = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec3 vD; uniform vec3 uTop; uniform vec3 uBot; uniform vec3 uSun; uniform float uNight; uniform float uTime; uniform float uCl;
float h(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float nz(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
  return mix(mix(h(i),h(i+vec2(1.0,0.0)),f.x),mix(h(i+vec2(0.0,1.0)),h(i+vec2(1.0,1.0)),f.x),f.y); }
void main(){
  vec3 d = normalize(vD); float y = d.y;
  float t = clamp(y*1.9+0.06,0.0,1.0); t = t*t*(3.0-2.0*t);
  vec3 col = mix(uBot,uTop,t);
  float sd = max(dot(d,uSun),0.0), md = max(dot(d,-uSun),0.0), dayK = 1.0-uNight;
  col += vec3(1.0,0.78,0.5)*pow(sd,18.0)*0.35*dayK;
  col += vec3(1.0,0.95,0.8)*smoothstep(0.99935,0.99965,sd)*dayK;
  col += vec3(0.55,0.65,0.9)*pow(md,40.0)*0.18*uNight;
  col += vec3(0.92,0.95,1.0)*smoothstep(0.9991,0.9994,md)*uNight;
  if (uNight > 0.03 && y > 0.0) {
    vec2 uv = vec2(atan(d.z,d.x)*38.0, y*70.0); vec2 ci = floor(uv); float r = h(ci);
    float st = step(0.975,r)*smoothstep(0.42,0.0,length(fract(uv)-0.5));
    st *= 0.55+0.45*sin(uTime*2.5+r*60.0);
    col += vec3(0.9,0.93,1.0)*st*uNight*smoothstep(0.02,0.2,y);
  }
  if (uCl > 0.5 && y > 0.0) {
    vec2 cp = d.xz/(y+0.14)*0.85 + vec2(uTime*0.01,uTime*0.004);
    float c = nz(cp*1.3)*0.58 + nz(cp*2.9)*0.3 + nz(cp*6.3)*0.12;
    c = smoothstep(0.52,0.8,c)*smoothstep(0.0,0.14,y);
    vec3 cc = mix(vec3(0.09,0.11,0.19),vec3(1.0,0.99,0.97),dayK);
    cc *= mix(vec3(1.0),uBot*1.2+0.1,0.5);
    col = mix(col,cc,c*0.8);
  }
  gl_FragColor = vec4(col,1.0);
}`;

function compile(vs, fs, attrs) {
  const mk = (type, src) => {
    const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
    return s;
  };
  const p = gl.createProgram();
  gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs));
  attrs.forEach((a, i) => gl.bindAttribLocation(p, i, a));
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  return p;
}
let PROG, SKYPROG; const U = {};
try {
  PROG = compile(VS, FS, ['aPos', 'aNor', 'aCol', 'aUV']);
  SKYPROG = compile(SKY_VS, SKY_FS, ['aP']);
} catch (e) { fatal('Ошибка шейдеров: ' + e.message); return; }
['uVP', 'uM', 'uCam', 'uSunDir', 'uSunCol', 'uSky', 'uGround', 'uFogNear', 'uFogFar', 'uFogCol', 'uTint', 'uUnlit', 'uAlpha', 'uUseTex', 'uNight', 'uTex', 'uTexE']
  .forEach(n => U[n] = gl.getUniformLocation(PROG, n));
const SKYU = {}; ['uTop', 'uBot', 'uSun', 'uNight', 'uTime', 'uCl', 'uR', 'uU', 'uF', 'uT'].forEach(n => SKYU[n] = gl.getUniformLocation(SKYPROG, n));
for (let i = 0; i < 4; i++) gl.enableVertexAttribArray(i);
const skyBuf = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, skyBuf);
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);

/* --- матрицы --- */
const newM = () => new Float32Array(16);
function mIdent(o) { o.fill(0); o[0] = o[5] = o[10] = o[15] = 1; return o; }
function mMul(o, a, b) {
  const a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3], a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7],
    a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11], a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
  let b0 = b[0], b1 = b[1], b2 = b[2], b3 = b[3];
  o[0] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30; o[1] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
  o[2] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32; o[3] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
  b0 = b[4]; b1 = b[5]; b2 = b[6]; b3 = b[7];
  o[4] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30; o[5] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
  o[6] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32; o[7] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
  b0 = b[8]; b1 = b[9]; b2 = b[10]; b3 = b[11];
  o[8] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30; o[9] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
  o[10] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32; o[11] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
  b0 = b[12]; b1 = b[13]; b2 = b[14]; b3 = b[15];
  o[12] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30; o[13] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
  o[14] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32; o[15] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
  return o;
}
function mPersp(o, fovy, asp, n, f) {
  const t = 1 / Math.tan(fovy / 2), nf = 1 / (n - f);
  o.fill(0); o[0] = t / asp; o[5] = t; o[10] = (f + n) * nf; o[11] = -1; o[14] = 2 * f * n * nf; return o;
}
function mLookAt(o, ex, ey, ez, cx, cy, cz) {
  let zx = ex - cx, zy = ey - cy, zz = ez - cz, l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
  let xx = zz, xy = 0, xz = -zx; l = Math.hypot(xx, xz) || 1; xx /= l; xz /= l;           // up=(0,1,0) × z
  const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
  o[0] = xx; o[1] = yx; o[2] = zx; o[3] = 0; o[4] = xy; o[5] = yy; o[6] = zy; o[7] = 0; o[8] = xz; o[9] = yz; o[10] = zz; o[11] = 0;
  o[12] = -(xx * ex + xy * ey + xz * ez); o[13] = -(yx * ex + yy * ey + yz * ez); o[14] = -(zx * ex + zy * ey + zz * ez); o[15] = 1;
  return o;
}
function mTRS(o, tx, ty, tz, ry, rx, rz, sx, sy, sz) {
  const cy = Math.cos(ry), sy_ = Math.sin(ry), cx = Math.cos(rx), sx_ = Math.sin(rx), cz = Math.cos(rz), sz_ = Math.sin(rz);
  const r11 = cy * cz + sy_ * sx_ * sz_, r12 = -cy * sz_ + sy_ * sx_ * cz, r13 = sy_ * cx;
  const r21 = cx * sz_, r22 = cx * cz, r23 = -sx_;
  const r31 = -sy_ * cz + cy * sx_ * sz_, r32 = sy_ * sz_ + cy * sx_ * cz, r33 = cy * cx;
  o[0] = r11 * sx; o[1] = r21 * sx; o[2] = r31 * sx; o[3] = 0;
  o[4] = r12 * sy; o[5] = r22 * sy; o[6] = r32 * sy; o[7] = 0;
  o[8] = r13 * sz; o[9] = r23 * sz; o[10] = r33 * sz; o[11] = 0;
  o[12] = tx; o[13] = ty; o[14] = tz; o[15] = 1;
  return o;
}

/* --- геометрия (CPU) → Mesh (GPU) --- */
class Geo {
  constructor() { this.v = []; this.i = []; this.nv = 0; }
  p(x, y, z, nx, ny, nz, c, u, v) { this.v.push(x, y, z, nx, ny, nz, c[0], c[1], c[2], c[3] === undefined ? 1 : c[3], u || 0, v || 0); return this.nv++; }
  quad(a, b, c, d) { this.i.push(a, b, c, a, c, d); }
  /* бокс; tex=true — окна на боковых гранях */
  box(x0, y0, z0, x1, y1, z1, c, tex, noBottom) {
    const w = x1 - x0, h = y1 - y0, d = z1 - z0, S = 12;
    const faces = [
      [[1, 0, 0], [[x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]], d, h],
      [[-1, 0, 0], [[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]], d, h],
      [[0, 1, 0], [[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]], 0, 0],
      [[0, 0, 1], [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]], w, h],
      [[0, 0, -1], [[x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]], w, h]
    ];
    if (!noBottom) faces.push([[0, -1, 0], [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]], 0, 0]);
    for (const f of faces) {
      const n = f[0], vs = f[1], uw = f[2] / S, uh = f[3] / S;
      const flat = !tex || (uw === 0 && uh === 0);
      const uv = flat ? [[0.01, 0.01], [0.01, 0.01], [0.01, 0.01], [0.01, 0.01]] : [[0, uh], [uw, uh], [uw, 0], [0, 0]];
      const a = [];
      for (let k = 0; k < 4; k++) a.push(this.p(vs[k][0], vs[k][1], vs[k][2], n[0], n[1], n[2], c, uv[k][0], uv[k][1]));
      this.quad(a[0], a[1], a[2], a[3]);
    }
  }
  /* плоский четырёхугольник, смотрит вверх */
  flat(x0, z0, x1, z1, y, c) {
    const a = this.p(x0, y, z1, 0, 1, 0, c, 0.01, 0.01), b = this.p(x1, y, z1, 0, 1, 0, c, 0.01, 0.01),
      cc = this.p(x1, y, z0, 0, 1, 0, c, 0.01, 0.01), d = this.p(x0, y, z0, 0, 1, 0, c, 0.01, 0.01);
    this.quad(a, b, cc, d);
  }
  /* конус / пирамида */
  cone(cx, y0, cz, r, h, sides, c, c2) {
    for (let i = 0; i < sides; i++) {
      const a0 = i / sides * TAU, a1 = (i + 1) / sides * TAU, am = (a0 + a1) / 2;
      let nx = Math.cos(am) * h, ny = r, nz = Math.sin(am) * h; const l = Math.hypot(nx, ny, nz); nx /= l; ny /= l; nz /= l;
      const cc = c2 && i % 2 ? c2 : c;
      const A = this.p(cx + Math.cos(a0) * r, y0, cz + Math.sin(a0) * r, nx, ny, nz, cc, 0.01, 0.01);
      const B = this.p(cx + Math.cos(a1) * r, y0, cz + Math.sin(a1) * r, nx, ny, nz, cc, 0.01, 0.01);
      const T = this.p(cx, y0 + h, cz, nx, ny, nz, cc, 0.01, 0.01);
      this.i.push(A, T, B);
    }
  }
  /* цилиндр вдоль оси X (колёса) */
  cylX(cx, cy, cz, r, hw, sides, c) {
    for (let i = 0; i < sides; i++) {
      const a0 = i / sides * TAU, a1 = (i + 1) / sides * TAU, am = (a0 + a1) / 2;
      const ny = Math.cos(am), nz = Math.sin(am);
      const y0 = cy + Math.cos(a0) * r, z0 = cz + Math.sin(a0) * r, y1 = cy + Math.cos(a1) * r, z1 = cz + Math.sin(a1) * r;
      const A = this.p(cx - hw, y0, z0, 0, ny, nz, c), B = this.p(cx + hw, y0, z0, 0, ny, nz, c),
        C = this.p(cx + hw, y1, z1, 0, ny, nz, c), D = this.p(cx - hw, y1, z1, 0, ny, nz, c);
      this.quad(A, D, C, B);
    }
    for (const sgn of [-1, 1]) {
      const cc = [c[0] * 0.9, c[1] * 0.9, c[2] * 0.9, 1];
      const ctr = this.p(cx + sgn * hw, cy, cz, sgn, 0, 0, cc);
      const ring = [];
      for (let i = 0; i < sides; i++) { const a = i / sides * TAU; ring.push(this.p(cx + sgn * hw, cy + Math.cos(a) * r, cz + Math.sin(a) * r, sgn, 0, 0, cc)); }
      for (let i = 0; i < sides; i++) { const A = ring[i], B = ring[(i + 1) % sides]; if (sgn > 0) this.i.push(ctr, B, A); else this.i.push(ctr, A, B); }
    }
  }
  /* открытая труба (луч), alpha: низ → верх */
  beam(sides, a0, a1, c) {
    const lo = [], hi = [];
    for (let i = 0; i <= sides; i++) {
      const a = i / sides * TAU, x = Math.cos(a), z = Math.sin(a);
      lo.push(this.p(x, 0, z, 0, 1, 0, [c[0], c[1], c[2], a0]));
      hi.push(this.p(x, 1, z, 0, 1, 0, [c[0], c[1], c[2], a1]));
    }
    for (let i = 0; i < sides; i++) { this.quad(lo[i], lo[i + 1], hi[i + 1], hi[i]); this.i.push(lo[i], hi[i], hi[i + 1], lo[i], hi[i + 1], lo[i + 1]); }
  }
  ring(sides, r0, r1, c) {
    const A = [], B = [];
    for (let i = 0; i <= sides; i++) {
      const a = i / sides * TAU, x = Math.cos(a), z = Math.sin(a);
      A.push(this.p(x * r0, 0, z * r0, 0, 1, 0, c)); B.push(this.p(x * r1, 0, z * r1, 0, 1, 0, c));
    }
    for (let i = 0; i < sides; i++) { this.i.push(A[i], B[i], B[i + 1], A[i], B[i + 1], A[i + 1]); this.i.push(A[i], B[i + 1], B[i], A[i], A[i + 1], B[i + 1]); }
  }
  disc(sides, cIn, cOut) {
    const c0 = this.p(0, 0, 0, 0, 1, 0, cIn); const ring = [];
    for (let i = 0; i < sides; i++) { const a = i / sides * TAU; ring.push(this.p(Math.cos(a), 0, Math.sin(a), 0, 1, 0, cOut)); }
    for (let i = 0; i < sides; i++) this.i.push(c0, ring[(i + 1) % sides], ring[i]);
  }
  discAt(cx, y, cz, r, sides, cIn, cOut) {
    const c0 = this.p(cx, y, cz, 0, 1, 0, cIn); const ring = [];
    for (let i = 0; i < sides; i++) { const a = i / sides * TAU; ring.push(this.p(cx + Math.cos(a) * r, y, cz + Math.sin(a) * r, 0, 1, 0, cOut)); }
    for (let i = 0; i < sides; i++) this.i.push(c0, ring[(i + 1) % sides], ring[i]);
  }
  octa(r, c) {
    const P = [[r, 0, 0], [-r, 0, 0], [0, r * 1.4, 0], [0, -r * 1.4, 0], [0, 0, r], [0, 0, -r]];
    const F = [[0, 2, 4], [4, 2, 1], [1, 2, 5], [5, 2, 0], [4, 3, 0], [1, 3, 4], [5, 3, 1], [0, 3, 5]];
    for (const f of F) {
      const a = P[f[0]], b = P[f[1]], d = P[f[2]];
      const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = d[0] - a[0], vy = d[1] - a[1], vz = d[2] - a[2];
      let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
      const i0 = this.p(a[0], a[1], a[2], nx, ny, nz, c), i1 = this.p(b[0], b[1], b[2], nx, ny, nz, c), i2 = this.p(d[0], d[1], d[2], nx, ny, nz, c);
      this.i.push(i0, i1, i2);
    }
  }
}
function makeMesh(g) {
  const vb = gl.createBuffer(), ib = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(g.v), gl.STATIC_DRAW);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(g.i), gl.STATIC_DRAW);
  return { vb, ib, n: g.i.length };
}
/* набор статической геометрии, режется на куски < 65k вершин */
class GeoSet {
  constructor() { this.list = []; this.cur = new Geo(); }
  g() { if (this.cur.nv > 63000) { this.list.push(this.cur); this.cur = new Geo(); } return this.cur; }
  done() { this.list.push(this.cur); return this.list.map(makeMesh); }
}

const STRIDE = 48;
let curBlend = '';
function setPass(kind) {
  if (curBlend === kind) return; curBlend = kind;
  if (kind === 'opaque') { gl.disable(gl.BLEND); gl.depthMask(true); gl.disable(gl.POLYGON_OFFSET_FILL); }
  else if (kind === 'decal') { gl.disable(gl.BLEND); gl.depthMask(false); gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(-2, -2); }
  else if (kind === 'alpha') { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(-1, -1); }
  else if (kind === 'add') { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE); gl.depthMask(false); gl.disable(gl.POLYGON_OFFSET_FILL); }
}
const DM = newM(), TM = newM();
function drawMesh(m, model, tr, tg, tb, alpha, unlit, tex) {
  gl.bindBuffer(gl.ARRAY_BUFFER, m.vb);
  gl.vertexAttribPointer(0, 3, gl.FLOAT, false, STRIDE, 0);
  gl.vertexAttribPointer(1, 3, gl.FLOAT, false, STRIDE, 12);
  gl.vertexAttribPointer(2, 4, gl.FLOAT, false, STRIDE, 24);
  gl.vertexAttribPointer(3, 2, gl.FLOAT, false, STRIDE, 40);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.ib);
  gl.uniformMatrix4fv(U.uM, false, model || IDENT);
  gl.uniform3f(U.uTint, tr === undefined ? 1 : tr, tg === undefined ? 1 : tg, tb === undefined ? 1 : tb);
  gl.uniform1f(U.uAlpha, alpha === undefined ? 1 : alpha);
  gl.uniform1f(U.uUnlit, unlit || 0);
  gl.uniform1f(U.uUseTex, tex ? 1 : 0);
  gl.drawElements(gl.TRIANGLES, m.n, gl.UNSIGNED_SHORT, 0);
  STATS.draws++;
}
const IDENT = mIdent(newM());
const STATS = { draws: 0 };

/* --- текстуры окон (днём и ночью) --- */
function makeWindowTextures() {
  const R = rng(777), N = 256, cells = 4, cs = N / cells;
  const c1 = document.createElement('canvas'), c2 = document.createElement('canvas');
  c1.width = c1.height = c2.width = c2.height = N;
  const a = c1.getContext('2d'), b = c2.getContext('2d');
  a.fillStyle = '#ffffff'; a.fillRect(0, 0, N, N);
  b.fillStyle = '#000000'; b.fillRect(0, 0, N, N);
  for (let y = 0; y < cells; y++) for (let x = 0; x < cells; x++) {
    const px = x * cs + 12, py = y * cs + 10, w = cs - 24, h = cs - 22;
    const shade = 70 + Math.floor(R() * 40);
    a.fillStyle = 'rgb(' + (shade - 20) + ',' + shade + ',' + (shade + 40) + ')';
    a.fillRect(px, py, w, h);
    a.fillStyle = 'rgba(255,255,255,0.18)'; a.fillRect(px, py, w, 6);
    a.fillStyle = 'rgba(0,0,0,0.25)'; a.fillRect(px, py + h - 3, w, 3);
    if (R() < 0.5) { b.fillStyle = R() < 0.7 ? 'rgb(255,210,120)' : 'rgb(190,225,255)'; b.fillRect(px, py, w, h); }
  }
  const mk = cv => {
    const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, cv);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
    const ext = gl.getExtension('EXT_texture_filter_anisotropic');
    if (ext) gl.texParameterf(gl.TEXTURE_2D, ext.TEXTURE_MAX_ANISOTROPY_EXT, 4);
    return t;
  };
  return [mk(c1), mk(c2)];
}
const [TEX_DAY, TEX_NIGHT] = makeWindowTextures();

