/* ===================== v31: КАЗИНО ===================== */
const CAS = { tab: 'roul', bet: 100, roul: { pick: 'red', num: 7, spin: false, last: null }, bj: null, slot: { spin: false, r: ['🍒', '🍋', '🔔'] }, msg: '' };
const RED_N = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
const CAS_BETS = [50, 100, 500, 1000, 5000];
function casMsg(t) { CAS.msg = t; const e = $('casMsg'); if (e) e.textContent = t; }
function casBusy() { return CAS.roul.spin || CAS.slot.spin; }
function casPay(n) { if (n > 0) { addMoney(n); SFX.cash(); } else refreshMoney(false); persist(); }
function casTake(n) { if (S.money < n) { SFX.err(); casMsg('Не хватает денег на ставку'); return false; } S.money -= n; refreshMoney(false); return true; }
function casRender() {
  document.querySelectorAll('#casino .cas-tabs .btn').forEach(b => b.classList.toggle('on', b.dataset.tab === CAS.tab));
  $('casBets').innerHTML = '<span class="muted" style="align-self:center">Ставка:</span>' + CAS_BETS.map(v => '<button class="btn' + (v === CAS.bet ? ' on' : '') + '" data-act="cas-bet" data-v="' + v + '">$' + v + '</button>').join('');
  const b = $('casBody'); let h = '';
  if (CAS.tab === 'roul') {
    const r = CAS.roul, P = [['red', '🔴 Красное ×2'], ['black', '⚫ Чёрное ×2'], ['even', 'Чёт ×2'], ['odd', 'Нечёт ×2'], ['low', '1–18 ×2'], ['high', '19–36 ×2'], ['zero', '🟢 Зеро ×36'], ['num', 'Число ×36']];
    const last = r.last === null ? '🎡' : (r.last === 0 ? '🟢 0' : (RED_N.has(r.last) ? '🔴 ' : '⚫ ') + r.last);
    h = '<div class="cas-wheel" id="casWheel">' + last + '</div><div class="cas-row">' + P.map(p => '<button class="btn' + (r.pick === p[0] ? ' on' : '') + '" data-act="cas-roul" data-v="' + p[0] + '">' + p[1] + '</button>').join('') + '</div>'
      + (r.pick === 'num' ? '<div class="cas-row"><span class="muted">Число 1–36:</span><input type="number" id="casNum" min="1" max="36" value="' + r.num + '" style="width:70px;font-size:16px"></div>' : '')
      + '<button class="btn pri" data-act="cas-roul" data-v="spin">▶ Крутить на $' + CAS.bet + '</button>';
  } else if (CAS.tab === 'bj') {
    const g = CAS.bj, cd = c => '<div class="cas-card' + (c.s === '♥' || c.s === '♦' ? ' red' : '') + '">' + c.r + c.s + '</div>';
    if (!g) h = '<p class="muted">Дилер стоит на 17. Блэкджек платит 3:2. Можно удвоить.</p><button class="btn pri" data-act="cas-bj" data-v="deal">🃏 Раздать на $' + CAS.bet + '</button>';
    else {
      const hide = !g.done;
      h = '<div>Дилер' + (hide ? '' : ' · ' + bjVal(g.d)) + '</div><div class="cas-cards">' + g.d.map((c, i) => hide && i === 1 ? '<div class="cas-card back">?</div>' : cd(c)).join('') + '</div>'
        + '<div>Вы · ' + bjVal(g.p) + ' · ставка $' + g.bet + '</div><div class="cas-cards">' + g.p.map(cd).join('') + '</div>'
        + (g.done ? '<button class="btn pri" data-act="cas-bj" data-v="deal">🃏 Ещё раз на $' + CAS.bet + '</button>' : '<div class="cas-row"><button class="btn pri" data-act="cas-bj" data-v="hit">Ещё</button><button class="btn" data-act="cas-bj" data-v="stand">Стоп</button>' + (g.p.length === 2 && S.money >= g.bet ? '<button class="btn" data-act="cas-bj" data-v="dbl">×2</button>' : '') + '</div>');
    }
  } else {
    const r = CAS.slot.r;
    h = '<div class="cas-wheel" id="casWheel">' + r.join(' ') + '</div><p class="muted">Три одинаковых ×10 (7️⃣ ×30), два одинаковых ×2.</p><button class="btn pri" data-act="cas-slot">🎰 Крутить на $' + CAS.bet + '</button>';
  }
  b.innerHTML = h + '<div class="cas-msg" id="casMsg">' + CAS.msg + '</div>';
}
function casAct(a, el) {
  SFX.click(); const v = el && el.dataset.v;
  if (a === 'cas-tab') { if (casBusy()) return; CAS.tab = el.dataset.tab; CAS.msg = ''; casRender(); return; }
  if (a === 'cas-bet') { if (casBusy()) return; CAS.bet = +v; casRender(); return; }
  if (a === 'cas-roul') {
    if (casBusy()) return; const r = CAS.roul;
    if (v !== 'spin') { r.pick = v; casRender(); return; }
    if (r.pick === 'num') { const n = Math.round(+($('casNum').value)); if (!(n >= 1 && n <= 36)) { casMsg('Число от 1 до 36'); return; } r.num = n; }
    if (!casTake(CAS.bet)) return;
    r.spin = true; casMsg('Шарик крутится…'); let t = 0; const w = $('casWheel');
    const res = Math.floor(Math.random() * 37);
    const iv = setInterval(() => {
      t++; const x = Math.floor(Math.random() * 37); if (w) w.textContent = (x === 0 ? '🟢 0' : (RED_N.has(x) ? '🔴 ' : '⚫ ') + x); SFX.tick && SFX.tick();
      if (t >= 14) {
        clearInterval(iv); r.spin = false; r.last = res;
        let mult = 0; const red = RED_N.has(res);
        if (res !== 0) {
          if (r.pick === 'red' && red) mult = 2; else if (r.pick === 'black' && !red) mult = 2; else if (r.pick === 'even' && res % 2 === 0) mult = 2; else if (r.pick === 'odd' && res % 2 === 1) mult = 2;
          else if (r.pick === 'low' && res <= 18) mult = 2; else if (r.pick === 'high' && res >= 19) mult = 2; else if (r.pick === 'num' && res === r.num) mult = 36;
        } else if (r.pick === 'zero') mult = 36;
        casPay(mult * CAS.bet); CAS.msg = mult ? '🎉 Выпало ' + res + '! Выигрыш ' + fmtMoney(mult * CAS.bet) : 'Выпало ' + res + '. Ставка проиграна'; if (!mult) SFX.err();
        if (UI.cur === 'casino') casRender();
      }
    }, 110);
    return;
  }
  if (a === 'cas-slot') {
    if (casBusy() || !casTake(CAS.bet)) return;
    const SY = ['🍒', '🍋', '🔔', '🍉', '7️⃣', '⭐']; const W = [3, 3, 3, 3, 1, 3], tot = 16;
    const pickS = () => { let x = Math.random() * tot; for (let i = 0; i < SY.length; i++) { x -= W[i]; if (x < 0) return SY[i]; } return SY[0]; };
    const fin = [pickS(), pickS(), pickS()]; CAS.slot.spin = true; casMsg('Барабаны крутятся…'); let t = 0; const w = $('casWheel');
    const iv = setInterval(() => {
      t++; if (w) w.textContent = [0, 1, 2].map(() => SY[Math.floor(Math.random() * SY.length)]).join(' ');
      if (t >= 12) {
        clearInterval(iv); CAS.slot.spin = false; CAS.slot.r = fin; let m = 0;
        if (fin[0] === fin[1] && fin[1] === fin[2]) m = fin[0] === '7️⃣' ? 30 : 10; else if (fin[0] === fin[1] || fin[1] === fin[2] || fin[0] === fin[2]) m = 2;
        casPay(m * CAS.bet); CAS.msg = m ? '🎉 Выигрыш ' + fmtMoney(m * CAS.bet) : 'Не повезло'; if (!m) SFX.err();
        if (UI.cur === 'casino') casRender();
      }
    }, 110);
    return;
  }
  if (a === 'cas-bj') {
    let g = CAS.bj;
    if (v === 'deal') {
      if (g && !g.done) return; if (!casTake(CAS.bet)) return;
      const deck = []; for (const s of ['♠', '♥', '♦', '♣']) for (const r of ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']) deck.push({ r, s });
      for (let i = deck.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
      g = CAS.bj = { deck, p: [deck.pop(), deck.pop()], d: [deck.pop(), deck.pop()], bet: CAS.bet, done: false }; CAS.msg = '';
      if (bjVal(g.p) === 21) bjEnd(g); casRender(); return;
    }
    if (!g || g.done) return;
    if (v === 'hit') { g.p.push(g.deck.pop()); if (bjVal(g.p) >= 21) bjEnd(g); }
    else if (v === 'stand') bjEnd(g);
    else if (v === 'dbl') { if (S.money < g.bet) return; S.money -= g.bet; g.bet *= 2; refreshMoney(false); g.p.push(g.deck.pop()); bjEnd(g); }
    casRender();
  }
}
function bjVal(h) { let t = 0, a = 0; for (const c of h) { if (c.r === 'A') { a++; t += 11; } else t += 'JQK'.includes(c.r) ? 10 : +c.r; } while (t > 21 && a > 0) { t -= 10; a--; } return t; }
function bjEnd(g) {
  const pv = bjVal(g.p); g.done = true;
  if (pv <= 21 && !(pv === 21 && g.p.length === 2)) while (bjVal(g.d) < 17) g.d.push(g.deck.pop());
  const dv = bjVal(g.d), nat = pv === 21 && g.p.length === 2, dnat = dv === 21 && g.d.length === 2; let pay = 0, msg;
  if (pv > 21) msg = 'Перебор! Проигрыш −' + fmtMoney(g.bet);
  else if (nat && !dnat) { pay = Math.round(g.bet * 2.5); msg = '🃏 Блэкджек! Выигрыш ' + fmtMoney(pay - g.bet); }
  else if (dv > 21 || pv > dv) { pay = g.bet * 2; msg = '🎉 Победа! +' + fmtMoney(g.bet); }
  else if (pv === dv && !(dnat && !nat)) { pay = g.bet; msg = 'Ничья — ставка возвращена'; }
  else msg = 'Дилер выиграл −' + fmtMoney(g.bet);
  CAS.msg = msg; casPay(pay); if (!pay) SFX.err();
}


