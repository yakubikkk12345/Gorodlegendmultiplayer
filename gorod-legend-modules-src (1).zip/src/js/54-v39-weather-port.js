/* ===================== v39: ПОГОДА ПО РАСПИСАНИЮ, ЖИВОЙ ПОРТ, ПРОМЗОНЫ, УЛИЧНЫЕ СОБЫТИЯ ===================== */
{
  const rnd = (a, b) => a + Math.random() * (b - a);
  const css = document.createElement('style');
  css.textContent = `
#wxChip, #evChip { position: fixed; left: 50%; transform: translateX(-50%); z-index: 21; padding: 3px 10px; border-radius: 14px; background: rgba(14,18,30,.62); border: 1px solid rgba(255,255,255,.22); color: #fff; font: 600 12px system-ui, sans-serif; white-space: nowrap; backdrop-filter: blur(4px); cursor: pointer; display: none; }
#wxChip { top: calc(var(--safe-t, 0px) + 50px); }
#evChip { top: calc(var(--safe-t, 0px) + 78px); background: rgba(120,20,20,.7); }
#wiper { position: fixed; left: 50%; bottom: 0; width: 0; height: 0; z-index: 4; pointer-events: none; display: none; }
#wiper i { position: absolute; left: -3px; bottom: 0; width: 6px; height: 46vh; background: linear-gradient(#222, #000); border-radius: 3px; transform-origin: 50% 100%; opacity: .5; animation: wipe 1.3s ease-in-out infinite alternate; }
@keyframes wipe { from { transform: rotate(-68deg); } to { transform: rotate(68deg); } }
`;
  document.head.appendChild(css);
  const hud = document.getElementById('hud') || document.body;
  const wxChip = document.createElement('div'); wxChip.id = 'wxChip'; hud.appendChild(wxChip);
  const evChip = document.createElement('div'); evChip.id = 'evChip'; hud.appendChild(evChip);
  const wiper = document.createElement('div'); wiper.id = 'wiper'; wiper.innerHTML = '<i></i>'; document.body.appendChild(wiper);

  /* ---------- 1. Погода по расписанию ---------- */
  const SLOT = 110, seed = Math.floor(Math.random() * 1e6);
  const hash = n => { let x = Math.sin(n * 127.1 + seed * 0.013) * 43758.5453; return x - Math.floor(x); };
  const WT = [
    { n: 'Ясно', ic: '☀️', rain: 0, storm: 0, fog: 0 }, { n: 'Облачно', ic: '⛅', rain: 0, storm: 0, fog: 0 },
    { n: 'Морось', ic: '🌦', rain: 0.4, storm: 0, fog: 0 }, { n: 'Дождь', ic: '🌧', rain: 1, storm: 0, fog: 0 },
    { n: 'Туман', ic: '🌫', rain: 0, storm: 0, fog: 1 }, { n: 'Гроза', ic: '⛈', rain: 1, storm: 1, fog: 0 }
  ];
  const slotType = n => { const u = hash(n); return u < 0.3 ? 0 : u < 0.46 ? 1 : u < 0.6 ? 2 : u < 0.76 ? 3 : u < 0.88 ? 4 : 5; };
  const W9 = { t: rnd(0, SLOT * 0.7), last: -1, aq: 0, aqDir: 1, aqCd: 0, gust: 0, wa: 0, rt: 0 };
  const wxName = w => (WINTER.on ? (w.rain ? (w.storm ? 'Метель' : 'Снегопад') : w.n) : w.n);
  const wxIcon = w => (WINTER.on && w.rain ? '❄️' : w.ic);
  function forecastText() {
    const n = Math.floor(W9.t / SLOT), left = Math.ceil(SLOT - (W9.t % SLOT));
    let s = 'Сейчас: ' + wxIcon(WT[slotType(n)]) + ' ' + wxName(WT[slotType(n)]);
    for (let k = 1; k <= 3; k++) { const w = WT[slotType(n + k)]; s += ' · через ' + Math.round((left + (k - 1) * SLOT) / 60 * 10) / 10 + ' мин ' + wxIcon(w) + ' ' + wxName(w); }
    return s;
  }
  wxChip.addEventListener('click', () => toast('🗓 Прогноз: ' + forecastText().replace('Сейчас: ', '')));
  evChip.addEventListener('click', () => { if (EVT.cur) toast(EVT.cur.hint || 'Событие на улице'); });
  function weatherTick(dt) {
    W9.t += dt;
    WX.t = Math.max(WX.t, 60); WX.fogT = Math.max(WX.fogT, 60);
    const n = Math.floor(W9.t / SLOT);
    if (n !== W9.last) {
      const first = W9.last < 0; W9.last = n;
      const w = WT[slotType(n)];
      WX.tgt = w.rain; WX.storm = WINTER.on ? 0 : w.storm; WX.fogTgt = w.fog;
      if (WX.tgt > 0 && WX.flashT > 3) WX.flashT = 3;
      if (!first && G.mode === 'play') toast(wxIcon(w) + ' Погода: ' + wxName(w) + (slotType(n + 1) !== slotType(n) ? ' · дальше ' + wxName(WT[slotType(n + 1)]).toLowerCase() : ''));
    }
    const w = WT[slotType(n)], left = Math.ceil(SLOT - (W9.t % SLOT));
    const play = G.mode === 'play' && !G.inHome;
    wxChip.style.display = play && !UI.cur ? 'block' : 'none';
    if (play) wxChip.textContent = wxIcon(w) + ' ' + wxName(w) + ' · ' + Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0');
    const c = P.car, wipe = !!c && !c.def.bike && !c.def.heli && WX.rain > 0.25 && !WINTER.on && play;
    wiper.style.display = wipe ? 'block' : 'none';
    // водители осторожнее в дождь и туман
    if ((W9.rt -= dt) <= 0) {
      W9.rt = 1;
      const k = 1 - 0.22 * WX.rain - 0.2 * WX.fog;
      for (const o of cars) if (o.kind === 'traffic' && o.ai && o.ai.base) o.ai.maxSp = o.ai.base * k;
    }
  }
  const sp0 = stepPhys;
  stepPhys = function (c, inp, dt) {
    sp0(c, inp, dt);
    if (c !== P.car || !inp || c.def.heli || G.inHome) return;
    const wet = clamp(WX.rain, 0, 1), fx = Math.sin(c.h), fz = Math.cos(c.h), rx = -fz, rz = fx, sp = Math.abs(c.vf);
    if (wet > 0.05 && inp.brake > 0 && c.vf > 0.6) { const add = c.st.brake * inp.brake * dt * 0.32 * wet; c.vx += fx * add; c.vz += fz * add; }
    if (wet > 0.6 && !c.def.bike) {
      W9.aqCd -= dt;
      if (W9.aq <= 0 && W9.aqCd <= 0 && c.vf > 27 && Math.random() < dt * 0.22 * (1 + (c.vf - 27) / 20)) {
        W9.aq = rnd(0.8, 1.3); W9.aqDir = Math.random() < 0.5 ? -1 : 1; W9.aqCd = 14; toast('💦 Аквапланирование! Сбросьте газ и не рулите резко'); SFX.err(); CAM.shake = Math.max(CAM.shake, 0.3);
      }
      if (W9.aq > 0) { W9.aq -= dt; c.vx += rx * W9.aqDir * 6 * dt; c.vz += rz * W9.aqDir * 6 * dt; c.h += W9.aqDir * 0.32 * dt; c.steer *= 0.9; }
    }
    if (WX.storm > 0.5 && !WINTER.on) {
      W9.wa += dt * 0.05; W9.gust += dt;
      const g = Math.max(0, Math.sin(W9.gust * 0.55)) * Math.max(0, Math.sin(W9.gust * 1.7 + 1)), wx = Math.sin(W9.wa * 6), wz = Math.cos(W9.wa * 6);
      const k = clamp(sp / 10, 0.2, 1) * g * 4.2 * dt; c.vx += wx * k; c.vz += wz * k;
      if (g > 0.6 && sp > 12 && Math.random() < dt * 0.4) CAM.shake = Math.max(CAM.shake, 0.12);
    }
  };

  const cs0 = closeScreens;
  closeScreens = function () { const r = cs0.apply(this, arguments); document.body.classList.remove('scr-on'); return r; };

  /* ---------- 2. Прохожие не ходят на закрытых территориях ---------- */
  const banKeys = () => {
    const out = ['1,3', '14,4', '1,11'];
    const pb = BIZ_BY.port && BIZ_BY.port.blk; if (pb) out.push(pb[0] + ',' + pb[1]);
    return out;
  };
  const up39 = updatePeds;
  updatePeds = function (dt) {
    const bans = banKeys();
    for (const p of peds) {
      if (p.drv || p.fixed || p.thief || p.dead) continue;
      if (bans.indexOf(p.bi + ',' + p.bj) >= 0) {
        for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const ni = clamp(p.bi + d[0], 0, GRID - 1), nj = clamp(p.bj + d[1], 0, GRID - 1);
          if (bans.indexOf(ni + ',' + nj) < 0) { p.bi = ni; p.bj = nj; p.s = Math.random() * 240; break; }
        }
      }
    }
    return up39(dt);
  };

  /* ---------- helpers: рисование ---------- */
  const boxAt = (x, y, z, sx, sy, sz, yaw, c) => { mTRS(DM, x, y, z, yaw || 0, 0, 0, sx, sy, sz); drawMesh(M_UCOL, DM, c[0], c[1], c[2], 1, 0, false); };
  const mkLook = (shirt, pants, hair) => ({ pants: pants || [0.16, 0.18, 0.28], shirt, skin: [0.85, 0.63, 0.48], hair: hair || [0.1, 0.08, 0.06], dark: [0.03, 0.03, 0.03] });
  const GUARD = mkLook([0.12, 0.17, 0.33], [0.1, 0.12, 0.2], [0.07, 0.07, 0.1]);
  const SMUG = mkLook([0.08, 0.08, 0.1], [0.12, 0.12, 0.14], [0.05, 0.05, 0.05]);
  const hasGun = { id: 'pistol', aim: 0.25, kick: 0, reload: 0 }, hasSmg = { id: 'smg', aim: 0.3, kick: 0, reload: 0 };
  function patrol(w, dt, lod, look, gun, carry, standOn) {
    if (w.wait > 0) { w.wait -= dt; w.amp = 0; }
    else {
      const L = Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]) || 1; w.u += w.dir * w.sp * dt / L; w.amp = 0.9; w.ph += dt * w.sp * 3.2;
      if (w.u >= 1 || w.u <= 0) { w.u = Math.min(1, Math.max(0, w.u)); w.dir = -w.dir; w.wait = 1.5 + Math.random() * 3; }
    }
    const x = w.a[0] + (w.b[0] - w.a[0]) * w.u, z = w.a[1] + (w.b[1] - w.a[1]) * w.u;
    w.h = Math.atan2((w.b[0] - w.a[0]) * w.dir, (w.b[1] - w.a[1]) * w.dir); w.x = x; w.z = z;
    const y = terrainY(x, z);
    drawHuman(x, y, z, w.h, w.ph, w.amp, look, lod, 1, gun);
    if (carry) { boxAt(x, y + 1.78, z, 0.5, 0.36, 0.5, w.h, [0.72, 0.5, 0.25]); }
  }

  /* ---------- 3. Порт: кран грузит контейнеры, погрузчик, грузчики, охрана, контрабандисты ---------- */
  const PL = { t: 0, guards: [], smug: [], fk: { u: 0.2, dir: 1, wait: 0 }, load: [], cd: 0, gd: 0, sd: 0, n: 0, cols: [[0.8, 0.2, 0.18], [0.15, 0.4, 0.75], [0.9, 0.65, 0.1], [0.2, 0.6, 0.3], [0.7, 0.35, 0.1]] };
  function portLifeInit() {
    const cx = PORT.x, cz = PORT.z;
    const mk = (a, b, sp) => ({ a, b, sp, u: Math.random(), dir: 1, wait: 0, ph: Math.random() * 6, amp: 0, h: 0 });
    PL.guards = [mk([cx - 29, cz - 27.5], [cx + 29, cz - 27.5], 1.2), mk([cx + 7, cz + 20], [cx + 7, cz + 30], 1.0)];
    PL.smug = [mk([cx - 29.6, cz - 14], [cx - 29.6, cz + 10], 1.1), mk([cx + 4.8, cz + 22], [cx + 9, cz + 30], 1.0)];
    PL.load = [mk([cx - 24, cz + 13], [cx - 16, cz + 19.4], 1.5), mk([cx - 13, cz + 19.4], [cx - 22, cz + 13.5], 1.6), mk([cx - 17, cz + 12], [cx - 11, cz + 12], 1.4)];
    PL.init = true;
  }
  function portLifeDraw(dt) {
    const cx = PORT.x, cz = PORT.z, d = Math.hypot(cx - CAM.x, cz - CAM.z); if (d > 230) return;
    if (!PL.init) portLifeInit();
    const lod = d > 120;
    PL.t += dt;
    // --- кран ---
    const T = 24, ph = PL.t % T, cyc = Math.floor(PL.t / T), X = cx - 17, Pz = cz + 19.5, Dz = cz + 27;
    let z = Pz, hy = 16, cont = false, drop = false;
    if (ph < 3) { hy = 16 - 14.8 * (ph / 3); }
    else if (ph < 4) { hy = 1.2; cont = true; }
    else if (ph < 8) { hy = 1.2 + 12.8 * ((ph - 4) / 4); cont = true; }
    else if (ph < 14) { const u = (ph - 8) / 6, s = u * u * (3 - 2 * u); z = Pz + (Dz - Pz) * s; hy = 14; cont = true; }
    else if (ph < 17) { z = Dz; hy = 14 - 11 * ((ph - 14) / 3); cont = true; }
    else if (ph < 18) { z = Dz; hy = 3; drop = true; }
    else { const u = (ph - 18) / 6, s = u * u * (3 - 2 * u); z = Dz + (Pz - Dz) * s; hy = 3 + 13 * Math.min(1, (ph - 18) / 2); if (ph - 18 > 2) hy = 16; drop = ph < 20; }
    const col = PL.cols[cyc % PL.cols.length], dk = [0.12, 0.12, 0.13];
    boxAt(X, 16.7, z, 3.2, 0.9, 2.2, 0, dk);
    boxAt(X, hy + 2.6, z, 0.12, 16.7 - hy - 2.6, 0.12, 0, [0.1, 0.1, 0.1]);
    boxAt(X, hy + 2.45, z, 2.6, 0.25, 6.2, 0, dk);
    if (cont) boxAt(X, hy - 0.2, z, 2.4, 2.6, 6.0, 0, col);
    if (drop) boxAt(X, 1.5, Dz, 2.4, 2.6, 6.0, 0, col);
    if (ph > 20 && ph <= 24 && false) boxAt(X, 1.5, Dz, 2.4, 2.6, 6.0, 0, col);
    // --- погрузчик ---
    const f = PL.fk; if (f.wait > 0) f.wait -= dt; else { f.u += f.dir * 3 * dt / 24; if (f.u >= 1 || f.u <= 0) { f.u = clamp(f.u, 0, 1); f.dir = -f.dir; f.wait = 2.5; } }
    const fx = cx - 12 + 24 * f.u, fz = cz + 13.6, fy = 0.3, yaw = f.dir > 0 ? Math.PI / 2 : -Math.PI / 2, s = Math.sin(yaw), c = Math.cos(yaw);
    boxAt(fx, fy + 0.3, fz, 1.5, 1.2, 2.4, yaw, [0.95, 0.75, 0.1]); boxAt(fx + s * 1.5, fy, fz + c * 1.5, 0.12, 2.2, 0.12, yaw, [0.2, 0.2, 0.22]);
    boxAt(fx + s * 1.7, fy + 0.3, fz + c * 1.7, 1.1, 0.1, 1.0, yaw, [0.2, 0.2, 0.22]);
    boxAt(fx + s * 1.9, fy + 0.4, fz + c * 1.9, 1.1, 0.9, 1.0, yaw, PL.cols[(cyc + 2) % PL.cols.length]);
    // --- грузчики и охрана ---
    PL.load.forEach((w, i) => patrol(w, dt, lod, PW.look, null, i < 2));
    const gH = PL.gd > 0, sH = PL.sd > 0;
    if (!gH) for (const w of PL.guards) patrol(w, dt, lod, GUARD, hasGun, false);
    if (!sH) for (const w of PL.smug) patrol(w, dt, lod, SMUG, hasSmg, false);
  }
  function mkEnemy(x, z, look, gun, hp, dmg, gang) {
    const e = { x, z, h: 0, hp, maxhp: hp, cd: rnd(0.6, 1.2), ph: Math.random() * 6, amp: 0, sp: rnd(3.8, 4.8), pref: rnd(9, 15), sdir: Math.random() < 0.5 ? 1 : -1, sflip: rnd(1, 3), hit: 0, boss: false, sc: 1, cop: false, gang: gang || 0, look,
      gun: { id: gun, aim: 0, kick: 0, reload: 0 }, dmg, rate: rnd(1.0, 1.6) };
    pushCircle(e, 0.6); GANG.units.push(e); return e;
  }
  function portAlert(dt) {
    if (!PL.init) return;
    const cx = PORT.x, cz = PORT.z, inP = Math.abs(P.x - cx) < 36 && Math.abs(P.z - cz) < 36 && !G.inHome;
    PL.gd -= dt; PL.sd -= dt;
    if (!inP) return;
    if (PL.gd <= 0 && !P.car && PGUN.kick > 0.5) {
      PL.gd = 100; toast('🛡 Охрана порта открыла огонь!');
      for (const w of PL.guards) { const e = mkEnemy(w.x || cx, w.z || cz - 27, GUARD, 'pistol', 60, 4, 0); e.guard39 = true; }
    }
    if (PL.sd <= 0 && !portOwn()) {
      for (const w of PL.smug) if (w.x !== undefined && Math.hypot(w.x - P.x, w.z - P.z) < 17) {
        PL.sd = 120; toast('☠ Контрабандисты заметили чужака и открыли огонь!');
        for (const q of PL.smug) { const e = mkEnemy(q.x, q.z, SMUG, 'smg', 52, 4, 0); e.smug39 = true; }
        break;
      }
    }
  }
  const dg0 = damageGang;
  damageGang = function (e, dmg) {
    const alive = e.hp > 0; dg0(e, dmg);
    if (alive && e.hp <= 0) {
      if (e.smug39) { addMoney(300); toast('💰 Контрабандист убит: +$300 (при нём были деньги)'); }
      if (e.rob39) EVT.onRobberDown(e);
    }
  };

  /* ---------- 4. Промзоны: рабочие ---------- */
  const IND_LOOK = {};
  function indDraw(dt) {
    if (!indKind.w) return;
    for (const k in indKind.w) {
      const wk = indKind.w[k]; if (!wk.length) continue;
      const key = k === 'build' ? '1,3' : k === 'ware' ? '14,4' : '1,11', a = key.split(',').map(Number);
      const cx = bc(a[0]), cz = bc(a[1]);
      if (Math.hypot(cx - CAM.x, cz - CAM.z) > 200) continue;
      for (const w of wk) {
        const look = IND_LOOK[w.vest.join()] || (IND_LOOK[w.vest.join()] = mkLook(w.vest, [0.2, 0.22, 0.3], w.vest[0] < 0.3 ? [0.07, 0.07, 0.1] : [0.95, 0.8, 0.1]));
        patrol(w, dt, false, look, w.vest[0] < 0.2 ? hasGun : null, w.carry);
      }
    }
  }

  /* ---------- 5. Уличные события ---------- */
  const EVT = { t: rnd(50, 90), cur: null, cd: 0 };
  const stdLook = (r, g, b) => mkLook([r, g, b], [0.2, 0.22, 0.3]);
  const ROBBER = mkLook([0.15, 0.15, 0.17], [0.1, 0.1, 0.12], [0.05, 0.05, 0.05]);
  const T_END = () => { const e = EVT.cur; if (e && e.clean) e.clean(); EVT.cur = null; evChip.style.display = 'none'; EVT.t = rnd(75, 150); };
  function pickRoadNear(dmin, dmax) {
    const ci = Math.round((P.x + HALF) / PITCH), cj = Math.round((P.z + HALF) / PITCH);
    for (let k = 0; k < 80; k++) {
      const i = clamp(ci + Math.floor(rnd(-3, 4)), 0, GRID), j = clamp(cj + Math.floor(rnd(-3, 4)), 0, GRID), d = Math.floor(Math.random() * 4), f = DIRS[d];
      if (i + f[0] < 0 || j + f[1] < 0 || i + f[0] > GRID || j + f[1] > GRID) continue;
      const x = nodeC(i) + f[0] * 30, z = nodeC(j) + f[1] * 30, dd = Math.hypot(x - P.x, z - P.z);
      if (dd >= dmin && dd <= dmax) return { i, j, d, f, x, z };
    }
    return null;
  }
  const aq0 = aiPlan;
  aiPlan = function (c) {
    const ai = c.ai;
    if (ai.mode === 'follow') {
      const L = ai.leader, i0 = ai.i, j0 = ai.j, d0 = ai.d; let dOut = null;
      const e = L && L.trail && L.trail.find(q => q.i === i0 && q.j === j0); if (e) dOut = e.d2;
      if (dOut == null) { const o = validDirs(i0, j0, d0); dOut = o.indexOf(d0) >= 0 ? d0 : o[0]; }
      pushTransition(ai, i0, j0, d0, dOut, LANE, 14); ai.i += DIRS[dOut][0]; ai.j += DIRS[dOut][1]; ai.d = dOut; return;
    }
    const i0 = ai.i, j0 = ai.j;
    aq0(c);
    if (c.evLead) c.trail.push({ i: i0, j: j0, d2: ai.d });
  };
  const sa0 = stepAI;
  stepAI = function (c, dt) {
    if (c.kind === 'event' && c.ai && !c.ai.hold) { const o = obstacleSpeed(c, dt); c.ai.maxSp = Math.max(10, Math.min(c.ai.base, o)); }
    return sa0(c, dt);
  };
  function startChase() {
    const r = pickRoadNear(95, 190); if (!r) return false;
    const flee = makeCar(CAR_BY_ID.sport, 'event', '#e0a000'), pol = makeCar(POLICE_DEF, 'event', '#f5f5f5'), pol2 = makeCar(POLICE_DEF, 'event', '#f5f5f5');
    initNavAI(flee, 'traffic', r.i, r.j, r.d, LANE, 36, 20); flee.x += r.f[0] * 34; flee.z += r.f[1] * 34; flee.evLead = true; flee.trail = [];
    initNavAI(pol, 'follow', r.i, r.j, r.d, LANE, 38, 21); pol.ai.leader = flee; pol.x -= r.f[0] * 8; pol.z -= r.f[1] * 8;
    initNavAI(pol2, 'follow', r.i, r.j, r.d, LANE, 38, 21); pol2.ai.leader = flee; pol2.x -= r.f[0] * 24; pol2.z -= r.f[1] * 24;
    for (const c of [flee, pol, pol2]) { c.ai.hold = false; c.ai.base = c.ai.maxSp; }
    const cs = [flee, pol, pol2];
    EVT.cur = { type: 'chase', t: 0, cars: cs, flee, done: 0, hint: '🚨 Погоня! Таран беглеца остановит его — награда за помощь.', clean() { for (const c of cs) removeCar(c); } };
    toast('🚨 Погоня! Полиция преследует беглеца — остановите его тараном (+$). Метка — красный значок.');
    return true;
  }
  function tickChase(e, dt) {
    const f = e.flee; e.t += dt;
    if (e.done) { if ((e.done += dt) > 9) T_END(); return; }
    const pc = P.car;
    if (pc && Math.hypot(pc.x - f.x, pc.z - f.z) < 7 && f.hitT > 0 && Math.abs(pc.vf) > 6) {
      const r = 400 + Math.floor(Math.random() * 7) * 100; addMoney(r); SFX.cash(); S.flags.chases = (S.flags.chases || 0) + 1; persist();
      toast('🚔 Беглец остановлен! Полиция благодарит: +' + fmtMoney(r)); f.ai.hold = true; e.cars.forEach(c => c.ai && (c.ai.hold = true)); e.done = 0.01; return;
    }
    const far = e.cars.every(c => Math.hypot(c.x - P.x, c.z - P.z) > 260);
    if (e.t > 85 || far) { toast('Погоня ушла из виду.'); T_END(); }
  }
  function startCrash() {
    const r = pickRoadNear(70, 140); if (!r) return false;
    const rt = rightOf(r.d), h = Math.atan2(r.f[0], r.f[1]);
    const defs = [CAR_BY_ID.sedan, CAR_BY_ID.hatch, CAR_BY_ID.suv, CAR_BY_ID.pickup];
    const a = makeCar(defs[Math.floor(Math.random() * 4)], 'parked', pick(COLORS)), b = makeCar(defs[Math.floor(Math.random() * 4)], 'parked', pick(COLORS));
    const x = r.x + rt[0] * LANE, z = r.z + rt[1] * LANE;
    a.x = x; a.z = z; a.h = h + 0.35; b.x = x + r.f[0] * 4.2 - rt[0] * 1.4; b.z = z + r.f[1] * 4.2 - rt[1] * 1.4; b.h = h - 0.9;
    a.dmg = 75; b.dmg = 60; a.vx = a.vz = b.vx = b.vz = 0;
    const wit = [];
    const shirts = [[0.8, 0.3, 0.3], [0.3, 0.5, 0.8], [0.9, 0.8, 0.3], [0.4, 0.7, 0.4], [0.7, 0.4, 0.8]];
    for (let k = 0; k < 4; k++) {
      const ang = k * 1.6 + 0.4, px = x + rt[0] * 5 + Math.sin(ang) * 3.5, pz = z + rt[1] * 5 + Math.cos(ang) * 3.5;
      const p = { fixed: true, ev39: true, x: px, z: pz, h: Math.atan2(x - px, z - pz), ph: Math.random() * 6, amp: 0, hp: 30, dir: 1, sp: 1, bi: 0, bj: 0, s: 0, look: stdLook(...shirts[k % shirts.length]) };
      peds.push(p); wit.push(p);
    }
    const inj = { fixed: true, ev39: true, x: x + r.f[0] * 2.2 + rt[0] * 2.8, z: z + r.f[1] * 2.2 + rt[1] * 2.8, h: 1, ph: 0, amp: 0, hp: 30, dir: 1, sp: 1, bi: 0, bj: 0, s: 0, look: stdLook(0.6, 0.6, 0.65), fall: 0.7 };
    peds.push(inj); wit.push(inj);
    const cs = [a, b];
    EVT.cur = { type: 'crash', t: 0, cars: cs, wit, x, z, near: 0, done: 0, said: false, hint: '🚑 ДТП! Подойдите пешком к пострадавшим и помогите.',
      clean() { for (const c of cs) removeCar(c); for (const p of wit) p.rm = true; } };
    toast('🚑 Авария! Свидетели на дороге — подойдите и помогите пострадавшим.');
    return true;
  }
  function tickCrash(e, dt) {
    e.t += dt;
    if ((e.sm = (e.sm || 0) - dt) <= 0) { e.sm = 0.2; emit(e.x + rnd(-1, 1), 1.1, e.z + rnd(-1, 1), rnd(-0.3, 0.3), 1.2, rnd(-0.3, 0.3), 1.6, 0.4, 1.7, 0.5, 0.5, 0.5, 0.5, false); }
    const d = Math.hypot(P.x - e.x, P.z - e.z), px = P.car ? P.car : P;
    if (e.done) { if ((e.done += dt) > 6) T_END(); return; }
    if (!e.said && Math.hypot(px.x - e.x, px.z - e.z) < 22) { e.said = true; for (const p of e.wit) p.panic = 0; toast(P.car ? '🚑 Остановитесь, выйдите из машины и подойдите к пострадавшим' : '👥 Свидетели: «Помогите ему!» Подойдите ближе.'); }
    if (!P.car && d < 6 && P.speed < 1) e.near += dt; else e.near = Math.max(0, e.near - dt);
    if (e.near > 2.5) {
      const r = 150 + Math.floor(Math.random() * 4) * 50; addMoney(r); SFX.cash(); S.flags.crashHelp = (S.flags.crashHelp || 0) + 1; persist();
      toast('🚑 Вы вызвали скорую и помогли пострадавшим. Свидетели благодарят: +' + fmtMoney(r)); e.done = 0.01; for (const p of e.wit) p.fall = 0;
    } else if (e.t > 120 || d > 230) T_END();
  }
  function startRobbery() {
    const c = peds.filter(p => !p.dead && !p.fixed && !p.thief && !p.talk && !p.drv && Math.hypot(p.x - P.x, p.z - P.z) > 26 && Math.hypot(p.x - P.x, p.z - P.z) < 46);
    if (!c.length) return false;
    const v = pick(c), ang = Math.random() * TAU, rx = v.x + Math.sin(ang) * 2.2, rz = v.z + Math.cos(ang) * 2.2;
    v.fixed = true; v.fall = 0; v.panic = 0; v.h = Math.atan2(rx - v.x, rz - v.z);
    const rob = mkEnemy(rx, rz, ROBBER, 'pistol', 48, 4, 0); rob.rob39 = true; rob.sp = 0; rob.cd = 99; rob.h = Math.atan2(v.x - rx, v.z - rz);
    EVT.cur = { type: 'rob', t: 0, v, rob, aggro: false, done: 0, hint: '🔫 Ограбление! Бандит держит прохожего под прицелом.', clean() { v.fixed = false; pedSnapToLoop(v); const i = GANG.units.indexOf(rob); if (i >= 0) GANG.units.splice(i, 1); } };
    toast('🔫 Ограбление! Бандит грабит прохожего поблизости — остановите его (+$).');
    return true;
  }
  EVT.onRobberDown = e => {
    const c = EVT.cur; if (!c || c.type !== 'rob' || c.rob !== e) return;
    const r = 300 + Math.floor(Math.random() * 5) * 100; addMoney(r); SFX.cash(); S.flags.robStop = (S.flags.robStop || 0) + 1; persist();
    toast('👮 Ограбление предотвращено! Жертва благодарит: +' + fmtMoney(r)); c.v.panic = 3; c.done = 0.01; c.v.fixed = false; c.rob = null;
  };
  function tickRob(e, dt) {
    e.t += dt;
    if (e.done) { if ((e.done += dt) > 4) T_END(); return; }
    const r = e.rob, d = Math.hypot(P.x - r.x, P.z - r.z);
    if (GANG.units.indexOf(r) < 0) { toast('Грабитель скрылся.'); T_END(); return; }
    if (!e.aggro) {
      r.sp = 0; if (d > 52) { toast('Грабитель скрылся.'); T_END(); return; } r.cd = Math.max(r.cd, 3);
      if (d < 24 || r.hp < r.maxhp) { e.aggro = true; r.sp = 4.4; r.cd = 0.7; e.v.fixed = false; e.v.panic = 6; toast('🔫 Грабитель открыл огонь!'); }
      else if (e.t > 85) { toast('Грабитель скрылся с добычей.'); T_END(); }
    } else if (e.t > 140) T_END();
  }
  function evTick(dt) {
    const play = G.mode === 'play' && !G.inHome && !G.paused;
    if (!play) return;
    const e = EVT.cur;
    if (!e) {
      if ((EVT.t -= dt) <= 0) {
        if (M || WANT.stars > 0 || EV.thief || EV.wallet || P.hp <= 0 || (JOB && JOB.state && JOB.state !== 'idle')) { EVT.t = 20; return; }
        const u = Math.random(); let ok = u < 0.35 ? startChase() : u < 0.7 ? startCrash() : startRobbery();
        if (!ok) EVT.t = 15;
      }
      return;
    }
    if (M || WANT.stars > 0 && e.type === 'chase') { /* миссия/розыск — продолжаем */ }
    ({ chase: tickChase, crash: tickCrash, rob: tickRob })[e.type](e, dt);
    if (EVT.cur) {
      const tx = e.type === 'chase' ? e.flee.x : e.type === 'crash' ? e.x : e.rob ? e.rob.x : P.x, tz = e.type === 'chase' ? e.flee.z : e.type === 'crash' ? e.z : e.rob ? e.rob.z : P.z;
      evChip.style.display = UI.cur ? 'none' : 'block';
      evChip.textContent = (e.type === 'chase' ? '🚨 Погоня' : e.type === 'crash' ? '🚑 Авария' : '🔫 Ограбление') + ' · ' + Math.round(Math.hypot(tx - P.x, tz - P.z)) + ' м';
    }
  }
  // свидетели виновного ДТП
  let witCd = 0;
  const cf0 = crashFx;
  crashFx = function (c, imp) {
    cf0(c, imp);
    if (c !== P.car || imp < 8 || M || G.mode !== 'play' || witCd > G.time) return;
    const other = cars.some(o => o !== c && (o.kind === 'traffic' || o.kind === 'parked') && Math.hypot(o.x - c.x, o.z - c.z) < 6.5);
    if (!other) return;
    const w = peds.filter(p => !p.dead && !p.ev39 && Math.hypot(p.x - c.x, p.z - c.z) < 30);
    if (!w.length) return;
    witCd = G.time + 15; for (const p of w) p.panic = 6;
    if (WANT.stars === 0) crimeWanted(1, 'ДТП со свидетелями'); else toast('👥 Свидетели запомнили ваш номер');
  };

  /* ---------- хуки: тик и отрисовка ---------- */
  const lt0 = lifeTick;
  lifeTick = function (dt) {
    lt0(dt);
    weatherTick(dt);
    if (G.mode === 'play' && !G.inHome) { portAlert(dt); evTick(dt); }
    else if (EVT.cur) T_END();
  };
  const vd0 = v31Draw;
  v31Draw = function () {
    vd0();
    const dt = 1 / 60;
    portLifeDraw(dt); indDraw(dt);
  };
  window.__v39 = { EVT, W9, PL, startChase, startCrash, startRobbery, slotType, forecastText, indKind };
}

