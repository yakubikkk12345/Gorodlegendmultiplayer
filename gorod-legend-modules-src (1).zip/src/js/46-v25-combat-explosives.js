/* ===================== v25: бой, взрывчатка, топливо и повреждения ===================== */
const CB = { crouch: false, block: false, roll: 0, rh: 0, inv: 0, cool: 0, combo: 0, comboT: 0, cover: false, coverT: 0, inp: null, badge: '', btnT: 0 };
const GRN = [], BOMBS = [], BURN = [];
const EXP = { gren: { ico: '💣', name: 'Граната', n: 3, price: 300, max: 20, info: 'Радиус ≈ 9 м, взрыв через 2 секунды. Клавиша Q.' }, c4: { ico: '🧨', name: 'Взрывчатка C4', n: 2, price: 800, max: 10, info: 'Заложите и подорвите (B), радиус ≈ 12 м, мощнее гранаты.' } };
function expN(id) { return (S.guns && S.guns[id]) || 0; }
function expCards() {
  return Object.keys(EXP).map(id => {
    const e = EXP[id], n = expN(id), cost = e.price;
    return '<div class="card"><div class="c-body"><b>' + e.ico + ' ' + e.name + '</b><small>' + e.info + '</small><div class="gbtns"><button class="btn small" data-gbuy="' + id + '"' + (S.money < cost || n + e.n > e.max ? ' disabled' : '') + '>+' + e.n + ' · ' + fmtMoney(cost) + '</button><span class="tag">В запасе: ' + n + '</span></div></div></div>';
  }).join('');
}
function buyExp(id) {
  const e = EXP[id]; if (!e) return;
  if (expN(id) + e.n > e.max) { toast('Больше не унести'); SFX.err(); return; }
  if (S.money < e.price) { SFX.err(); toast('Не хватает денег'); return; }
  S.money -= e.price; S.guns[id] = expN(id) + e.n; SFX.buy(); persist(); refreshMoney(true); toast(e.ico + ' ' + e.name + ': +' + e.n); renderGunshop();
}
function cbCover() {
  if (G.inHome) return false;
  for (let k = 0; k < boxes.length; k++) { const b = boxes[k]; if (b.h < 0.9) continue; if (P.x > b.x0 - 1.4 && P.x < b.x1 + 1.4 && P.z > b.z0 - 1.4 && P.z < b.z1 + 1.4) return true; }
  for (const c of cars) if (c !== P.car && Math.hypot(c.x - P.x, c.z - P.z) < 3) return true;
  return false;
}
function cbDefense() { let f = 1; if (CB.block) f *= 0.35; if (CB.crouch) f *= CB.cover ? 0.4 : 0.65; return f; }
function cbSpeedMul() { return CB.block ? 0.5 : CB.crouch ? 0.55 : 1; }
function cbZ() {
  if (P.car || P.hp <= 0 || G.paused) return;
  const moving = P.speed > 2.4 || (CB.inp && (Math.abs(CB.inp.x) + Math.abs(CB.inp.y) > 0.3));
  if (moving) {
    if (CB.cool > 0 || CB.roll > 0) return;
    let h = P.h;
    if (CB.inp && (CB.inp.x || CB.inp.y)) { const fx = Math.sin(CAM.yaw), fz = Math.cos(CAM.yaw), wx = fx * CB.inp.y - fz * CB.inp.x, wz = fz * CB.inp.y + fx * CB.inp.x; h = Math.atan2(wx, wz); }
    CB.rh = h; P.h = h; CB.roll = 0.5; CB.inv = 0.45; CB.cool = 1.0; CB.crouch = false; SFX.click();
  } else { CB.crouch = !CB.crouch; toast(CB.crouch ? '🛡 Присели: урон снижен (рядом с укрытием — ещё сильнее)' : 'Встали'); }
}
function cbMelee(t, kind, base) {
  let dm = base;
  const now = G.time;
  CB.combo = (now - CB.comboT < 0.9) ? CB.combo + 1 : 1; CB.comboT = now;
  if (CB.combo === 2) dm *= 1.25; else if (CB.combo >= 3) { dm *= 1.6; CB.combo = 0; toast('💥 Комбо!'); CAM.shake = Math.max(CAM.shake, 0.25); if (t) { t.x += Math.sin(P.h) * 1.4; t.z += Math.cos(P.h) * 1.4; } }
  if (kind !== 'ped' && t && t.hp !== undefined && t.hp > 0 && t.hp <= 22 && t.hp > dm * 0.0) { if (t.hp > dm) { dm = t.hp + 1; toast('☠ Добивание!'); P.hp = Math.min(100, P.hp + 6); } }
  return dm;
}
function expPlayerDist(x, z) { return Math.hypot(x - P.x, z - P.z); }
function throwGrenade() {
  if (P.car || G.inHome || P.hp <= 0) { toast('Здесь не бросить'); return; }
  if (expN('gren') < 1) { toast('💣 Нет гранат — купите в оружейном'); SFX.err(); return; }
  S.guns.gren--; persist();
  let a = P.h, v = 13;
  const tg = pickTarget(30); if (tg) { a = Math.atan2(tg.x - P.x, tg.z - P.z); v = clamp(Math.hypot(tg.x - P.x, tg.z - P.z) * 0.9, 7, 18); }
  P.h = a; P.aimT = 0.4; PGUN.kick = 1; SFX.click();
  GRN.push({ x: P.x + Math.sin(a) * 0.7, y: 1.5, z: P.z + Math.cos(a) * 0.7, vx: Math.sin(a) * v, vz: Math.cos(a) * v, vy: 5.5, t: 1.8 });
  crimeWanted(1, 'бросок гранаты');
}
function c4Action() {
  if (BOMBS.length) { const arr = BOMBS.splice(0); for (const b of arr) boom(b.x, b.z, 12, 150, 'player'); return; }
  if (P.car || G.inHome || P.hp <= 0) { toast('Здесь не заложить'); return; }
  if (expN('c4') < 1) { toast('🧨 Нет C4 — купите в оружейном'); SFX.err(); return; }
  S.guns.c4--; persist(); BOMBS.push({ x: P.x + Math.sin(P.h) * 0.8, z: P.z + Math.cos(P.h) * 0.8, t: 0 });
  toast('🧨 C4 заложена. Отойдите и нажмите B ещё раз, чтобы подорвать'); SFX.click();
}
function boom(x, z, r, dmg, src) {
  const y = terrainY(x, z) + 0.5;
  for (let i = 0; i < 30; i++) emit(x + rand(-0.6, 0.6), y + rand(0, 1), z + rand(-0.6, 0.6), rand(-r, r) * 0.5, rand(2, 9), rand(-r, r) * 0.5, 0.5 + Math.random() * 0.5, 0.5, 3.4, 1, 0.5 + Math.random() * 0.35, 0.1, 1, true);
  for (let i = 0; i < 20; i++) emit(x + rand(-1, 1), y + rand(0, 1.5), z + rand(-1, 1), rand(-2, 2), rand(1, 4), rand(-2, 2), 1.6, 0.9, 4.2, 0.25, 0.25, 0.27, 0.7, false);
  SFX.crash(40); SFX.crash(25);
  const dP = expPlayerDist(x, z); CAM.shake = Math.max(CAM.shake, clamp(1.1 - dP / 40, 0, 1));
  const hit = (e, apply) => { const d = Math.hypot(e.x - x, e.z - z); if (d < r) apply(Math.max(10, dmg * (1 - d / r))); };
  if (M && M.enemies) for (const e of M.enemies.slice()) hit(e, f => damageEnemy(e, f));
  for (const e of WANT.units.slice()) hit(e, f => damageCop(e, f));
  for (const e of GANG.units.slice()) hit(e, f => damageGang(e, f));
  for (const p of peds) { if (p.dead) continue; const d = Math.hypot(p.x - x, p.z - z); if (d < r) damagePed(p, dmg * (1 - d / r) * 2.2 + 10); else if (d < r * 3) p.panic = 6; }
  for (const c of cars) {
    const dx = c.x - x, dz = c.z - z, d = Math.hypot(dx, dz); if (d > r * 1.3 || c.def.heli) continue;
    const f = 1 - d / (r * 1.3), n = d || 1;
    c.vx += dx / n * f * 20; c.vz += dz / n * f * 20; c.vf *= 0.5; if (c.ai) c.spd = (c.spd || 0) * 0.3;
    carInit(c); c.dmg = Math.min(100, (c.dmg || 0) + f * 95);
    if (c.dmg >= 90 && !(c.burn > 0)) { c.burn = 14; BURN.push(c); }
  }
  if (dP < r) { const f = Math.max(0.15, 1 - dP / r); if (P.car) { carInit(P.car); P.car.dmg = Math.min(100, (P.car.dmg || 0) + f * 60); hurtPlayer(dmg * f * 0.35, 'boom'); } else hurtPlayer(dmg * f * 0.7, 'boom'); }
  if (src === 'player') crimeWanted(2, 'взрыв');
}
function v25Combat(dt, inp) {
  if (CB.roll > 0) CB.roll = Math.max(0, CB.roll - dt);
  if (CB.inv > 0) CB.inv -= dt;
  if (CB.cool > 0) CB.cool -= dt;
  CB.block = !!(keys.KeyV || touch.block) && !P.car && !G.inHome;
  if (P.car || G.inHome) CB.crouch = false;
  if (CB.crouch && inp && inp.run) CB.crouch = false;
  if ((CB.coverT -= dt) <= 0) { CB.coverT = 0.25; CB.cover = CB.crouch ? cbCover() : false; }
  PLAYER_LOOK._sy = CB.roll > 0 ? 1 : CB.crouch ? 0.74 : 1;
  if (CB.block && !(P.aimT > 0)) P.aimT = 0.1;
}
function v25Tick(dt) {
  // гранаты
  for (let i = GRN.length - 1; i >= 0; i--) {
    const g = GRN[i];
    g.t -= dt; g.vy -= 22 * dt;
    g.x += g.vx * dt; g.z += g.vz * dt; g.y += g.vy * dt;
    const q = { x: g.x, z: g.z };
    if (g.y < 2.6 && pushCircle(q, 0.25, 0)) { g.x = q.x; g.z = q.z; const vn = g.vx * HIT.nx + g.vz * HIT.nz; if (vn < 0) { g.vx -= 1.7 * vn * HIT.nx; g.vz -= 1.7 * vn * HIT.nz; } }
    const gy = terrainY(g.x, g.z) + 0.15;
    if (g.y < gy) { g.y = gy; g.vy = -g.vy * 0.35; g.vx *= 0.7; g.vz *= 0.7; if (Math.abs(g.vy) < 1) g.vy = 0; }
    if (g.t <= 0) { GRN.splice(i, 1); boom(g.x, g.z, 9, 95, 'player'); }
  }
  for (const b of BOMBS) b.t += dt;
  // горящие и дымящие машины
  for (let i = BURN.length - 1; i >= 0; i--) {
    const c = BURN[i]; c.burn -= dt;
    if (c.burn <= 0 || !cars.includes(c)) { c.burn = 0; BURN.splice(i, 1); continue; }
    if (Math.random() < dt * 14) { emit(c.x + rand(-0.8, 0.8), 0.9, c.z + rand(-0.8, 0.8), rand(-0.5, 0.5), rand(2, 4), rand(-0.5, 0.5), 0.5, 0.5, 0.1, 1, 0.5, 0.1, 0.9, true); emit(c.x, 1.3, c.z, rand(-0.5, 0.5), rand(1.5, 3), rand(-0.5, 0.5), 1.4, 0.5, 2.2, 0.2, 0.2, 0.22, 0.6, false); }
  }
  // дым от повреждённой машины игрока
  const pc = P.car;
  if (pc && !pc.def.heli) {
    carInit(pc);
    const d = pc.dmg || 0;
    if (d > 45 && Math.random() < dt * (4 + d * 0.12)) {
      const fx = Math.sin(pc.h), fz = Math.cos(pc.h), g = 0.15 + Math.random() * 0.2 + (d > 85 ? 0 : 0.15);
      emit(pc.x + fx * pc.L * 0.38, 1.0, pc.z + fz * pc.L * 0.38, rand(-0.4, 0.4), rand(1, 2.2), rand(-0.4, 0.4), 1.1, 0.3, 1.3, g, g, g, 0.55, false);
      if (d > 85) emit(pc.x + fx * pc.L * 0.38, 0.9, pc.z + fz * pc.L * 0.38, rand(-0.3, 0.3), rand(1, 2), rand(-0.3, 0.3), 0.4, 0.4, 0.05, 1, 0.5, 0.1, 0.9, true);
    }
  }
  // сохранение состояния своей машины
  if ((CB.sv = (CB.sv || 0) + dt) > 4) { CB.sv = 0; if (OWN && OWN.fuel !== undefined && S.cars[OWN.recId]) { S.cars[OWN.recId].fuel = OWN.fuel; S.cars[OWN.recId].dmg = OWN.dmg || 0; } }
  // значки и кнопки
  if ((CB.btnT -= dt) <= 0) {
    CB.btnT = 0.3;
    const el = $('cbBadge'), bt = $('cbBtns');
    const parts = [];
    if (CB.block) parts.push('✋ БЛОК'); else if (CB.crouch) parts.push(CB.cover ? '🛡 В УКРЫТИИ' : '🛡 ПРИСЕЛ');
    if (expN('gren') > 0) parts.push('💣 ×' + expN('gren') + ' (Q)');
    if (expN('c4') > 0 || BOMBS.length) parts.push('🧨 ×' + expN('c4') + (BOMBS.length ? ' · заложено ' + BOMBS.length + ' (B — подрыв)' : ' (B)'));
    const txt = parts.join('\n');
    if (el) { if (txt !== CB.badge) { CB.badge = txt; el.textContent = ''; for (const p of parts) { const d = document.createElement('div'); d.textContent = p; el.appendChild(d); } } el.style.display = parts.length && G.mode === 'play' && !G.inHome ? 'block' : 'none'; }
    if (bt) bt.style.display = UI.touchMode && G.mode === 'play' && !P.car && !G.inHome ? 'flex' : 'none';
  }
}
function drawExplosives() {
  for (const g of GRN) {
    mTRS(DM, g.x, g.y, g.z, 0, 0, 0, 0.3, 0.3, 0.3); drawMesh(M_UCOL, DM, 0.14, 0.22, 0.14, 1, 0, false);
    const bl = g.t < 0.7 && Math.floor(G.time * 12) % 2;
    mTRS(DM, g.x, g.y + 0.3, g.z, 0, 0, 0, 0.12, 0.12, 0.12); drawMesh(M_UCOL, DM, bl ? 1 : 0.5, bl ? 0.2 : 0.1, 0.1, 1, 1, false);
  }
  for (const b of BOMBS) {
    const y = terrainY(b.x, b.z);
    mTRS(DM, b.x, y + 0.02, b.z, 0, 0, 0, 0.55, 0.16, 0.4); drawMesh(M_UCOL, DM, 0.25, 0.27, 0.2, 1, 0, false);
    const bl = Math.floor(b.t * 2.5) % 2;
    mTRS(DM, b.x, y + 0.18, b.z, 0, 0, 0, 0.1, 0.08, 0.1); drawMesh(M_UCOL, DM, bl ? 1 : 0.3, 0.05, 0.05, 1, 1, false);
  }
}
/* --- топливо и повреждения --- */
function carInit(c) {
  if (c.fuel !== undefined) return;
  const rec = c === OWN && c.recId ? S.cars[c.recId] : null;
  c.fuel = rec && rec.fuel !== undefined ? rec.fuel : (c === OWN ? 1 : rand(0.45, 1));
  c.dmg = rec && rec.dmg ? rec.dmg : 0;
  c.pullDir = Math.random() < 0.5 ? -1 : 1;
}
function v25Car(c, inp, dt) {
  carInit(c);
  if (c === P.car) {
    const thr = inp.gas || 0;
    c.fuel = Math.max(0, c.fuel - dt * (0.0011 + 0.0042 * thr + (c.nitroOn ? 0.004 : 0)));
    if (c.fuel < 0.12 && !c.warnLow) { c.warnLow = true; toast('⛽ Топливо на исходе — ищите АЗС (оранжевая метка на карте)'); }
    if (c.fuel > 0.2) { c.warnLow = false; c.warnEmpty = false; }
    if (c.fuel <= 0 && !c.warnEmpty) { c.warnEmpty = true; toast('⛽ Бензин закончился! Машина ползёт — доберитесь до АЗС'); SFX.err(); }
  }
  let m = 1 - 0.35 * (c.dmg || 0) / 100;
  if (c.fuel <= 0) m *= 0.22;
  c.lim = m < 0.999;
  return m;
}
function carHurt(c, imp) {
  if (c.def.heli) return;
  carInit(c); imp *= (c.def.dmgK || 1);
  const was = c.dmg || 0;
  c.dmg = Math.min(100, was + imp * 0.55);
  if (was < 60 && c.dmg >= 60) toast('🔧 Машина сильно повреждена — руль уводит, скорость падает. Ремонт — на АЗС');
  if (was < 100 && c.dmg >= 100) { toast('🔥 Машина вся в дыму и огне! Срочно на ремонт'); if (!(c.burn > 0)) { c.burn = 8; BURN.push(c); } }
}
function fuelOpts() {
  const c = P.car || (OWN && Math.hypot(OWN.x - P.x, OWN.z - P.z) < 50 ? OWN : null);
  if (!c || c.def.heli) return [{ t: '⛽ Подгоните машину к заправке (в пределах 50 м)', dis: true, fn: () => { } }];
  carInit(c);
  const need = Math.round((1 - c.fuel) * 100), cost = Math.ceil(need * 1.2), dm = Math.round(c.dmg || 0), rc = Math.ceil(dm * 2.5);
  return [
    { t: need > 0 ? '⛽ Заправить до полного — ' + fmtMoney(cost) : '⛽ Бак полон', dis: need < 1 || S.money < cost, fn: () => { S.money -= cost; c.fuel = 1; c.warnLow = c.warnEmpty = false; persist(); SFX.buy(); refreshMoney(true); say('Бак полный! Счастливого пути.'); } },
    { t: dm > 0 ? '🔧 Починить машину (' + dm + '% повреждений) — ' + fmtMoney(rc) : '🔧 Машина исправна', dis: dm < 1 || S.money < rc, fn: () => { S.money -= rc; c.dmg = 0; c.burn = 0; persist(); SFX.buy(); refreshMoney(true); say('Кузов и двигатель как новые.'); } }
  ];
}
(function v25Ui() {
  const b = document.createElement('div'); b.id = 'cbBadge'; document.body.appendChild(b);
  const w = document.createElement('div'); w.id = 'cbBtns';
  const mk = (ico, small, on, off) => { const x = document.createElement('button'); x.innerHTML = ico + '<small>' + small + '</small>'; x.addEventListener('pointerdown', e => { e.preventDefault(); auInit(); on(); }); if (off) { const f = e => { e.preventDefault(); off(); }; x.addEventListener('pointerup', f); x.addEventListener('pointerleave', f); x.addEventListener('pointercancel', f); } w.appendChild(x); };
  mk('🧎', 'присесть', () => { if (!CB.crouch) cbZ(); else CB.crouch = false; });
  mk('🤸', 'перекат', () => { CB.crouch = false; cbZ(); });
  mk('✋', 'блок', () => { touch.block = 1; }, () => { touch.block = 0; });
  mk('💣', 'граната', () => throwGrenade());
  mk('🧨', 'C4', () => c4Action());
  document.body.appendChild(w);
})();

