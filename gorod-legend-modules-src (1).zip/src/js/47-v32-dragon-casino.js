/* ===================== v32: КАЗИНО «ЗОЛОТОЙ ДРАКОН», АК-47, ГАРАЖ +2, ЛЁГКОЕ МОРЕ ===================== */

/* ---------- АК-47 ---------- */
{
  const ak = { id: 'kalash', name: 'АК-47', icon: '🔫', price: 18000, dmg: 23, pellets: 1, rate: 0.095, mag: 30, reload: 1.7, spread: 0.05, range: 115, ammoPack: 60, packPrice: 420, minAmmo: 120 };
  WEAPONS.push(ak); WBY[ak.id] = ak;
  GUNMODEL.kalash = { two: true, m: 0.84, b: [
    [0, 0.03, 0.30, 0.06, 0.09, 0.78, 0.14, 0.14, 0.15],
    [0, -0.14, 0.20, 0.04, 0.17, 0.07, 0.10, 0.10, 0.10],
    [0, -0.04, -0.14, 0.06, 0.11, 0.30, 0.45, 0.28, 0.14],
    [0, 0.00, 0.55, 0.07, 0.06, 0.28, 0.45, 0.28, 0.14],
    [0, -0.07, 0.05, 0.04, 0.10, 0.05, 0.10, 0.10, 0.10]
  ] };
  const g0 = SFX.gun;
  SFX.gun = function (id, v) {
    if (id === 'kalash') { v = v === undefined ? 1 : v; noiseBurst(0.12, 0.34 * v, 2300); tone(150, 0.1, 'sawtooth', 0.2 * v, 55); return; }
    g0(id, v);
  };
}

/* ---------- КАЗИНО: данные и метки ---------- */
INT.casino = { kind: 'casino', x: INX + 5600, z: INZ };
Object.assign(NPC, {
  b_casino: { ico: '🤵', name: 'Управляющий', role: 'Казино «Золотой дракон»', greet: [''], tips: [] },
  casino: { ico: '🎰', name: 'Казино «Золотой дракон»', role: 'Игровой зал', greet: [''], tips: [] }
});
{
  const i = WORLD_MARKS.findIndex(m => m.id === 'biz_casino'); if (i >= 0) WORLD_MARKS.splice(i, 1);
  const cb = BIZ_BY.casino.blk;
  WORLD_MARKS.push({ id: 'casino_in', x: bc(cb[0]) + 18, z: bc(cb[1]) + 3.5, c: [1, 0.8, 0.2], label: '🎰 ВОЙТИ В КАЗИНО', short: '🎰 КАЗИНО', dot: '#ff2fa0', fn: 'enterShop', kind: 'casino', r: 6, br: 3 });
  const O = INT.casino, mk = o => WORLD_MARKS.push(Object.assign({ int: true, r: 1.3 }, o));
  mk({ id: 'door_casino', x: O.x, z: O.z - 6.3, r: 2.6, label: '🚪 ВЫЙТИ НА УЛИЦУ', fn: 'leaveShop' });
  [-17, -14.8, -12.6, -10.4, -8.2, -6].forEach((x, k) => mk({ id: 'cs_slot' + k, x: O.x + x, z: O.z + 5.3, label: '🎰 ИГРОВОЙ АВТОМАТ', fn: 'casinoPlay', tab: 'slot' }));
  [8, 10.2, 12.4].forEach((x, k) => mk({ id: 'cs_vp' + k, x: O.x + x, z: O.z + 5.3, label: '🂡 ВИДЕОПОКЕР', fn: 'casinoPlay', tab: 'vp' }));
  [-13, -3].forEach((x, k) => mk({ id: 'cs_pk' + k, x: O.x + x, z: O.z - 3.0, r: 2.1, label: '♠ СЕСТЬ ЗА ПОКЕРНЫЙ СТОЛ', fn: 'casinoPlay', tab: 'pk' }));
  mk({ id: 'cs_roul', x: O.x + 6, z: O.z - 2.8, r: 2.1, label: '🎡 РУЛЕТКА', fn: 'casinoPlay', tab: 'roul' });
  mk({ id: 'cs_bj', x: O.x + 14, z: O.z - 2.8, r: 2.1, label: '🃏 БЛЭКДЖЕК', fn: 'casinoPlay', tab: 'bj' });
  mk({ id: 'cs_vip', x: O.x + 16.6, z: O.z - 3.6, r: 2.2, label: '👑 VIP-ЗАЛ', fn: 'casinoVip' });
  mk({ id: 'cs_mgr', x: O.x + 17.9, z: O.z + 2.6, r: 2.3, label: '💼 УПРАВЛЯЮЩИЙ: КАЗИНО', fn: 'talk', kind: 'b_casino' });
}
HOME_FN.casinoPlay = function (m) { CAS.tab = m.tab; CAS.msg = ''; openScreen('casino'); };

/* ---------- КАЗИНО: управляющий (покупка, прокачка до 5 уровня) ---------- */
{
  const _bo = bizOptions;
  bizOptions = function (id) {
    if (id !== 'casino') return _bo(id);
    const r = S.biz.casino;
    if (!r || !r.own) return _bo(id);
    const b = BIZ_BY.casino, o = [], lvl = r.lvl || 1, a = Math.floor(r.acc || 0);
    o.push({ t: a >= 1 ? '💵 Забрать выручку — ' + fmtMoney(a) : (hasOffice() ? '💼 Выручка идёт в сейф кабинета пентхауса' : '💵 Выручки пока нет'), dis: a < 1, fn: () => { const n = Math.floor(r.acc || 0); r.acc = 0; addMoney(n); persist(); SFX.cash(); say('Вот выручка казино: ' + fmtMoney(n) + '.'); } });
    if (lvl < 5) {
      const cost = Math.round(b.price * 0.6 * lvl);
      o.push({ t: '⬆️ Прокачать казино до ур. ' + (lvl + 1) + ' — ' + fmtMoney(cost) + ' (+50% дохода)', dis: S.money < cost, fn: () => { S.money -= cost; r.lvl = lvl + 1; persist(); SFX.buy(); refreshMoney(true); say('Новые залы и автоматы! Теперь доход ' + fmtMoney(Math.round(b.rate * bizMult(r))) + ' в минуту.'); } });
    } else o.push({ t: '⭐ Максимальный уровень', dis: true, fn: () => { } });
    o.push({ t: '📊 Отчёт', fn: () => say('Уровень ' + lvl + ' из 5. Доход ' + fmtMoney(Math.round(b.rate * bizMult(r))) + ' в минуту. Касса вмещает ' + fmtMoney(Math.round(bizCap(r, b))) + '.' + (hasOffice() ? ' Деньги уходят прямо в сейф вашего пентхауса.' : ' Купите пентхаус — и деньги пойдут в его сейф.')) });
    o.push(byeOpt());
    return o;
  };
}

/* ---------- ПОКЕР: Холдем против дилера и видеопокер ---------- */
const PK_SUIT = ['♠', '♥', '♦', '♣'], PK_RK = v => ({ 11: 'J', 12: 'Q', 13: 'K', 14: 'A' }[v] || String(v));
const PK_NAMES = ['Старшая карта', 'Пара', 'Две пары', 'Сет', 'Стрит', 'Флеш', 'Фулл-хаус', 'Каре', 'Стрит-флеш'];
const VP_PAY = [['Роял-флеш', 250], ['Стрит-флеш', 50], ['Каре', 25], ['Фулл-хаус', 9], ['Флеш', 6], ['Стрит', 4], ['Сет', 3], ['Две пары', 2], ['Пара J+', 1]];
function pkDeck() {
  const d = []; for (let s = 0; s < 4; s++) for (let v = 2; v <= 14; v++) d.push({ v, s });
  for (let i = d.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = d[i]; d[i] = d[j]; d[j] = t; }
  return d;
}
function pkCard(c, hidden) {
  if (hidden || !c) return '<div class="cas-card back">?</div>';
  return '<div class="cas-card' + (c.s === 1 || c.s === 2 ? ' red' : '') + '">' + PK_RK(c.v) + PK_SUIT[c.s] + '</div>';
}
function pkRank5(c) {
  const v = c.map(x => x.v).sort((a, b) => b - a), flush = c.every(x => x.s === c[0].s), cnt = {};
  v.forEach(x => { cnt[x] = (cnt[x] || 0) + 1; });
  const gr = Object.keys(cnt).map(k => [cnt[k], +k]).sort((a, b) => b[0] - a[0] || b[1] - a[1]);
  let straight = false, hi = v[0];
  if (gr.length === 5) { if (v[0] - v[4] === 4) straight = true; else if (v[0] === 14 && v[1] === 5 && v[4] === 2) { straight = true; hi = 5; } }
  let cat;
  if (straight && flush) cat = 8; else if (gr[0][0] === 4) cat = 7; else if (gr[0][0] === 3 && gr[1][0] === 2) cat = 6; else if (flush) cat = 5;
  else if (straight) cat = 4; else if (gr[0][0] === 3) cat = 3; else if (gr[0][0] === 2 && gr[1][0] === 2) cat = 2; else if (gr[0][0] === 2) cat = 1; else cat = 0;
  const ks = straight ? [hi] : gr.map(g => g[1]);
  let key = cat; for (let i = 0; i < 5; i++) key = key * 15 + (ks[i] || 0);
  return key;
}
const pkCat = r => Math.floor(r / 759375);
function pkBest(c7) {
  let best = -1;
  for (let i = 0; i < c7.length; i++) for (let j = i + 1; j < c7.length; j++) {
    const h = []; for (let k = 0; k < c7.length; k++) if (k !== i && k !== j) h.push(c7[k]);
    const r = pkRank5(h); if (r > best) best = r;
  }
  return best;
}
function vpMult(h) {
  const cat = pkCat(pkRank5(h));
  if (cat === 8) return Math.min.apply(null, h.map(c => c.v)) === 10 ? 250 : 50;
  if (cat === 7) return 25; if (cat === 6) return 9; if (cat === 5) return 6; if (cat === 4) return 4; if (cat === 3) return 3; if (cat === 2) return 2;
  if (cat === 1) { const cnt = {}; h.forEach(c => { cnt[c.v] = (cnt[c.v] || 0) + 1; }); for (const k in cnt) if (cnt[k] === 2 && +k >= 11) return 1; }
  return 0;
}
function v32PkHtml() {
  const g = CAS.pk;
  if (!g) return '<p class="muted">Холдем против дилера. Ставка — Анте: вам две карты и флоп. «Колл» — доплатить ×2 Анте, «Фолд» — сбросить. Дилер играет от пары, иначе Анте возвращается.</p><button class="btn pri" data-act="cas-pk" data-v="deal">♠ Раздать на $' + CAS.bet + '</button>';
  const sh = g.done;
  let h = '<div>Дилер' + (sh ? ' · ' + PK_NAMES[pkCat(pkBest(g.d.concat(g.b)))] : '') + '</div><div class="cas-cards">' + g.d.map(c => pkCard(c, !sh)).join('') + '</div>';
  h += '<div>Стол</div><div class="cas-cards">' + g.b.map((c, i) => pkCard(c, !sh && i >= 3)).join('') + '</div>';
  h += '<div>Вы' + (sh ? ' · ' + PK_NAMES[pkCat(pkBest(g.p.concat(g.b)))] : '') + ' · Анте $' + g.ante + (g.call ? ' · Колл $' + g.call : '') + '</div><div class="cas-cards">' + g.p.map(c => pkCard(c)).join('') + '</div>';
  h += sh ? '<button class="btn pri" data-act="cas-pk" data-v="deal">♠ Ещё раз на $' + CAS.bet + '</button>'
    : '<div class="cas-row"><button class="btn pri" data-act="cas-pk" data-v="call">Колл $' + g.ante * 2 + '</button><button class="btn" data-act="cas-pk" data-v="fold">Фолд</button></div>';
  return h;
}
function v32VpHtml() {
  const g = CAS.vp, tbl = '<p class="muted" style="font-size:12px">' + VP_PAY.map(x => x[0] + ' ×' + x[1]).join(' · ') + '</p>';
  if (!g) return tbl + '<button class="btn pri" data-act="cas-vp" data-v="deal">🂡 Раздать на $' + CAS.bet + '</button>';
  const cards = '<div class="cas-cards">' + g.h.map((c, i) => {
    const hold = g.hold[i] && !g.done;
    return '<button class="cas-card' + (c.s === 1 || c.s === 2 ? ' red' : '') + '" style="border:0;cursor:pointer;' + (hold ? 'outline:3px solid #ffd60a;' : '') + '" data-act="cas-vp" data-v="h' + i + '">' + PK_RK(c.v) + PK_SUIT[c.s] + (hold ? '<br><small>HOLD</small>' : '') + '</button>';
  }).join('') + '</div>';
  return tbl + (g.done ? '' : '<p class="muted">Нажмите на карты, которые оставляете, затем «Заменить».</p>') + cards +
    (g.done ? '<button class="btn pri" data-act="cas-vp" data-v="deal">🂡 Ещё раз на $' + CAS.bet + '</button>' : '<button class="btn pri" data-act="cas-vp" data-v="draw">Заменить</button>');
}
function v32Act(a, el) {
  const v = el && el.dataset.v; SFX.click();
  if (a === 'cas-pk') {
    const g = CAS.pk;
    if (v === 'deal') {
      if (g && !g.done) return; if (!casTake(CAS.bet)) return;
      const dk = pkDeck();
      CAS.pk = { dk, p: [dk.pop(), dk.pop()], d: [dk.pop(), dk.pop()], b: [dk.pop(), dk.pop(), dk.pop(), dk.pop(), dk.pop()], ante: CAS.bet, call: 0, done: false }; CAS.msg = '';
    } else if (g && !g.done && v === 'fold') { g.done = true; CAS.msg = 'Фолд. Анте $' + g.ante + ' потеряно'; SFX.err(); persist(); }
    else if (g && !g.done && v === 'call') {
      if (S.money < g.ante * 2) { casMsg('Не хватает денег на колл — можно сбросить'); return; }
      S.money -= g.ante * 2; refreshMoney(false); g.call = g.ante * 2; g.done = true;
      const pr = pkBest(g.p.concat(g.b)), dr = pkBest(g.d.concat(g.b)), dq = pkCat(dr) >= 1; let pay = 0;
      if (pr > dr) { pay = g.call * 2 + (dq ? g.ante * 2 : g.ante); CAS.msg = '🎉 Победа! ' + PK_NAMES[pkCat(pr)] + ' бьёт «' + PK_NAMES[pkCat(dr)] + '». ' + (dq ? '' : 'Дилер не дотянул до пары — Анте возвращено. ') + 'Выплата ' + fmtMoney(pay); }
      else if (pr === dr) { pay = g.ante + g.call; CAS.msg = 'Ничья — ставки возвращены'; }
      else { CAS.msg = 'Дилер выиграл: ' + PK_NAMES[pkCat(dr)] + '. −' + fmtMoney(g.ante + g.call); SFX.err(); }
      casPay(pay);
    }
  } else {
    const g = CAS.vp;
    if (v === 'deal') {
      if (g && !g.done) return; if (!casTake(CAS.bet)) return;
      const dk = pkDeck(); CAS.vp = { dk, h: [dk.pop(), dk.pop(), dk.pop(), dk.pop(), dk.pop()], hold: [0, 0, 0, 0, 0], bet: CAS.bet, done: false }; CAS.msg = '';
    } else if (g && !g.done && v && v[0] === 'h') g.hold[+v.slice(1)] ^= 1;
    else if (g && !g.done && v === 'draw') {
      g.h = g.h.map((c, i) => g.hold[i] ? c : g.dk.pop()); g.done = true;
      const m = vpMult(g.h); casPay(m * g.bet);
      CAS.msg = m ? '🎉 Выигрыш ×' + m + ' = ' + fmtMoney(m * g.bet) : 'Ничего не собрано. Ставка проиграна'; if (!m) SFX.err();
    }
  }
  casRender();
}
{
  const _cr = casRender;
  casRender = function () {
    if (CAS.tab !== 'pk' && CAS.tab !== 'vp') return _cr();
    document.querySelectorAll('#casino .cas-tabs .btn').forEach(b => b.classList.toggle('on', b.dataset.tab === CAS.tab));
    $('casBets').innerHTML = '<span class="muted" style="align-self:center">Ставка:</span>' + CAS_BETS.map(x => '<button class="btn' + (x === CAS.bet ? ' on' : '') + '" data-act="cas-bet" data-v="' + x + '">$' + x + '</button>').join('');
    $('casBody').innerHTML = (CAS.tab === 'pk' ? v32PkHtml() : v32VpHtml()) + '<div class="cas-msg" id="casMsg">' + CAS.msg + '</div>';
  };
  const _ca = casAct;
  casAct = function (a, el) { if (a === 'cas-pk' || a === 'cas-vp') return v32Act(a, el); return _ca(a, el); };
  const tb = document.querySelector('#casino .cas-tabs');
  if (tb) tb.insertAdjacentHTML('beforeend', '<button class="btn" data-act="cas-tab" data-tab="pk">♠ Холдем</button><button class="btn" data-act="cas-tab" data-tab="vp">🂡 Видеопокер</button>');
}

/* ---------- КАЗИНО: здание снаружи ---------- */
function buildCasinoHouse(WORLD, cx, cz) {
  const g = WORLD.g(), x0 = cx + 8, x1 = cx + 28, z0 = cz + 8, z1 = cz + 28;
  const gold = [0.9, 0.72, 0.2, 1], wall = [0.24, 0.1, 0.3, 1], dk = [0.07, 0.05, 0.09, 1], glass = [0.5, 0.7, 0.95, 1];
  const neon = [[1, 0.2, 0.5, 1], [1, 0.85, 0.2, 1], [0.2, 0.9, 1, 1]];
  g.box(x0 - 1.5, 0.2, z0 - 5, x1 + 0.5, 0.25, z1, [0.3, 0.3, 0.34, 1], false, true);
  g.box(x0, 0.25, z0, x1, 12, z1, wall, true, true);
  g.box(x0 - 0.4, 12, z0 - 0.4, x1 + 0.4, 12.8, z1 + 0.4, gold, false, true);
  g.box(x0 + 4, 12.8, z0 + 4, x1 - 4, 17, z1 - 4, wall, true, true);
  g.box(x0 + 3.6, 17, z0 + 3.6, x1 - 3.6, 17.6, z1 - 3.6, gold, false, true);
  g.cone(cx + 18, 17.6, cz + 18, 5.5, 5, 8, gold);
  g.box(cx + 16, 0.25, z0 - 0.35, cx + 20, 4.6, z0, dk, false, true);
  g.box(cx + 9, 0.4, z0 - 0.3, cx + 15, 6, z0, glass, false, true);
  g.box(cx + 21, 0.4, z0 - 0.3, cx + 27, 6, z0, glass, false, true);
  g.box(cx + 16, 0.25, z0 - 5, cx + 20, 0.3, z0 - 0.35, [0.7, 0.08, 0.12, 1], false, true);
  g.box(cx + 13.5, 5.2, z0 - 5, cx + 22.5, 5.7, z0, gold, false, true);
  for (const px of [cx + 13.7, cx + 22.3]) { g.box(px - 0.3, 0.25, z0 - 4.8, px + 0.3, 5.2, z0 - 4.2, [1, 0.95, 0.85, 1], false, true); boxes.push({ x0: px - 0.3, x1: px + 0.3, z0: z0 - 4.8, z1: z0 - 4.2, h: 5.2 }); }
  g.box(cx + 10, 13.4, z0 - 0.5, cx + 26, 16.2, z0, dk, false, true);
  for (let k = 0; k < 8; k++) g.box(cx + 10.6 + k * 1.9, 13.9, z0 - 0.8, cx + 11.9 + k * 1.9, 15.7, z0 - 0.5, neon[k % 3], false, true);
  g.box(x0 - 0.2, 0.25, z0 - 0.2, x0 + 0.2, 12, z0 + 0.2, neon[0], false, true);
  g.box(x1 - 0.2, 0.25, z0 - 0.2, x1 + 0.2, 12, z0 + 0.2, neon[2], false, true);
  boxes.push({ x0, x1, z0, z1, h: 17.6 });
}
{
  const _bk = buildKiosk;
  buildKiosk = function (WORLD, cx, cz, b) { if (b && b.id === 'casino') return buildCasinoHouse(WORLD, cx, cz); return _bk(WORLD, cx, cz, b); };
}

/* ---------- КАЗИНО: интерьер (40×16 м) ---------- */
function buildCasinoInterior() {
  const O = INT.casino, S1 = new GeoSet(), S2 = new GeoSet(), bg = mkBG(S1, S2, O.x, O.z), B = bg[0], GL = bg[1];
  const gold = [0.85, 0.68, 0.2], wl = [0.18, 0.09, 0.16], dark = [0.1, 0.08, 0.12], wood = [0.3, 0.18, 0.1];
  B(-90, -0.4, -90, 90, -0.05, 90, [0.03, 0.03, 0.05]);
  B(-20, -0.2, -8, 20, 0, 8, [0.34, 0.05, 0.1]);
  for (let i = -18; i <= 18; i += 4) B(i - 0.06, 0, -8, i + 0.06, 0.006, 8, gold);
  for (let j = -6; j <= 6; j += 4) B(-20, 0, j - 0.06, 20, 0.006, j + 0.06, [0.5, 0.1, 0.16]);
  B(-20.6, -0.2, 8, 20.6, 3.8, 8.6, wl, true); B(-20.6, -0.2, -8.6, 20.6, 3.8, -8, wl, true);
  B(-20.6, -0.2, -8, -20, 3.8, 8, wl, true); B(20, -0.2, -8, 20.6, 3.8, 8, wl, true);
  B(-20, 0, 7.9, 20, 0.3, 8, dark); B(-20, 0, -8, 20, 0.3, -7.9, dark);
  GL(-20, 3.5, 7.93, 20, 3.65, 7.98, [1, 0.8, 0.25]); GL(-20, 3.5, -7.98, 20, 3.65, -7.93, [1, 0.8, 0.25]);
  GL(-19.97, 3.5, -8, -19.92, 3.65, 8, [1, 0.8, 0.25]); GL(19.92, 3.5, -8, 19.97, 3.65, 8, [1, 0.8, 0.25]);
  GL(-18, 2.7, 7.93, -5, 3.2, 7.98, [1, 0.3, 0.3]); GL(5, 2.7, 7.93, 14, 3.2, 7.98, [0.2, 0.9, 1]);
  GL(-9, 2.2, -7.98, -5, 3.0, -7.93, [1, 0.2, 0.5]); GL(-2, 2.2, -7.98, 2, 3.0, -7.93, [1, 0.85, 0.2]); GL(5, 2.2, -7.98, 9, 3.0, -7.93, [0.2, 0.9, 1]);
  // выход
  B(-1.7, 0, -8.0, 1.7, 3.0, -7.9, [0.95, 0.95, 0.92]); B(-1.3, 0, -8.0, 1.3, 2.75, -7.78, [0.38, 0.22, 0.12]); B(0.8, 1.2, -7.85, 1.0, 1.4, -7.7, [0.95, 0.8, 0.2]);
  // игровые автоматы
  const cols = [[1, 0.3, 0.3], [1, 0.85, 0.2], [0.3, 1, 0.5], [0.4, 0.7, 1], [1, 0.4, 0.9], [1, 0.6, 0.2]];
  const mach = (x, col, scr) => {
    B(x - 0.6, 0, 6.7, x + 0.6, 2.0, 7.8, [0.12, 0.1, 0.2], true); GL(x - 0.5, 2.05, 6.7, x + 0.5, 2.35, 7.7, col);
    GL(x - 0.45, 1.15, 6.62, x + 0.45, 1.85, 6.68, scr); B(x - 0.5, 0.95, 6.5, x + 0.5, 1.1, 6.7, [0.55, 0.55, 0.6]); B(x + 0.62, 0.9, 7.1, x + 0.72, 1.9, 7.2, [0.8, 0.1, 0.1]);
  };
  [-17, -14.8, -12.6, -10.4, -8.2, -6].forEach((x, k) => mach(x, cols[k], [0.45, 0.9, 1]));
  [8, 10.2, 12.4].forEach(x => mach(x, [0.2, 0.9, 1], [0.3, 1, 0.55]));
  // столы
  const table = (x, z, w, d, fc) => {
    B(x - w / 2 - 0.15, 0, z - d / 2 - 0.15, x + w / 2 + 0.15, 0.8, z + d / 2 + 0.15, wood, true);
    B(x - w / 2, 0.8, z - d / 2, x + w / 2, 0.9, z + d / 2, fc);
    B(x - 0.5, 0.9, z - 0.15, x - 0.3, 0.98, z + 0.05, [0.9, 0.1, 0.1]); B(x + 0.2, 0.9, z, x + 0.4, 0.98, z + 0.2, [0.1, 0.4, 0.9]); B(x - 0.1, 0.9, z + 0.2, x + 0.1, 0.98, z + 0.4, [0.95, 0.85, 0.2]);
    B(x - 0.9, 0.9, z + 0.4, x - 0.5, 0.92, z + 0.7, [1, 1, 1]); B(x + 0.5, 0.9, z + 0.35, x + 0.9, 0.92, z + 0.65, [1, 1, 1]);
  };
  const stool = (x, z) => { B(x - 0.32, 0, z - 0.32, x + 0.32, 0.5, z + 0.32, [0.55, 0.08, 0.14]); };
  for (const px of [-13, -3]) {
    table(px, 0, 4.2, 2.6, [0.05, 0.38, 0.2]);
    for (const [dx, dz] of [[-3, 0], [3, 0], [-1.8, -2.2], [1.8, -2.2]]) stool(px + dx, dz);
  }
  table(6, 0, 4.0, 2.4, [0.05, 0.3, 0.16]); S1.g().discAt(O.x + 7.2, 0.93, O.z, 0.7, 16, [0.7, 0.1, 0.1, 1], [0.15, 0.15, 0.15, 1]);
  table(14, 0, 3.6, 2.2, [0.04, 0.34, 0.18]); stool(12.8, -1.9); stool(15.2, -1.9);
  // VIP-зал (правый дальний угол): подиум, канаты, золотые автоматы
  B(13.6, 0, -7.7, 19.6, 0.18, -2.7, [0.45, 0.06, 0.18]); B(13.6, 0.18, -7.7, 19.6, 0.2, -7.6, gold); B(13.6, 0.18, -2.8, 19.6, 0.2, -2.7, gold);
  B(13.6, 0.18, -7.7, 13.7, 0.2, -2.7, gold); B(19.5, 0.18, -7.7, 19.6, 0.2, -2.7, gold);
  for (const px of [13.7, 15.6, 17.6, 19.5]) B(px - 0.07, 0.2, -2.77, px + 0.07, 1.05, -2.63, gold, true);
  GL(13.7, 0.86, -2.74, 19.5, 0.92, -2.66, [0.9, 0.1, 0.25]);
  for (const x of [14.9, 16.5, 18.1]) {
    B(x - 0.6, 0.2, -7.8, x + 0.6, 2.2, -6.7, [0.25, 0.17, 0.05], true); GL(x - 0.5, 2.25, -7.7, x + 0.5, 2.55, -6.7, [1, 0.8, 0.2]);
    GL(x - 0.45, 1.3, -6.68, x + 0.45, 2.0, -6.62, [1, 0.92, 0.55]); B(x - 0.5, 1.05, -6.7, x + 0.5, 1.2, -6.5, [0.75, 0.6, 0.2]);
  }
  GL(13.8, 3.0, -7.98, 19.4, 3.4, -7.93, [1, 0.85, 0.2]); GL(15.4, 2.6, -7.98, 17.8, 2.9, -7.93, [1, 0.2, 0.4]);
  // стол управляющего
  B(16.3, 0, 3.4, 19.5, 0.9, 4.6, wood, true); GL(16.8, 0.92, 3.7, 17.6, 0.95, 4.3, [0.4, 0.9, 0.6]);
  return { lit: S1.done(), glow: S2.done() };
}

/* ---------- КАЗИНО: посетители, крупье, игроки за столами ---------- */
const CASP = { list: null, t: 0 };
function casinoPeopleInit() {
  const sh = ['#3a86ff', '#2ecc71', '#ffd60a', '#ff4fa3', '#9b5de5', '#f1f1f1', '#ff7b00', '#00b4d8'], O = INT.casino, L = [];
  const face = (x, z, tx, tz) => Math.atan2(tx - x, tz - z);
  const seat = (x, z, tx, tz) => { const lk = genPedLook(sh); lk._sy = 0.74; L.push({ x: O.x + x, z: O.z + z, h: face(x, z, tx, tz), look: lk, ph: 0, amp: 0 }); };
  const stand = (x, z, h) => L.push({ x: O.x + x, z: O.z + z, h, look: genPedLook(sh), ph: 0, amp: 0 });
  const dealerM = () => emLook('#f4f4f6', '#16161a', '#2a1a10', false, 'm1', 'long', 0.1), dealerF = () => emLook('#f4f4f6', '#16161a', '#3a2415', true, 'f1', 'long', 0.1);
  for (const px of [-13, -3]) {
    L.push({ x: O.x + px, z: O.z + 2.3, h: Math.PI, look: px < -5 ? dealerF() : dealerM(), ph: 0, amp: 0 });
    seat(px - 3, 0, px, 0); seat(px + 3, 0, px, 0); seat(px + 1.8, -2.2, px, 0);
  }
  L.push({ x: O.x + 6, z: O.z + 2.1, h: Math.PI, look: dealerM(), ph: 0, amp: 0 }); stand(4, -2.0, 0); stand(8.2, -2.0, 0);
  L.push({ x: O.x + 14, z: O.z + 1.9, h: Math.PI, look: dealerF(), ph: 0, amp: 0 }); seat(12.8, -1.9, 14, 0); seat(15.2, -1.9, 14, 0);
  stand(-12.6, 5.9, 0); stand(-8.2, 5.9, 0); stand(10.2, 5.9, 0);
  L.push({ x: O.x + 17.9, z: O.z + 5.4, h: Math.PI, look: emLook('#7a1f3d', '#101014', '#2a2a30', false, 'm1', 'jacket', 0.2), ph: 0, amp: 0 });
  L.push({ x: O.x + 15.0, z: O.z - 2.2, h: Math.PI, look: emLook('#111114', '#0a0a0d', '#1a1208', false, 'm1', 'jacket', 0.2), ph: 0, amp: 0 });
  stand(16.2, -5.2, Math.PI * 0.5); stand(18.4, -4.4, -Math.PI * 0.5);
  const lane = (ax, az, bx, bz, u) => L.push({ a: [O.x + ax, O.z + az], b: [O.x + bx, O.z + bz], u, dir: 1, wait: Math.random() * 3, sp: 1.1 + Math.random() * 0.5, x: O.x + ax, z: O.z + az, h: 0, look: genPedLook(sh), ph: Math.random() * 6, amp: 0 });
  lane(-18.5, -5.2, 12.0, -5.2, 0.2); lane(12.0, -5.2, -18.5, -5.2, 0.7); lane(-18, 4.2, 2, 4.2, 0.4); lane(4, 4.2, 15, 4.2, 0.1); lane(-18.5, -4.0, 12.0, -4.0, 0.9);
  CASP.list = L; CASP.t = G.time;
}
function casinoPeopleDraw() {
  if (!CASP.list) casinoPeopleInit();
  const dt = clamp(G.time - CASP.t, 0, 0.1); CASP.t = G.time;
  for (const w of CASP.list) {
    if (w.a) {
      if (w.wait > 0) { w.wait -= dt; w.amp = 0; }
      else {
        const len = Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]) || 1; w.u += w.dir * w.sp * dt / len; w.amp = 0.9; w.ph += dt * w.sp * 3.2;
        if (w.u >= 1 || w.u <= 0) { w.u = clamp(w.u, 0, 1); w.dir = -w.dir; w.wait = 2 + Math.random() * 4; }
      }
      w.x = w.a[0] + (w.b[0] - w.a[0]) * w.u; w.z = w.a[1] + (w.b[1] - w.a[1]) * w.u;
      w.h = Math.atan2((w.b[0] - w.a[0]) * w.dir, (w.b[1] - w.a[1]) * w.dir);
    }
    drawHuman(w.x, 0, w.z, w.h, w.ph, w.amp, w.look, false, 1, null);
  }
}
{
  const _dhs = drawHomeScene;
  drawHomeScene = function () { _dhs(); if (G.int && G.int.kind === 'casino') casinoPeopleDraw(); };
  const _bcity = buildCity;
  buildCity = function () { _bcity(); CITY.ints.casino = buildCasinoInterior(); seaInit(); };
}

/* ---------- МОРЕ: лёгкая версия (строится при загрузке, отсечение по дальности, без мерцания) ---------- */
function seaInit() {
  if (SEA.sides) return;
  const A = [0.08, 0.40, 0.66, 1], B = [0.10, 0.45, 0.72, 1], SAND = [0.86, 0.78, 0.56, 1];
  const E = EDGE, E2 = EDGE + 14, N = E + 600, y = -0.03, T = 80;
  const side = (x0, z0, x1, z1) => {
    const gs = new GeoSet(); let k = 0;
    for (let x = x0; x < x1; x += T) { let j = k; for (let z = z0; z < z1; z += T, j++) gs.g().flat(x, z, Math.min(x + T, x1), Math.min(z + T, z1), y, (j & 1) ? A : B); k++; }
    return { ms: gs.done(), x0, x1, z0, z1 };
  };
  SEA.sides = [side(-N, E2, N, N), side(-N, -N, N, -E2), side(-N, -E2, -E2, E2), side(E2, -E2, N, E2)];
  const gb = new GeoSet(), s = -0.05, st = 70;
  for (let t = -E2; t < E2; t += st) {
    const t2 = Math.min(t + st, E2);
    gb.g().flat(t, E, t2, E2, s, SAND); gb.g().flat(t, -E2, t2, -E, s, SAND);
    if (t >= -E && t2 <= E) { gb.g().flat(-E2, t, -E, t2, s, SAND); gb.g().flat(E, t, E2, t2, s, SAND); }
  }
  SEA.beach = gb.done();
  SEA.ships = [
    { m: shipMesh('cargo'), x: -300, z: E + 260, v: 6, x0: -1300, x1: 1300, ph: 0 },
    { m: shipMesh('cargo'), x: 400, z: -(E + 330), v: -5, x0: -1300, x1: 1300, ph: 2 },
    { m: shipMesh('yacht'), cx: PORT.x + 70, cz: E + 120, r: 70, a: 0, sp: 0.07, ph: 1 },
    { m: shipMesh('sail'), cx: -300, cz: E + 220, r: 110, a: 2, sp: 0.04, ph: 3 },
    { m: shipMesh('sail'), cx: 420, cz: E + 160, r: 80, a: 4, sp: -0.05, ph: 5 },
    { m: shipMesh('yacht'), cx: 520, cz: -(E + 160), r: 90, a: 1, sp: 0.05, ph: 4 }
  ];
  SEA.m = true;
}
seaDraw = function () {
  if (G.mode !== 'play' || G.inHome) return;
  if (!SEA.sides) seaInit();
  const t = G.time, k = 0.97 + 0.04 * Math.sin(t * 0.7), far = ENV.fogFar + 80;
  setPass('decal');   // polygonOffset: вода не «мерцает» на земле, глубина не пишется
  for (const s of SEA.sides) {
    const dx = Math.max(s.x0 - CAM.x, 0, CAM.x - s.x1), dz = Math.max(s.z0 - CAM.z, 0, CAM.z - s.z1);
    if (dx * dx + dz * dz > far * far) continue;
    for (const m of s.ms) drawMesh(m, IDENT, k * 0.98, k, k * 1.02, 1, 0, false);
  }
  for (const m of SEA.beach) drawMesh(m, IDENT, k * 0.98, k, k * 1.02, 1, 0, false);
  setPass('opaque');
  for (const s of SEA.ships) {
    let x, z, yaw;
    if (s.r) { const a = s.a + s.sp * t; x = s.cx + Math.cos(a) * s.r; z = s.cz + Math.sin(a) * s.r; yaw = Math.atan2(-Math.sin(a) * s.sp, Math.cos(a) * s.sp); }
    else { const span = s.x1 - s.x0, u = ((s.x - s.x0 + s.v * t) % (span * 2) + span * 2) % (span * 2); x = s.x0 + (u < span ? u : span * 2 - u); z = s.z; yaw = (u < span) === (s.v > 0) ? Math.PI / 2 : -Math.PI / 2; }
    if (Math.hypot(x - CAM.x, z - CAM.z) > far) continue;
    mTRS(DM, x, -0.1 + Math.sin(t * 0.9 + s.ph) * 0.18, z, yaw, Math.sin(t * 0.7 + s.ph) * 0.02, Math.sin(t * 0.8 + s.ph) * 0.03, 1, 1, 1); drawMesh(s.m, DM, 1, 1, 1, 1, 0, false);
  }
};


