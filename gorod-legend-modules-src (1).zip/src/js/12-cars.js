/* ===================== 9. МАШИНЫ ===================== */
const cars = [];
let OWN = null;
const MESH_CACHE = {}, WHEEL_CACHE = {};
function wheelMesh(wr, rim) {
  const k = wr.toFixed(2) + (rim || '');
  if (WHEEL_CACHE[k]) return WHEEL_CACHE[k];
  const g = new Geo();
  g.cylX(0, 0, 0, wr, 0.13, 10, [0.07, 0.07, 0.08, 1]);
  const sp = rim ? hexRGB(rim).concat(1) : [0.72, 0.74, 0.78, 1];
  if (rim) g.cylX(0, 0, 0, wr * 0.66, 0.15, 10, sp);
  g.box(-0.14, -wr * 0.55, -0.04, 0.14, wr * 0.55, 0.04, rim ? [1, 1, 1, 1] : sp, false, true);
  g.box(-0.14, -0.04, -wr * 0.55, 0.14, 0.04, wr * 0.55, rim ? [1, 1, 1, 1] : sp, false, true);
  return WHEEL_CACHE[k] = makeMesh(g);
}
function bikeMeshes(def, colorHex, key) {
  const s = def.shape, L = s.L, y0 = s.wr * 0.8, col = hexRGB(colorHex).concat(1);
  const body = new Geo(), lights = new Geo(), tail = new Geo();
  const dark = [0.1, 0.1, 0.12, 1], suit = [0.12, 0.14, 0.2, 1], helm = [0.92, 0.92, 0.95, 1];
  body.box(-0.1, y0 + 0.1, -L * 0.32, 0.1, y0 + 0.5, L * 0.3, dark, false, true);
  body.box(-0.2, y0 + 0.5, -0.05, 0.2, y0 + 0.82, 0.55, col, false, true);
  body.box(-0.17, y0 + 0.5, -0.75, 0.17, y0 + 0.64, -0.05, dark, false, true);
  body.box(-0.05, y0, L * 0.28, 0.05, y0 + 0.9, L * 0.34, dark, false, true);
  body.box(-0.5, y0 + 0.9, L * 0.24, 0.5, y0 + 0.97, L * 0.3, dark, false, true);
  body.box(-0.2, y0 + 0.3, -L * 0.4, 0.2, y0 + 0.5, -L * 0.28, col, false, true);
  body.box(-0.2, y0 + 0.64, -0.7, 0.2, y0 + 1.3, -0.25, suit, false, true);
  body.box(-0.14, y0 + 1.3, -0.62, 0.14, y0 + 1.6, -0.3, helm, false, true);
  body.box(-0.45, y0 + 0.98, -0.4, -0.33, y0 + 1.12, 0.28, suit, false, true);
  body.box(0.33, y0 + 0.98, -0.4, 0.45, y0 + 1.12, 0.28, suit, false, true);
  body.box(-0.28, y0 + 0.4, -0.6, -0.18, y0 + 0.8, 0.1, suit, false, true);
  body.box(0.18, y0 + 0.4, -0.6, 0.28, y0 + 0.8, 0.1, suit, false, true);
  lights.box(-0.09, y0 + 0.75, L * 0.34, 0.09, y0 + 0.9, L * 0.34 + 0.05, [1, 0.97, 0.8, 1], false, true);
  tail.box(-0.12, y0 + 0.55, -L * 0.4 - 0.05, 0.12, y0 + 0.65, -L * 0.4, [1, 1, 1, 1], false, true);
  return MESH_CACHE[key] = { body: makeMesh(body), lights: makeMesh(lights), tail: makeMesh(tail), wheel: wheelMesh(s.wr) };
}
function heliMeshes(def, colorHex, key) {
  const s = def.shape, y0 = s.wr * 0.8, col = hexRGB(colorHex).concat(1);
  const body = new Geo(), lights = new Geo(), tail = new Geo(), rotor = new Geo();
  const glass = [0.1, 0.15, 0.22, 1], dark = [0.1, 0.1, 0.12, 1];
  body.box(-0.9, y0 + 0.2, -1.4, 0.9, y0 + 1.5, 2.0, col, false, true);
  body.box(-0.8, y0 + 0.55, 1.4, 0.8, y0 + 1.35, 2.3, glass, false, true);
  body.box(-0.15, y0 + 0.9, -3.9, 0.15, y0 + 1.3, -1.4, col, false, true);
  body.box(-0.05, y0 + 1.3, -3.9, 0.05, y0 + 2.2, -3.3, col, false, true);
  body.box(-1.05, 0.05, -1.8, -0.95, 0.2, 2.0, dark, false, true);
  body.box(0.95, 0.05, -1.8, 1.05, 0.2, 2.0, dark, false, true);
  body.box(-1.0, 0.2, -1.0, -0.9, y0 + 0.4, -0.8, dark, false, true);
  body.box(0.9, 0.2, -1.0, 1.0, y0 + 0.4, -0.8, dark, false, true);
  body.box(-1.0, 0.2, 1.0, -0.9, y0 + 0.4, 1.2, dark, false, true);
  body.box(0.9, 0.2, 1.0, 1.0, y0 + 0.4, 1.2, dark, false, true);
  body.box(-0.1, y0 + 1.5, -0.1, 0.1, y0 + 1.9, 0.1, dark, false, true);
  lights.box(-0.25, y0 + 0.4, 2.0, 0.25, y0 + 0.6, 2.05, [1, 0.97, 0.8, 1], false, true);
  tail.box(-0.1, y0 + 1.0, -3.95, 0.1, y0 + 1.2, -3.9, [1, 1, 1, 1], false, true);
  rotor.box(-4.2, 0, -0.12, 4.2, 0.05, 0.12, dark, false, true);
  rotor.box(-0.12, 0, -4.2, 0.12, 0.05, 4.2, dark, false, true);
  return MESH_CACHE[key] = { body: makeMesh(body), lights: makeMesh(lights), tail: makeMesh(tail), rotor: makeMesh(rotor), wheel: wheelMesh(s.wr) };
}
function carMeshes(def, colorHex, mods) {
  const key = def.id + colorHex + meshKey(mods);
  if (MESH_CACHE[key]) return MESH_CACHE[key];
  if (def.bike) return bikeMeshes(def, colorHex, key);
  if (def.heli) return heliMeshes(def, colorHex, key);
  const s = def.shape, col = hexRGB(colorHex).concat(1), W = s.W, L = s.L, wr = s.wr, y0 = wr * 0.8;
  const body = new Geo(), lights = new Geo(), tail = new Geo(), barR = new Geo(), barB = new Geo();
  const glass = (mods && mods.tint) ? [0.015, 0.02, 0.03, 1] : [0.1, 0.15, 0.22, 1], dark = [0.1, 0.1, 0.12, 1];
  body.box(-W / 2, y0, -L / 2, W / 2, y0 + s.H, L / 2, col, false, true);
  const cy0 = y0 + s.H, cz0 = s.cZ - s.cL / 2, cz1 = s.cZ + s.cL / 2;
  body.box(-W * 0.45, cy0, cz0, W * 0.45, cy0 + s.cH, cz1, glass, false, true);
  body.box(-W * 0.46, cy0 + s.cH, cz0 + 0.12, W * 0.46, cy0 + s.cH + 0.07, cz1 - 0.12, col, false, true);
  if (def.tank) { const tur = (body._tur = new Geo()); const dk2 = [col[0] * 0.8, col[1] * 0.8, col[2] * 0.8, 1]; tur.box(-W * 0.32, cy0 + s.cH, -0.9, W * 0.32, cy0 + s.cH + 0.5, 1.1, dk2, false, true); tur.box(-0.22, cy0 + s.cH + 0.1, 1.0, 0.22, cy0 + s.cH + 0.43, 1.55, dk2, false, true); tur.box(-0.14, cy0 + s.cH + 0.15, 1.1, 0.14, cy0 + s.cH + 0.38, 4.6, [0.15, 0.17, 0.12, 1], false, true); tur.box(-0.19, cy0 + s.cH + 0.11, 4.0, 0.19, cy0 + s.cH + 0.42, 4.7, [0.12, 0.13, 0.1, 1], false, true); body.box(-W / 2 - 0.15, 0, -L / 2, -W / 2 + 0.55, y0 + 0.8, L / 2, [0.1, 0.1, 0.1, 1], false, true); body.box(W / 2 - 0.55, 0, -L / 2, W / 2 + 0.15, y0 + 0.8, L / 2, [0.1, 0.1, 0.1, 1], false, true); }
  // капот и багажник: чуть темнее
  const dk = [col[0] * 0.82, col[1] * 0.82, col[2] * 0.82, 1];
  body.box(-W * 0.4, y0 + s.H, cz1 + 0.05, W * 0.4, y0 + s.H + 0.02, L / 2 - 0.1, dk, false, true);
  body.box(-W / 2 - 0.02, y0 - 0.02, L / 2 - 0.05, W / 2 + 0.02, y0 + 0.2, L / 2 + 0.1, dark, false, true);
  body.box(-W / 2 - 0.02, y0 - 0.02, -L / 2 - 0.1, W / 2 + 0.02, y0 + 0.2, -L / 2 + 0.05, dark, false, true);
  body.box(-W / 2 + 0.05, y0 - 0.12, -L / 2 + 0.2, W / 2 - 0.05, y0, L / 2 - 0.2, dark, false, true);
  if (mods && mods.st) {
    const sc = hexRGB(mods.st).concat(1);
    for (const sx of [-1, 1]) {
      const a = sx * W * 0.05, b = sx * W * 0.15;
      body.box(Math.min(a, b), y0 + s.H + 0.025, cz1 + 0.05, Math.max(a, b), y0 + s.H + 0.04, L / 2 - 0.1, sc, false, true);
      body.box(Math.min(a, b), cy0 + s.cH + 0.075, cz0 + 0.12, Math.max(a, b), cy0 + s.cH + 0.09, cz1 - 0.12, sc, false, true);
      body.box(Math.min(a, b), y0 + s.H + 0.025, -L / 2 + 0.1, Math.max(a, b), y0 + s.H + 0.04, cz0 - 0.05, sc, false, true);
    }
  }
  const spSt = (mods && mods.sp !== undefined) ? mods.sp : (def.spoiler ? 1 : 0);
  if (spSt === 2) {
    const wc = (mods && mods.st) ? hexRGB(mods.st).concat(1) : [0.06, 0.06, 0.08, 1];
    for (const sx of [-1, 1]) body.box(sx * W * 0.32 - 0.05, y0 + s.H, -L / 2 + 0.12, sx * W * 0.32 + 0.05, y0 + s.H + 0.62, -L / 2 + 0.26, dark, false, true);
    body.box(-W * 0.5, y0 + s.H + 0.62, -L / 2 - 0.1, W * 0.5, y0 + s.H + 0.7, -L / 2 + 0.5, wc, false, true);
    for (const sx of [-1, 1]) body.box(sx * W * 0.5 - 0.03, y0 + s.H + 0.5, -L / 2 - 0.1, sx * W * 0.5 + 0.03, y0 + s.H + 0.84, -L / 2 + 0.5, wc, false, true);
  } else if (spSt === 1) {
    body.box(-W * 0.34, y0 + s.H, -L / 2 + 0.15, -W * 0.3, y0 + s.H + 0.28, -L / 2 + 0.3, dark, false, true);
    body.box(W * 0.3, y0 + s.H, -L / 2 + 0.15, W * 0.34, y0 + s.H + 0.28, -L / 2 + 0.3, dark, false, true);
    body.box(-W * 0.46, y0 + s.H + 0.28, -L / 2 + 0.05, W * 0.46, y0 + s.H + 0.34, -L / 2 + 0.42, col, false, true);
  }
  if (def.taxi) body.box(-0.35, cy0 + s.cH + 0.07, s.cZ - 0.2, 0.35, cy0 + s.cH + 0.3, s.cZ + 0.2, [1, 0.95, 0.5, 1], false, true);
  if (def.police || def.siren) {
    if (def.siren) body.box(-W / 2 - 0.005, y0 + 0.25, -L * 0.4, W / 2 + 0.005, y0 + 0.5, L * 0.4, def.stripe || [0.85, 0.1, 0.1, 1], false, true);
    if (def.fire) body.box(-0.3, cy0 + s.cH + 0.07, -L * 0.4, 0.3, cy0 + s.cH + 0.2, L * 0.2, [0.7, 0.7, 0.72, 1], false, true);
    if (def.police) body.box(-W / 2 - 0.005, y0 + 0.1, -L * 0.22, W / 2 + 0.005, y0 + s.H - 0.06, L * 0.22, [0.08, 0.08, 0.1, 1], false, true);
    barR.box(-0.5, cy0 + s.cH + 0.07, s.cZ - 0.14, -0.02, cy0 + s.cH + 0.22, s.cZ + 0.14, [1, 1, 1, 1], false, true);
    barB.box(0.02, cy0 + s.cH + 0.07, s.cZ - 0.14, 0.5, cy0 + s.cH + 0.22, s.cZ + 0.14, [1, 1, 1, 1], false, true);
  }
  for (const sx of [-1, 1]) {
    lights.box(sx * W * 0.32 - W * 0.1, y0 + s.H * 0.5, L / 2 + 0.01, sx * W * 0.32 + W * 0.1, y0 + s.H * 0.5 + 0.13, L / 2 + 0.05, [1, 0.97, 0.8, 1], false, true);
    tail.box(sx * W * 0.34 - W * 0.11, y0 + s.H * 0.5, -L / 2 - 0.05, sx * W * 0.34 + W * 0.11, y0 + s.H * 0.5 + 0.13, -L / 2 - 0.01, [1, 1, 1, 1], false, true);
  }
  const r = { body: makeMesh(body), lights: makeMesh(lights), tail: makeMesh(tail), wheel: wheelMesh(wr, mods && mods.rim) }; if (body._tur) r.turret = makeMesh(body._tur);
  if (def.police || def.siren) { r.barR = makeMesh(barR); r.barB = makeMesh(barB); }
  return MESH_CACHE[key] = r;
}
function massOf(c) { return (c.def.shape.W * c.def.shape.L / 7.5 + (c.def.price > 50000 ? 0.1 : 0)) * (c.def.massK || 1); }
function makeCar(def, kind, colorHex, upg, mods) {
  const c = {
    kind, def, col: colorHex || def.color, meshes: null, x: 0, z: 0, y: 0, h: 0, vx: 0, vz: 0, vf: 0, vl: 0, spd: 0,
    steer: 0, pitch: 0, lean: 0, roll: 0, nitro: 1, nitroOn: false, driver: null, st: statsFor(def, upg), ai: null,
    hitT: 0, brake: false, L: def.shape.L, W: def.shape.W, bumpT: 0, drifting: false, mods: mods || null
  };
  c.meshes = carMeshes(def, c.col, c.mods);
  c.mass = massOf(c);
  cars.push(c);
  return c;
}
function removeCar(c) { const i = cars.indexOf(c); if (i >= 0) cars.splice(i, 1); if (OWN === c) OWN = null; if (P.car === c) { P.car = null; P.vis = true; } }
function setCarColor(c, hex) { c.col = hex; c.meshes = carMeshes(c.def, hex, c.mods); }

/* физика управляемой / свободно катящейся машины */
function stepHeli(c, inp, dt) {
  const st = c.st, drv = !!inp;
  if (c.alt === undefined) c.alt = 0;
  const rf = roofInfo(c.x, c.z, 0.6), fl = rf ? rf.y : 0; c.fl = fl;
  if (c.alt < fl) c.alt = fl;
  const air = c.alt - fl > 0.6, roof = fl > 0 && !air;
  if (drv) {
    c.steer += (inp.steer - c.steer) * Math.min(1, dt * 6);
    c.h -= c.steer * 1.5 * dt * (air ? 1 : clamp(Math.abs(c.vf) / 6, 0, 1));
    if (inp.nitro) c.alt = Math.min(160, c.alt + 11 * dt);
    else if (inp.hand) c.alt = Math.max(fl, c.alt - 11 * dt);
  } else if (c.alt > fl) c.alt = Math.max(fl, c.alt - 6 * dt);
  const fx = Math.sin(c.h), fz = Math.cos(c.h), rx = -fz, rz = fx;
  let vf = c.vx * fx + c.vz * fz, vl = c.vx * rx + c.vz * rz;
  if (drv) {
    const cap = air ? st.maxSpeed : 8;
    if (inp.gas > 0 && !roof) vf += st.accel * 0.8 * inp.gas * Math.max(0, 1 - Math.pow(Math.max(0, vf) / cap, 2)) * dt;
    if (inp.brake > 0 && !roof) vf = vf > 0.5 ? Math.max(0, vf - st.brake * 0.6 * inp.brake * dt) : Math.max(-10, vf - st.accel * 0.4 * inp.brake * dt);
  }
  c.brake = false; c.nitroOn = false;
  vf *= Math.exp(-(air ? 0.25 : roof ? 9 : 2.2) * dt);
  vl *= Math.exp(-(air ? 1.4 : roof ? 9 : 6) * dt);
  c.vx = fx * vf + rx * vl; c.vz = fz * vf + rz * vl;
  c.x += c.vx * dt; c.z += c.vz * dt; c.vf = vf; c.vl = vl;
}
function stepPhys(c, inp, dt) {
  if (c.def.heli) { stepHeli(c, inp, dt); return; }
  const st = c.st, drv = !!inp;
  let fx = Math.sin(c.h), fz = Math.cos(c.h);
  let nit = false;
  if (drv && inp.nitro && c.nitro > 0.02 && inp.gas > 0.1 && c.vf > 3) { nit = true; c.nitro = Math.max(0, c.nitro - dt * 0.3 / st.nitro); }
  else c.nitro = Math.min(1, c.nitro + dt * (drv ? 0.05 : 0.1));
  if (nit && !c.nitroOn) SFX.nitro();
  c.nitroOn = nit;
  const maxS = st.maxSpeed * (nit ? 1.32 : 1) * (drv ? v25Car(c, inp, dt) : 1);
  if (drv) {
    const sp = Math.abs(c.vf);
    const tgt = inp.steer;
    c.steer += (tgt - c.steer) * Math.min(1, dt * (Math.abs(tgt) > 0.01 ? 7 : 10));
    const rate = c.steer * st.handling * 2.3 * clamp(sp / 5, 0, 1) / (1 + sp / 40) * (inp.hand ? 1.5 : 1);
    c.h -= rate * dt * (c.vf >= -0.5 ? 1 : -1);
    if (c.dmg > 40) c.h += (c.pullDir || 1) * 0.12 * ((c.dmg - 40) / 60) * clamp(sp / 20, 0, 1) * dt;
    fx = Math.sin(c.h); fz = Math.cos(c.h);
  }
  const rx = -fz, rz = fx;
  let vf = c.vx * fx + c.vz * fz, vl = c.vx * rx + c.vz * rz;
  if (drv) {
    let a = 0;
    if (inp.gas > 0) {
      if (vf < -0.5) vf += st.brake * inp.gas * dt;
      else { const ratio = clamp(vf / maxS, 0, 1.2); a = st.accel * (nit ? 2.2 : 1) * inp.gas * Math.max(0, 1 - Math.pow(ratio, 2.2)); }
    }
    if (inp.brake > 0) {
      if (vf > 0.6) vf = Math.max(0, vf - st.brake * inp.brake * dt);
      else vf = Math.max(-13, vf - st.accel * 0.55 * inp.brake * dt);
    }
    vf += a * dt;
    if (inp.gas <= 0 && inp.brake <= 0) { const dv = Math.min(Math.abs(vf), 2.4 * dt); vf -= Math.sign(vf) * dv; }
    if (inp.hand) { const dv = Math.min(Math.abs(vf), 7 * dt); vf -= Math.sign(vf) * dv; }
    c.brake = inp.brake > 0 && vf > 0.5 || inp.hand;
    const sp = Math.abs(vf);
    let grip = st.grip * (1 - clamp((sp - 30) / 90, 0, 0.35)) * (1 - 0.3 * WX.rain - (WINTER.on ? 0.1 + 0.15 * WX.rain : 0));
    if (inp.hand) grip = 1.1;
    vl *= Math.exp(-grip * dt);
  } else {
    vf *= Math.exp(-1.8 * dt); vl *= Math.exp(-6 * dt); c.brake = false;
    if (Math.abs(vf) < 0.15) vf = 0;
    if (Math.abs(vl) < 0.1) vl = 0;
  }
  vf -= vf * Math.abs(vf) * 0.0007 * dt;
  if (drv && c.lim && vf > maxS) vf -= (vf - maxS) * Math.min(1, dt * 1.5);
  c.vx = fx * vf + rx * vl; c.vz = fz * vf + rz * vl;
  c.x += c.vx * dt; c.z += c.vz * dt;
  c.vf = vf; c.vl = vl;
}

/* столкновения машины со зданиями и деревьями */
function carWalls(c) {
  let impact = 0;
  const off = c.L * 0.5 - 0.9;
  for (let k = 1; k >= -1; k -= 2) {
    const p = { x: c.x + Math.sin(c.h) * off * k, z: c.z + Math.cos(c.h) * off * k };
    const ox = p.x, oz = p.z;
    if (pushCircle(p, 0.95, c.alt)) {
      c.x += p.x - ox; c.z += p.z - oz;
      const vn = c.vx * HIT.nx + c.vz * HIT.nz;
      if (vn < 0) { c.vx -= 1.25 * vn * HIT.nx; c.vz -= 1.25 * vn * HIT.nz; impact = Math.max(impact, -vn); }
    }
  }
  const lim = WLIM();
  if (c.x > lim) { c.x = lim; if (c.vx > 0) { impact = Math.max(impact, c.vx); c.vx *= -0.3; } }
  if (c.x < -lim) { c.x = -lim; if (c.vx < 0) { impact = Math.max(impact, -c.vx); c.vx *= -0.3; } }
  if (c.z > lim) { c.z = lim; if (c.vz > 0) { impact = Math.max(impact, c.vz); c.vz *= -0.3; } }
  if (c.z < -lim) { c.z = -lim; if (c.vz < 0) { impact = Math.max(impact, -c.vz); c.vz *= -0.3; } }
  return impact;
}
/* столкновение пары машин (a — динамическая) */
function carPair(a, b) {
  const dx = b.x - a.x, dz = b.z - a.z;
  if (dx * dx + dz * dz > 49) return 0;
  const fa = [Math.sin(a.h), Math.cos(a.h)], fb = [Math.sin(b.h), Math.cos(b.h)], R = 0.98;
  let best = null;
  for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
    const ax = a.x + fa[0] * i * a.L * 0.28, az = a.z + fa[1] * i * a.L * 0.28;
    const bx = b.x + fb[0] * j * b.L * 0.28, bz = b.z + fb[1] * j * b.L * 0.28;
    const d = Math.hypot(ax - bx, az - bz);
    if (d < 2 * R && (!best || d < best.d)) best = { d, nx: ax - bx, nz: az - bz };
  }
  if (!best) return 0;
  let l = Math.hypot(best.nx, best.nz) || 1; const nx = best.nx / l, nz = best.nz / l, pen = 2 * R - best.d;
  const ma = a.mass, mb = b.mass, tot = ma + mb;
  a.x += nx * pen * mb / tot; a.z += nz * pen * mb / tot;
  b.x -= nx * pen * ma / tot; b.z -= nz * pen * ma / tot;
  const vrel = (a.vx - b.vx) * nx + (a.vz - b.vz) * nz;
  if (vrel < 0) {
    const j = -1.35 * vrel / (1 / ma + 1 / mb);
    a.vx += j / ma * nx; a.vz += j / ma * nz; b.vx -= j / mb * nx; b.vz -= j / mb * nz;
    if (b.ai) { b.spd = Math.max(0, b.vx * fb[0] + b.vz * fb[1]); b.hitT = 0.6; }
    return -vrel;
  }
  return 0;
}

/* ---- ИИ машин (трафик / гонщики / полиция) ---- */
function dirBetween(a, b) {
  if (b[0] > a[0]) return 0; if (b[1] > a[1]) return 1; if (b[0] < a[0]) return 2; return 3;
}
function pushTransition(ai, i, j, dIn, dOut, lane, cornerSp) {
  const ax = nodeC(i), az = nodeC(j), rIn = rightOf(dIn), rOut = rightOf(dOut), fi = DIRS[dIn], fo = DIRS[dOut];
  if (dIn === dOut) ai.wps.push({ x: ax + fi[0] * 9 + rIn[0] * lane, z: az + fi[1] * 9 + rIn[1] * lane });
  else ai.wps.push({ x: ax + rIn[0] * lane + rOut[0] * lane, z: az + rIn[1] * lane + rOut[1] * lane, sp: cornerSp });
  const bx = nodeC(i + fo[0]), bz = nodeC(j + fo[1]);
  ai.wps.push({ x: bx - fo[0] * 14 + rOut[0] * lane, z: bz - fo[1] * 14 + rOut[1] * lane });
}
function validDirs(i, j, dIn) {
  const o = [];
  for (let d = 0; d < 4; d++) {
    if (d === (dIn + 2) % 4) continue;
    const ni = i + DIRS[d][0], nj = j + DIRS[d][1];
    if (ni < 0 || nj < 0 || ni > GRID || nj > GRID) continue;
    o.push(d);
  }
  if (!o.length) o.push((dIn + 2) % 4);
  return o;
}
function aiPlan(c) {
  const ai = c.ai;
  if (ai.mode === 'traffic') {
    const opts = validDirs(ai.i, ai.j, ai.d);
    let dOut = opts[0], best = -1;
    for (const d of opts) { const w = (d === ai.d ? 2.4 : 1) * Math.random(); if (w > best) { best = w; dOut = d; } }
    pushTransition(ai, ai.i, ai.j, ai.d, dOut, LANE, 9);
    ai.i += DIRS[dOut][0]; ai.j += DIRS[dOut][1]; ai.d = dOut;
  } else if (ai.mode === 'race') {
    const r = ai.route, k = ai.k;
    if (k >= r.length - 1) { ai.wps.push({ x: c.x + Math.sin(c.h) * 25, z: c.z + Math.cos(c.h) * 25 }); return; }
    const dOut = dirBetween(r[k], r[k + 1]);
    pushTransition(ai, r[k][0], r[k][1], ai.d, dOut, 2.4, 15);
    ai.d = dOut; ai.k = k + 1;
  } else if (ai.mode === 'police') {
    const tg = P.car || P;
    const opts = validDirs(ai.i, ai.j, ai.d);
    let dOut = opts[0], best = 1e9;
    for (const d of opts) {
      const nx = nodeC(ai.i + DIRS[d][0]), nz = nodeC(ai.j + DIRS[d][1]);
      const sc = Math.hypot(nx - tg.x, nz - tg.z) + Math.random() * 25;
      if (sc < best) { best = sc; dOut = d; }
    }
    pushTransition(ai, ai.i, ai.j, ai.d, dOut, 2, 14);
    ai.i += DIRS[dOut][0]; ai.j += DIRS[dOut][1]; ai.d = dOut;
  }
}
