/* ===================== v38: ТЕЛЕФОН, РЕДАКТОР КНОПОК, ОБВЕСЫ В РУКАХ, БЛИЖНИЙ БОЙ ===================== */
{
  /* ---------- 1. Экраны под телефон ---------- */
  const css = document.createElement('style');
  css.textContent = `
body.scr-on #cbBtns, body.scr-on #hintBox, body.scr-on #distPill { display: none !important; }
@media (max-height: 520px) {
  .screen { padding: calc(var(--safe-t) + 4px) calc(var(--safe-r) + 6px) calc(var(--safe-b) + 4px) calc(var(--safe-l) + 6px); }
  .panel { padding: 8px 10px; border-radius: 14px; max-height: 98vh; width: min(97vw, 860px); }
  .panel h2 { font-size: 18px; }
  .ps-head { margin-bottom: 6px; gap: 8px; }
  .ps-head .btn.small { padding: 6px 10px; font-size: 13px; }
  .scroll { gap: 6px; }
  .card { padding: 7px 9px; gap: 8px; border-radius: 12px; }
  .mission .m-ico { font-size: 26px; width: 34px; }
  .m-title { font-size: 14px; } .m-desc { font-size: 12px; margin: 1px 0 3px; }
  .c-body small { font-size: 11px; } .tag { font-size: 11px; padding: 2px 7px; }
  .card .btn, .upg .btn { padding: 7px 12px; font-size: 13px; }
  .btn { padding: 9px 12px; font-size: 14px; }
  .set { padding: 4px 2px; font-size: 13.5px; gap: 8px; }
  .set select { padding: 5px; font-size: 13px; }
  #settings .panel.narrow { width: min(97vw, 860px); }
  #settings .scroll { display: grid; grid-template-columns: 1fr 1fr; gap: 0 18px; align-content: start; }
  #settings .scroll > .btn { margin: 4px 0; align-self: start; }
  #settings .scroll > #ctlBox { grid-column: 1 / -1; }
  #missionList, #achList { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; align-content: start; }
  .panel.side { width: min(54vw, 440px); }
  .pv-info { padding: 8px 10px; } .pv-info h3 { font-size: 15px; } .pv-info p { font-size: 12px; margin: 2px 0; }
  .bar { font-size: 12px; margin: 1px 0; } .bar span { width: 74px; }
  .upg { padding: 5px 8px; gap: 8px; } .u-ico { font-size: 20px; } .u-body small { font-size: 10.5px; }
  .chip { padding: 4px 9px; font-size: 12px; }
  .sw { width: 28px; height: 28px; }
}
@media (max-width: 520px) and (orientation: portrait) {
  .panel { padding: 10px; width: 98vw; border-radius: 14px; }
  .panel h2 { font-size: 19px; }
  .card { padding: 9px; gap: 8px; }
  .m-desc { font-size: 12.5px; }
  .set { font-size: 14px; }
  .set input[type=range] { width: 42%; }
}
/* ---------- редактор кнопок ---------- */
#touch .tbtn, #touch #stick, #cbBtns button { opacity: var(--glop, 1); }
#beBar { position: fixed; z-index: 130; left: 50%; top: calc(var(--safe-t) + 6px); transform: translateX(-50%); display: none; flex-wrap: wrap; gap: 6px 8px; justify-content: center; align-items: center;
  max-width: 96vw; padding: 8px 10px; background: rgba(10, 14, 28, .94); border: 1px solid var(--acc); border-radius: 14px; box-shadow: 0 8px 30px rgba(0, 0, 0, .6); font-size: 13px; color: #fff; }
body.btnedit #beBar { display: flex; }
@media (max-height: 520px) { #beBar { gap: 4px 6px; padding: 5px 8px; font-size: 12px; } #beBar button { padding: 4px 8px; min-height: 30px; font-size: 12px; } #beSel { min-width: 90px; } #beBar input[type=range] { width: 70px; } }
#beBar button { border: 1px solid var(--line); background: rgba(255, 255, 255, .1); border-radius: 10px; padding: 7px 11px; font-size: 13px; font-weight: 700; min-height: 36px; }
#beBar button.on { background: var(--acc); color: #1a0f00; border-color: transparent; }
#beBar button.primary { background: linear-gradient(180deg, #ffc233, #ff8c1a); color: #1a0f00; border-color: transparent; }
#beBar label { display: flex; align-items: center; gap: 6px; } #beBar input[type=range] { width: 90px; accent-color: var(--acc); }
#beSel { min-width: 120px; text-align: center; color: var(--gold); font-weight: 800; }
body.btnedit .screen { display: none !important; }
body.btnedit #hud, body.btnedit #hud.hidden { display: block !important; }
body.btnedit #touch { display: block !important; }
body.btnedit #mPanel, body.btnedit #hintBox, body.btnedit #cbBadge { display: none !important; }
body.btnedit.be-foot #steerBtns, body.btnedit.be-foot #actCar, body.btnedit.be-foot #actCarGun { display: none !important; }
body.btnedit.be-foot #stick { display: block !important; } body.btnedit.be-foot #actFoot, body.btnedit.be-foot #actGun, body.btnedit.be-foot #cbBtns { display: flex !important; }
body.btnedit.be-car #stick, body.btnedit.be-car #actFoot, body.btnedit.be-car #actGun, body.btnedit.be-car #cbBtns { display: none !important; }
body.btnedit.be-car #steerBtns, body.btnedit.be-car #actCarGun { display: flex !important; } body.btnedit.be-car #actCar { display: block !important; }
body.btnedit #btnZoom, body.btnedit .tbtn.act, body.btnedit .tbtn.act2 { display: flex !important; }
body.btnedit .tbtn.act:empty::before { content: 'Действие'; } body.btnedit .tbtn.act2:empty::before { content: 'Метка'; }
body.btnedit #touch .tbtn, body.btnedit #touch #stick, body.btnedit #cbBtns button { outline: 2px dashed rgba(255, 255, 255, .55); outline-offset: 2px; cursor: grab; pointer-events: auto !important; opacity: 1; }
body.btnedit .be-sel { outline: 3px solid #ffb703 !important; background: rgba(255, 183, 3, .35); }
`;
  document.head.appendChild(css);
  const ssA = showScreen;
  showScreen = function () { const r = ssA.apply(this, arguments); document.body.classList.toggle('scr-on', !!UI.cur); return r; };

  /* ---------- 2. Редактор экранных кнопок ---------- */
  const LK = 'gl_btnlay_v1';
  let LAY = {};
  try { LAY = JSON.parse(localStorage.getItem(LK) || '{}') || {}; } catch (e) { LAY = {}; }
  const saveLay = () => { try { localStorage.setItem(LK, JSON.stringify(LAY)); } catch (e) { } };
  const TSEL = '#touch .tbtn, #touch #stick, #cbBtns button';
  const keyOf = el => el.id ? '#' + el.id : ((el.parentElement && el.parentElement.id) || '') + ':' + (el.dataset.hold || el.dataset.tap || el.dataset.v28 || (el.textContent || '').replace(/\s+/g, '').slice(0, 10));
  function applyOne(el) {
    const k = keyOf(el), L = LAY[k] || { x: 0, y: 0, s: 1 };
    el.dataset.glk = k;
    const tr = (L.x || L.y) ? L.x + 'px ' + L.y + 'px' : '';
    if (el.id === 'stick') {
      const z = Math.round(130 * L.s), kz = Math.round(60 * L.s), kn = el.querySelector('#knob');
      el.style.width = el.style.height = L.s === 1 ? '' : z + 'px';
      if (kn) { kn.style.width = kn.style.height = L.s === 1 ? '' : kz + 'px'; kn.style.left = kn.style.top = L.s === 1 ? '' : Math.round((z - kz) / 2) + 'px'; }
      el.style.translate = tr;
    } else { el.style.translate = tr; el.style.scale = L.s === 1 ? '' : String(L.s); }
  }
  const applyAll = () => document.querySelectorAll(TSEL).forEach(applyOne);
  const applyOp = () => document.documentElement.style.setProperty('--glop', String(LAY._op || 1));
  applyAll(); applyOp();
  setInterval(() => { document.querySelectorAll(TSEL).forEach(el => { if (!el.dataset.glk) applyOne(el); }); }, 1500);

  const bar = document.createElement('div'); bar.id = 'beBar';
  bar.innerHTML = '<button data-be="foot" class="on">🚶 Пешком</button><button data-be="car">🚗 В машине</button><span id="beSel">Нажмите на кнопку</span>'
    + '<button data-be="minus">−</button><button data-be="plus">＋</button><button data-be="rs">↺ Кнопка</button>'
    + '<label>Прозрачность <input id="beOp" type="range" min="0.25" max="1" step="0.05"></label><button data-be="all">↺ Все</button><button data-be="done" class="primary">✔ Готово</button>';
  document.body.appendChild(bar);
  const EB = { on: false, sel: null };
  const labelOf = el => el.id === 'stick' ? 'Джойстик' : ((el.textContent || '').replace(/\s+/g, ' ').trim() || (el.id === 'btnEnter' ? 'Действие' : el.id === 'btnMarker' ? 'Метка' : 'Кнопка'));
  function pick(el) {
    if (EB.sel) EB.sel.classList.remove('be-sel');
    EB.sel = el; const s = $('beSel');
    if (!el) { s.textContent = 'Нажмите на кнопку'; return; }
    el.classList.add('be-sel'); const L = LAY[keyOf(el)] || { s: 1 };
    s.textContent = labelOf(el).slice(0, 18) + ' · ×' + (L.s || 1).toFixed(1);
  }
  function setTab(t) {
    document.body.classList.toggle('be-foot', t === 'foot'); document.body.classList.toggle('be-car', t === 'car');
    bar.querySelectorAll('[data-be="foot"],[data-be="car"]').forEach(b => b.classList.toggle('on', b.dataset.be === t)); pick(null);
  }
  function editOn() {
    EB.on = true; document.body.classList.add('btnedit'); $('beOp').value = LAY._op || 1; setTab('foot'); applyAll();
  }
  function editOff() {
    EB.on = false; pick(null); document.body.classList.remove('btnedit', 'be-foot', 'be-car'); saveLay();
  }
  function clampOn(el, L) {
    const r = el.getBoundingClientRect(); let dx = 0, dy = 0;
    if (r.left < 0) dx = -r.left; else if (r.right > innerWidth) dx = innerWidth - r.right;
    if (r.top < 0) dy = -r.top; else if (r.bottom > innerHeight) dy = innerHeight - r.bottom;
    if (dx || dy) { L.x = Math.round(L.x + dx); L.y = Math.round(L.y + dy); applyOne(el); }
  }
  let drag = null;
  document.addEventListener('pointerdown', e => {
    if (!EB.on || e.target.closest('#beBar')) return;
    e.stopImmediatePropagation(); e.preventDefault();
    const el = e.target.closest(TSEL);
    if (!el) { pick(null); return; }
    const k = keyOf(el), L = LAY[k] || (LAY[k] = { x: 0, y: 0, s: 1 });
    pick(el); drag = { el, id: e.pointerId, sx: e.clientX, sy: e.clientY, x0: L.x || 0, y0: L.y || 0, L };
  }, true);
  document.addEventListener('pointermove', e => {
    if (!EB.on || !drag || e.pointerId !== drag.id) return;
    e.stopImmediatePropagation(); drag.L.x = Math.round(drag.x0 + e.clientX - drag.sx); drag.L.y = Math.round(drag.y0 + e.clientY - drag.sy);
    applyOne(drag.el); clampOn(drag.el, drag.L);
  }, true);
  const dEnd = e => { if (!EB.on || !drag || e.pointerId !== drag.id) return; e.stopImmediatePropagation(); drag = null; saveLay(); };
  document.addEventListener('pointerup', dEnd, true); document.addEventListener('pointercancel', dEnd, true);
  document.addEventListener('contextmenu', e => { if (EB.on) e.preventDefault(); }, true);
  bar.addEventListener('click', e => {
    const b = e.target.closest('[data-be]'); if (!b) return; const a = b.dataset.be;
    if (a === 'foot' || a === 'car') setTab(a);
    else if (a === 'done') editOff();
    else if (a === 'plus' || a === 'minus') {
      if (!EB.sel) { toast('Сначала нажмите на кнопку'); return; }
      const k = keyOf(EB.sel), L = LAY[k] || (LAY[k] = { x: 0, y: 0, s: 1 });
      L.s = Math.max(0.5, Math.min(2, Math.round(((L.s || 1) + (a === 'plus' ? 0.1 : -0.1)) * 10) / 10)); applyOne(EB.sel); clampOn(EB.sel, L); saveLay(); pick(EB.sel);
    } else if (a === 'rs') {
      if (!EB.sel) { toast('Сначала нажмите на кнопку'); return; }
      delete LAY[keyOf(EB.sel)]; applyOne(EB.sel); saveLay(); pick(EB.sel);
    } else if (a === 'all') {
      for (const k of Object.keys(LAY)) if (k !== '_op') delete LAY[k];
      delete LAY._op; applyAll(); applyOp(); $('beOp').value = 1; saveLay(); pick(null); toast('Расположение кнопок сброшено');
    }
  });
  $('beOp').addEventListener('input', e => { LAY._op = +e.target.value; applyOp(); saveLay(); });
  window.addEventListener('resize', () => { if (EB.on && EB.sel) clampOn(EB.sel, LAY[keyOf(EB.sel)] || { x: 0, y: 0, s: 1 }); });

  /* ---------- 3. Кнопки в настройках: редактор, установка ---------- */
  const fsBtn = document.querySelector('#settings [data-act="fullscreen"]');
  if (fsBtn) {
    const be = document.createElement('button'); be.className = 'btn'; be.textContent = '🎛 Расположение и размер кнопок';
    be.addEventListener('click', () => { SFX.click(); editOn(); });
    const ins = document.createElement('button'); ins.className = 'btn'; ins.id = 'glInstall'; ins.style.display = 'none'; ins.textContent = '📲 Установить как приложение';
    const anchor = document.getElementById('ctlBox') || fsBtn; anchor.insertAdjacentElement('beforebegin', be); anchor.insertAdjacentElement('beforebegin', ins);
    let dip = null;
    const standalone = () => (window.matchMedia && (matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: fullscreen)').matches)) || navigator.standalone;
    const ios = /iphone|ipad|ipod/i.test(navigator.userAgent) && !standalone();
    if (ios) ins.style.display = '';
    window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); dip = e; if (!standalone()) ins.style.display = ''; });
    window.addEventListener('appinstalled', () => { ins.style.display = 'none'; dip = null; toast('📲 Приложение установлено'); });
    ins.addEventListener('click', () => {
      SFX.click();
      if (dip) { dip.prompt(); dip.userChoice.then(() => { dip = null; ins.style.display = 'none'; }).catch(() => { }); }
      else toast('📲 На iPhone: «Поделиться» → «На экран Домой»');
    });
  }
  // офлайн-режим: service worker и уведомления о сети
  try { if ('serviceWorker' in navigator && window.isSecureContext) navigator.serviceWorker.register('/sw.js').catch(() => { }); } catch (e) { }
  window.addEventListener('offline', () => toast('📴 Нет сети: одиночная игра работает, мультиплеер недоступен'));
  window.addEventListener('online', () => toast('🌐 Сеть появилась'));

  /* ---------- 4. Убрать / достать оружие ---------- */
  function holster() {
    if (P.car || G.inHome || P.hp <= 0 || G.mode !== 'play') return;
    if (S.guns.sel !== 'fist') { S.guns.hol = S.guns.sel; selectWeapon('fist'); toast('✊ Оружие убрано'); return; }
    let b = S.guns.hol;
    if (!(b && b !== 'fist' && S.guns.own[b])) { const o = WEAPONS.filter(w => S.guns.own[w.id] && w.id !== 'fist'); b = o.length ? o[0].id : null; }
    if (b) selectWeapon(b); else toast('У вас нет оружия');
  }
  window.__holster = holster;
  window.addEventListener('keydown', e => { if (e.code === 'KeyT' && !e.repeat && UI.cur === null && !EB.on) holster(); });
  const cb = $('cbBtns');
  if (cb) {
    const hb = document.createElement('button'); hb.innerHTML = '✊<small>убрать</small>';
    hb.addEventListener('pointerdown', e => { e.preventDefault(); auInit(); holster(); });
    cb.appendChild(hb);
  }

  /* ---------- 5. Ближний бой: замах, блок, добивание ---------- */
  window.__PGUN = PGUN;
  const BLADE = { bat: 1, knife: 1, machete: 1, katana: 1 };
  const pn0 = punch;
  punch = function (d) {
    if (!BLADE[d.id] || P.car) return pn0(d);
    if (WS.cd > 0 || PGUN.swT > 0) return;
    PGUN.swT = 0.0001; PGUN.swDur = Math.max(0.28, Math.min(0.5, d.rate * 1.15)); PGUN.swD = d; PGUN.swHit = false; WS.cd = PGUN.swDur; P.aimT = 0.45;
  };
  const cbm0 = cbMelee;
  cbMelee = function (t, kind, base) {
    const pre = t && t.hp, dm = cbm0(t, kind, base);
    if (kind !== 'ped' && t && pre !== undefined && pre > 0 && dm === pre + 1 && BLADE[S.guns.sel]) {
      PGUN.fin = 0.45; CAM.shake = Math.max(CAM.shake || 0, 0.4);
      for (let i = 0; i < 3; i++) sparks(t.x, 1.0 + i * 0.25, t.z, [0.9, 0.1, 0.1]);
    }
    return dm;
  };
  const uc3 = updateCombat;
  updateCombat = function (dt) {
    const r = uc3.apply(this, arguments);
    if (PGUN.swT > 0) {
      if (S.guns.sel !== PGUN.swD.id || P.car || P.hp <= 0) PGUN.swT = 0;
      else {
        PGUN.swT += dt / PGUN.swDur;
        if (!PGUN.swHit && PGUN.swT >= 0.3) { PGUN.swHit = true; WS.cd = 0; pn0(PGUN.swD); WS.cd = Math.max(0, PGUN.swDur * (1 - PGUN.swT)); }
        if (PGUN.swT >= 1) PGUN.swT = 0;
      }
    }
    if (PGUN.fin > 0) PGUN.fin -= dt;
    PGUN.blk = !!(CB.block && wDef().melee && !P.car);
    return r;
  };
  /* ---------- 6. Прицел: окуляр не закрывает кнопки, «Огонь» всегда виден ---------- */
  const sc = document.createElement('style');
  sc.textContent = `
#scope { background: radial-gradient(circle at 50% 50%, transparent 0, transparent 42.6vmin, rgba(0,0,0,.9) 43.2vmin, rgba(0,0,0,.9) 44vmin, rgba(0,0,0,.28) 44.6vmin, rgba(0,0,0,.34) 100%); }
#scope::before { background: linear-gradient(#000,#000) 50% 50%/100% 1px no-repeat, linear-gradient(#000,#000) 0 50%/14% 2px no-repeat, linear-gradient(#000,#000) 100% 50%/14% 2px no-repeat; }
#scope::after { background: linear-gradient(#000,#000) 50% 50%/1px 100% no-repeat, linear-gradient(#000,#000) 50% 0/2px 14% no-repeat, linear-gradient(#000,#000) 50% 100%/2px 14% no-repeat; }
body.scoping #touch .tbtn, body.scoping #cbBtns button { background: rgba(14, 18, 30, .6); border-color: rgba(255, 255, 255, .8); box-shadow: 0 0 0 1px rgba(0, 0, 0, .5); }
body.scoping #actGun .fire { background: rgba(255, 70, 60, .6); border-color: #fff; box-shadow: 0 0 0 2px rgba(0, 0, 0, .55), 0 0 18px rgba(255, 70, 60, .8); }
`;
  document.head.appendChild(sc);
  const scEl = $('scope');
  if (scEl && window.MutationObserver) new MutationObserver(() => document.body.classList.toggle('scoping', parseFloat(scEl.style.opacity || 0) > 0.05)).observe(scEl, { attributes: true, attributeFilter: ['style'] });

  /* ---------- 7. Поворот к цели при прицеливании + кнопка «прицел» под «зум» ---------- */
  const ucP = updateCombat;
  updateCombat = function (dt) {
    if (!P.car && P.downT <= 0 && P.hp > 0 && aimManual()) P.h = CAM.yaw;
    return ucP.apply(this, arguments);
  };
  const ag = $('actGun'), bA = $('btnAim'), bZ = $('btnZoom');
  if (ag && bA && bZ && !$('actAimCol')) {
    const col = document.createElement('div'); col.id = 'actAimCol';
    col.style.cssText = 'display:flex;flex-direction:column;gap:8px;align-items:center;';
    ag.insertBefore(col, ag.firstChild); col.appendChild(bA); col.appendChild(bZ);
  }
}

/* ---- v39: промзоны (стройка, склады, аэродром) ---- */
function indKind(key) { return ({ '1,3': 'build', '14,4': 'ware', '1,11': 'air' })[key] || null; }
function buildIndustrial(WORLD, cx, cz, kind) {
  const G = WORLD.g(), R = rng(cx * 7 + cz * 13 + 5);
  const W = indKind.w = indKind.w || {};
  const wk = W[kind] = [];
  const dirt = kind === 'air' ? [0.42, 0.5, 0.36, 1] : [0.46, 0.44, 0.41, 1];
  G.box(cx - 32, 0, cz - 32, cx + 32, 0.16, cz + 32, [0.6, 0.6, 0.58, 1], false, true);
  G.box(cx - 29, 0.16, cz - 29, cx + 29, 0.2, cz + 29, dirt, false, true);
  const fc = [0.5, 0.55, 0.5, 1], gate = kind === 'air' ? [-5, 5] : [-4.5, 4.5];
  const fence = (x0, z0, x1, z1) => { G.box(x0, 0.2, z0, x1, 2.2, z1, fc, false, true); boxes.push({ x0: Math.min(x0, x1) - 0.1, x1: Math.max(x0, x1) + 0.1, z0: Math.min(z0, z1) - 0.1, z1: Math.max(z0, z1) + 0.1, h: 2.2 }); };
  fence(cx - 29, cz - 29.2, cx + gate[0], cz - 28.8); fence(cx + gate[1], cz - 29.2, cx + 29, cz - 28.8);
  fence(cx - 29, cz + 28.8, cx + 29, cz + 29.2); fence(cx - 29.2, cz - 29, cx - 28.8, cz + 29); fence(cx + 28.8, cz - 29, cx + 29.2, cz + 29);
  G.box(cx + gate[0] - 0.4, 0.2, cz - 29.6, cx + gate[0] + 0.2, 3.2, cz - 28.4, [0.9, 0.7, 0.1, 1], false, true);
  G.box(cx + gate[1] - 0.2, 0.2, cz - 29.6, cx + gate[1] + 0.4, 3.2, cz - 28.4, [0.9, 0.7, 0.1, 1], false, true);
  G.box(cx + gate[0], 3.2, cz - 29.6, cx + gate[1], 3.7, cz - 28.4, [0.85, 0.15, 0.1, 1], false, true);
  const solid = (x0, y0, z0, x1, y1, z1, c) => { G.box(x0, y0, z0, x1, y1, z1, c, false, true); boxes.push({ x0, x1, z0, z1, h: y1 }); };
  const wl = (a, b, sp, vest, carry) => wk.push({ a, b, sp, u: R(), dir: R() < 0.5 ? 1 : -1, ph: R() * 6, wait: 0, vest, carry });
  if (kind === 'build') {
    const gx = cx - 14, gz = cz - 6, cc = [0.62, 0.62, 0.6, 1];
    for (let f = 0; f < 3; f++) {
      const y = 0.2 + f * 3.4;
      for (let i = 0; i < 4; i++) for (let j = 0; j < 3; j++) { const px = gx + i * 6.4, pz = gz + j * 8; if (f === 0) solid(px, y, pz, px + 0.8, y + 3, pz + 0.8, cc); else G.box(px, y, pz, px + 0.8, y + 3, pz + 0.8, cc, false, true); }
      G.box(gx - 0.4, y + 3, gz - 0.4, gx + 19.6, y + 3.4, gz + 16.4, [0.7, 0.7, 0.68, 1], false, true);
    }
    G.box(gx - 0.2, 10.4, gz - 0.2, gx + 19.4, 10.6, gz + 0.2, [0.9, 0.5, 0.1, 1], false, true);
    G.box(cx + 18, 0.2, cz - 22, cx + 19.8, 40, cz - 20.2, [0.95, 0.75, 0.1, 1], false, true); boxes.push({ x0: cx + 18, x1: cx + 19.8, z0: cz - 22, z1: cz - 20.2, h: 40 });
    G.box(cx - 8, 40, cz - 21.6, cx + 32, 40.8, cz - 20.6, [0.95, 0.75, 0.1, 1], false, true);
    G.box(cx + 21, 38.6, cz - 21.8, cx + 24, 41.5, cz - 20.4, [0.2, 0.55, 0.8, 1], false, true);
    G.box(cx - 3, 35, cz - 21.4, cx - 2.7, 40, cz - 20.8, [0.1, 0.1, 0.1, 1], false, true);
    solid(cx - 4, 35, cz - 21.8, cx - 1.6, 36.2, cz - 20.4, [0.8, 0.3, 0.1, 1]);
    solid(cx + 18, 0.2, cz + 12, cx + 26, 2.9, cz + 15, [0.9, 0.7, 0.15, 1]); solid(cx + 18, 0.2, cz + 17, cx + 26, 2.9, cz + 20, [0.2, 0.5, 0.75, 1]);
    for (const [px, pz] of [[-24, 8], [-22, 18], [-6, 20]]) G.cone(cx + px, 0.2, cz + pz, 3 + R() * 1.5, 2.2 + R(), 8, [0.75, 0.68, 0.5]);
    for (let k = 0; k < 4; k++) solid(cx - 26 + k * 2.2, 0.2, cz + 24, cx - 24.4 + k * 2.2, 1.4, cz + 26, [0.7, 0.3, 0.2, 1]);
    for (let k = 0; k < 6; k++) wl([cx - 20 + R() * 6, cz - 2 + R() * 14], [cx - 2 + R() * 6, cz - 2 + R() * 14], 1.5 + R() * 0.5, [0.95, 0.5, 0.1]);
    wl([cx - 24, cz + 4], [cx - 24, cz + 20], 1.4, [0.95, 0.5, 0.1], true); wl([cx + 8, cz + 22], [cx + 14, cz + 6], 1.3, [0.95, 0.5, 0.1], true);
  } else if (kind === 'ware') {
    const pal = [[0.8, 0.2, 0.18, 1], [0.15, 0.4, 0.75, 1], [0.9, 0.65, 0.1, 1], [0.2, 0.6, 0.3, 1], [0.55, 0.55, 0.6, 1]];
    for (const [x0, z0, x1, z1] of [[-27, -23, -3, -7], [3, -23, 27, -7]]) {
      solid(cx + x0, 0.2, cz + z0, cx + x1, 9, cz + z1, [0.58, 0.62, 0.66, 1]);
      G.box(cx + x0 - 0.3, 9, cz + z0 - 0.3, cx + x1 + 0.3, 9.6, cz + z1 + 0.3, [0.4, 0.42, 0.46, 1], false, true);
      for (let k = 0; k < 3; k++) { const dx = cx + x0 + 3 + k * ((x1 - x0 - 6) / 3); G.box(dx, 0.2, cz + z1 - 0.1, dx + 4.4, 4.6, cz + z1 + 0.3, [0.25, 0.3, 0.36, 1], false, true); }
    }
    for (let r = 0; r < 2; r++) for (let c = 0; c < 4; c++) for (let l = 0; l < 2; l++) solid(cx - 25 + c * 6.6, 0.2 + l * 2.6, cz + 6 + r * 4, cx - 19 + c * 6.6, 2.8 + l * 2.6, cz + 8.4 + r * 4, pal[Math.floor(R() * pal.length)]);
    solid(cx + 8, 0.6, cz + 8, cx + 14.5, 3.8, cz + 11, [0.9, 0.9, 0.92, 1]); solid(cx + 14.7, 0.6, cz + 8.4, cx + 17, 2.8, cz + 10.6, [0.2, 0.3, 0.6, 1]);
    solid(cx + 8, 0.2, cz + 17, cx + 12, 1.6, cz + 19, [0.95, 0.75, 0.1, 1]);
    for (let k = 0; k < 4; k++) wl([cx - 8 + k * 2, cz + 2], [cx + 8 + k, cz + 4 + k * 3], 1.8, [0.95, 0.75, 0.1], true);
    wl([cx - 26, cz + 20], [cx + 6, cz + 22], 1.5, [0.95, 0.75, 0.1], true); wl([cx + 20, cz + 6], [cx + 20, cz + 24], 1.4, [0.95, 0.75, 0.1], false);
  } else {
    G.box(cx - 6, 0.2, cz - 29, cx + 6, 0.24, cz + 29, [0.2, 0.2, 0.22, 1], false, true);
    for (let z = -26; z < 28; z += 6) G.box(cx - 0.4, 0.24, cz + z, cx + 0.4, 0.26, cz + z + 3, [0.95, 0.95, 0.9, 1], false, true);
    G.box(cx + 6, 0.2, cz - 12, cx + 24, 0.24, cz + 6, [0.3, 0.3, 0.32, 1], false, true);
    solid(cx + 12, 0.2, cz - 29 + 3, cx + 28, 8.5, cz - 29 + 20, [0.7, 0.72, 0.76, 1]); G.box(cx + 11.6, 8.5, cz - 26.4, cx + 28.4, 9.2, cz - 8.6, [0.45, 0.47, 0.52, 1], false, true);
    G.box(cx + 11.9, 0.2, cz - 8.8, cx + 28, 7.6, cz - 8.6, [0.2, 0.22, 0.28, 1], false, true);
    const px = cx + 15, pz = cz - 2, wc = [0.9, 0.9, 0.95, 1];
    solid(px, 0.9, pz, px + 1.5, 2.4, pz + 7, wc); solid(px - 4.5, 1.7, pz + 2, px + 6, 1.9, pz + 3.6, wc);
    solid(px + 0.3, 1.6, pz + 6.8, px + 1.2, 3.6, pz + 8.4, [0.85, 0.15, 0.1, 1]); G.box(px - 2, 1.8, pz + 7.6, px + 3.5, 1.95, pz + 8.2, wc, false, true);
    G.box(px + 0.2, 1.0, pz - 0.5, px + 1.3, 2.2, pz, [0.1, 0.1, 0.12, 1], false, true);
    solid(cx + 20, 0.2, cz + 14, cx + 25, 3.4, cz + 19, [0.75, 0.75, 0.78, 1]); solid(cx + 20, 0.2, cz + 21, cx + 25, 3.4, cz + 26, [0.75, 0.75, 0.78, 1]);
    G.box(cx - 12, 0.2, cz + 18, cx - 11.7, 6, cz + 18.3, [0.7, 0.7, 0.7, 1], false, true); G.box(cx - 11.7, 5.2, cz + 18, cx - 8, 6, cz + 18.3, [0.95, 0.4, 0.1, 1], false, true);
    wl([cx + 10, cz - 8], [cx + 20, cz + 2], 1.5, [0.2, 0.45, 0.8]); wl([cx + 8, cz + 8], [cx + 26, cz + 10], 1.4, [0.2, 0.45, 0.8]); wl([cx + 14, cz - 12], [cx + 14, cz + 8], 1.2, [0.95, 0.75, 0.1]);
  }
  wl([cx - 12, cz - 26], [cx + 12, cz - 26], 1.1, [0.15, 0.2, 0.3]);
}

