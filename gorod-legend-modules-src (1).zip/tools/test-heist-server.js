// Тест кооп-ограбления на сервере: node tools/test-heist-server.js
const { spawn } = require('child_process');
const srv = spawn('node', ['server-10.js'], { env: { ...process.env, PORT: '18099' }, stdio: ['ignore', 'pipe', 'inherit'] });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const mk = name => new Promise(res => { const ws = new WebSocket('ws://127.0.0.1:18099'); const c = { ws, log: [], name }; ws.onmessage = e => { const m = JSON.parse(e.data); c.log.push(m); if (m.t === 'welcome') c.id = m.id; }; ws.onopen = () => res(c); });
const send = (c, o) => c.ws.send(JSON.stringify(o));
const last = (c, t) => [...c.log].reverse().find(m => m.t === t);
(async () => {
  await sleep(600);
  const A = await mk('A'), B = await mk('B');
  send(A, { t: 'join', name: 'Alice', create: true }); await sleep(300);
  const room = last(A, 'welcome').room; send(B, { t: 'join', name: 'Bob', room }); await sleep(300);
  send(A, { t: 'heist-open', kind: 'jewel' }); await sleep(200);
  send(B, { t: 'heist-join' }); await sleep(200);
  console.log('lobby players:', last(B, 'heist-lobby').players.length);
  send(A, { t: 'heist-start' }); await sleep(300);
  console.log('go:', !!last(A, 'heist-go'), 'stage0:', last(A, 'heist-stage').k, 'actor', last(A, 'heist-stage').actor, 'A.id', A.id);
  const near = (c, x, z) => send(c, { t: 's', x, z, y: 0, h: 0 });
  near(A, -520, -132); await sleep(60); near(B, -515, -130);
  await sleep(300);
  send(A, { t: 'heist-done', i: 0, fails: 0 }); await sleep(200);
  console.log('too fast rejected:', !!last(A, 'warn'), 'still stage 0:', last(A, 'heist-stage').i === 0);
  await sleep(9000);
  near(A, -520, -132); await sleep(60);
  send(B, { t: 'heist-done', i: 0, fails: 0 }); await sleep(150);   // не тот игрок (хакер = первый)
  console.log('wrong actor ignored:', last(A, 'heist-stage').i === 0);
  send(A, { t: 'heist-done', i: 0, fails: 1 }); await sleep(200);
  console.log('stage1:', last(A, 'heist-stage').k, 'alarm:', !!last(A, 'heist-alarm'));
  await sleep(8000); near(B, -515, -130); await sleep(60);
  send(B, { t: 'heist-done', i: 1, fails: 0 }); await sleep(200);
  console.log('stage2:', last(A, 'heist-stage').k, 'actor is B:', last(A, 'heist-stage').actor === B.id);
  await sleep(12000);
  send(B, { t: 'heist-done', i: 2, fails: 0 }); await sleep(200);
  console.log('stage3:', last(A, 'heist-stage').k);
  near(B, -200, 200); await sleep(60);   // далеко от цели
  await sleep(15000);
  send(B, { t: 'heist-done', i: 3, fails: 0 }); await sleep(300);
  const e = last(A, 'heist-end'), e2 = last(B, 'heist-end');
  console.log('end ok:', e && e.ok, 'A pay', e && e.pay, 'B pay', e2 && e2.pay, 'total', e && e.total);
  srv.kill(); process.exit(0);
})().catch(e => { console.error(e); srv.kill(); process.exit(1); });
