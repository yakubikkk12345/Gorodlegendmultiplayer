// Игровой тест в Chromium: node tools/play-test.js
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'] });
  const pg = await b.newPage({ viewport: { width: 1000, height: 600 } });
  const errs = []; pg.on('pageerror', e => errs.push('PAGEERR ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 3).join('\n')));
  await pg.route('**/telegram.org/**', r => r.abort());
  await pg.goto('file://' + process.cwd() + '/dist/index.html'); await pg.waitForTimeout(1500);
  await pg.click('[data-act="newgame"]'); await pg.waitForTimeout(300);
  await pg.evaluate(() => { const c = document.querySelector('#confirm button.primary, #confirm .btn.primary, #confirm [data-yes]'); c && c.click(); }); await pg.waitForTimeout(2500);
  const g = () => pg.evaluate(() => { const a = window.__game.v31(), b = window.__game.v25 ? window.__game.v25() : {}; return 1; });
  const T = fn => pg.evaluate(fn);
  console.log('mode:', await T(() => { const x = window.__game.v25(); return x.G.mode + ' hud:' + !document.getElementById('hud').classList.contains('hidden'); }));
  await pg.waitForTimeout(800);
  console.log('tutorial box:', await T(() => { const e = document.getElementById('tutBox'); return e.style.display + ' | ' + e.innerText.replace(/\n/g, ' / ').slice(0, 120); }));
  await pg.screenshot({ path: '/tmp/claude-0/s1.png' });
  // --- рыбалка ---
  const fish = await T(async () => {
    const x = window.__game.v25(), F = window.__fish, V = window.__v42, out = [];
    x.P.x = V.SW + 80; x.P.z = V.PZ; x.P.y = 0;
    await new Promise(r => setTimeout(r, 600));
    document.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyL' })); out.push('after cast: ' + F.F.st);
    F.F.t = 0; await new Promise(r => setTimeout(r, 300)); out.push('after wait: ' + F.F.st);
    return out.join(' | ');
  });
  console.log('fishing:', fish);
  // подсечка + мини-игра
  await pg.evaluate(() => document.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyL' })));
  await pg.waitForTimeout(200);
  let done = false;
  for (let i = 0; i < 600 && !done; i++) {
    const r = await pg.evaluate(() => { const o = document.getElementById('skOv'); if (!o || o.style.display === 'none') return 'off'; const z = o.querySelector('.zone'), n = o.querySelector('.ndl'); return parseFloat(n.style.left) + '|' + parseFloat(z.style.left) + '|' + parseFloat(z.style.width); });
    if (r === 'off') { if (i > 5) done = true; await pg.waitForTimeout(15); continue; }
    const [n, zl, zw] = r.split('|').map(Number);
    if (n >= zl + 1 && n <= zl + zw - 1) await pg.keyboard.press('Space');
    await pg.waitForTimeout(10);
  }
  console.log('fish result:', await T(() => JSON.stringify(window.__fish.FD().bag) + ' fishN=' + window.__game.v25().S.flags.fishN + ' st=' + window.__fish.F.st));
  await pg.screenshot({ path: '/tmp/claude-0/s2.png' });
  // --- дайвинг ---
  console.log('dive:', await T(async () => {
    const x = window.__game.v25(), D = window.__dive, V = window.__v42; const it = D.ITEMS.find(i => i.t === 'pearl');
    x.P.x = it.x; x.P.z = it.z + 4; x.P.y = 0; x.P.car = null;
    await new Promise(r => setTimeout(r, 1500));
    const st1 = x.P.swim; document.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyV' })); await new Promise(r => setTimeout(r, 800));
    const dv = x.P.dive; x.P.x = it.x; x.P.z = it.z; await new Promise(r => setTimeout(r, 800));
    return 'swim=' + st1 + ' dive=' + dv + ' found=' + D.DD().n + ' flag=' + x.S.flags.dvN + ' money=' + x.S.money;
  }));
  await pg.screenshot({ path: '/tmp/claude-0/s3.png' });
  // --- самолёт ---
  console.log('plane:', await T(async () => {
    const x = window.__game.v31(), y = window.__game.v25(); const sl = ms => new Promise(r => setTimeout(r, ms));
    y.S.money += 500000; x.buyCar('plane'); await sl(300);
    const no = [...document.querySelectorAll('#confirm button')].find(b => /Нет/.test(b.textContent)); no && no.click(); await sl(200);
    const own = !!y.S.cars.plane;
    y.P.x = 0; y.P.z = 0; y.P.swim = false; y.P.dive = false; y.P.y = 0;
    y.HOME_FN.hangar(); await sl(300); const c = y.getOwn(); x.seatPlayer(c);
    return 'own=' + own + ' car=' + (c && c.def.id) + ' alt=' + c.alt;
  }));
  await pg.keyboard.down('KeyW');
  for (let i = 0; i < 80; i++) { const v = await T(() => window.__game.v25().getOwn().vf); if (v > 27) break; await pg.waitForTimeout(500); }
  console.log('speed before rotate (m/s):', await T(() => window.__game.v25().getOwn().vf.toFixed(1)));
  await pg.keyboard.down('ShiftLeft'); await pg.waitForTimeout(6000); await pg.keyboard.up('ShiftLeft');
  console.log('after liftoff:', await T(() => { const c = window.__game.v25().getOwn(); return 'alt=' + c.alt.toFixed(1) + ' vf=' + Math.round(c.vf * 3.6) + 'kmh z=' + c.z.toFixed(0) + ' flag=' + window.__game.v25().S.flags.planeFly + ' hud=' + document.getElementById('planeHud').innerText.replace(/\n/g, ' '); }));
  await pg.screenshot({ path: '/tmp/claude-0/s4.png' });
  await pg.keyboard.up('KeyW');
  console.log(errs.length ? errs.join('\n') : 'NO ERRORS');
  await b.close();
})();
