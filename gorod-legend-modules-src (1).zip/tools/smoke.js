// Дымовой тест: node tools/smoke.js [seconds]  — грузит dist/index.html в Chromium, ловит ошибки JS
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const pg = await b.newPage({ viewport: { width: 1000, height: 600 } });
  const errs = [];
  pg.on('pageerror', e => errs.push('PAGEERR ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 4).join('\n')));
  pg.on('console', m => { if (m.type() === 'error' && !/telegram|ERR_|Failed to load resource/.test(m.text())) errs.push('CONSOLE ' + m.text()); });
  await pg.route('**/telegram.org/**', r => r.abort());
  await pg.goto('file://' + process.cwd() + '/dist/index.html');
  await pg.waitForTimeout(+process.argv[2] * 1000 || 3000);
  console.log(await pg.evaluate(() => document.title + ' | menu:' + !!document.getElementById('menu')));
  await pg.screenshot({ path: process.env.SHOT || '/tmp/claude-0/shot.png' });
  console.log(errs.length ? errs.join('\n') : 'NO ERRORS');
  await b.close();
})();
