// ---------- v44: КООПЕРАТИВНЫЕ ОГРАБЛЕНИЯ (комната до 4 игроков, этапы и роли проверяет сервер) ----------
// Цели совпадают с магазинами клиента: координаты = центр блока (HALF=640, PITCH=80), метка смещена на -12 по Z.
const HX_BC = i => -640 + (i + 0.5) * 80;
const HEIST_T = {
  jewel: { name: 'Ювелирный «Бриллиант»', ico: '💎', b: [1, 6], min: 2, time: 360, pay: [24000, 34000], need: 'Ювелирный: взлом сигнализации → охрана → витрины → уход',
    st: [{ k: 'hack', ch: 2, ms: 9000 }, { k: 'guards', n: 4, ms: 8000 }, { k: 'vault', ch: 3, ms: 12000 }, { k: 'escape', ms: 15000 }] },
  bank: { name: 'Банк «Столичный»', ico: '🏦', b: [7, 5], min: 2, time: 540, pay: [80000, 110000], need: 'Банк: взлом → охрана → бурение → подкрепление → уход',
    st: [{ k: 'hack', ch: 3, ms: 12000 }, { k: 'guards', n: 6, ms: 12000 }, { k: 'vault', ch: 4, ms: 18000 }, { k: 'guards', n: 7, ms: 12000 }, { k: 'escape', ms: 20000 }] },
  vault: { name: 'Хранилище «Народный»', ico: '💰', b: [12, 12], min: 3, time: 720, pay: [190000, 260000], need: 'Хранилище: минимум 3 игрока. Три волны охраны, сейф с 5 замками',
    st: [{ k: 'hack', ch: 4, ms: 14000 }, { k: 'guards', n: 7, ms: 14000 }, { k: 'vault', ch: 5, ms: 22000 }, { k: 'guards', n: 9, ms: 14000 }, { k: 'vault', ch: 4, ms: 18000 }, { k: 'escape', ms: 25000 }] }
};
const HX_ROLE = { hack: 'Хакер', guards: 'Стрелок', vault: 'Взломщик', escape: 'Водитель' };
const hxPos = h => ({ x: HX_BC(h.T.b[0]), z: HX_BC(h.T.b[1]) - 12 });
function hxTeam(room, h) { return h.ids.filter(id => room.players.has(id)); }
function hxActor(room, h, k) {      // кто выполняет этап: хакер/взломщик — по ролям, стрелки и побег — любой из команды
  const team = hxTeam(room, h); if (!team.length) return 0;
  const ri = { hack: 0, vault: 1 }[k]; return ri === undefined ? 0 : team[ri % team.length];
}
function hxLobby(room) {
  const h = room.heist; if (!h) return;
  bcast(room, { t: 'heist-lobby', kind: h.kind, host: h.host, min: h.T.min, players: h.ids.map(id => ({ id, name: nm(room, id) })) });
}
function hxStage(room) {
  const h = room.heist; if (!h) return; const s = h.T.st[h.i];
  h.stAt = Date.now();
  bcast(room, { t: 'heist-stage', i: h.i, of: h.T.st.length, k: s.k, ch: s.ch || 0, n: s.n || 0, actor: hxActor(room, h, s.k), aname: nm(room, hxActor(room, h, s.k)), role: HX_ROLE[s.k], left: Math.max(0, h.endAt - Date.now()) });
}
function hxStart(room) {
  const h = room.heist; if (!h || h.state !== 'lobby') return;
  const team = hxTeam(room, h);
  if (team.length < h.T.min) return bcast(room, { t: 'warn', msg: 'Для «' + h.T.name + '» нужно минимум ' + h.T.min + ' игрока' });
  clearTimers(h); h.state = 'run'; h.i = 0; h.fails = 0; h.alarm = 0; h.down = new Set(); h.startAt = Date.now(); h.endAt = h.startAt + h.T.time * 1000;
  bcast(room, { t: 'heist-go', kind: h.kind, name: h.T.name, ico: h.T.ico, x: hxPos(h).x, z: hxPos(h).z, total: h.T.st.length, time: h.T.time * 1000, players: team.map(id => ({ id, name: nm(room, id) })) });
  hxStage(room);
  h.timers.push(setTimeout(() => hxEnd(room, false, 'Время вышло — группа не успела уйти'), h.T.time * 1000));
  const tick = () => {      // тревога растёт: каждые 40 с +1 звезда розыска у всей команды
    if (!room.heist || room.heist !== h || h.state !== 'run') return;
    if (h.alarm < 4) { h.alarm++; bcast(room, { t: 'heist-alarm', stars: Math.min(5, h.alarm + 1) }); }
    h.timers.push(setTimeout(tick, 40000));
  };
  h.timers.push(setTimeout(tick, 25000));
}
function hxEnd(room, ok, why) {
  const h = room.heist; if (!h) return; clearTimers(h); room.heist = null;
  const alive = hxTeam(room, h).filter(id => !h.down || !h.down.has(id));
  let total = 0, share = 0;
  if (ok && alive.length) {
    const base = h.T.pay[0] + crypto.randomInt(h.T.pay[1] - h.T.pay[0] + 1);
    const fast = (Date.now() - h.startAt) < h.T.time * 1000 * 0.6 ? 1.15 : 1;
    const cr = 1 + 0.1 * (hxTeam(room, h).length - h.T.min);      // больше людей в деле — выше добыча
    total = Math.round(base * Math.max(0.5, 1 - 0.07 * h.fails) * fast * cr / 100) * 100;
    share = Math.floor(total / alive.length / 100) * 100;
  }
  for (const id of hxTeam(room, h)) { const p = room.players.get(id); if (p) send(p, { t: 'heist-end', ok: !!ok, why: why || '', total, pay: ok && alive.includes(id) ? share : 0, fails: h.fails, secs: Math.round((Date.now() - h.startAt) / 1000) }); }
}
function hxLeave(room, c) {
  const h = room.heist; if (!h || !h.ids.includes(c.id)) return;
  if (h.state === 'lobby') {
    h.ids = h.ids.filter(i => i !== c.id);
    if (c.id === h.host || !h.ids.length) { clearTimers(h); room.heist = null; bcast(room, { t: 'heist-cancel' }); } else hxLobby(room);
    return;
  }
  const team = hxTeam(room, h).filter(i => i !== c.id);
  if (team.length < 1 || team.every(i => h.down.has(i))) return hxEnd(room, false, 'Команда распалась');
  hxStage(room);
}
function heistHandle(c, m, now) {
  const room = c.room, h = room.heist;
  if (now - (c.hxW || 0) > 1000) { c.hxW = now; c.hxN = 0; }
  if (++c.hxN > 12) return;
  if (m.t === 'heist-open') {
    if (room.race || room.arena || h) return send(c, { t: 'warn', msg: 'В комнате уже идёт событие' });
    const kind = HEIST_T[m.kind] ? m.kind : 'jewel';
    const nh = room.heist = { kind, T: HEIST_T[kind], state: 'lobby', host: c.id, ids: [c.id], timers: [] };
    bcast(room, { t: 'heist-open', kind, host: c.id, hname: c.name, name: nh.T.name, ico: nh.T.ico, min: nh.T.min });
    hxLobby(room);
    nh.timers.push(setTimeout(() => { if (room.heist === nh && nh.state === 'lobby') { room.heist = null; bcast(room, { t: 'heist-cancel' }); } }, 180000));
    return;
  }
  if (!h) return;
  if (m.t === 'heist-join') { if (h.state !== 'lobby' || h.ids.includes(c.id) || h.ids.length >= 4) return; h.ids.push(c.id); return hxLobby(room); }
  if (m.t === 'heist-leave') { if (h.ids.includes(c.id)) hxLeave(room, c); return; }
  if (m.t === 'heist-start') { if (h.host === c.id) hxStart(room); return; }
  if (m.t === 'heist-cancel') { if (h.host === c.id && h.state === 'lobby') { clearTimers(h); room.heist = null; bcast(room, { t: 'heist-cancel' }); } return; }
  if (h.state !== 'run' || !h.ids.includes(c.id)) return;
  if (m.t === 'heist-down') {
    if (h.down.has(c.id)) return; h.down.add(c.id); bcast(room, { t: 'heist-note', msg: '🚑 ' + c.name + ' ранен и выбывает из дела' });
    if (hxTeam(room, h).every(i => h.down.has(i))) hxEnd(room, false, 'Вся команда выведена из строя');
    return;
  }
  if (m.t === 'heist-done') {
    const s = h.T.st[h.i]; if ((m.i | 0) !== h.i || !s || h.down.has(c.id)) return;
    if (now - h.stAt < s.ms) return send(c, { t: 'warn', msg: 'Слишком быстро — действие не засчитано' });
    const st = c.state, P = hxPos(h); if (!st) return;
    const d = Math.hypot(st.x - P.x, st.z - P.z);
    if (s.k === 'escape') { if (d < 110) return send(c, { t: 'warn', msg: 'Отъедьте дальше от места ограбления' }); }
    else if (d > 60) return send(c, { t: 'warn', msg: 'Вы слишком далеко от цели' });
    if ((s.k === 'hack' || s.k === 'vault') && hxActor(room, h, s.k) !== c.id) return;
    const fl = Math.max(0, Math.min(s.ch || 0, m.fails | 0)); h.fails += fl; h.alarm = Math.min(4, h.alarm + (fl ? 1 : 0));
    if (fl) bcast(room, { t: 'heist-alarm', stars: Math.min(5, h.alarm + 1) });
    bcast(room, { t: 'heist-note', msg: '✔ ' + c.name + ': этап «' + HX_ROLE[s.k] + '» выполнен' + (fl ? ' (ошибок: ' + fl + ')' : '') });
    h.i++;
    if (h.i >= h.T.st.length) return hxEnd(room, true, '');
    return hxStage(room);
  }
}
