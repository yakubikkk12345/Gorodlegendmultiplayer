const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=swiftshader'] }); const pg = await b.newPage();
  await pg.route('**/telegram.org/**', r => r.abort());
  await pg.goto('file://' + process.cwd() + '/dist/index.html'); await pg.waitForTimeout(1500);
  console.log(await pg.evaluate(() => {
    const v = window.__game.v31(), y = window.__game.v25(), A = v.blkAudit(), GRID = y.GRID, used = new Set(Object.keys(A.seen));
    ['1,3', '14,4', '1,11'].forEach(k => used.add(k));
    for (const k of v.PARKS) used.add(k);
    const marks = y.WORLD_MARKS.filter(m => !m.int);
    const blkOf = m => Math.floor((m.x + GRID * 40) / 80) + ',' + Math.floor((m.z + 12 + GRID * 40) / 80);
    const mk = new Set(marks.map(blkOf));
    const free = []; for (let i = 0; i < GRID; i++) for (let j = 0; j < GRID; j++) { const k = i + ',' + j; if (!used.has(k) && !mk.has(k)) free.push(k); }
    return 'GRID=' + GRID + ' used=' + used.size + ' free(' + free.length + '): ' + free.join(' ') + ' dup=' + JSON.stringify(A.dup);
  }));
  await b.close();
})();
