const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=swiftshader', '--ignore-gpu-blocklist'] });
  const pg = await b.newPage({ viewport: { width: 1000, height: 600 } });
  const errs = []; pg.on('pageerror', e => errs.push(e.message + '\n' + (e.stack || '').split('\n').slice(0, 3).join('\n')));
  await pg.route('**/telegram.org/**', r => r.abort());
  await pg.goto('file://' + process.cwd() + '/dist/index.html'); await pg.waitForTimeout(1500);
  await pg.click('[data-act="newgame"]'); await pg.waitForTimeout(2500);
  console.log(await pg.evaluate(async () => {
    const y = window.__game.v25(), v = window.__game.v31(), sl = ms => new Promise(r => setTimeout(r, ms));
    for (const id of ['flat', 'house', 'villa', 'tower', 'park1', 'park2', 'park3', 'park4', 'park5']) y.S.props[id] = { own: true, acc: 0 };
    let n = 0; for (const k in v.CAR_BY_ID) { const d = v.CAR_BY_ID[k]; y.S.cars[k] = { u: { eng: 0, acc: 0, tir: 0, nit: 0 }, color: d.color }; n++; }
    const m = y.WORLD_MARKS.find(m => m.id === 'homegar'); y.HOME_FN.enterGarage(m); await sl(2500);
    const o = y.INT.garage; y.P.z = o.z + 18.5; y.P.x = o.x; await sl(800);
    return 'cars=' + n + ' inHome=' + y.G.inHome + ' cap marks=' + y.WORLD_MARKS.filter(m => /^gbay_/.test(m.id)).length + ' props=' + Object.keys(y.S.props).length;
  }));
  await pg.screenshot({ path: '/tmp/claude-0/g1.png' });
  await pg.evaluate(() => { const y = window.__game.v25(); y.P.z = y.INT.garage.z + 4; });
  await pg.waitForTimeout(800); await pg.screenshot({ path: '/tmp/claude-0/g2.png' });
  console.log(errs.length ? errs.join('\n') : 'NO ERRORS'); await b.close();
})();
