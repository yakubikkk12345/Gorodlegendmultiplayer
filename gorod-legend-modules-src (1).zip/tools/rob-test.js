const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=swiftshader', '--ignore-gpu-blocklist'] });
  const pg = await b.newPage({ viewport: { width: 1000, height: 600 } });
  const errs = []; pg.on('pageerror', e => errs.push(e.message + '\n' + (e.stack || '').split('\n').slice(0, 3).join('\n')));
  await pg.route('**/telegram.org/**', r => r.abort());
  await pg.goto('file://' + process.cwd() + '/dist/index.html'); await pg.waitForTimeout(1500);
  await pg.click('[data-act="newgame"]'); await pg.waitForTimeout(2500);
  console.log(await pg.evaluate(async () => {
    const y = window.__game.v25(), sl = ms => new Promise(r => setTimeout(r, ms));
    const m = y.WORLD_MARKS.find(m => /^rob_/.test(m.id)); y.P.x = m.x; y.P.z = m.z; y.P.car = null; await sl(500);
    const st = Object.keys(y.HOME_FN).filter(k => /rob/i.test(k));
    y.S.guns.own.pistol = 1; y.S.guns.cur = 'pistol';
    y.HOME_FN[m.fn](m); await sl(1500);
    const o = document.getElementById('skOv');
    return 'mark=' + m.id + ' fn=' + m.fn + ' fns=' + st + ' guards=' + window.__hx.HXS.guards.length + ' chkN=' + window.__hx.HXS.chkN + ' sk=' + (o && o.style.display);
  }));
  for (let i = 0; i < 12; i++) { await pg.waitForTimeout(2000); console.log(await pg.evaluate(() => { const y = window.__game.v25(), o = document.getElementById('skOv'); return 'sk=' + o.style.display + ' chk=' + window.__hx.HXS.chk + ' guards=' + window.__hx.HXS.guards.length + ' hp=' + Math.round(y.P.hp) + ' robs=' + (y.S.stats.robs || 0) + ' money=' + y.S.money + ' bar=' + (document.querySelector('#robBar') ? document.querySelector('#robBar').style.display : '?'); })); }
  await pg.screenshot({ path: '/tmp/claude-0/s5.png' });
  console.log(errs.length ? errs.join('\n') : 'NO ERRORS'); await b.close();
})();
