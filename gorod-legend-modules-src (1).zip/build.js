// Сборка: node build.js  ->  dist/index.html (один файл, как раньше) + dist/game.js, dist/game.css
// Модули src/js/NN-*.js склеиваются в ОДНУ область видимости (IIFE) в порядке modules.json:
// слои v32+ перепривязывают функции (monkey-patch), поэтому порядок важен.
const fs=require('fs'),path=require('path');
const R=p=>fs.readFileSync(path.join(__dirname,p),'utf8');
const mods=JSON.parse(R('src/modules.json'));
const banner=R('src/js/_banner.txt');
const body=mods.map(f=>R('src/js/'+f)).join('');
const js=banner+'(function () {\n'+body+'})();\n';
const css=R('src/css/main.css');
const tpl=R('src/template.html');
fs.mkdirSync(path.join(__dirname,'dist'),{recursive:true});
const w=(n,s)=>fs.writeFileSync(path.join(__dirname,'dist',n),s);
w('game.js',js);w('game.css',css);
// единый файл (по умолчанию — совместим с server.js и PWA)
w('index.html',tpl.replace('/*@CSS*/',()=>css).replace('/*@JS*/',()=>js));
console.log('built', mods.length, 'modules,', js.length, 'bytes js');
