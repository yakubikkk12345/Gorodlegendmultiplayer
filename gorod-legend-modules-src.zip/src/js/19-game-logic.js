/* ===================== 15. ИГРОВАЯ ЛОГИКА ===================== */
const DR = { cur: 0, mult: 1, idle: 0, active: false, total: 0 };
let M = null, lastMissionId = null;

function addMoney(n) { S.money += n; refreshMoney(true); if (n > 0) floatMoney('+' + fmtMoney(n)); }

function enterCar(c) {
  if (!c || P.car) return;
  P.car = c; c.driver = 'player'; P.vis = false; SFX.door();
  if (c.def.heli) toast('🚁 Shift — вверх, Пробел — вниз, W/S — вперёд/назад. Выше 100 м — над всеми зданиями.');
  else if (c.kind === 'parked') toast('Вы сели в чужую машину. Ваша — в гараже (клавиша C: вызвать).');
}
function exitCar(force) {
  const c = P.car; if (!c) return;
  const rf = c.def.heli ? roofInfo(c.x, c.z, 0.6) : null, fl = rf ? rf.y : 0;
  if (!force && (c.alt || 0) - fl > 1.5) { toast('Сначала приземлитесь (Пробел — вниз)'); SFX.err(); return; }
  if (!force && Math.abs(c.vf) > 7) { toast('Остановитесь, чтобы выйти'); SFX.err(); return; }
  const onRoof = !!rf && (c.alt || 0) - fl <= 1.5;
  if (!onRoof) c.alt = 0;
  const f = [Math.sin(c.h), Math.cos(c.h)], l = [f[1], -f[0]];
  const p = { x: c.x + l[0] * 2.4, z: c.z + l[1] * 2.4 };
  if (onRoof) { const b = rf.rect; p.x = clamp(p.x, b.x0 + 0.9, b.x1 - 0.9); p.z = clamp(p.z, b.z0 + 0.9, b.z1 - 0.9); P.roof = rf; P.x = p.x; P.z = p.z; roofWalk(); P.y = rf.base; }
  else { pushCircle(p, 0.5); P.x = p.x; P.z = p.z; P.y = terrainY(P.x, P.z); }
  P.h = c.h;
  c.driver = null; P.car = null; P.vis = true; SFX.door();
}
function nearbyCar() {
  if (P.car) return null;
  let best = null, bd = 4.2;
  for (const c of cars) {
    if (c.kind !== 'own' && c.kind !== 'parked' && !(c.kind === 'traffic' && Math.hypot(c.vx, c.vz) < 9)) continue;
    const d = Math.hypot(c.x - P.x, c.z - P.z);
    if (d < bd) { bd = d; best = c; }
  }
  return best;
}
function nearbyMark() {
  const x = P.car ? P.car.x : P.x, z = P.car ? P.car.z : P.z;
  for (const m of WORLD_MARKS) {
    if (m.roofY !== undefined && !(P.roof && !P.car && Math.abs(P.roof.base - m.roofY) < 0.5)) continue;
    if (Math.hypot(m.x - x, m.z - z) < (m.r || 7)) return m;
  }
  if (!P.car && !G.inHome && G.mode === 'play') {
    let best = null, bd = 2.6;
    for (const p of peds) { if (p.dead || p.fixed || p.thief) continue; const d = Math.hypot(p.x - P.x, p.z - P.z); if (d < bd) { bd = d; best = p; } }
    if (best) return best._mk || (best._mk = { id: 'ped', label: '💬 ПОГОВОРИТЬ С ПРОХОЖИМ', fn: 'talkPed', ped: best });
  }
  return null;
}
function interactCar() {
  if (G.mode !== 'play' || G.paused) return;
  if (M && M.state === 'countdown') return;
  if (P.car) exitCar(false); else { const c = nearbyCar(); if (c) { if (c.kind === 'traffic') carjack(c); else enterCar(c); } else if (P.roof) roofDown(); }
}
const OUTFITS = [
  { n: 'Красная куртка', shirt: '#c0392b', pants: '#23262e' }, { n: 'Синяя футболка', shirt: '#2c7be5', pants: '#1c1f2a' },
  { n: 'Зелёная толстовка', shirt: '#2ecc71', pants: '#3a3a3a' }, { n: 'Жёлтая худи', shirt: '#f1c40f', pants: '#2b2d42' },
  { n: 'Фиолетовая рубашка', shirt: '#8e44ad', pants: '#222222' }, { n: 'Белая рубашка', shirt: '#ecf0f1', pants: '#1b263b' },
  { n: 'Оранжевая куртка', shirt: '#e67e22', pants: '#3d2b1f' }, { n: 'Чёрный костюм', shirt: '#161616', pants: '#555555' }
];
const TV_NEWS = ['Новости: в городе открыли ещё одну гоночную трассу!', 'Новости: водитель красного хэтчбека снова ушёл от патруля.', 'Прогноз: ночью ясно, на дорогах скользко от дрифта.',
  'Спорт: чемпионат улиц, главный приз — титул короля города.', 'Реклама: покупайте Суперкар Феникс — скорость мечты!', 'Новости: в магазине машин появились новые модели.'];
function applyLook() { fillLook(PLAYER_LOOK, chState()); }
function homeDoorPos() { return { x: 40, z: 16.5 }; }
function setHomeState(on, kind, ret) {
  G.inHome = on; G.int = on ? Object.assign({}, INT[kind || 'home'], { ret: ret || null }) : null; document.body.classList.toggle('home', on);
}
const HOME_FN = {
  healHere() {
    if (P.hp >= 99) { toast('🏥 Вы здоровы'); return; }
    if (S.money < 50) { SFX.err(); toast('Нужно $50'); return; }
    S.money -= 50; P.hp = 100; HITFX.flash = 0; SFX.buy(); refreshMoney(true); toast('🏥 Вас вылечили');
  },
  payFine() {
    if (WANT.stars <= 0) { toast('🚓 За вами ничего нет'); return; }
    const f = 400 * WANT.stars;
    if (S.money < f) { SFX.err(); toast('Штраф ' + fmtMoney(f) + ' — не хватает денег'); return; }
    S.money -= f; clearWanted(true); SFX.cash(); refreshMoney(true); toast('🚓 Штраф ' + fmtMoney(f) + ' оплачен');
  },
  enterHome() {
    if (G.inHome) return;
    fadeThen(() => {
      if (P.car) exitCar(true);
      setHomeState(true);
      P.x = INX; P.z = INZ - 4.6; P.y = 0; P.h = 0; P.speed = 0; P.vis = true;
      CAM.yaw = 0; CAM.pitch = 0.82; CAM.off = 0;
      toast('🏠 Добро пожаловать домой!');
    });
  },
  leaveHome() {
    if (!G.inHome) return;
    fadeThen(() => {
      const d = homeDoorPos();
      setHomeState(false);
      P.x = d.x; P.z = d.z; P.y = terrainY(P.x, P.z); P.h = Math.PI; P.speed = 0;
      CAM.yaw = Math.PI; CAM.pitch = 0.3; CAM.off = 0;
    });
  },
  sleep() {
    fadeThen(() => {
      dayT = DAY_LEN * 0.05;
      S.pos = homeDoorPos(); persist();
      toast('😴 Вы выспались. Наступило утро. Игра сохранена.');
    });
  },
  wardrobe() { openStyle('wd'); },
  watchTV() { SFX.click(); toast('📺 ' + pick(TV_NEWS)); },
  enterShop(m) {
    if (G.inHome) return;
    fadeThen(() => {
      if (P.car) exitCar(true);
      const o = INT[m.kind];
      setHomeState(true, m.kind, { x: m.x, z: m.z - 2, h: Math.PI });
      P.x = o.x; P.z = o.z - 4.6; P.y = 0; P.h = 0; P.speed = 0; P.vis = true;
      CAM.yaw = 0; CAM.pitch = 0.82; CAM.off = 0;
      toast(NPC[m.kind].ico + ' ' + NPC[m.kind].name + ': подойдите к прилавку и нажмите E');
    });
  },
  leaveShop() {
    if (!G.inHome || !G.int || !G.int.ret) return;
    fadeThen(() => {
      if (!G.int || !G.int.ret) return;
      const r = G.int.ret, wasGar = G.int.kind === 'garage' || !!G.int.callCar;
      setHomeState(false);
      P.x = r.x; P.z = r.z; P.y = terrainY(P.x, P.z); P.h = r.h; P.speed = 0;
      CAM.yaw = Math.PI; CAM.pitch = 0.3; CAM.off = 0;
      if (wasGar) callCar();
    });
  },
  talk(m) { openTalk(m.kind); },
  bizTalk(m) { openTalk(m.kind === 'boss' || m.kind === 'taxi' || m.kind === 'food' ? m.kind : 'b_' + m.kind); },
  talkPed(m) { talkPed(m.ped); }
};
function interactMark() {
  if (G.mode !== 'play' || G.paused) return;
  const m = nearbyMark(); if (m) { SFX.click(); if (m.fn) HOME_FN[m.fn](m); else openScreen(m.act); }
}
function callCar() {
  if (G.mode !== 'play' || G.paused || P.car) return;
  if (G.inHome) { toast('Сначала выйдите из дома'); return; }
  const r = nearestRoad(P.x + Math.sin(P.h) * 9, P.z + Math.cos(P.h) * 9, Math.sin(P.h), Math.cos(P.h));
  const c = OWN || spawnOwn(r.x, r.z, r.h);
  c.x = r.x; c.z = r.z; c.h = r.h; c.vx = c.vz = c.vf = c.vl = 0;
  toast('🚗 Ваша машина подана'); SFX.click();
}
function resetCar() {
  const c = P.car; if (!c || G.paused) return;
  const r = nearestRoad(c.x, c.z, Math.sin(c.h), Math.cos(c.h));
  c.x = r.x; c.z = r.z; c.h = r.h; c.vx = c.vz = c.vf = c.vl = 0; c.alt = 0; toast('Машина поставлена на дорогу');
}
function horn() { if (P.car) SFX.horn(); }

function crashFx(c, imp) {
  if (c.bumpT > 0) return;
  c.bumpT = 0.3;
  if (c === P.car) {
    SFX.crash(imp); CAM.shake = Math.max(CAM.shake, clamp(imp * 0.04, 0.1, 0.9));
    for (let i = 0; i < 8; i++) emit(c.x + Math.sin(c.h) * 2, c.y + 0.6, c.z + Math.cos(c.h) * 2, rand(-5, 5), rand(1, 5), rand(-5, 5), 0.5, 0.18, 0.05, 1, 0.8, 0.3, 1, true);
    DR.cur = 0; DR.mult = 1;
    carHurt(c, imp);
  } else if (Math.hypot(c.x - CAM.x, c.z - CAM.z) < 60) SFX.crash(imp * 0.5);
}

function updateCars(dt, inp) {
  for (const c of cars) {
    if (c.bumpT > 0) c.bumpT -= dt;
    if (c.ai) stepAI(c, dt);
    else if (c.driver === 'player') stepPhys(c, inp, dt);
    else if (Math.abs(c.vx) + Math.abs(c.vz) > 0.05) stepPhys(c, null, dt);
  }
  for (const c of cars) {
    if (c.ai) continue;
    if (c.driver || Math.abs(c.vx) + Math.abs(c.vz) > 0.2) { const imp = carWalls(c); if (imp > 3) crashFx(c, imp); }
  }
  const pc = P.car;
  if (pc) for (const o of cars) { if (o === pc) continue; if (Math.abs((pc.alt || 0) - (o.alt || 0)) > 3) continue; const imp = carPair(pc, o); if (imp > 2.5) crashFx(pc, imp); }
  for (const c of cars) {
    const ty = (c.def.heli && c.fl > 0 ? 0 : terrainY(c.x, c.z)) + (c.alt || 0);
    c.y += (ty - c.y) * Math.min(1, dt * 14);
    c.roll += c.vf * dt / c.def.shape.wr;
    if (c === pc || !c.ai) {
      const acc = (c.vf - (c.lastVf || 0)) / Math.max(dt, 0.001); c.lastVf = c.vf;
      c.pitch += ((c.def.heli ? ((c.alt - (c.fl || 0)) > 0.6 ? clamp(c.vf * 0.006, -0.05, 0.25) : 0) : clamp(-acc * 0.0035, -0.05, 0.05)) - c.pitch) * Math.min(1, dt * 6);
      c.lean += ((c.def.bike ? clamp(c.steer * c.vf * 0.011, -0.5, 0.5) : c.def.heli ? clamp(-c.steer * c.vf * 0.01, -0.3, 0.3) : clamp(-c.vl * 0.012 - c.steer * c.vf * 0.0007, -0.07, 0.07)) - c.lean) * Math.min(1, dt * 6);
    } else { c.pitch = 0; c.lean = 0; c.steer += ((c.ai.steerV || 0) - c.steer) * 0.1; }
  }
}

function updateWalk(dt, inp) {
  const sp = (inp.run ? 8.5 : 4.4) * cbSpeedMul();
  CB.inp = inp;
  let mx = CB.roll > 0 ? 0 : inp.x, my = CB.roll > 0 ? 0 : inp.y; const len = Math.hypot(mx, my); if (len > 1) { mx /= len; my /= len; }
  const fx = Math.sin(CAM.yaw), fz = Math.cos(CAM.yaw), rx = -fz, rz = fx;
  const wx = fx * my + rx * mx, wz = fz * my + rz * mx, mag = Math.hypot(wx, wz);
  P.speed += (mag * sp - P.speed) * Math.min(1, dt * 10);
  if (mag > 0.05 && !(P.aimT > 0 && aimManual())) P.h += wrapA(Math.atan2(wx, wz) - P.h) * Math.min(1, dt * 12);
  P.x += wx * sp * dt; P.z += wz * sp * dt;
  if (CB.roll > 0) { P.x += Math.sin(CB.rh) * 10 * dt; P.z += Math.cos(CB.rh) * 10 * dt; }
  if (!P.roof) pushCircle(P, 0.45, P.jh > 0.1 ? P.y : 0);
  for (const c of cars) {
    const dx0 = c.x - P.x, dz0 = c.z - P.z; if (dx0 * dx0 + dz0 * dz0 > 36 || P.jh > 0.55) continue;
    for (let j = -1; j <= 1; j++) {
      const cx = c.x + Math.sin(c.h) * j * c.L * 0.3, cz = c.z + Math.cos(c.h) * j * c.L * 0.3;
      const dx = P.x - cx, dz = P.z - cz, d = Math.hypot(dx, dz), rr = 1.35;
      if (d < rr && d > 0.001) { P.x += dx / d * (rr - d); P.z += dz / d * (rr - d); }
    }
  }
  if (G.inHome) { const ix = G.int ? G.int.x : INX, iz = G.int ? G.int.z : INZ; const hw = G.int && G.int.kind === 'garage' ? 27.3 : (G.int && G.int.kind === 'casino' ? 19.3 : 9.5); P.x = clamp(P.x, ix - hw, ix + hw); P.z = clamp(P.z, iz - 7.5, iz + 7.5); }
  else { const L = WLIM(); P.x = clamp(P.x, -L, L); P.z = clamp(P.z, -L, L); }
  if (P.roof) roofWalk();
  walkJump(dt, inp, P.roof ? P.roof.base : terrainY(P.x, P.z));
  P.phase += P.speed * dt * 1.6; P.amp = clamp(P.speed / 5, 0, 1);
  S.stats.dist += P.speed * dt;
}

function updateDrift(dt) {
  const c = P.car;
  if (!c) { DR.active = false; return; }
  const drifting = c.vf > 8 && Math.abs(c.vl) > 3.2;
  if (drifting) {
    DR.active = true; DR.idle = 0; DR.mult = Math.min(5, DR.mult + dt * 0.35);
    DR.cur += dt * Math.abs(c.vl) * c.vf * 0.3 * DR.mult;
    if (Math.random() < dt * 40) {
      const f = [Math.sin(c.h), Math.cos(c.h)], r = [-f[1], f[0]], sx = Math.random() < 0.5 ? -1 : 1;
      emit(c.x - f[0] * c.L * 0.32 + r[0] * sx * c.W * 0.4, 0.3, c.z - f[1] * c.L * 0.32 + r[1] * sx * c.W * 0.4, rand(-1, 1), rand(0.4, 1.2), rand(-1, 1), 0.9, 0.5, 2.3, 0.82, 0.82, 0.85, 0.55, false);
    }
    if (Math.random() < dt * 4) SFX.skid();
  } else if (DR.cur > 0) {
    DR.active = false; DR.idle += dt;
    if (DR.idle > 0.9) {
      const pts = Math.round(DR.cur); DR.total += pts; S.stats.drift += pts;
      if (pts > 150) toast('🌀 Дрифт: +' + pts + ' очков');
      DR.cur = 0; DR.mult = 1;
    }
  } else { DR.active = false; DR.mult = 1; }
}

function updatePickups(dt) {
  const x = P.car ? P.car.x : P.x, z = P.car ? P.car.z : P.z;
  for (const c of cash) {
    if (c.t > 0) { c.t -= dt; continue; }
    if (Math.abs(c.x - x) < 3.6 && Math.abs(c.z - z) < 3.6) { c.t = 240; SFX.cash(); addMoney(c.v); }
  }
}

