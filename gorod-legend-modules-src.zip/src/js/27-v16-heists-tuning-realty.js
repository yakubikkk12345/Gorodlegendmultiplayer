/* ===================== v16: ОГРАБЛЕНИЯ, ТЮНИНГ, НЕДВИЖИМОСТЬ, ГАРАЖ ===================== */
const STORE_BY = {}; STORES.forEach(s => STORE_BY[s.id] = s);
const PROP_BY = {}; PROPS.forEach(p => PROP_BY[p.id] = p);
const markOf = id => WORLD_MARKS.find(m => m.id === id);

/* --- метки в мире и в интерьерах --- */
for (const s of STORES) {
  const T = STORE_TYPES[s.t];
  WORLD_MARKS.push({ id: 'rob_' + s.id, x: bc(s.b[0]), z: bc(s.b[1]) - 12, c: [1, 0.35, 0.15], label: T.ico + ' ОГРАБИТЬ: ' + s.nm, short: T.ico + ' ' + T.name, dot: T.dot, fn: 'robStore', kind: s.id, r: 6, br: 3 });
}
WORLD_MARKS.push({ id: 'club', x: bc(CLUB_BLK[0]), z: bc(CLUB_BLK[1]) - 12, c: [1, 0.55, 0.1], label: '🏁 ВОЙТИ В ГАРАЖ-КЛУБ', short: '🏁 ГАРАЖ-КЛУБ', dot: '#ff8c1a', fn: 'enterShop', kind: 'club', r: 6, br: 3 });
WORLD_MARKS.push({ id: 'tune', x: bc(TUNE_BLK[0]), z: bc(TUNE_BLK[1]) - 12, c: [1, 0.5, 0.15], label: '🛠 ВОЙТИ В ТЮНИНГ-ЦЕНТР', short: '🛠 ТЮНИНГ', dot: '#ff9f1c', fn: 'enterShop', kind: 'tune', r: 6, br: 3 });
WORLD_MARKS.push({ id: 'estate', x: bc(ESTATE_BLK[0]), z: bc(ESTATE_BLK[1]) - 12, c: [0.4, 0.8, 1], label: '🏠 ПОГОВОРИТЬ С РИЕЛТОРОМ', short: '🏠 НЕДВИЖИМОСТЬ', dot: '#8ecae6', fn: 'talkEstate', kind: 'estate', r: 6, br: 3 });
for (const p of PROPS) {
  WORLD_MARKS.push({ id: 'prop_' + p.id, x: bc(p.b[0]), z: bc(p.b[1]) - 12, c: [0.4, 0.8, 1], label: p.ico + ' ' + p.nm.toUpperCase() + ': ПОДОЙТИ', short: p.ico + ' ' + p.nm, dot: '#8ecae6', fn: 'propTalk', kind: p.id, r: 6, br: 3 });
}
WORLD_MARKS.push({ id: 'homegar', x: bc(HOME_B) + 14, z: bc(HOME_B) - 14, c: [1, 0.8, 0.2], label: '🚗 ГАРАЖ ДОМА', short: '🚗 ГАРАЖ', dot: '#ffd23f', fn: 'enterGarage', kind: 'home', r: 5, br: 2.4 });
WORLD_MARKS.push({ id: 'door_garage', int: true, x: INT.garage.x, z: INT.garage.z - 6.3, r: 2.6, label: '🚪 ВЫЙТИ НА УЛИЦУ', fn: 'leaveShop' });
for (let i = 0; i < GARAGE_BAYS; i++) {
  const p = bayPos(i);
  WORLD_MARKS.push({ id: 'gbay_' + i, int: true, x: INT.garage.x + p.x, z: INT.garage.z + (i < 10 ? 1.9 : -1.6), r: 1.7, label: '🅿 Место ' + (i + 1), fn: 'garagePick', idx: i });
}
Object.assign(NPC, {
  club: { ico: '🧑‍🎤', name: 'Гена', role: 'Председатель «Гараж-клуба»',
    greet: ['Добро пожаловать в «Гараж-клуб»! Тут уважают тех, кто любит машины.', 'О, новый человек! Присаживайся, у нас лучшие автошоу в городе.', 'Здорово! Клуб — это коллекция, связи и приличные деньги.'],
    tips: ['Чем больше тюнинга на машине — тем выше награда на автошоу.', 'Одну и ту же машину можно выставлять раз в четыре минуты. Чередуй.', 'Ранг Мастер даёт +6 мест в гараже: хватит на всю коллекцию.'] },
  tune: { ico: '🧑‍🔧', name: 'Макс', role: 'Мастер тюнинг-центра',
    greet: ['О, клиент! Спойлеры, диски, неон — сделаем твою тачку звездой улицы.', 'Заходи! Пока ты не видел наш неон — ты не видел ночного города.', 'Покраска — бесплатно, а вот детали — по цене. Зато как смотрятся!'],
    tips: ['Неон особенно хорош ночью. Выбирай цвет под кузов.', 'Тонировка и контрастные диски делают даже простой хэтч заметным.', 'Движок, шины и нитро — тоже здесь: жми «Тюнинг машины».'] },
  estate: { ico: '👩‍💼', name: 'Эльвира', role: 'Агентство недвижимости',
    greet: ['Добрый день! Квартиры, дома, виллы — всё с парковкой для вашей коллекции.', 'Здравствуйте! Недвижимость — лучший способ вложить деньги: она ещё и платит аренду.', 'Чем больше машин — тем больше нужно мест. Подберём вам гараж?'],
    tips: ['Гараж дома вмещает 6 машин. Каждая недвижимость добавляет места.', 'Аренда копится сама, даже пока вас нет. Заходите за деньгами к объекту.', 'Пентхаус «Небо» — самый доходный объект города.'] }
});
for (const p of PROPS) NPC['p_' + p.id] = { ico: p.ico, name: p.nm, role: 'Недвижимость', greet: [''], tips: [] };

/* --- гараж и недвижимость --- */
const propOwn = id => !!(S.props && S.props[id] && S.props[id].own);
function garageCap() { let n = GARAGE_BASE + clubRank() * 2; for (const p of PROPS) if (propOwn(p.id)) n += p.slots; return Math.min(n, GARAGE_BAYS); }
const carCount = () => Object.keys(S.cars).length;
const propCap = p => Math.round(p.rate * 15);
function propAdd(id, sec) { const r = S.props[id], p = PROP_BY[id]; if (r && r.own && p && hasOffice()) { if (r.acc > 0) { S.safe = (S.safe || 0) + r.acc; r.acc = 0; } safeIn(p.rate / 60 * sec); return; } if (r && r.own && p) r.acc = Math.min(propCap(p), (r.acc || 0) + p.rate / 60 * sec); }
(function propOffline() {
  const offs = Math.min(1200, Math.max(0, (Date.now() - (S.bizT || Date.now())) / 1000));
  for (const p of PROPS) if (propOwn(p.id)) propAdd(p.id, offs);
})();
function propGreet(id) {
  const p = PROP_BY[id], r = S.props[id];
  if (propOwn(id)) { const a = Math.floor(r.acc || 0); return 'Ваш объект «' + p.nm + '». ' + (a >= 1 ? 'Аренда накопила ' + fmtMoney(a) + '.' : 'Аренда пока копится.') + ' Гараж даёт +' + p.slots + ' мест.'; }
  return 'Продаётся: «' + p.nm + '». Цена ' + fmtMoney(p.price) + ', +' + p.slots + ' мест в гараже и ≈ ' + fmtMoney(p.rate) + ' аренды в минуту.';
}
function buyProp(id) {
  const p = PROP_BY[id]; if (propOwn(id)) return false;
  if (S.money < p.price) { SFX.err(); toast('Не хватает денег'); return false; }
  S.money -= p.price; S.props[id] = { own: true, acc: 0 }; persist(); SFX.buy(); refreshMoney(true);
  toast(p.ico + ' Куплено: ' + p.nm + ' (+' + p.slots + ' мест в гараже)');
  return true;
}
function propOptions(id) {
  const p = PROP_BY[id], r = S.props[id], o = [], m = markOf('prop_' + id);
  if (!propOwn(id)) {
    o.push({ t: '💰 Купить — ' + fmtMoney(p.price), dis: S.money < p.price, fn: () => { if (buyProp(id)) say('Поздравляю! Теперь это ваш объект. Гараж открыт — заходите, когда захотите.'); } });
    o.push({ t: '🧭 Построить маршрут', fn: () => { closeScreens(); navSet(m.x, m.z); } });
  } else {
    const a = Math.floor(r.acc || 0);
    o.push({ t: a >= 1 ? '💵 Забрать аренду — ' + fmtMoney(a) : (hasOffice() ? '💼 Аренда идёт в сейф кабинета пентхауса' : '💵 Аренды пока нет'), dis: a < 1, fn: () => { const n = Math.floor(r.acc || 0); r.acc = 0; addMoney(n); persist(); SFX.cash(); say('Аренда: ' + fmtMoney(n) + '. Приятно иметь дело!'); } });
    o.push({ t: id === 'tower' ? '🌆 Подняться в пентхаус (11 этажей)' : '🏠 Войти в ' + (id === 'flat' ? 'квартиру' : id === 'house' ? 'дом' : 'виллу'), fn: () => { closeScreens(); HOME_FN.enterApt({ x: m.x, z: m.z, kind: id }); } });
    o.push({ t: '🚗 Войти в гараж', fn: () => { closeScreens(); HOME_FN.enterGarage({ x: m.x, z: m.z, kind: id }); } });
  }
  o.push({ t: '📋 Подробнее', fn: () => say(propGreet(id)) });
  o.push(byeOpt());
  return o;
}
function estateOptions() {
  const o = [];
  for (const p of PROPS) {
    if (propOwn(p.id)) o.push({ t: '✔ ' + p.ico + ' ' + p.nm + ' — ваша', dis: true, fn: () => { } });
    else o.push({ t: p.ico + ' ' + p.nm + ' — ' + fmtMoney(p.price) + ' (+' + p.slots + ' мест, ' + fmtMoney(p.rate) + '/мин)', dis: S.money < p.price, fn: () => { if (buyProp(p.id)) say('Сделка оформлена! Объект отмечен на карте — заходите в гараж.'); else say('Деньги — не проблема. Вернитесь, когда накопите.'); } });
  }
  const free = PROPS.filter(p => !propOwn(p.id));
  if (free.length) {
    let best = free[0], bd = 1e9; for (const p of free) { const d = Math.hypot(bc(p.b[0]) - P.x, bc(p.b[1]) - P.z); if (d < bd) { bd = d; best = p; } }
    o.push({ t: '🧭 Показать ближайший объект: ' + best.nm, fn: () => { closeScreens(); navSet(bc(best.b[0]), bc(best.b[1]) - 12); } });
  }
  o.push({ t: '📋 Мой гараж: ' + carCount() + ' из ' + garageCap() + ' мест', fn: () => say('Вместимость гаража: ' + garageCap() + ' из ' + GARAGE_BAYS + '. Сейчас у вас машин: ' + carCount() + '.') });
  o.push({ t: '❓ Совет', fn: () => say(pick(NPC.estate.tips)) });
  o.push(byeOpt());
  return o;
}
function tuneOptions() {
  const o = [];
  o.push({ t: '🛠 Тюнинг машины: детали, диски, неон', fn: () => { UI.tuneMode = true; UI.garSel = null; openScreen('garage'); } });
  o.push({ t: '⚙️ Двигатель, шины и нитро', fn: () => { UI.tuneMode = true; UI.garSel = null; openScreen('garage'); } });
  o.push({ t: '💡 Расскажи про неон', fn: () => say('Подсветка днища: светится на дороге, ночью — просто бомба. Выбери цвет в разделе «Неон».') });
  o.push({ t: '❓ Совет мастера', fn: () => say(pick(NPC.tune.tips)) });
  o.push(byeOpt());
  return o;
}
HOME_FN.talkEstate = function () { openTalk('estate'); };
HOME_FN.propTalk = function (m) { openTalk('p_' + m.kind); };
HOME_FN.enterGarage = function (m) {
  if (G.inHome) return;
  fadeThen(() => {
    if (P.car) exitCar(true);
    const o = INT.garage;
    setHomeState(true, 'garage', { x: m.x, z: m.z - 2, h: Math.PI });
    P.x = o.x; P.z = o.z - 4.6; P.y = 0; P.h = 0; P.speed = 0; P.vis = true;
    CAM.yaw = 0; CAM.pitch = 0.82; CAM.off = 0;
    refreshGarageMarks();
    toast('🅿 Гараж: ' + carCount() + ' из ' + garageCap() + ' мест. Подойдите к машине и нажмите E');
  });
};
function ownedIds() { return CARS.filter(c => S.cars[c.id]).map(c => c.id); }
function refreshGarageMarks() {
  const ids = ownedIds(), cap = garageCap();
  for (let i = 0; i < GARAGE_BAYS; i++) {
    const m = markOf('gbay_' + i); if (!m) continue;
    if (ids[i]) m.label = '🚗 ' + (S.sel === ids[i] ? '✔ ' : '') + CAR_BY_ID[ids[i]].name + ': ' + (S.sel === ids[i] ? 'выбрана' : 'взять');
    else if (i < cap) m.label = '🅿 Свободное место ' + (i + 1);
    else m.label = '🔒 Место ' + (i + 1) + ' закрыто — нужна недвижимость';
  }
}
HOME_FN.garagePick = function (m) {
  const id = ownedIds()[m.idx];
  if (!id) { toast(m.idx < garageCap() ? '🅿 Свободное место — купите машину в автосалоне' : '🔒 Нужна недвижимость с гаражом — загляните к риелтору'); SFX.err(); return; }
  if (S.sel !== id) {
    S.sel = id; if (OWN) removeCar(OWN);
    persist(); SFX.buy(); refreshGarageMarks();
    toast('🚗 «' + CAR_BY_ID[id].name + '» будет подана, когда выйдете из гаража');
  } else toast('Эта машина уже выбрана');
};
const GFAKE = {};
function drawGarageCars() {
  const ids = ownedIds(), o = INT.garage;
  for (let i = 0; i < ids.length && i < GARAGE_BAYS; i++) {
    const id = ids[i], rec = S.cars[id], def = CAR_BY_ID[id], p = bayPos(i), mk = id + rec.color + modKey(rec.mods);
    let f = GFAKE[i];
    if (!f || f.mk !== mk) f = GFAKE[i] = { mk, def, col: rec.color, mods: rec.mods, meshes: carMeshes(def, rec.color, rec.mods), x: o.x + p.x, y: 0.02, z: o.z + p.z, h: p.h, pitch: 0, lean: 0, roll: 0, steer: 0, brake: false, W: def.shape.W, L: def.shape.L, nitroOn: false, kind: 'show' };
    drawCar(f, 0);
  }
  setPass('add');
  for (let i = 0; i < ids.length && i < GARAGE_BAYS; i++) {
    const f = GFAKE[i]; if (!f) continue;
    if (f.mods && f.mods.neon) { const nc = hexRGB(f.mods.neon); mTRS(DM, f.x, 0.06, f.z, f.h, 0, 0, f.W * 1.4, 1, f.L * 0.8); drawMesh(M_GLOW, DM, nc[0], nc[1], nc[2], 0.75, 2, false); }
  }
  setPass('alpha');
  const si = ids.indexOf(S.sel);
  if (si >= 0) { const p = bayPos(si); mTRS(DM, o.x + p.x, 0.05, o.z + p.z, 0, 0, 0, 2.6, 1, 3.4); drawMesh(M_RING, DM, 1, 0.85, 0.2, 0.7, 1, false); }
  setPass('opaque');
}
let TUNEFAKE = null;
function drawTuneCar() {
  const o = INT.tune, def = CAR_BY_ID.rally, mods = { sp: 2, st: '#ffd60a', rim: '#ff2bd6', neon: '#00e5ff', tint: 1 };
  if (!TUNEFAKE) TUNEFAKE = { def, col: '#0077b6', mods, meshes: carMeshes(def, '#0077b6', mods), x: o.x + 6.4, y: 0.62, z: o.z - 2.6, h: 0, pitch: 0, lean: 0, roll: 0, steer: 0, brake: false, W: def.shape.W, L: def.shape.L, nitroOn: false, kind: 'show' };
  TUNEFAKE.h = G.time * 0.5; drawCar(TUNEFAKE, 0);
  setPass('add'); const nc = hexRGB(mods.neon); mTRS(DM, TUNEFAKE.x, 0.66, TUNEFAKE.z, TUNEFAKE.h, 0, 0, 2.7, 1, 3.7); drawMesh(M_GLOW, DM, nc[0], nc[1], nc[2], 0.8, 2, false); setPass('opaque');
}

/* --- тюнинг: детали внешнего вида --- */
const MOD_BASE = { sp: [0, 1200, 3200], st: 900, rim: 700, tint: 600, neon: 2400 };
const NEONS = ['#00e5ff', '#ff2bd6', '#39ff14', '#ffd60a', '#ff3b30', '#8338ec', '#ffffff'];
const modCost = (def, base) => Math.max(50, Math.round(base * (1 + def.price / 40000) / 50) * 50);
function modKey(m) { return m ? [m.sp === undefined ? '' : m.sp, m.st || '', m.rim || '', m.tint ? 1 : 0, m.neon || ''].join('|') : ''; }
function meshKey(m) { return m ? [m.sp === undefined ? '' : m.sp, m.st || '', m.rim || '', m.tint ? 1 : 0].join('|') : ''; }
function applyMods(c) { c.meshes = carMeshes(c.def, c.col, c.mods); }
function modsHTML(def, rec) {
  const m = rec.mods || {}, plain = def.bike || def.heli, pr = b => ' · ' + fmtMoney(modCost(def, b));
  const sw = (key, list, cur, label) => '<p class="muted">' + label + pr(MOD_BASE[key]) + '</p><div class="swatches"><button class="sw' + (!cur ? ' on' : '') + '" style="background:#1b1f2e;color:#fff" data-mod="' + key + ':" aria-label="нет">✕</button>' +
    list.map(c => '<button class="sw' + (c === cur ? ' on' : '') + '" style="background:' + c + '" data-mod="' + key + ':' + c + '" aria-label="цвет"></button>').join('') + '</div>';
  let h = '<h4>Внешний тюнинг</h4>';
  if (!plain) {
    const cur = m.sp === undefined ? (def.spoiler ? 1 : 0) : m.sp;
    h += '<p class="muted">Спойлер</p><div class="chips">' + ['Без спойлера', 'Спойлер' + pr(MOD_BASE.sp[1]), 'GT-крыло' + pr(MOD_BASE.sp[2])].map((n, i) => '<button class="chip' + (cur === i ? ' on' : '') + '" data-mod="sp:' + i + '">' + n + '</button>').join('') + '</div>';
    h += sw('st', COLORS, m.st || '', 'Полоса по центру');
    h += sw('rim', COLORS, m.rim || '', 'Диски');
    h += '<p class="muted">Тонировка стёкол</p><div class="chips"><button class="chip' + (!m.tint ? ' on' : '') + '" data-mod="tint:0">Обычные</button><button class="chip' + (m.tint ? ' on' : '') + '" data-mod="tint:1">Тонировка' + pr(MOD_BASE.tint) + '</button></div>';
  }
  h += sw('neon', NEONS, m.neon || '', 'Неон-подсветка днища');
  return h;
}
function applyMod(spec) {
  const i = spec.indexOf(':'), key = spec.slice(0, i), raw = spec.slice(i + 1);
  const id = UI.garSel, def = CAR_BY_ID[id], rec = S.cars[id]; if (!rec) return;
  const m = rec.mods = rec.mods || {};
  let val = raw, cur, base;
  if (key === 'sp') { val = +raw; cur = m.sp === undefined ? (def.spoiler ? 1 : 0) : m.sp; base = val > cur ? MOD_BASE.sp[val] : 0; }
  else if (key === 'tint') { val = +raw; cur = m.tint ? 1 : 0; base = val ? MOD_BASE.tint : 0; }
  else { cur = m[key] || ''; base = val ? MOD_BASE[key] : 0; }
  if (val === cur) return;
  const cost = base ? modCost(def, base) : 0;
  if (cost && S.money < cost) { SFX.err(); toast('Не хватает денег'); return; }
  if (cost) { S.money -= cost; SFX.buy(); refreshMoney(true); } else SFX.click();
  if (key === 'sp') m.sp = val; else if (key === 'tint') m.tint = val ? 1 : 0; else if (val) m[key] = val; else delete m[key];
  S.flags.mods = (S.flags.mods || 0) + (cost ? 1 : 0);
  persist();
  if (OWN && S.sel === id) { OWN.mods = m; applyMods(OWN); }
  toast(cost ? '🛠 Установлено за ' + fmtMoney(cost) : '🛠 Деталь снята');
  renderGarage();
}

/* --- ограбления --- */
const ROB = { st: null, t: 0, dotT: 0 };
function robBarEl() {
  let e = document.getElementById('robBar');
  if (!e) {
    e = document.createElement('div'); e.id = 'robBar';
    e.style.cssText = 'position:fixed;left:50%;top:22%;transform:translateX(-50%);width:min(320px,70vw);padding:8px 12px;border-radius:12px;background:rgba(10,12,20,.85);color:#fff;font:700 14px system-ui,sans-serif;text-align:center;z-index:30;display:none;pointer-events:none';
    e.innerHTML = '<div id="robTx"></div><div style="height:8px;margin-top:6px;background:#333;border-radius:6px;overflow:hidden"><i id="robFl" style="display:block;height:100%;width:0;background:linear-gradient(90deg,#ffb703,#ff4d4d)"></i></div>';
    document.body.appendChild(e);
  }
  return e;
}
function robStart(s) {
  if (!s || ROB.st) return;
  const T = STORE_TYPES[s.t];
  if (M) { toast('Сейчас не до грабежей'); SFX.err(); return; }
  const left = ((S.rob[s.id] || 0) - Date.now()) / 1000;
  if (left > 0) { toast('🧾 Касса пуста. Загляните через ' + fmtTime(left)); SFX.err(); return; }
  if (P.car) { toast('Выйдите из машины'); SFX.err(); return; }
  if (!hasAnyGun()) { toast('🔫 Без оружия не получится — купите ствол в оружейном магазине'); SFX.err(); return; }
  ROB.st = s; ROB.t = 0;
  toast(T.ico + ' Ограбление! Стойте у кассы ' + T.dur + ' с. Сработала сигнализация!');
  crimeWanted(T.stars, 'ограбление'); SFX.err();
  for (const p of peds) if (!p.dead && !p.fixed && Math.hypot(p.x - P.x, p.z - P.z) < 40) p.panic = 7;
}
function robEnd(ok) {
  const s = ROB.st; if (!s) return;
  const T = STORE_TYPES[s.t]; ROB.st = null; robBarEl().style.display = 'none';
  if (ok) {
    const pay = Math.round((T.lo + Math.random() * (T.hi - T.lo)) / 10) * 10;
    addMoney(pay); SFX.cash(); S.rob[s.id] = Date.now() + 6 * 60 * 1000;
    S.stats.robs = (S.stats.robs || 0) + 1; if (s.t === 'bank') S.flags.bank = 1;
    toast(T.ico + ' Касса вскрыта: ' + fmtMoney(pay) + '. Уходите от полиции!'); persist();
  } else { S.rob[s.id] = Date.now() + 60 * 1000; toast('❌ Ограбление сорвано'); SFX.err(); }
}
HOME_FN.robStore = function (m) { robStart(STORE_BY[m.kind]); };
function v16Tick(dt) {
  if (ROB.st) {
    const s = ROB.st, T = STORE_TYPES[s.t], m = markOf('rob_' + s.id), el = robBarEl();
    if (P.hp <= 0 || G.inHome || P.car || Math.hypot(P.x - m.x, P.z - m.z) > 14) robEnd(false);
    else {
      ROB.t += dt; el.style.display = 'block';
      document.getElementById('robTx').textContent = T.ico + ' Ограбление: ' + s.nm + ' — ' + Math.max(0, Math.ceil(T.dur - ROB.t)) + ' с';
      document.getElementById('robFl').style.width = Math.min(100, ROB.t / T.dur * 100) + '%';
      if (ROB.t >= T.dur) robEnd(true);
    }
  }
  if ((ROB.dotT -= dt) <= 0) {
    ROB.dotT = 1;
    const now = Date.now();
    for (const s of STORES) { const m = markOf('rob_' + s.id); if (m) m.dot = (S.rob[s.id] || 0) > now ? '#666a73' : STORE_TYPES[s.t].dot; }
  }
  let any = false;
  for (const p of PROPS) if (propOwn(p.id)) { propAdd(p.id, dt); any = true; }
  if (any && (BZ.t2 = (BZ.t2 || 0) + dt) > 30) { BZ.t2 = 0; persist(); }
}

