/* ===================== 21. ГЛАВНЫЙ ЦИКЛ ===================== */
let lastT = performance.now(), fpsAcc = 0, fpsN = 0, errShown = false, adaptT = 0, adaptN = 0, adaptSkip = 1;
/* --- Погода --- */
const WX = { rain: 0, tgt: 0, t: 100 + Math.random() * 60, drops: [], storm: 0, fog: 0, fogTgt: 0, fogT: 90 + Math.random() * 90, flash: 0, flashT: 4, re: 0 };
const rainCv = document.createElement('canvas'); rainCv.id = 'rainCv'; document.body.appendChild(rainCv);
const rainCtx = rainCv.getContext('2d');
const armBoxEl = document.createElement('div'); armBoxEl.id = 'armBox'; document.body.appendChild(armBoxEl);
function weatherEnv() {
  if (WINTER.on) winterEnv();
  weatherFog();
  const r = WX.rain; if (r < 0.01) { weatherStorm(0); return; }
  const g = ENV.night < 0.5 ? [0.42, 0.45, 0.5] : [0.07, 0.08, 0.11];
  ENV.top = mix3(ENV.top, g, r * 0.75); ENV.bot = mix3(ENV.bot, g, r * 0.75);
  ENV.sky = mix3(ENV.sky, g, r * 0.4);
  ENV.sunCol = ENV.sunCol.map(v => v * (1 - 0.45 * r));
  ENV.fogNear = lerp(ENV.fogNear, 30, r); ENV.fogFar = lerp(ENV.fogFar, 230, r);
  weatherStorm(r);
}
function drawRain(dt) {
  if (WINTER.on) { drawSnowfall(dt); return; }
  const on = WX.rain > 0.02 && G.mode === 'play' && !G.inHome;
  if (!on) { if (rainCv.style.display !== 'none') { rainCv.style.display = 'none'; } return; }
  rainCv.style.display = 'block';
  const w = window.innerWidth, h = window.innerHeight;
  if (rainCv.width !== w) rainCv.width = w; if (rainCv.height !== h) rainCv.height = h;
  const n = Math.round(220 * WX.rain * (WX.storm ? 1.8 : 1));
  while (WX.drops.length < n) WX.drops.push({ x: Math.random() * w, y: Math.random() * h, v: 900 + Math.random() * 500, l: 14 + Math.random() * 14 });
  WX.drops.length = n;
  rainCtx.clearRect(0, 0, w, h);
  rainCtx.strokeStyle = 'rgba(200,215,235,0.4)'; rainCtx.lineWidth = 1.2; rainCtx.beginPath();
  for (const d of WX.drops) {
    d.y += d.v * dt; d.x -= d.v * dt * 0.18;
    if (d.y > h) { d.y = -20; d.x = Math.random() * (w + 200); }
    rainCtx.moveTo(d.x, d.y); rainCtx.lineTo(d.x + d.l * 0.18, d.y - d.l);
  }
  rainCtx.stroke();
}
const ACH = [
  { id: 'a1', ico: '🎯', t: 'Первое дело', d: 'Выполните любое задание', r: 200, f: () => doneCount() >= 1 },
  { id: 'a2', ico: '📋', t: 'Работяга', d: 'Выполните 8 заданий', r: 1000, f: () => doneCount() >= 8 },
  { id: 'a3', ico: '🏆', t: 'Профи', d: 'Выполните 20 заданий', r: 5000, f: () => doneCount() >= 20 },
  { id: 'a4', ico: '💰', t: 'Состоятельный', d: 'Накопите $50 000', r: 2000, f: () => S.money >= 50000 },
  { id: 'a5', ico: '🏢', t: 'Бизнесмен', d: 'Купите бизнес', r: 1000, f: () => Object.keys(S.biz).some(k => S.biz[k] && S.biz[k].own) },
  { id: 'a6', ico: '🏙', t: 'Магнат', d: 'Купите все три бизнеса', r: 8000, f: () => BIZ.every(b => S.biz[b.id] && S.biz[b.id].own) },
  { id: 'a7', ico: '🚘', t: 'Коллекционер', d: 'Соберите 6 машин', r: 3000, f: () => Object.keys(S.cars).length >= 6 },
  { id: 'a8', ico: '🏍', t: 'Байкер', d: 'Купите мотоцикл', r: 1000, f: () => ['scooter', 'moto', 'superbike'].some(i => S.cars[i]) },
  { id: 'a9', ico: '🚁', t: 'Лётчик', d: 'Купите вертолёт', r: 5000, f: () => !!S.cars.heli },
  { id: 'a10', ico: '🧭', t: 'Штурман', d: 'Проложите маршрут на карте', r: 300, f: () => !!S.flags.nav },
  { id: 'a11', ico: '🛡', t: 'Под защитой', d: 'Купите бронежилет', r: 300, f: () => !!S.flags.armor },
  { id: 'a12', ico: '🏏', t: 'Рукопашный', d: 'Купите биту или нож', r: 300, f: () => !!(S.guns.own.bat || S.guns.own.knife) },
  { id: 'a13', ico: '📞', t: 'Человек Крота', d: 'Пройдите 3 главы сюжета', r: 2000, f: () => S.story.ch >= 3 },
  { id: 'a14', ico: '👑', t: 'Король города', d: 'Пройдите весь сюжет', r: 15000, f: () => S.story.ch >= STORY.length },
  { id: 'a15', ico: '🏃', t: 'Марафонец', d: 'Пройдите и проедьте 20 км', r: 2500, f: () => S.stats.dist >= 20000 },
  { id: 'a16', ico: '🌀', t: 'Дрифтер', d: 'Наберите 10 000 очков дрифта', r: 2500, f: () => S.stats.drift >= 10000 },
  { id: 'a17', ico: '🌧', t: 'Дождь не помеха', d: 'Проедьте под дождём на скорости', r: 300, f: () => !!S.flags.rainDrive },
  { id: 'a18', ico: '💬', t: 'Душа компании', d: 'Поговорите с 15 прохожими', r: 500, f: () => (S.flags.talks || 0) >= 15 },
  { id: 'a19', ico: '🚕', t: 'Таксист', d: 'Выполните 5 заказов такси', r: 2000, f: () => (S.flags.taxi || 0) >= 5 },
  { id: 'a20', ico: '🎒', t: 'Страж порядка', d: 'Поймайте вора', r: 1000, f: () => (S.flags.thief || 0) >= 1 },
  { id: 'a21', ico: '🌭', t: 'Гурман', d: 'Поешьте в кафе 5 раз', r: 300, f: () => (S.flags.food || 0) >= 5 },
  { id: 'a22', ico: '👛', t: 'Везунчик', d: 'Найдите 3 потерянных кошелька', r: 600, f: () => (S.flags.wallet || 0) >= 3 }
];
ACH.push(
  { id: 'a23', ico: '🔫', t: 'Грабитель', d: 'Ограбьте 3 магазина', r: 1500, f: () => (S.stats.robs || 0) >= 3 },
  { id: 'a24', ico: '🏦', t: 'Налёт на банк', d: 'Ограбьте банк', r: 4000, f: () => !!S.flags.bank },
  { id: 'a25', ico: '🏠', t: 'Домовладелец', d: 'Купите недвижимость', r: 2000, f: () => Object.keys(S.props || {}).some(k => S.props[k] && S.props[k].own) },
  { id: 'a26', ico: '🅿', t: 'Большой гараж', d: 'Откройте все места в гараже', r: 10000, f: () => garageCap() >= GARAGE_BAYS },
  { id: 'a27', ico: '🛠', t: 'Тюнер', d: 'Установите 3 детали тюнинга', r: 1200, f: () => (S.flags.mods || 0) >= 3 }
);
ACH.push(
  { id: 'a28', ico: '⛈', t: 'Гроза не страшна', d: 'Проедьте на скорости во время грозы', r: 1500, f: () => !!S.flags.storm },
  { id: 'a29', ico: '📻', t: 'Меломан', d: 'Переключите радио 5 раз', r: 500, f: () => (S.flags.radioN || 0) >= 5 }
);
ACH.push({ id: 'a30', ico: '🚁', t: 'Король крыш', d: 'Посадите вертолёт на 3 разные крыши', r: 2000, f: () => Object.keys(S.flags.roofs || {}).length >= 3 });
ACH.push(
  { id: 'a31', ico: '🏴', t: 'Хозяин района', d: 'Захватите район у банды', r: 1500, f: () => ownedCount() >= 1 },
  { id: 'a32', ico: '👑', t: 'Король города', d: 'Захватите все 12 районов банд', r: 10000, f: () => ownedCount() >= 12 }
);
ACH.push(
  { id: 'a33', ico: '📖', t: 'Хозяин города', d: 'Пройдите эпилог сюжета', r: 25000, f: () => epiIdx() >= STORY2.length },
  { id: 'a34', ico: '⤴', t: 'Прыгун', d: 'Прыгните 50 раз', r: 800, f: () => (S.stats.jumps || 0) >= 50 },
  { id: 'a35', ico: '🏁', t: 'Свой в клубе', d: 'Достигните ранга «Мастер» в Гараж-клубе', r: 5000, f: () => clubRank() >= 3 }
);
ACH.push({ id: 'a36', ico: '🌆', t: 'Небожитель', d: 'Побывайте на всех 11 этажах пентхауса', r: 3000, f: () => Object.keys(S.flags.twf || {}).length >= 11 });
function doneCount() { return MISSIONS.filter(m => S.missions[m.id] && S.missions[m.id].done).length; }
function renderAch() {
  const n = ACH.filter(a => S.ach[a.id]).length;
  $('achCnt').textContent = n + ' / ' + ACH.length;
  $('achList').innerHTML = ACH.map(a => '<div class="card"><div class="c-body"><b>' + a.ico + ' ' + a.t + '</b><small>' + a.d + '</small></div>' +
    (S.ach[a.id] ? '<span class="tag">✔ +' + fmtMoney(a.r) + '</span>' : '<span class="muted">+' + fmtMoney(a.r) + '</span>') + '</div>').join('');
}
const XT = { ach: 0 };
function extraTick(dt) {
  WX.t -= dt;
  if (WX.t <= 0) {
    if (WX.tgt) { const wasS = WX.storm; WX.tgt = 0; WX.storm = 0; WX.t = 150 + Math.random() * 230; toast('🌤 ' + (WINTER.on ? 'Снегопад' : wasS ? 'Гроза' : 'Дождь') + ' закончился'); }
    else { WX.tgt = 1; WX.storm = !WINTER.on && Math.random() < 0.4 ? 1 : 0; WX.flashT = 3; WX.t = 70 + Math.random() * 90; if (WINTER.on) toast('❄ Пошёл сильный снег — дороги скользкие'); else toast(WX.storm ? '⛈ Гроза! Молнии и ливень, дороги скользкие' : '🌧 Начался дождь — дороги скользкие'); }
  }
  WX.rain += clamp(WX.tgt - WX.rain, -dt * 0.1, dt * 0.1);
  drawRain(dt);
  if (WX.rain > 0.5 && P.car && Math.abs(P.car.vf) > 8 && !G.inHome) S.flags.rainDrive = true;
  const showArm = S.armor > 0 && G.mode === 'play' && !G.inHome;
  armBoxEl.style.display = showArm ? 'block' : 'none';
  if (showArm) setText(armBoxEl, '🛡 ' + Math.ceil(S.armor));
  if ((XT.ach += dt) > 2) {
    XT.ach = 0;
    for (const a of ACH) if (!S.ach[a.id] && a.f()) { S.ach[a.id] = true; addMoney(a.r); SFX.cash(); toast('🏅 Достижение: ' + a.t + ' (+' + fmtMoney(a.r) + ')'); persist(); }
  }
}
